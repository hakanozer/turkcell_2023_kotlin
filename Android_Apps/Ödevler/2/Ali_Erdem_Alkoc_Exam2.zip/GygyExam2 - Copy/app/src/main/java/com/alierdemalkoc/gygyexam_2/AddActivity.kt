package com.alierdemalkoc.gygyexam_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlin.collections.ArrayList

class AddActivity : AppCompatActivity() {

    lateinit var dataText1: EditText
    lateinit var dataText2: EditText
    lateinit var addButton1: Button
    lateinit var addButton2: Button
    lateinit var showResultsbutton: Button
    var arr1 = mutableListOf<String>()
    var arr2 = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        dataText1 = findViewById(R.id.dataText1)
        dataText2 = findViewById(R.id.dataText2)
        addButton1 = findViewById(R.id.addButton1)
        addButton2 = findViewById(R.id.addButton2)
        showResultsbutton = findViewById(R.id.showResultsButton)

        addButton1.setOnClickListener {
            val item = dataText1.text.toString()
            if (dataText1.text.isEmpty()){
                Toast.makeText(this,"Please Entry!",Toast.LENGTH_LONG).show()
            } else{
                arr1.add(item)
                dataText1.setText("")
                dataText1.requestFocus()
            }

        }
        addButton2.setOnClickListener {
            val item = dataText2.text.toString()
            if (dataText2.text.isEmpty()){
                Toast.makeText(this,"Please Entry!",Toast.LENGTH_LONG).show()
            } else {
                arr2.add(item)
                dataText2.setText("")
                dataText2.requestFocus()
            }
        }

        showResultsbutton.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            intent.putStringArrayListExtra("data1", ArrayList(arr1))
            intent.putStringArrayListExtra("data2", ArrayList(arr2))
            startActivity(intent)
        }
    }
}