package com.alierdemalkoc.gygyexam_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    lateinit var listView1: ListView
    lateinit var listView2: ListView
    var arr1 = mutableListOf<String>()
    var arr2 = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView1 = findViewById(R.id.listView1)
        listView2 = findViewById(R.id.listView2)
        arr1 = intent.getStringArrayListExtra("data1")?.toMutableList()!!
        arr2 = intent.getStringArrayListExtra("data2")?.toMutableList()!!

        val adapter1 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arr1)
        listView1.adapter = adapter1

        val adapter2 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arr2)
        listView2.adapter = adapter2

    }
}
