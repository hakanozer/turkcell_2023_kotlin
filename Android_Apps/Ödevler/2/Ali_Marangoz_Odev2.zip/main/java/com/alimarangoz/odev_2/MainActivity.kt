package com.alimarangoz.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    private lateinit var data1 : EditText
    private lateinit var data2 : EditText
    private lateinit var buttonData1 : Button
    private lateinit var buttonData2 : Button
    private lateinit var resultsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        data1 = findViewById(R.id.data1_edt_text)
        data2 = findViewById(R.id.data2_edt_text)
        buttonData1 = findViewById(R.id.btn_data1)
        buttonData2 = findViewById(R.id.btn_data2)
        resultsButton = findViewById(R.id.see_result_btn)

        var data1Arr = ArrayList<String>()
        var data2Arr = ArrayList<String>()

        buttonData1.setOnClickListener{
            var itemInData1 = data1.text.toString()
            data1Arr.add(itemInData1)
            data1.setText("")
        }

        buttonData2.setOnClickListener{
            var itemInData2 = data2.text.toString()
            data2Arr.add(itemInData2)
            data2.setText("")
        }

        resultsButton.setOnClickListener {
            var intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("data1_arr", data1Arr)
            intent.putExtra("data2_arr", data2Arr)
            startActivity(intent)
        }


    }
}