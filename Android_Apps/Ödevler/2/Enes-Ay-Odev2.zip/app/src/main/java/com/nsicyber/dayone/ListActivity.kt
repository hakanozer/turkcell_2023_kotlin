package com.nsicyber.dayone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class ListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        val data1List = intent.getStringArrayListExtra("data1List") as List<String>
        val data2List = intent.getStringArrayListExtra("data2List") as List<String>

        val data1ListView = findViewById<ListView>(R.id.data1ListView)
        val data2ListView = findViewById<ListView>(R.id.data2ListView)

        val data1Adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data1List)
        val data2Adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data2List)

        data1ListView.adapter = data1Adapter
        data2ListView.adapter = data2Adapter
        data1ListView.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position).toString()
            Toast.makeText(this, selectedItem, Toast.LENGTH_SHORT).show()
        }
        data2ListView.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position).toString()
            Toast.makeText(this, selectedItem, Toast.LENGTH_SHORT).show()
        }

    }
}
