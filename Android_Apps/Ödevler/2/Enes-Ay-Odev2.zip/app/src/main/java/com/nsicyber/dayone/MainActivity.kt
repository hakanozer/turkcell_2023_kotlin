package com.nsicyber.dayone
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val data1List = ArrayList<String>()
    private val data2List = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val data1EditText = findViewById<EditText>(R.id.data1EditText)
        val data2EditText = findViewById<EditText>(R.id.data2EditText)

        val saveData1Button = findViewById<Button>(R.id.saveData1Button)
        saveData1Button.setOnClickListener {
            val data1 = data1EditText.text.toString()
            data1List.add(data1)
            data1EditText.text.clear()
            Toast.makeText(this,data1+" eklendi",Toast.LENGTH_SHORT).show()
        }

        val saveData2Button = findViewById<Button>(R.id.saveData2Button)
        saveData2Button.setOnClickListener {
            val data2 = data2EditText.text.toString()
            data2List.add(data2)
            data2EditText.text.clear()
            Toast.makeText(this,data2+" eklendi",Toast.LENGTH_SHORT).show()

        }

        val showResultButton = findViewById<Button>(R.id.showResultButton)
        showResultButton.setOnClickListener {
            val intent = Intent(this, ListActivity::class.java)
            intent.putExtra("data1List", data1List)
            intent.putExtra("data2List", data2List)
            startActivity(intent)
        }
    }

}
