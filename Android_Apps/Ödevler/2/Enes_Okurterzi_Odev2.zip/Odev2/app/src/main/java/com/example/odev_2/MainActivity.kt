package com.example.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    
    companion object {
        var dataListOne = mutableListOf<String>()
        var dataListTwo = mutableListOf<String>()
    }

    lateinit var txtDataOne: EditText
    lateinit var txtDataTwo: EditText
    lateinit var btnDataOneAdd: Button
    lateinit var btnDataTwoAdd: Button
    lateinit var btnShowLists: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtDataOne = findViewById(R.id.txtDataOne)
        txtDataTwo = findViewById(R.id.txtDataTwo)
        btnDataOneAdd = findViewById(R.id.btnDataOneAdd)
        btnDataTwoAdd = findViewById(R.id.btnDataTwoAdd)
        btnShowLists = findViewById(R.id.btnShowLists)
        
        btnDataOneAdd.setOnClickListener {
            listAdder(txtDataOne, dataListOne, 1)
        }
        
        btnDataTwoAdd.setOnClickListener {
            listAdder(txtDataTwo, dataListTwo, 2)
        }
        
        btnShowLists.setOnClickListener {
            val intent = Intent(this, TwoListView::class.java)
            startActivity(intent)
        }

    }

    fun listAdder(txtData: EditText, dataList: MutableList<String>, listNumber: Int) {
        val data = txtData.text.toString()

        if (data.isNotEmpty()) {
            dataList.add(data)
            txtData.setText("")
            txtData.requestFocus()
            Toast.makeText(this,"\"$data\" added to list $listNumber", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this,"Input is Empty", Toast.LENGTH_LONG).show()
        }

    }

}