package com.example.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import com.example.odev_2.MainActivity.Companion.dataListOne
import com.example.odev_2.MainActivity.Companion.dataListTwo

class TwoListView : AppCompatActivity() {

    lateinit var dataListOneView: ListView
    lateinit var dataListTwoView: ListView
    lateinit var txtListNumberOne: TextView
    lateinit var txtListNumberTwo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_two_list_view)

        dataListOneView = findViewById(R.id.dataListOneView)
        dataListTwoView = findViewById(R.id.dataListTwoView)
        txtListNumberOne = findViewById(R.id.txtListNumberOne)
        txtListNumberTwo = findViewById(R.id.txtListNumberTwo)

        val listOneAdapter = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            dataListOne
        )
        val listTwoAdapter = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            dataListTwo
        )

        dataListOneView.adapter = listOneAdapter
        dataListTwoView.adapter = listTwoAdapter

        listEmptyCheck(dataListOne, txtListNumberOne, 1)
        listEmptyCheck(dataListTwo, txtListNumberTwo, 2)

        dataListOneView.setOnItemLongClickListener { adapterView, view, i, l ->
            dataListOne.removeAt(i)
            listOneAdapter.notifyDataSetChanged()
            true
        }

        dataListTwoView.setOnItemLongClickListener { adapterView, view, i, l ->
            dataListTwo.removeAt(i)
            listTwoAdapter.notifyDataSetChanged()
            true
        }

        dataListOneView.setOnItemClickListener { adapterView, view, i, l ->
            val intent = Intent(this, Detail::class.java)
            intent.putExtra("data", dataListOne[i])
            startActivity(intent)
        }

        dataListTwoView.setOnItemClickListener { adapterView, view, i, l ->
            val intent = Intent(this, Detail::class.java)
            intent.putExtra("data", dataListTwo[i])
            startActivity(intent)
        }

    }

    fun listEmptyCheck(dataList: MutableList<String>, txtListNumber: TextView, listNumber: Int) {
        if (dataList.isEmpty()){
            txtListNumber.text = "List $listNumber Is Empty"
        } else {
            txtListNumber.text = "List $listNumber"
        }

    }

}