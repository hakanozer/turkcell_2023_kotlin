package com.works

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    lateinit var ekle1btn : Button
    lateinit var ekle2btn : Button
    lateinit var veri1edittxt : EditText
    lateinit var veri2edittxt : EditText
    lateinit var sonucbtn : Button

    var veri1list = mutableListOf<String>()
    var veri2list = mutableListOf<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ekle1btn = findViewById(R.id.ekle1btn)
        ekle2btn = findViewById(R.id.ekle2btn)
        veri1edittxt = findViewById(R.id.Veri1edittxt)
        veri2edittxt = findViewById(R.id.Veri2edittxt)
        sonucbtn = findViewById(R.id.sonucbtn)

        ekle1btn.setOnClickListener{

            veriEkle(veri1list, veri1edittxt)
        }
        ekle2btn.setOnClickListener{

            veriEkle( veri2list, veri2edittxt)
        }
        sonucbtn.setOnClickListener{
            val intent = Intent( this, Sonuc::class.java )
            intent.putStringArrayListExtra("veri1", ArrayList(veri1list))
            intent.putStringArrayListExtra("veri2", ArrayList(veri2list))
            startActivity( intent )
        }


    }

    fun veriEkle (  verilist : MutableList<String>, veriedittxt : EditText ) {
        val veri = veriedittxt.text.toString()
        if (  veri.isNotEmpty()  ) {
            verilist.add( veri )
            veriedittxt.text.clear()
        }
    }
}