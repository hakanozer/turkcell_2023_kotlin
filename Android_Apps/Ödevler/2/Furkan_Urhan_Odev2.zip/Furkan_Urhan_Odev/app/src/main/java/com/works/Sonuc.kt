package com.works

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.ListView

class Sonuc : AppCompatActivity() {

    lateinit var listview1 : ListView
    lateinit var listview2 : ListView
    lateinit var  veri1 : ArrayList<String>
    lateinit var  veri2 : ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sonuc)

        listview1 = findViewById(R.id.listview1)
        listview2 = findViewById(R.id.listview2)

        veri1 = intent.getStringArrayListExtra("veri1") ?: arrayListOf()
        veri2 = intent.getStringArrayListExtra("veri2") ?: arrayListOf()

        val adapter1 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, veri1)
        val adapter2 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, veri2)

        listview1.adapter = adapter1
        listview2.adapter = adapter2
    }
}