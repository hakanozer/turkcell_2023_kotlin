package com.gultendogan.turkcellodev2

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.custom_toast.*
import kotlinx.android.synthetic.main.custom_toast.view.*

class Detail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val layout = layoutInflater.inflate(R.layout.custom_toast,ll_wrapper)

        val dersler1 = intent.getSerializableExtra("ders1List") as ArrayList<*>
        val dersler2 = intent.getSerializableExtra("ders2List") as ArrayList<*>

        val adapter1 = ArrayAdapter(this,R.layout.item_list,dersler1)
        val adapter2 = ArrayAdapter(this, R.layout.item_list,dersler2)

        ders_1_list.adapter = adapter1
        ders_2_list.adapter = adapter2


        ders_1_list.setOnItemLongClickListener { adapterView, v, i, l ->

            layout.toastText.setText(dersler1[i].toString())

            Toast(this).apply {
                duration = Toast.LENGTH_LONG
                setGravity(Gravity.CENTER,0,0)
                view = layout
            }.show()

            if ( i == 5 ) {
                false
            }else {
                adapter1.notifyDataSetChanged()
                v.setBackgroundColor(Color.BLUE)
                true
            }
        }


        ders_2_list.setOnItemLongClickListener { adapterView, v, i, l ->

            layout.toastText.setText(dersler1[i].toString())

            Toast(this).apply {
                duration = Toast.LENGTH_LONG
                setGravity(Gravity.CENTER,0,0)
                view = layout
            }.show()

            if ( i == 5 ) {
                false
            }else {
                adapter2.notifyDataSetChanged()
                v.setBackgroundColor(Color.RED)
                true
            }
        }

    }
}