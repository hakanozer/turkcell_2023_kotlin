package com.gultendogan.turkcellodev2

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.core.view.get
import kotlinx.android.synthetic.main.activity_main.*
import java.util.UUID

class MainActivity : AppCompatActivity() {

    var dersler1 = arrayListOf<String>()
    var dersler2 = arrayListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ders_1_buton.setOnClickListener {
            dersler1.add(ders_1_text.text.toString())
            ders_1_text.setText("")
        }

        ders_2_buton.setOnClickListener {
            dersler2.add(ders_2_text.text.toString())
            ders_2_text.setText("")
        }

        sonuc_buton.setOnClickListener {
            val intent = Intent(this,Detail::class.java)
            intent.putExtra("ders1List",dersler1)
            intent.putExtra("ders2List",dersler2)
            startActivity(intent)
        }

    }


}