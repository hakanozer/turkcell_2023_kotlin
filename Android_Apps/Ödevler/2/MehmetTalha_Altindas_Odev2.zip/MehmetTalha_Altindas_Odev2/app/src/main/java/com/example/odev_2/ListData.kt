package com.example.odev_2


data class ListData(
    val list_data : MutableList<String> = arrayListOf()
)