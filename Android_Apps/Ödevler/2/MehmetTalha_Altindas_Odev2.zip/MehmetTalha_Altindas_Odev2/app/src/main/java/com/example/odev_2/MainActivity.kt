package com.example.odev_2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity



class MainActivity : AppCompatActivity() {
    companion object{
        var list1=ListData()
        var list2=ListData()

    }

    lateinit var button1:Button
    lateinit var button2:Button
    lateinit var button3:Button

    lateinit var editText1:EditText
    lateinit var editText2: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button1=findViewById(R.id.button1)
        button2=findViewById(R.id.button2)
        button3=findViewById(R.id.button3)

        editText1=findViewById(R.id.editText1)
        editText2=findViewById(R.id.editText2)


        button1.setOnClickListener {
            var item=editText1.text.toString()
            list1.list_data.add(item)
            Toast.makeText(this,"$item 1.ListView'a eklendi",Toast.LENGTH_SHORT).show()

        }
        button2.setOnClickListener {
            var item=editText2.text.toString()
            list2.list_data.add(item)
            Toast.makeText(this,"$item 2.ListView'a eklendi",Toast.LENGTH_LONG).show()

        }
        button3.setOnClickListener {
            if(list1.list_data.isEmpty()==false||list2.list_data.isEmpty()==false){
                var intent= Intent(this,list_view::class.java)
                startActivity(intent)
            }else{
                Toast.makeText(this,"Lütfen Listelerden birine bir eleman ekleyiniz!",Toast.LENGTH_LONG).show()
            }

        }
    }
}