package com.example.odev_2

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class list_view : AppCompatActivity() {
    lateinit var  listView1: ListView
    lateinit var  listView2: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        listView1=findViewById(R.id.listView1)
        listView2=findViewById(R.id.listView2)


        val arr1=MainActivity.list1.list_data
        val arr2=MainActivity.list2.list_data

        var adapter1 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arr1)
        var adapter2 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arr2)

        listView1.adapter=adapter1
        listView2.adapter=adapter2


    }
}