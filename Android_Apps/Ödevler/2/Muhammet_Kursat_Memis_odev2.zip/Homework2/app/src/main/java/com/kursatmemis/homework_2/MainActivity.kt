package com.kursatmemis.homework_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var getInput1EditText: EditText
    private lateinit var getInput2EditText: EditText
    private lateinit var addData1Button: Button
    private lateinit var addData2Button: Button
    private lateinit var showResultsButton: Button

    /**
     * Result Activity'de kullanılacak olan listview'lar için veri kümeleri static olarak
     * tanimlandi.
     * Bu veri kümeleri, dinamik olarak eleman eklenip-cikarilabilmesi adina mutableList olarak
     * belirlendi.
     */
    companion object {
        val datas1 = mutableListOf<String>()
        val datas2 = mutableListOf<String>()
    }

    private var data: String = "" // Kullanicinin girdiği data bu değişkene atanacak.

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setViews()

        /**
         * Eğer kullanıcı tarafından eklenmek istenen veri;
         * Boş ise -> Veri eklenmez ve kullanıcıdan bir veri girilmesi istenir.
         *
         * Daha önce eklenmiş ise -> Veri eklenmez ve kullanıcıya daha önce eklenildiği bilgisi
         * verilir.
         *
         * Diğer durumlarda -> Veri Eklenir.
         */
        addData1Button.setOnClickListener {
            data = getInput1EditText.text.toString()
            if (data.equals("")) {
                Toast.makeText(this, "Please enter an item.", Toast.LENGTH_SHORT)
                    .show()
            } else if (datas1.contains(data)) {
                Toast.makeText(this, "The item you want to add already exists", Toast.LENGTH_SHORT)
                    .show()
            } else {
                datas1.add(data)
            }
            getInput1EditText.text.clear()
        }

        /**
         * Eğer kullanıcı tarafından eklenmek istenen veri;
         * Boş ise -> Veri eklenmez ve kullanıcıdan bir veri girilmesi istenir.
         *
         * Daha önce eklenmiş ise -> Veri eklenmez ve kullanıcıya daha önce eklenildiği bilgisi
         * verilir.
         *
         * Diğer durumlarda -> Veri Eklenir.
         */
        addData2Button.setOnClickListener {
            data = getInput2EditText.text.toString()
            if (data.equals("")) {
                Toast.makeText(this, "Please enter an item.", Toast.LENGTH_SHORT)
                    .show()
            } else if (datas2.contains(data)) {
                Toast.makeText(this, "The item you want to add already exists", Toast.LENGTH_SHORT)
                    .show()
            } else {
                datas2.add(data)
            }
            getInput2EditText.text.clear()
        }

        /**
         * Bir intent objesi oluşturulur ve bu oje ile MainActivity'den ResultActivity'e geçiş
         * yapılması sağlanır.
         *
         * Kullanıcının tekrar MainActivity'e geri dönüp yeni veriler ekleme ihtiyacına karşılık
         * finish() methodu çağrılmamıştır.
         */
        showResultsButton.setOnClickListener {
            val intent = Intent(this, ResultActivity::class.java)
            startActivity(intent)
        }

    }

    /**
     * XML'deki view'ları, class attribute'leri set eder.
     *
     * onCreate methodunun içeriğini sade tutabilmek adına set etme işlemini
     * bu method içerisinde yaptım.
     */
    private fun setViews() {
        getInput1EditText = findViewById(R.id.getInput1EditText)
        getInput2EditText = findViewById(R.id.getInput2EditText)
        addData1Button = findViewById(R.id.addData1Button)
        addData2Button = findViewById(R.id.addData2Button)
        showResultsButton = findViewById(R.id.showResultsButton)
    }
}