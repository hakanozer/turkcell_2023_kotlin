package com.kursatmemis.homework_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class ResultActivity : AppCompatActivity() {

    private lateinit var datas1ListView: ListView
    private lateinit var datas2ListView: ListView
    private lateinit var selectedText: String // ListView'lar üzerinde tıklanan veriyi tutacak.

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        datas1ListView = findViewById(R.id.datas1ListView)
        datas2ListView = findViewById(R.id.datas2ListView)

        /**
         * ListView1 ve ListView2 view'larına eklenecek verileri yöntecek olan adapter'lar
         * set edilir.
         *
         * Android Studio'da default olarak tanımlı olan layout'lar yerine,
         * kendim 'my_textview_layout' adında bir textview layout oluşturdum ve onu kullandım.
         *
         */
        val adapterForDatas1 = ArrayAdapter<String>(
            this, R.layout.my_textview_layout,
            MainActivity.datas1
        )
        val adapterForDatas2 = ArrayAdapter<String>(
            this, R.layout.my_textview_layout,
            MainActivity.datas2
        )

        /**
         * Adapter'lar, ListView'lara bağlanır.
         */
        datas1ListView.adapter = adapterForDatas1
        datas2ListView.adapter = adapterForDatas2

        /**
         * ListView1'deki bir veriye tıklanıldığında, veriyi toast mesajıyla ekranda gösterir.
         */
        datas1ListView.setOnItemClickListener { adapterView, view, i, l ->
            selectedText = (view as TextView).text.toString()
            Toast.makeText(this, "Clicked on '$selectedText' item in the ListView-1.", Toast.LENGTH_SHORT).show()
        }


        /**
         * ListView2'deki bir veriye tıklanıldığında, veriyi toast mesajıyla ekranda gösterir.
         */
        datas2ListView.setOnItemClickListener { adapterView, view, i, l ->
            selectedText = (view as TextView).text.toString()
            Toast.makeText(this, "Clicked on '$selectedText' item in the ListView-2.", Toast.LENGTH_SHORT).show()
        }

        /**
         * ListView1'deki bir veriye uzun tıklanıldığında veriyi listview'dan siler ve toast mesajı
         * ile silinen veriyi ekranda gösterir.
         */
        datas1ListView.setOnItemLongClickListener { adapterView, view, i, l ->
            selectedText = (view as TextView).text.toString()
            MainActivity.datas1.remove(selectedText)
            adapterForDatas1.notifyDataSetChanged()
            Toast.makeText(this, "'$selectedText' removed from 1st ListView.", Toast.LENGTH_SHORT).show()
            true
        }

        /**
         * ListView'daki bir veriye uzun tıklanıldığında veriyi listview'dan siler ve toast mesajı
         * ile silinen veriyi ekranda gösterir.
         */
        datas2ListView.setOnItemLongClickListener { adapterView, view, i, l ->
            selectedText = (view as TextView).text.toString()
            MainActivity.datas2.remove(selectedText)
            adapterForDatas2.notifyDataSetChanged()
            Toast.makeText(this, "'$selectedText' removed from 2nd ListView.", Toast.LENGTH_SHORT).show()
            true
        }

    }
}