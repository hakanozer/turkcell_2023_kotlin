package com.alimarangoz.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView

class ResultActivity : AppCompatActivity() {

    lateinit var data1ListView: ListView
    lateinit var data2ListView: ListView
    lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        data1ListView = findViewById(R.id.data1_list_view)
        data2ListView = findViewById(R.id.data2_list_view)
        backButton = findViewById(R.id.back_to_add_btn)

        val data1Arr : ArrayList<String> = intent.getSerializableExtra("data1_arr") as ArrayList<String>

        val data2Arr : ArrayList<String> = intent.getSerializableExtra("data2_arr") as ArrayList<String>

        var adapterData1 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data1Arr)

        var adapterData2 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data2Arr)


        data1ListView.adapter = adapterData1
        data2ListView.adapter = adapterData2


        backButton.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


    }
}