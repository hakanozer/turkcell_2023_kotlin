package com.uysal.turkcell_odev2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var editTextA: EditText
    lateinit var editTextB: EditText
    lateinit var btnAddA: Button
    lateinit var btnAddB: Button
    lateinit var btnResult: Button

    companion object {
        var arrA = mutableListOf<String>()
        var arrB = mutableListOf<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        editTextA = findViewById(R.id.editTextA)
        editTextB = findViewById(R.id.editTextB)
        btnAddA = findViewById(R.id.btnAddA)
        btnAddB = findViewById(R.id.btnAddB)
        btnResult = findViewById(R.id.btnResult)

        btnAddA.setOnClickListener {
            if (editTextA.text.isNotEmpty()) {
                arrA.add("${arrA.size + 1} -) " +  editTextA.text.toString())
                Toast.makeText(this, "istenilen değer eklendi", Toast.LENGTH_SHORT).show()
                editTextA.setText("")
            }
        }
        btnAddB.setOnClickListener {
            if (editTextB.text.isNotEmpty()) {
                arrB.add("${arrB.size + 1} -) " + editTextB.text.toString())
                Toast.makeText(this, "istenilen değer eklendi", Toast.LENGTH_SHORT).show()
                editTextB.setText("")
            }
        }

        btnResult.setOnClickListener {
            var intent = Intent(this , Result::class.java)
            startActivity(intent)

        }


    }
}