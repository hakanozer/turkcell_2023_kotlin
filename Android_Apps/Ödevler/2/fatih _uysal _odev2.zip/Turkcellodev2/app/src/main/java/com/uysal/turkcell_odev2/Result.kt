package com.uysal.turkcell_odev2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class Result : AppCompatActivity() {
    lateinit var listViewA: ListView
    lateinit var listViewB: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        listViewA = findViewById(R.id.listViewA)
        listViewB= findViewById(R.id.listViewB)


        var adapter = ArrayAdapter(this , android.R.layout.simple_list_item_1 , MainActivity.arrA)
        var adapter2 = ArrayAdapter(this , android.R.layout.simple_list_item_1 , MainActivity.arrB)

        listViewA.adapter = adapter
        listViewB.adapter = adapter2





    }
}