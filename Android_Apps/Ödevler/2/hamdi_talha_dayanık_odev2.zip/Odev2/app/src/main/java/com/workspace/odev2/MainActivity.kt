package com.workspace.odev2

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {

    companion object{
        var data1 = mutableListOf<String>()
        var data2 = mutableListOf<String>()
    }

    lateinit var txtData1 : EditText
    lateinit var btnAdd1 : Button
    lateinit var txtData2 : EditText
    lateinit var btnAdd2 : Button
    lateinit var btnShowResults : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtData1 = findViewById(R.id.edittxtData1)
        btnAdd1 = findViewById(R.id.btnAdd1)
        txtData2 = findViewById(R.id.edittxtData2)
        btnAdd2 = findViewById(R.id.btnAdd2)
        btnShowResults = findViewById(R.id.btnShowResults)

        btnAdd1.setOnClickListener {
            data1.add(txtData1.text.toString())
        }

        btnAdd2.setOnClickListener {
            data2.add(txtData2.text.toString())
        }

        btnShowResults.setOnClickListener {
            var intent = Intent(this, ResultsActivity::class.java)
            startActivity(intent)
        }
    }
}