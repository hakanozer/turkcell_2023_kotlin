package com.workspace.odev2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class ResultsActivity : AppCompatActivity() {

    lateinit var listData1 : ListView
    lateinit var listData2 : ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        listData1 = findViewById(R.id.listData1)
        listData2 = findViewById(R.id.listData2)

        var adapter1 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, MainActivity.data1)
        var adapter2 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, MainActivity.data2)

        listData1.adapter = adapter1
        listData2.adapter = adapter2
    }
}