package com.hasandeniz.hasan_deniz_v2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private val list1 = mutableListOf<String>()
    private val list2 = mutableListOf<String>()
    private lateinit var etData1: EditText
    private lateinit var etData2: EditText
    private lateinit var btnAddData1: Button
    private lateinit var btnAddData2: Button
    private lateinit var btnSeeResults: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etData1 = findViewById(R.id.etData1)
        etData2 = findViewById(R.id.etData2)
        btnAddData1 = findViewById(R.id.btnAddData1)
        btnAddData2 = findViewById(R.id.btnAddData2)
        btnSeeResults = findViewById(R.id.btnSeeResults)

        btnAddData1.setOnClickListener {
            addButtonOnClick(etData1, list1)
        }

        btnAddData2.setOnClickListener {
            addButtonOnClick(etData2, list2)
        }

        btnSeeResults.setOnClickListener {
            val intent = Intent(this, ResultsActivity::class.java)
            intent.putStringArrayListExtra("list1", list1 as ArrayList<String>)
            intent.putStringArrayListExtra("list2", list2 as ArrayList<String>)
            startActivity(intent)
        }

    }

    private fun addButtonOnClick(editText: EditText, list: MutableList<String>) {
        val data = editText.text.toString()
        if (data.isEmpty()) {
            showToast("Please enter a value")
            return
        }
        list.add(data)
        editText.text.clear()
        showToast("$data added to List")
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}