package com.hasandeniz.hasan_deniz_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.recyclerview.widget.RecyclerView

class ResultsActivity : AppCompatActivity() {
    private lateinit var lvData1: ListView
    private lateinit var lvData2: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        lvData1 = findViewById(R.id.lvData1)
        lvData2 = findViewById(R.id.lvData2)

        val list1 = intent.getStringArrayListExtra("list1") as List<String>
        val list2 = intent.getStringArrayListExtra("list2") as List<String>

        val adapter1 = ArrayAdapter(this, android.R.layout.simple_list_item_1, list1)
        val adapter2 = ArrayAdapter(this, android.R.layout.simple_list_item_1, list2)

        lvData1.adapter = adapter1
        lvData2.adapter = adapter2

    }
}