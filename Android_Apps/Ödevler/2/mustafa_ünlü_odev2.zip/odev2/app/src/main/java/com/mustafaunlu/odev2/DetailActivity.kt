package com.mustafaunlu.odev2

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {
    lateinit var data1ListView: ListView // bu sayfada findViewById kullanildi
    lateinit var data2ListView: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        data1ListView = findViewById(R.id.list_view_1)
        data2ListView = findViewById(R.id.list_view_2)

        val data1Adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, MainActivity.dataList1)
        val data2Adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, MainActivity.dataList2)

        data1ListView.adapter = data1Adapter
        data2ListView.adapter = data2Adapter
    }
}
