package com.mustafaunlu.odev2

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.mustafaunlu.odev2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val customToast = CustomToast()
    lateinit var binding: ActivityMainBinding // bu sayfada view binding kullanildi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.data1Button.setOnClickListener {
            val data1 = binding.data1Edtxt.text.toString()
            if (data1.isEmpty()) {
                customToast.emptyFieldAlertToast(this)
                return@setOnClickListener
            }
            dataList1.add(data1)
            customToast.makeToast(this, "$data1 eklendi").show()
            binding.data1Edtxt.clearAndFocus()
        }
        binding.data2Button.setOnClickListener {
            val data2 = binding.data2Edtxt.text.toString()
            if (data2.isEmpty()) {
                customToast.emptyFieldAlertToast(this)
                return@setOnClickListener
            }
            dataList2.add(data2)
            customToast.makeToast(this, "$data2 eklendi").show()
            binding.data2Edtxt.clearAndFocus()
        }
        binding.resultButton.setOnClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }
    }

    // EditText clear ve focus ozelliklerini tek seferde yapan extension fonksiyon
    private fun EditText.clearAndFocus() {
        this.text.clear()
        this.requestFocus()
    }

    companion object {
        val dataList1 = mutableListOf<String>()
        val dataList2 = mutableListOf<String>()
    }
}
