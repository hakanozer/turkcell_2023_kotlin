package com.odev_2

import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)




        Toast.makeText(this,intent.getStringExtra("data"),Toast.LENGTH_SHORT).show()
        //Toast.makeText(this,intent.getStringExtra("data2"),Toast.LENGTH_LONG).show()


        //toast1.setGravity(Gravity.CENTER,250,200)




           /* var dataFromListView2 = intent.getStringExtra("data2")
            val toast2: Toast
            toast2 = Toast.makeText(this, dataFromListView2, Toast.LENGTH_LONG)
          //  toast2.setGravity(Gravity.CENTER_HORIZONTAL, 400, 70)
            toast2.show()*/

        //Toast.makeText(this,dataFromListView2,Toast.LENGTH_LONG).show()
    }
}