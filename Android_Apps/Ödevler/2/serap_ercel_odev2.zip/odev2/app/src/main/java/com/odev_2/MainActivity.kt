package com.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.core.text.toHtml

class MainActivity : AppCompatActivity() {

    lateinit var editTextName: EditText
    lateinit var editTextNumeric: EditText
    lateinit var btnAdd1: Button
    lateinit var btnAdd2: Button
    lateinit var btnSonucGoster: Button

    var arr1 = arrayListOf<String>()
    var arr2 = arrayListOf<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextNumeric = findViewById(R.id.editTextNumeric)
        btnAdd1 = findViewById(R.id.btnAdd1)
        btnAdd2 = findViewById(R.id.btnAdd2)
        btnSonucGoster = findViewById(R.id.btnSonucGoster)

        btnAdd1.setOnClickListener {
            val data1 = editTextName.text.toString()
            data1.isNotEmpty().let {
                val intent = Intent(this, ResultActivity::class.java)
                arr1.add(data1)
            }
            editTextName.setText("")
            editTextName.requestFocus()
        }

        btnAdd2.setOnClickListener {
            val data2 = editTextNumeric.text.toString()
            data2.isNotEmpty().let {
                val intent = Intent(this, ResultActivity::class.java)
                arr2.add(data2)

            }
            editTextNumeric.setText("")

        }

        btnSonucGoster.setOnClickListener {
            intent = Intent(this, ResultActivity::class.java)
            intent.putStringArrayListExtra("data1", arr1)
            intent.putStringArrayListExtra("data2", arr2)
            startActivity(intent)
        }

    }

}