package com.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class ResultActivity : AppCompatActivity() {

    private lateinit var veri1ListView: ListView
    lateinit var veri2ListView: ListView

    var arr1 = arrayListOf<String>()
    var arr2 = mutableListOf<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        intent.getStringArrayListExtra("data1")?.let {
            arr1 = it
        }
        intent.getStringArrayListExtra("data2")?.let {
            arr2 = it
        }

        veri1ListView = findViewById(R.id.veri1ListView)
        val adapter1 =
            ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, arr1)
        veri1ListView.adapter = adapter1
        veri2ListView = findViewById(R.id.veri2ListView)
        val adapter2 =
            ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, arr2)
        veri2ListView.adapter = adapter2
        adapter1.notifyDataSetChanged()
        adapter2.notifyDataSetChanged()

        veri1ListView.setOnItemClickListener { adapterView, view, i, l ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("data", arr1[i])
            startActivity(intent)
            true
        }

        veri2ListView.setOnItemClickListener { adapterView, view, i, l ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("data", arr2[i])
            startActivity(intent)
            true
        }

    }


}