package com.example.odev_2

import android.content.Context
import android.content.Intent
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast

class AdapterConnection<T : CharSequence> (
    private var intent : Intent,
    private var sourceContext: Context,
    ) {

    //Send Dynamic Data With Intent
    fun sendData(dataTag: String, etData: EditText){
        if(etData.text.isNotEmpty()){
            intent.putExtra(dataTag,etData.text.toString())
            etData.setText("")
            etData.requestFocus()
        }else{
            Toast.makeText(sourceContext,"Data Empty!", Toast.LENGTH_SHORT).show()
        }
    }

    //Get String Data With Intent
    fun getStringData(dataTag: String,listView: ListView,list: MutableList<String>) : MutableList<String>{
        var connectedAdapter = createAndConnectAdapterToListView(list as MutableList<T>,listView)
        var data = intent.getStringExtra(dataTag)
        if(data != null){
            list.add(data)
            connectedAdapter.notifyDataSetChanged()
        }
        return list
    }

    //Create Adapter And Connect It To Target ListView
    private fun createAndConnectAdapterToListView(list: MutableList<T>, listView : ListView) : ArrayAdapter<T>{
       var adapter =  ArrayAdapter(sourceContext,android.R.layout.simple_list_item_1, list)
        listView.adapter = adapter
        return adapter
    }

}


