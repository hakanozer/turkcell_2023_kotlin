package com.example.odev_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.odev_2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Define Intent for Data Transfer
        val intent = Intent(this, ResultsActivity::class.java)

        val adapterConnection = AdapterConnection<String>(intent,this)
        binding.btnAddData.setOnClickListener {
            adapterConnection.sendData("data1", binding.etData)
        }

        binding.btnAddData2.setOnClickListener {
            adapterConnection.sendData("data2", binding.etData2)
        }

        //Show Results Button Click Listener for Changing Page With Intent
        binding.btnShowResults.setOnClickListener {
            startActivity(intent)
        }
    }
}