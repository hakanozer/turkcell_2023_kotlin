package com.example.odev_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import com.example.odev_2.databinding.ActivityResultsBinding

class ResultsActivity : AppCompatActivity() {

    private lateinit var binding : ActivityResultsBinding

    companion object{
        private var data1Arr = mutableListOf<String>()
        private var data2Arr = mutableListOf<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var adapterConnection = AdapterConnection<String>(intent,this)

        data1Arr = adapterConnection.getStringData("data1", binding.data1ListView, data1Arr)
        data2Arr = adapterConnection.getStringData("data2", binding.data2ListView, data2Arr)
    }
}