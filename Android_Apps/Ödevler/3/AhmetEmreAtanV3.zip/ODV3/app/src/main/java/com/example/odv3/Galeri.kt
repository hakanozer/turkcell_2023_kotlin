package com.example.odv3

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout

class Galeri : AppCompatActivity() {

    lateinit var galeriListView : ListView
    lateinit var btnAlert2 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_galeri)



        btnAlert2 = findViewById(R.id.button2)

        btnAlert2.setOnClickListener {

            var titleView = layoutInflater.inflate(R.layout.button_alert, null)
            var alert = AlertDialog.Builder(this)
            alert.setCustomTitle(titleView!!)
            alert.setMessage("Anasayfaya dönmek istediğinize emin misiniz?")
            alert.setCancelable(false)
            //buttons
            alert.setPositiveButton("Evet", DialogInterface.OnClickListener { dialogInterface, i ->
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            })
            alert.setNegativeButton("Hayır", DialogInterface.OnClickListener { dialogInterface, i ->
            })

            alert.setIcon(R.drawable.baseline_info_24)

            alert.show()
        }


        val listView = findViewById<ListView>(R.id.galeriListView)
        val images = arrayOf(
            R.drawable.profilepicture,
            R.drawable.picture2,
            R.drawable.picture3,
            R.drawable.picture4,
            R.drawable.picture5)
        val adapter = ImageAdapter(this, images)
        listView.adapter = adapter


    }

    private class ImageAdapter(private val context: Context, private val images: Array<Int>) : BaseAdapter() {
        private val inflater: LayoutInflater = LayoutInflater.from(context)



        override fun getCount(): Int {
            return images.size
        }

        override fun getItem(position: Int): Any {
            return images[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var view = convertView
            if (view == null) {
                view = inflater.inflate(R.layout.image_item, parent, false)
            }

            val image = images[position]
            val imageView = view!!.findViewById<ImageView>(R.id.image_view)

            imageView.setImageResource(image)

            return view
        }
    }
}