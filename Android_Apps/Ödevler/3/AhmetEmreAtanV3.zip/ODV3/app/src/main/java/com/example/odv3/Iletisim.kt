package com.example.odv3

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class Iletisim : AppCompatActivity() {

    lateinit var IletisimListView: ListView
    var arr = mutableListOf<String>()
    var arrIndex = mutableListOf<Int>()
    lateinit var btnAlert : Button

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iletisim)



        IletisimListView = findViewById(R.id.iletisimListView)
        val items = arrayOf("Telefon: 505-066-5553", "Instagram: ahmetemreatan", "Github: AhmetAtan", "Linkedin: Ahmet Emre Atan", "Mail: ahmet_emrea@hotmail.com")
        IletisimListView.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position) as String
            Toast.makeText(this, selectedItem, Toast.LENGTH_SHORT).show()
        }
        var adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items)
        IletisimListView.adapter = adapter





        btnAlert = findViewById(R.id.button3)

        btnAlert.setOnClickListener {

            var titleView = layoutInflater.inflate(R.layout.button_alert, null)
            var alert = AlertDialog.Builder(this)
            alert.setCustomTitle(titleView!!)
            alert.setMessage("Anasayfaya dönmek istediğinize emin misiniz?")
            alert.setCancelable(false)
            //buttons
            alert.setPositiveButton("Evet", DialogInterface.OnClickListener { dialogInterface, i ->
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            })
            alert.setNegativeButton("Hayır", DialogInterface.OnClickListener { dialogInterface, i ->
            })

            alert.setIcon(R.drawable.baseline_info_24)

            alert.show()
        }

    }
}