package com.example.odv3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var btnHome : Button
    lateinit var btnHakkinda : Button
    lateinit var btnGaleri : Button
    lateinit var btnIletisim : Button
    lateinit var btnBlog : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btnHome = findViewById(R.id.btnanasayfa)
        btnHakkinda = findViewById(R.id.btnhakkinda)
        btnGaleri = findViewById(R.id.btngaleri)
        btnIletisim = findViewById(R.id.btniletisim)
        btnBlog = findViewById(R.id.btnblog)




        //Sayfa geçiş intentleri
        btnHome.setOnClickListener {
            intent = Intent(this, MainActivity::class.java)
            Toast.makeText(this, "Anasayfa", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }

        btnHakkinda.setOnClickListener {
            intent = Intent(this, Hakkinda::class.java)
            Toast.makeText(this, "Hakkında!", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }

        btnGaleri.setOnClickListener {
            intent = Intent(this, Galeri::class.java)
            Toast.makeText(this, "Galeri", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }

        btnIletisim.setOnClickListener {
            intent = Intent(this, Iletisim::class.java)
            Toast.makeText(this, "İletişim", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }

        btnBlog.setOnClickListener {
            intent = Intent(this, Blog::class.java)
            Toast.makeText(this, "Blog", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }



    }
}