package com.works.biography_app.models

data class Gallery(
    val caption: String,
    val date: String,
    val image: String
)

