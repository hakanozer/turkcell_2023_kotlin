package com.alierdemalkoc.mybiography.model

data class Gallery(
    var name: String,
    var image: String
)
