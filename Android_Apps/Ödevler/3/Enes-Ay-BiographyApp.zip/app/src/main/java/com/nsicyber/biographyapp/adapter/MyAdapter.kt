package com.nsicyber.biographyapp.adapter

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.nsicyber.biographyapp.R
import com.nsicyber.biographyapp.activities.ImageReviewActivity

class MyAdapter(private val myList: List<String>,var context: Context) : RecyclerView.Adapter<MyViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.viewholder, parent, false)
        return MyViewHolder(view,myList,context)
    }


    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = myList[position]
        Glide.with(context)
            .load(currentItem)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .into(object : CustomTarget<Drawable>() {
                override fun onLoadCleared(placeholder: Drawable?) {}
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?
                ) {
                    holder.image.apply {
                        setImageDrawable(resource)
                        layoutParams.height = resource.intrinsicHeight
                    }
                }
            })



    }


    override fun getItemCount() = myList.size
}

class MyViewHolder(itemView: View, list: List<String>, context: Context) : RecyclerView.ViewHolder(itemView) {
    val image: ImageView = itemView.findViewById(R.id.imageView)
    init {
        itemView.setOnClickListener {


            val bundle = Bundle()
            bundle.putString("url",list.get(adapterPosition)
            )

            val intent = Intent(context, ImageReviewActivity::class.java)
            intent.putExtras(bundle)

            context.startActivity(intent)

        }
    }
}
