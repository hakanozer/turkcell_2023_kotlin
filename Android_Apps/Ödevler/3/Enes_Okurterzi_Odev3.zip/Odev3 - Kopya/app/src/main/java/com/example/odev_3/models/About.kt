package com.example.odev_3.models

data class About (
    val aboutContent: String
        )