package com.example.odev_3.models

data class Contact (
    val number: String,
    val email: String,
    val gitHub: String,
    val linkedIn: String
        )