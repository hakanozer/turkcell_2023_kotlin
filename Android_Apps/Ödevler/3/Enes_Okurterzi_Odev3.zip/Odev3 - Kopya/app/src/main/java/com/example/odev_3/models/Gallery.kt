package com.example.odev_3.models

data class Gallery(
    val image: String,
    val place: String,
    val date: String,
    val detail: String
)