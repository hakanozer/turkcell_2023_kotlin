package com.example.odev_3.services

import com.example.odev_3.models.Contact

class ContactService {

    fun contactResult(): Contact {
        val contact = Contact(
            "+90 532 579 94 87",
            "enes.okurterzi@gmail.com",
            "https://github.com/enesokurterzi",
            "https://www.linkedin.com/in/enes-okurterzi/"
        )

        return contact
    }
}