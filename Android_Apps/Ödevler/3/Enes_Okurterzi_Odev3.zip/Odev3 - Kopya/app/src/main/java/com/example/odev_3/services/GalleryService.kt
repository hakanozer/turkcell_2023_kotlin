package com.example.odev_3.services

import com.example.odev_3.models.Gallery

class GalleryService {

    fun galleryResult(): List<Gallery> {
        val resultList = mutableListOf<Gallery>()

        val g1 = Gallery("https://db3pap006files.storage.live.com/y4mPduT_WNVssnneNUzskBar92kEPfkoeqAZjxsEKBORWvH2vhyYQoOcqHChtqk54GsMUkbbJFTL25iXDoL0LM1ue6YyGmVjoCIsxrLiF5v9eCbCUuw1ZuhpOc4D_MpBzC2lXKYpQh_jt27wOzxpTrSc0g_WP-XnAThFXOskyKKj_bR0B6EfgitB8LS7u7schoh?encodeFailures=1&width=1037&height=883","Salda Lake, Burdur, Turkey", "03/06/2018", "Lake Salda is a mid-size crater lake in southwestern Turkey, within the boundaries of Yeşilova district of Burdur Province. It lies at a distance of about fifty kilometers to the west from the province seat Burdur.")
        val g2 = Gallery("https://db3pap006files.storage.live.com/y4m3splmxvpNchUdFI6A7ylnTvHrm2l5wfHEtLhboN_1ZoBhTRvrkbbWExG40g3BxcLBZYosJ-4Y1Cg7AimRTGmdyxsa4P0BxrNKWl6DlYuJqmc0XnjjXVnSqLI0tROT8O4aZO1LOtiRwbZ-zclY_kMyQwy9LbUNRfbNLhn5ZYuJ3Zq2Dh6FdCYdzGAse8JlQsX?encodeFailures=1&width=1080&height=720", "Gölyazı, Bursa, Turkey", "07/09/2017", "Gölyazı is a Turkish town founded on a small peninsula on Lake Uluabat. Gölyazı was founded by the Ancient Greeks. but remains of the Roman period are abundant. Every year the town holds the Stork Festival and until the 20th century, Greeks and Manavs lived together.")
        val g3 = Gallery("https://db3pap006files.storage.live.com/y4mf0KtsJjnoTrKcAzMNksKRuKzCrNBPkbx-F3MVJB27Phi6rQel7JyRpunbpuesc-6qPZAGu5pU707N26LAhQbpYvhhwAGZSDavA1si4rEc8i_-WkkSQw1ie6utHQyaxCkkrlX7GUP9L68N6D5HElrBh2rSoWnEELsbJou833nR6gx2pqFqXToPNBJ-WsMxIxP?encodeFailures=1&width=662&height=883", "Pisa, Italy", "13/11/2020", "The Leaning Tower of Pisa, or simply, the Tower of Pisa, is the campanile, or freestanding bell tower, of Pisa Cathedral. It is known for its nearly four-degree lean, the result of an unstable foundation.")
        val g4 = Gallery("https://db3pap006files.storage.live.com/y4mwkAvvgAxsm8ZBvaS5501yEyvIZWfFibhN6DR6co7QZZ8Wltw7yele6Vsi0glv0nlYfolFbc02JeTm5DnoAXEGRkWtG7ZK4cF42K3kugx71xpINnanvdTY7ygjTVtgChmcxliLI_Eoc_AEa8zcAKB-UtNspTUNHYB2IjxQrzgxh_WQgvgy5oRnoOWNFRGqgjl?encodeFailures=1&width=662&height=883", "Rome, Italy", "10/11/2020", "Rome is the capital city of Italy. It is also the capital of the Lazio region, the centre of the Metropolitan City of Rome, and a special comune named Comune di Roma Capitale.")
        val g5 = Gallery("https://db3pap006files.storage.live.com/y4mA-tfoLmgj2YisHHO3frg3sZFeBFDrO34R_9-m3z2pm1DkQ-zT1DMIjnDSPsLlEREza9aZDMixfYPZsS2vv20Gjs22D1fCXlTEDr7msufp3MqqC7cntr4RKZ9GAYOyWeiWjbE7ZJZZD1WYRlHseizWGf8TY_exGyOpV2QMsezq8wvEOkSA7xApqrw2JCKkfpf?encodeFailures=1&width=1177&height=883", "Vatican City, Rome, Italy", "11/11/2020", "The Vatican Museums are the public museums of the Vatican City. They display works from the immense collection amassed by the Catholic Church and the papacy throughout the centuries, including several of the most well-known Roman sculptures and most important masterpieces of Renaissance art in the world.")
        val g6 = Gallery("https://db3pap006files.storage.live.com/y4mYN7iSzChIerTlTlZCXd4qoFIBezQbaCw7OAsPzWKJN5Ma51WtfyNqeOPEcZJAO-dbf-No4iWe4snVS5YDc1su0mTNn--xYuJ2WOzGYAOxB1A3uwMCUDvjzicmapl61PdxuWz-XFW-VtIMkscvCOffTAjKp5vPpy1kv2D0JU10BGiG2W0x8szv71nuD2DKa1k?encodeFailures=1&width=496&height=883", "Venice, Italy", "15/11/2020", "Venice, the capital of northern Italy’s Veneto region, is built on more than 100 small islands in a lagoon in the Adriatic Sea. It has no roads, just canals – including the Grand Canal thoroughfare – lined with Renaissance and Gothic palaces. The central square, Piazza San Marco, contains St. Mark’s Basilica, which is tiled with Byzantine mosaics, and the Campanile bell tower offering views of the city’s red roofs.")

        resultList.add(g1)
        resultList.add(g2)
        resultList.add(g3)
        resultList.add(g4)
        resultList.add(g5)
        resultList.add(g6)

        return resultList
    }
}