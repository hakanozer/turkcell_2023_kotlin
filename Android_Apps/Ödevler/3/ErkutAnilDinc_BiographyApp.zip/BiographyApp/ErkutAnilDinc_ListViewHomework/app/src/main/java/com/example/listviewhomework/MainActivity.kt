package com.example.listviewhomework

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    companion object {
        var movieArr = mutableListOf<String>()
        var movieStarArr = mutableListOf<String>()
    }

    lateinit var movieAddButton: Button
    lateinit var movieStarAddButton: Button
    lateinit var resultScreenButton: Button
    lateinit var movieNameEditText: EditText
    lateinit var movieStarNameEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        movieAddButton = findViewById(R.id.movieAddButton)
        movieStarAddButton = findViewById(R.id.movieStarAddButton)
        resultScreenButton = findViewById(R.id.resultScreenButton)
        movieNameEditText = findViewById(R.id.movieEditText)
        movieStarNameEditText = findViewById(R.id.movieStarEditText)

        movieAddButton.setOnClickListener {
            var movieName = movieNameEditText.text.toString()
            movieNameEditText.text.clear()
            movieArr.add(movieName)
        }

        movieStarAddButton.setOnClickListener {
            var movieStarName = movieStarNameEditText.text.toString()
            movieStarNameEditText.text.clear()
            movieStarArr.add(movieStarName)
        }

        resultScreenButton.setOnClickListener {
            var intent = Intent(this, ResultActivity::class.java)
            startActivity(intent)
        }

    }

}