package com.example.listviewhomework

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class ResultActivity : AppCompatActivity() {

    lateinit var movieList: ListView
    lateinit var movieStarList: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        movieList = findViewById(R.id.movieListView)
        movieStarList = findViewById(R.id.movieStarListView)

        var adapterMovie =
            ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, MainActivity.movieArr)
        var adapterMovieStar = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            MainActivity.movieStarArr
        )
        movieList.adapter = adapterMovie
        movieStarList.adapter = adapterMovieStar
    }
}