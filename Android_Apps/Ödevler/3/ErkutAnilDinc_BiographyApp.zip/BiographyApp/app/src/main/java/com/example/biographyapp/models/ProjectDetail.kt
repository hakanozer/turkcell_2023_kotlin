package com.example.biographyapp.models

import android.media.Image

data class ProjectDetail(
    var projectPictures: Int,
    var projectName: String,
    var projectDate: String,
    var projectSummary: String
)
