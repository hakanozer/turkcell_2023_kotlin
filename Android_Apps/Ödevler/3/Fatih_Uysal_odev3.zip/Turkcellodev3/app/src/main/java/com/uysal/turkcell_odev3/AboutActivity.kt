package com.uysal.turkcell_odev3

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class AboutActivity : Page() {
    lateinit var btnHome: Button
    lateinit var btnGallery: Button
    lateinit var btnIletisim: Button
    lateinit var btnBlog: Button
    lateinit var btnAbout: Button
    lateinit var textViewAbout : TextView
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        btnHome = findViewById(R.id.btnHome)
        btnAbout = findViewById(R.id.btnAbout)
        btnGallery = findViewById(R.id.btnGalery)
        btnIletisim = findViewById(R.id.btnCom)
        btnBlog = findViewById(R.id.btnBlog)
        textViewAbout = findViewById(R.id.textViewAbout)
        btnAbout.setBackgroundColor(R.color.SelectedBtn)

        textViewAbout.setText("""Merhaba
            |adım Fatih Uysal 23 yaşında havacılık elektrik elektroniği 4. sınıf öğrencisiyim thy da staj yapıyorum aynı zamanda ek olarak turkcell geleceği yazanlar projesinde eğitim almaktayım eğitimden önce zamanımı  1.5 yıl java için 1 yıl kotlin için öğrenmeye harcadım. Çalışmayı kendi kendime sürdürebildiğim kadar sürdürdüm. Bu eğitim ile gerekli şeyleri öğrenmiş işe girebilecek düzeye gelebileceğimi düşünüyorum. 
        """.trimMargin())

        btnHome.setOnClickListener {
            openFragment(MainActivity())
        }
        btnAbout.setOnClickListener {
            warnMessage()
        }
        btnGallery.setOnClickListener {
           openFragment(GalleryActivity())
        }
        btnIletisim.setOnClickListener {
            openFragment(IletisimActivity())
        }
        btnBlog.setOnClickListener {
            openFragment(BlogActivity())
        }

    }

    override fun onBackPressed() {
        quitAlertDiaglog()

    }

}