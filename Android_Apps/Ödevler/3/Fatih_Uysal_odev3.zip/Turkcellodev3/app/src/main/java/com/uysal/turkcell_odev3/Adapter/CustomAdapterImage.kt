package com.uysal.turkcell_odev3.Adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.uysal.turkcell_odev3.Models.Photos
import com.uysal.turkcell_odev3.R

class CustomAdapterImage(val context: Activity, private val list: List<Photos>) :
    ArrayAdapter<Photos>(context, R.layout.custom_list_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)
        val r_image = rootView.findViewById<ImageView>(R.id.imageView)
        val user = list.get(position)
        Glide.with(rootView).load(user.image).into(r_image)
        return rootView


    }
}