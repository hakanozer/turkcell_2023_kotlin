package com.uysal.turkcell_odev3

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.widget.Button

class BlogActivity : Page() {

    lateinit var btnHome: Button
    lateinit var btnGallery: Button
    lateinit var btnIletisim: Button
    lateinit var detailWebView: WebView
    lateinit var btnBlog: Button
    lateinit var btnAbout: Button
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blog)
        btnHome = findViewById(R.id.btnHome)
        btnAbout = findViewById(R.id.btnAbout)
        btnGallery = findViewById(R.id.btnGalery)
        btnIletisim = findViewById(R.id.btnCom)
        btnBlog = findViewById(R.id.btnBlog)
        detailWebView = findViewById(R.id.detailWebView)
        btnBlog.setBackgroundColor(R.color.SelectedBtn)



        btnHome.setOnClickListener {
            openFragment(MainActivity())
        }
        btnAbout.setOnClickListener {
            openFragment(AboutActivity())
        }
        btnGallery.setOnClickListener {
            openFragment(GalleryActivity())
        }
        btnIletisim.setOnClickListener {
            openFragment(IletisimActivity())
        }
        btnBlog.setOnClickListener {
            warnMessage()
        }

        var url = "https://github.com/fatihuysall"
//        var url = "https://www.instagram.com/lxwittle/"
        detailWebView.settings.javaScriptEnabled = true
        detailWebView.settings.allowContentAccess = true
        detailWebView.loadUrl(url)
    }

    override fun onBackPressed() {
        quitAlertDiaglog()

    }


}