package com.uysal.turkcell_odev3

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import com.uysal.turkcell_odev3.Adapter.CustomAdapterImage
import com.uysal.turkcell_odev3.Models.Photos

class GalleryActivity : Page() {

    lateinit var btnHome: Button
    lateinit var btnGallery: Button
    lateinit var btnIletisim: Button
    lateinit var btnBlog: Button
    lateinit var galleryListView: ListView
    lateinit var btnAbout: Button

    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        btnHome = findViewById(R.id.btnHome)
        btnAbout = findViewById(R.id.btnAbout)
        btnGallery = findViewById(R.id.btnGalery)
        btnIletisim = findViewById(R.id.btnCom)
        btnBlog = findViewById(R.id.btnBlog)
        galleryListView = findViewById(R.id.galleryListView)
        btnGallery.setBackgroundColor(R.color.SelectedBtn)

        var photo = Photos().showPages()
        var adapter = CustomAdapterImage(this, photo)
        galleryListView.adapter = adapter

        galleryListView.setOnItemClickListener { adapterView, view, i, l ->

            var intent = Intent(this, PhotoDetailActivity::class.java)

            intent.putExtra("order" , i)
            startActivity(intent)

        }


        btnHome.setOnClickListener {
            openFragment(MainActivity())
        }
        btnAbout.setOnClickListener {
            openFragment(AboutActivity())
        }
        btnGallery.setOnClickListener {
            warnMessage()
        }
        btnIletisim.setOnClickListener {
            openFragment(IletisimActivity())
        }
        btnBlog.setOnClickListener {
            openFragment(BlogActivity())
        }
    }

    override fun onBackPressed() {
        quitAlertDiaglog()

    }


}