package com.uysal.turkcell_odev3

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class IletisimActivity : Page() {
    lateinit var btnHome: Button
    lateinit var btnGallery: Button
    lateinit var btnIletisim: Button
    lateinit var textEmail : TextView
    lateinit var btnBlog: Button
    lateinit var btnAbout: Button
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iletisim)
        btnHome = findViewById(R.id.btnHome)
        btnAbout = findViewById(R.id.btnAbout)
        btnGallery = findViewById(R.id.btnGalery)
        btnIletisim = findViewById(R.id.btnCom)
        btnBlog = findViewById(R.id.btnBlog)
        textEmail = findViewById(R.id.textMail)
        btnIletisim.setBackgroundColor(R.color.SelectedBtn)

        btnHome.setOnClickListener {
            openFragment(MainActivity())
        }
        btnAbout.setOnClickListener {
            openFragment(AboutActivity())
        }
        btnGallery.setOnClickListener {
            openFragment(GalleryActivity())
        }
        btnIletisim.setOnClickListener {
            warnMessage()
        }
        btnBlog.setOnClickListener {
            openFragment(BlogActivity())
        }
//TODO("bu kısım tekrar düşünülecek tam bir yere varılamadı sistem çalışıyor...")
//        textEmail.setOnClickListener {
//         alertDiaglog()
//        }
    }
    override fun onBackPressed() {
        quitAlertDiaglog()

    }






}