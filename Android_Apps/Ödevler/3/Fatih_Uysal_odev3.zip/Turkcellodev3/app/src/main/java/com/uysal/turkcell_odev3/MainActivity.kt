package com.uysal.turkcell_odev3

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Page() {

    lateinit var btnHome: Button
    lateinit var btnGallery: Button
    lateinit var btnIletisim: Button
    lateinit var btnBlog: Button
    lateinit var btnAbout: Button
    lateinit var homeTextView: TextView

    @SuppressLint("ResourceAsColor")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnHome = findViewById(R.id.btnHome)
        btnAbout = findViewById(R.id.btnAbout)
        btnGallery = findViewById(R.id.btnGalery)
        btnIletisim = findViewById(R.id.btnCom)
        btnBlog = findViewById(R.id.btnBlog)
        btnHome.setBackgroundColor(R.color.SelectedBtn)
//        homeTextView = findViewById(R.id.textViewHome)

//        homeTextView.setText("""
//            |1-) Backpress buttonuna alert eklendi
//            |
//            |2-) Galeride kullanılan fotoğraflara click eventi eklendi
//            |
//            |3-) İletişim ekranındaki numara ve linklere click event eklendi
//            |
//            |4-) Blog sayfasına WebView kullanılarak github ekranı koyuldu
//            |
//            |5-) Galerinin doldurulması için glide kütüphanesi kullanılmıştır
//            |
//            |6-) Sadece Activity kullanılarak bottom nav yapıldı
//        """.trimMargin()
//        )


        btnHome.setOnClickListener {
            warnMessage()

        }
        btnAbout.setOnClickListener {
            openFragment(AboutActivity())
        }
        btnGallery.setOnClickListener {
            openFragment(GalleryActivity())
        }
        btnIletisim.setOnClickListener {
            openFragment(IletisimActivity())
        }
        btnBlog.setOnClickListener {
            openFragment(BlogActivity())
        }


    }

    override fun onBackPressed() {
        quitAlertDiaglog()

    }


}


/**
 * temel şemalar hazırlandı her sayfanın geçişleri düzenlendi ,
 * sayfaların herbirinin içinde ne olacak ?
 * kullanmam gereken şeyler galeri için glide kullanılabilir webView blog için kullanılcak iletişim kısmında izin isteyerek siteye yönlendirebilirim
 * anasayfada ne olacak ?
 * blog githuba gidebilir
 * hakkıomda biyografi tarzı mı olacak ?
 * arka plan renklendirilmeli mi
 * --------------
 * 2.gün iletişim çoğunlukla bitti içime tam sinmedi biraz boş gibi kaldı blog kısmı dolduruldu
 * nereye uyarı verebilirim uyarı sistemini çalıştıracağım bir yer belirleyemedim
 * galeri fotoğrafları dikine sıralanacak mı
 * hakkımda biyografi tarzı olacak muhtemelen orayı hareketlendirecek ne bulabilirim
 * custom alert boş duruyor kullanılmazsa sil!!!
 * ----------------
 *
 * 3.gün galeriyi yaptım içeriğe girmesini ayarladım geri tuşuna alert koyulabilir çıkmak istiyor munsuuz diye
 * hakkımda ve ana sayfa kaldı ana sayfaya kullanılmış kütüphaneler falan yazılabilir
 * fotoların boyutları ?
 * karanlık modu kaldırdım belki ona da ayarlama yapılabilir
 *
 *
 */