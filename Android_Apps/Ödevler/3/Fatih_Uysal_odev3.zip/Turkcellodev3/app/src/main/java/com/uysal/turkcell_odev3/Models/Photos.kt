package com.uysal.turkcell_odev3.Models

class Photos(var image: String = "") {

    fun showPages(): List<Photos> {


        photoList.add(Photos("https://marketplace.canva.com/EAFEits4-uw/1/0/800w/canva-boy-cartoon-gamer-animated-twitch-profile-photo-r0bPCSjUqg0.jpg"))
        photoList.add(Photos("https://wallpapers.com/images/featured/87h46gcobjl5e4xu.jpg"))
        photoList.add(Photos("https://randomuser.me/api/portraits/women/89.jpg"))
        photoList.add(Photos("https://randomuser.me/api/portraits/women/74.jpg"))
        photoList.add(Photos("https://dp.profilepics.in/profile_pictures/cute-profile-pics/cute-profile-pics-781.jpg"))
        photoList.add(Photos("https://dp.profilepics.in/profile_pictures/flower/flower_profile_pictures_01.jpg"))
        photoList.add(Photos("https://www.thesprucepets.com/thmb/7YGQUU_FYAd2XCNmnW_9_jKcDZU=/5762x0/filters:no_upscale():strip_icc()/siamese-fighting-fish-bettas-1378308-hero-f459084da1414308accde7e21001906c.jpg"))
        photoList.add(Photos("https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg"))
        photoList.add(Photos("https://randomuser.me/api/portraits/men/72.jpg"))

        return photoList
    }
}

var photoList = mutableListOf<Photos>()