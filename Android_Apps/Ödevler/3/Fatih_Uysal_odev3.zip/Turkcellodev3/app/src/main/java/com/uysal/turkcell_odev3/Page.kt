package com.uysal.turkcell_odev3

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

open class Page : AppCompatActivity() {

    fun warnMessage(){
        Toast.makeText(this , "istenilen sayfadasınız." , Toast.LENGTH_SHORT).show()
    }

    fun quitAlertDiaglog() {
        var titleView = layoutInflater.inflate(R.layout.custom_alert, null)
        var alert = AlertDialog.Builder(this)
        alert.setTitle("alert title")
        alert.setCustomTitle(titleView)
        alert.setMessage("Çıkma işlemini onaylıyor musunuz ? ")
        alert.setCancelable(false)
        alert.setPositiveButton("evet", DialogInterface.OnClickListener { dialogInterface, i ->
            super.onBackPressed()
        })
        alert.setNegativeButton("hayır", DialogInterface.OnClickListener { dialogInterface, i ->

        })
        alert.show()
    }


    fun goToUrl(url:String){

        var intent = Intent(Intent.ACTION_VIEW , Uri.parse(url))
        startActivity(intent)
    }

    fun openFragment( page : Activity) {
        var intent = Intent(this, page::class.java)
        startActivity(intent)
        finish()

    }
}