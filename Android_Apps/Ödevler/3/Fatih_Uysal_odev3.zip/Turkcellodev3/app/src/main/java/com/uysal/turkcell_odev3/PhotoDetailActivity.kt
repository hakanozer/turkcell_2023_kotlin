package com.uysal.turkcell_odev3

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.uysal.turkcell_odev3.Models.photoList


class PhotoDetailActivity : AppCompatActivity() {
    lateinit var imageDetail: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo_detail)
        imageDetail = findViewById(R.id.imageDetail)
        val order = intent.getIntExtra("order", 0)

        var usingImage = photoList.get(order).image
        Glide.with(this).load(usingImage).into(imageDetail)


//        Toast.makeText(this, "verilen değer : ${photoList.get(order).image}" , Toast.LENGTH_SHORT).show()
//        imageDetail.setImageResource(photoList.get(order))


    }
}


