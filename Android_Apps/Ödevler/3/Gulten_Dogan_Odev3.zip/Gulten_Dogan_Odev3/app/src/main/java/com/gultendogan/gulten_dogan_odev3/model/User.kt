package com.gultendogan.gulten_dogan_odev3.model

data class User (
    var first: String,
    var last: String,
    var email: String,
    var age: Int,
    var image: String
)