package com.example.odev3.models

data class User (
    var name: String,
    var image: String
)
