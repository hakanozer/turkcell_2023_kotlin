package com.kursatmemis.blog_application.models

data class CommunicationListViewItem(
    val imageViewResource: String,
    val siteInfo: String,
    val buttonTag: String,
    val buttonText: String
)