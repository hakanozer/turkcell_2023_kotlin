package com.kursatmemis.blog_application.models

data class MainListViewItem(
    var imageViewResource: Int,
    var header: String,
    var explanation: String,
    var buttonTag: String
)