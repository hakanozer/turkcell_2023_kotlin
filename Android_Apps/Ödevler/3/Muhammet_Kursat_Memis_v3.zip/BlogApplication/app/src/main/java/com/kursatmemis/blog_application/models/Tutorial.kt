package com.kursatmemis.blog_application.models

data class Tutorial(val subjectExplanation: String, val videoLink: String)
