package com.odev3.model

data class Hoby(
    val name:String?,
    val text:String?,
    val imges:String?
        )
