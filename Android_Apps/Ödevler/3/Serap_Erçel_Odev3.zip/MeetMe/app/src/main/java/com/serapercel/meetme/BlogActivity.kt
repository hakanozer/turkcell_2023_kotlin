package com.serapercel.meetme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class BlogActivity : AppCompatActivity() {
    lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blog)

        webView = findViewById(R.id.webView2)
        webView.settings.javaScriptEnabled = true
        webView.loadUrl("https://medium.com/@ercelserap/")


    }
}