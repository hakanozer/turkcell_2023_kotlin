package com.serapercel.meetme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ContactActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)
    }
}