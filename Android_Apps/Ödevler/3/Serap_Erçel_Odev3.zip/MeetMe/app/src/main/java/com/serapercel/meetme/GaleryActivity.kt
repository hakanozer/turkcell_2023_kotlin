package com.serapercel.meetme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.bumptech.glide.Glide

class GaleryActivity : AppCompatActivity() {
    lateinit var imageView1: ImageView
    lateinit var imageView2: ImageView
    lateinit var imageView3: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_galery)

        imageView1 = findViewById<ImageView>(R.id.imageView2)
        Glide.with(this)
            .load("https://raw.githubusercontent.com/sercel23/Recipes-App/main/YemekTarifleri1.png")
            .into(imageView1)
        imageView2 = findViewById<ImageView>(R.id.imageView3)
        Glide.with(this)
            .load("https://raw.githubusercontent.com/sercel23/Recipes-App/main/YemekTarifleri1.png")
            .into(imageView2)
        imageView3 = findViewById<ImageView>(R.id.imageView)
        Glide.with(this)
            .load("https://raw.githubusercontent.com/sercel23/Recipes-App/main/YemekTarifleri1.png")
            .into(imageView3)



    }
}