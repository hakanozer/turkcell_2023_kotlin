package com.sumeyra.mybio.data

import com.sumeyra.mybio.R
import com.sumeyra.mybio.model.GalleryModel


object GalleryList {

    val galleryList = arrayListOf(
        GalleryModel(1, "https://i.ibb.co/7yw6Rtf/Whats-App-Image-2023-04-12-at-23-41-43.jpg","A cold day"),
        GalleryModel(2, "https://i.ibb.co/RPf0KZp/Whats-App-Image-2023-04-28-at-02-07-46.jpg","A boring day"),
        GalleryModel(3, "https://i.ibb.co/M6T76ZX/Whats-App-Image-2023-04-28-at-02-07-47.jpg","Rice pudding"),
        GalleryModel(4, "https://i.ibb.co/ZTZfbB0/Whats-App-Image-2023-04-28-at-02-07-49-1.jpg","A day in Manisa"),
        GalleryModel(5, "https://i.ibb.co/fD8w46D/Whats-App-Image-2023-04-28-at-02-07-50.jpg","A day in Aydın"),
        GalleryModel(6, "https://i.ibb.co/4Pk1yJh/Whats-App-Image-2023-04-28-at-02-07-54-1.jpg","it is me:)"),
        GalleryModel(7, "https://i.ibb.co/QFh1CLy/Whats-App-Image-2023-04-28-at-02-07-54-3.jpg","Sahlep"),
        GalleryModel(8, "https://i.ibb.co/d7XV0y1/Whats-App-Image-2023-04-28-at-02-07-55.jpg","Time to beautify"),
        GalleryModel(9, "https://i.ibb.co/YZ0zvZV/Whats-App-Image-2023-04-28-at-02-07-54.jpg","A day in Aydın"),
        GalleryModel(10, "https://i.ibb.co/qY8tkv2/Whats-App-Image-2023-04-28-at-02-24-56.jpg","Linkedin profile"),
    )
}