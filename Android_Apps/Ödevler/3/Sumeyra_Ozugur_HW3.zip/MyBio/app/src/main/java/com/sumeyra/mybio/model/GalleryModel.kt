package com.sumeyra.mybio.model

data class GalleryModel(
    val id:Int,
    val img: String,
    val title:String
)