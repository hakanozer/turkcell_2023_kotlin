package com.example.can_karademir_biography_app.models

data class About(
    var name: String,
    var surname: String,
    var dateofbirth: String,
    var hometown: String,
    var aboutme : String,
    var h_education: String,
    var u_education: String,
    var abilities: String,
    var image: String
)
