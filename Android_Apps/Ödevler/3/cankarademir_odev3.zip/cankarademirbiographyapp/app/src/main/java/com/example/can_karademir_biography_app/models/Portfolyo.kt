package com.example.can_karademir_biography_app.models

data class Portfolyo(
    var name :String,
    var teknology : String,
    var projectDetail: String,
    var year: Int,
    var image: String
)
