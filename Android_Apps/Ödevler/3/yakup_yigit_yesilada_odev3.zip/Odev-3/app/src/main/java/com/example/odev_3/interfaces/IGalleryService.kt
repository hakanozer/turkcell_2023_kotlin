package com.example.odev_3.interfaces

import com.example.odev_3.models.GalleryItem

interface IGalleryService : IBaseService<GalleryItem>{

    override fun getDataById(id : String) : GalleryItem?
    override fun getDataList() : List<GalleryItem>
}