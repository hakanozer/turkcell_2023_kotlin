package com.example.odev_3.screens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.odev_3.adapters.CustomGalleryAdapter
import com.example.odev_3.databinding.ActivityGalleryBinding
import com.example.odev_3.interfaces.IBaseService
import com.example.odev_3.models.GalleryItem
import com.example.odev_3.services.GalleryService

class GalleryActivity : AppCompatActivity() {

    private lateinit var binding : ActivityGalleryBinding
    private lateinit var customGalleryAdapter: CustomGalleryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        GalleryService().fillGalleryItems()
        var galleryItems = GalleryService.galleryItems

        customGalleryAdapter = if(galleryItems != null){
            CustomGalleryAdapter(this,galleryItems)
        }else{
            CustomGalleryAdapter(this, listOf<GalleryItem>())
        }

        binding.galleryListView.adapter = customGalleryAdapter
    }
}