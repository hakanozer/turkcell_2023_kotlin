package com.example.yusuf_emre_cevizci_odev3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class Blog : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blog)

        val webView = findViewById<WebView>(R.id.webview)
        webView.loadUrl("https://www.linkedin.com/in/yusuf-emre-cevizci-b24ab4195/")
    }
}