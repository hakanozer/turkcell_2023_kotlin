package com.example.yusuf_emre_cevizci_odev3

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class Contact : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)

        val medium_button = findViewById<Button>(R.id.medium_btn)
        val linkedin_button = findViewById<Button>(R.id.linkedin_btn)
        val github_button = findViewById<Button>(R.id.github_btn)


        linkedin_button.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Siteye gitmek istiyor musun?")
                .setPositiveButton("Evet") { dialog, which ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/yusuf-emre-cevizci-b24ab4195/"))
                    startActivity(intent)
                }
                .setNegativeButton("Hayır") { dialog, which ->
                }
                .show()
        }


        medium_button.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Siteye gitmek istiyor musun?")
                .setPositiveButton("Evet") { dialog, which ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://medium.com/@yusuf.cevizci"))
                    startActivity(intent)
                }
                .setNegativeButton("Hayır") { dialog, which ->
                }
                .show()
        }

        github_button.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Siteye gitmek istiyor musun?")
                .setPositiveButton("Evet") { dialog, which ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/yusufemrecevizci"))
                    startActivity(intent)
                }
                .setNegativeButton("Hayır") { dialog, which ->
                }
                .show()
        }
    }



}