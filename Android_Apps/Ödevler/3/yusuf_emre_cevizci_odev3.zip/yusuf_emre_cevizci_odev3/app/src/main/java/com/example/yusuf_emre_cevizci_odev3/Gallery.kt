package com.example.yusuf_emre_cevizci_odev3

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class Gallery : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)


        val mycargit = findViewById<Button>(R.id.mycar_git)
        val spidermangit = findViewById<Button>(R.id.spiderman_git)



        mycargit.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Projeye gitmek istiyor musunuz?")
                .setPositiveButton("Evet") { dialog, which ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/yusufemrecevizci/Arac-forum-sitesi"))
                    startActivity(intent)
                }
                .setNegativeButton("Hayır") { dialog, which ->
                }
                .show()
        }

        spidermangit.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Projeye gitmek istiyor musunuz?")
                .setPositiveButton("Evet") { dialog, which ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/yusufemrecevizci/CatchTheSpiderMan"))
                    startActivity(intent)
                }
                .setNegativeButton("Hayır") { dialog, which ->
                }
                .show()
        }
    }
}