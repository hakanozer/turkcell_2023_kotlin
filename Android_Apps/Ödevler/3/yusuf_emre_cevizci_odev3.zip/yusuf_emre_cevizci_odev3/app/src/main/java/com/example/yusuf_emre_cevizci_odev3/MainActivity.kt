package com.example.yusuf_emre_cevizci_odev3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val aboutMeBtn = findViewById<Button>(R.id.aboutMe_btn)
        val galleryBtn = findViewById<Button>(R.id.gallery_btn)
        val contactBtn = findViewById<Button>(R.id.contact_btn)
        val blogBtn = findViewById<Button>(R.id.blog_btn)

        aboutMeBtn.setOnClickListener {
            val intent = Intent(this, AboutMe::class.java)
            startActivity(intent)
        }

        galleryBtn.setOnClickListener {
            val intent = Intent(this, Gallery::class.java)
            startActivity(intent)
        }

        contactBtn.setOnClickListener {
            val intent = Intent(this, Contact::class.java)
            startActivity(intent)
        }

        blogBtn.setOnClickListener {
            val intent = Intent(this, Blog::class.java)
            startActivity(intent)
        }

    }
}