package com.example.days_8

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.days_8.Result

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var listView = findViewById<ListView>(R.id.listView)

        val run = Runnable {
            Result().news() { newsList ->
                runOnUiThread {
                    val adapter = CustomListAdapter(this, newsList)
                    listView.adapter = adapter
                    listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
                        // Get the clicked News item
                        val clickedNews = newsList[position].href
                        // Start a new activity to show the details of the clicked News item
                        val intent = Intent(this, ReviewPageActivity::class.java)
                        intent.putExtra("url", clickedNews)
                        startActivity(intent)
                    }
                }
            }
        }
        Thread(run).start()





    }
}


class CustomListAdapter(var context: Context, private val items: List<News>) : BaseAdapter() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return items.size
    }

    override fun getItem(position: Int): Any {
        return items[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view = convertView
        val holder: ViewHolder

        if (view == null) {
            view = inflater.inflate(R.layout.list_item, parent, false)
            holder = ViewHolder()

            holder.itemName = view.findViewById(R.id.textView)
            holder.itemImage = view.findViewById(R.id.imageView)
            view.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }

        val item = items[position]

        holder.itemName?.text = item.title
        //glide
        Glide.with(context).load(item.img).into(holder.itemImage!!);


        return view!!
    }

    private class ViewHolder {
        var itemName: TextView? = null
        var itemImage: ImageView? = null

    }
}
