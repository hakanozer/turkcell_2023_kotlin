package com.example.days_8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class ReviewPageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_page)
        var webView=findViewById<WebView>(R.id.webView)
        webView.settings.javaScriptEnabled=true

        val bundle = intent.extras
        val url = bundle?.getString("url")
        webView.loadUrl(url!!)




    }
}