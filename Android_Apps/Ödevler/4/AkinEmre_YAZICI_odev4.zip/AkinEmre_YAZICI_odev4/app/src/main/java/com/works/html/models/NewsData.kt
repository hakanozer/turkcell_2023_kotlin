package com.works.html.models

data class NewsData(
    val title: String,
    val img: String,
    val href: String
)
