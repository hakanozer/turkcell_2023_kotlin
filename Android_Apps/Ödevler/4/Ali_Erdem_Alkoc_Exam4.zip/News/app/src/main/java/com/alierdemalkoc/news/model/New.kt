package com.alierdemalkoc.news.model

data class New(val title:String, val img:String, val href:String)
