package com.example.odev_4.models

data class News (
    val title: String,
    val img: String,
    val href: String
        )