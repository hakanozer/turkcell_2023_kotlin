package com.example.jsoupparser

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ListView
import androidx.core.view.get
import com.example.jsoupparser.adapter.NewsCustomAdapter
import com.example.jsoupparser.models.News
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    lateinit var newsList : ListView
    lateinit var newsAdapter : NewsCustomAdapter
    lateinit var list : List<News>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        newsList = findViewById(R.id.newsListview)
        MainScope().launch {
            withContext(Dispatchers.Default) {
                var result = Result()
                list = result.news()
                newsAdapter = NewsCustomAdapter(this@MainActivity,list)
            }
            newsList.adapter = newsAdapter
        }

        newsList.setOnItemClickListener {adapterView,view,position, id ->
            val newsDetailIntent = Intent(this,NewsDetail::class.java)
            var newsUrl = list.get(position).src
            newsDetailIntent.putExtra("url",newsUrl)
            startActivity(newsDetailIntent)
        }

    }


}