package com.example.jsoupparser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class NewsDetail : AppCompatActivity() {

    lateinit var newsWebView : WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_detail)

        newsWebView = findViewById(R.id.newsDetailWeb)
        val newsURL = intent.getStringExtra("url")
        if (newsURL != null) {
            newsWebView.loadUrl(newsURL)
        }
    }
}