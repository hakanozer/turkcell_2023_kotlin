package com.example.jsoupparser.adapter

import android.app.Activity
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.jsoupparser.R
import com.example.jsoupparser.models.News

class NewsCustomAdapter (private val context : Activity,private val list : List<News>) : ArrayAdapter<News>(context,
    R.layout.custom_news_listview,list){

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_news_listview,null,true)

        var news_title = rootView.findViewById<TextView>(R.id.newsTitleTextView)
        var news_img = rootView.findViewById<ImageView>(R.id.newsImageView)

        val news = list.get(position)

        news_title.text = news.title
        Glide.with(rootView).load(news.img).into(news_img)
        return rootView
    }

    override fun getItem(position: Int): News? {
        return super.getItem(position)
    }




}