package com.example.jsoupparser.models

data class News(val title:String, val img:String, val src:String)
