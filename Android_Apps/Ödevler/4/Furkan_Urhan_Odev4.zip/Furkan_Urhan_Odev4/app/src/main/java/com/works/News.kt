package com.works

data class News(val title:String, val img:String, val href:String)