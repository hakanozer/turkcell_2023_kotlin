# Project Features

<div>-Lifecycle</div>
<div>-Room</div>
<div>-Coroutines</div>
<div>-Retrofit</div>
<div>-Navigation</div>
<div>-Glide</div>

<div style="display: flex;">
<img src="https://user-images.githubusercontent.com/63645518/157669695-d3cbfb8d-e738-47ed-8838-539b645fc4dd.jpeg" width="280" height="600">
<img src="https://user-images.githubusercontent.com/63645518/157671010-57bec5dd-4bcc-4ac3-8782-cad8636b8580.jpeg" width="280" height="600">
<img src="https://user-images.githubusercontent.com/63645518/157671023-0d8737d4-79db-48c9-a2fe-7b666793dbc6.jpeg" width="280" height="600">
<img src="https://user-images.githubusercontent.com/63645518/157671040-a9b55eed-6ba2-455e-b87d-165d5607867e.jpeg" width="280" height="600">
</div>




