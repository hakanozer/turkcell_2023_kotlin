package com.gultendogan.mvvmnewsapp.models

data class Source(
    val id: String,
    val name: String
)