package com.marangoz.jsoup_sebahaddin_marangoz

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class DetailActivity : AppCompatActivity() {
    private lateinit var webView : WebView
    @SuppressLint("MissingInflatedId", "SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        webView = findViewById(R.id.webView)

        val url = intent.getStringExtra("link")
        Toast.makeText(this,url.toString(),Toast.LENGTH_SHORT).show()


        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true
        webView.loadUrl(url!!)









    }
}