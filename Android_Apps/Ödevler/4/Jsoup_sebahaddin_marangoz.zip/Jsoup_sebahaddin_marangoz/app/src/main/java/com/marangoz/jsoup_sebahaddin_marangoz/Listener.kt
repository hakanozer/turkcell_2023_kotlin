package com.marangoz.jsoup_sebahaddin_marangoz

interface Listener {

    fun finishData()


}