package com.marangoz.jsoup_sebahaddin_marangoz

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() ,Listener{
    private lateinit var listView : ListView
    private var resultList : List<News>? = null
    @OptIn(DelicateCoroutinesApi::class)
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.rv)

        val result = com.marangoz.jsoup_sebahaddin_marangoz.Result()
        result.listener = this

        resultList = result.news()


    }

    override fun finishData() {
        val customAdapter = NewsAdapter(this@MainActivity, resultList!!)
        listView.adapter = customAdapter
    }


}