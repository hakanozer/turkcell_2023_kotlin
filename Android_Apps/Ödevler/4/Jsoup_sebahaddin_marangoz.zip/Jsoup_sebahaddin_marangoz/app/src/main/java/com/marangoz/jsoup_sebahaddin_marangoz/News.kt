package com.marangoz.jsoup_sebahaddin_marangoz

data class News(val title:String, val img:String, val href:String)