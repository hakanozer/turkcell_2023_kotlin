package com.marangoz.jsoup_sebahaddin_marangoz

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.bumptech.glide.Glide
import kotlinx.coroutines.newSingleThreadContext

class NewsAdapter(private val context: Activity, var list: List<News>): ArrayAdapter<News>(context,R.layout.custom_list_item, list ) {

    @SuppressLint("ViewHolder", "InflateParams", "MissingInflatedId")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)


        val titleText = rootView.findViewById<TextView>(R.id.titleText)
        val image = rootView.findViewById<ImageView>(R.id.image)
        val itemView = rootView.findViewById<CardView>(R.id.itemView)


        val news = list[position]


        titleText.text = news.title
        Glide.with(rootView).load(news.img).into(image)

        itemView.setOnClickListener(){
            val intent = Intent(context,DetailActivity::class.java)
            intent.putExtra("link", news.href)
            context.startActivity(intent)
        }




        return rootView
    }


}