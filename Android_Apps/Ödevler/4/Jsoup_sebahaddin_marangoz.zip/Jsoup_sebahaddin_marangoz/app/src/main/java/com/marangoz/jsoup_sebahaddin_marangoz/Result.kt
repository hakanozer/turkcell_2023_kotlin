package com.marangoz.jsoup_sebahaddin_marangoz

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements

class Result {
    var listener : Listener? = null
    fun news () : List<News>  {

        val arr = mutableListOf<News>()
        val url = "https://www.haberler.com/"

       CoroutineScope(Dispatchers.IO).launch {
            val doc:Document = Jsoup.connect(url).timeout(15000).get()
            val elements:Elements = doc.getElementsByAttribute("data-headlinenumber")
            for ( item in elements) {

                //Log.d("item", item.getElementsByTag("img").toString() )
                val img = item.getElementsByTag("img")

                val href = item.attr("abs:href")
                val src = img.attr("data-src")
                val title = img.attr("alt")

                if ( title != "" && href != "" && src != "" ) {
                    val news = News(title, src, href)
                    arr.add(news)
                }

            }
           CoroutineScope(Dispatchers.Main).launch {
               listener?.finishData()
           }



        }

        return arr

    }



}
