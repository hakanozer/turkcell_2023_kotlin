package com.serapercel.seraperel_odev4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class DetailActivity : AppCompatActivity() {

    lateinit var detailWebView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val url: String = intent.getStringExtra("url")!!
        detailWebView = findViewById(R.id.webView)
        detailWebView.settings.javaScriptEnabled = true
        detailWebView.settings.allowContentAccess = true
        detailWebView.loadUrl(url)
    }
}