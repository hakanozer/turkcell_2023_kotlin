package com.serapercel.seraperel_odev4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.serapercel.seraperel_odev4.adapter.Adapter
import com.serapercel.seraperel_odev4.service.NewsService

class MainActivity : AppCompatActivity() {

    lateinit var listView: ListView
    private val newsService = NewsService()
    val newsList = newsService.newsResult()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView= findViewById(R.id.lvNews)

        val run = Runnable {
            val customAdapter = Adapter(this, newsList)
            listView.adapter = customAdapter
        }
        Thread(run).start()

        listView.setOnItemClickListener { adapterView, view, i, l ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("url", newsList[i].href)
            startActivity(intent)
        }
    }
}