package com.serapercel.seraperel_odev4.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.serapercel.seraperel_odev4.model.News
import com.serapercel.seraperel_odev4.R

class Adapter(private val context: Activity, private val list: List<News>) :
    ArrayAdapter<News>(context, R.layout.list_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.list_item, null, true)
        val image = rootView.findViewById<ImageView>(R.id.ivNews)
        val title = rootView.findViewById<TextView>(R.id.tvTitle)
        val user = list[position]
        title.text = user.title
        Glide.with(rootView).load(user.src).into(image)

        return rootView
    }
}