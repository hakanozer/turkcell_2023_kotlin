package com.serapercel.seraperel_odev4.model

data class News(val title : String , val src : String , val href : String)
