package com.sumeyra.hw4

data class NewsModel(val title:String, val img:String, val href:String)
