package com.uysal.turkcell_odev4.Adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.uysal.turkcell_odev4.News
import com.uysal.turkcell_odev4.R

class CustomAdapter(private val context: Activity, private val list: List<News>) :
    ArrayAdapter<News>(context, R.layout.custom_list_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)

        val r_image = rootView.findViewById<ImageView>(R.id.imageNews)
        val r_title = rootView.findViewById<TextView>(R.id.TextTitle)

        val user = list.get(position)

        r_title.text = user.title

        Glide.with(rootView).load(user.src).into(r_image)

        return rootView
    }
}