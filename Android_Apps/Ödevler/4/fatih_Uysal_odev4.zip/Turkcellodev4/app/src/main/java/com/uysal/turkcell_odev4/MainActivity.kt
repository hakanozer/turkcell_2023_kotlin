package com.uysal.turkcell_odev4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.uysal.turkcell_odev4.Adapter.CustomAdapter

class MainActivity : AppCompatActivity() {

    lateinit var listView:ListView
    val news = NewsService()
    val list = news.newsResult()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.ListView)


        val run = Runnable {

            val customAdapter = CustomAdapter(this , list)
            listView.adapter = customAdapter
        }
        Thread(run).start()


        listView.setOnItemClickListener { adapterView, view, i, l ->

            val intent = Intent(this , NewsDetailActivity::class.java)
            intent.putExtra("url" , list.get(i).href )
            startActivity(intent)

        }









    }
}