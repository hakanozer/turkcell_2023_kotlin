package com.uysal.turkcell_odev4

data class News(val title : String , val src : String , val href : String)
