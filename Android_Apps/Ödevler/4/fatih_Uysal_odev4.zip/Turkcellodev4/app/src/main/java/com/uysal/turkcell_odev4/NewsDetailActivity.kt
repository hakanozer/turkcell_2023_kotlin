package com.uysal.turkcell_odev4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class NewsDetailActivity : AppCompatActivity() {

    lateinit var detailWebView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_detail)
        val url : String = intent.getStringExtra("url")!!
        detailWebView = findViewById(R.id.WebView)
        detailWebView.settings.javaScriptEnabled = true
        detailWebView.settings.allowContentAccess = true
        detailWebView.loadUrl(url)



    }
}