package com.example.haberapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.widget.ListView
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    lateinit var listView : ListView
    val service = NewsService()
    lateinit var newsList : List<News>

    var policy : StrictMode.ThreadPolicy = StrictMode.ThreadPolicy.Builder().permitAll().build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        StrictMode.setThreadPolicy(policy)

        listView = findViewById(R.id.listNews)
        newsList = service.getNews()
/*
        val run = Runnable {
            newsList = service.getNews()
        }
        Thread(run).start()

 */
        val customAdapter = NewsCustomAdapter(this, newsList)
        //customAdapter.notifyDataSetChanged()
        listView.adapter = customAdapter

        listView.setOnItemClickListener { parent, view, position, id ->
            startActivity(activity_web.newWebActivity(this, newsList[position].href))
        }

    }
}