package com.example.haberapp

data class News(
    var title : String,
    var href : String,
    var image : String,
)