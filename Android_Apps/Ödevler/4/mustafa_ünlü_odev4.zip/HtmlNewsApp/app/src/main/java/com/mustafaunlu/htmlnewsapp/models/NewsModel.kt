package com.mustafaunlu.htmlnewsapp.models

data class NewsModel(
    val title: String,
    val detailLink: String,
    val image: String
)
