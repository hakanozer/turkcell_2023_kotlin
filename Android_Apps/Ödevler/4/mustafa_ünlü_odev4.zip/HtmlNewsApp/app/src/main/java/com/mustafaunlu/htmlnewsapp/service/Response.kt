package com.mustafaunlu.htmlnewsapp.service

import com.mustafaunlu.htmlnewsapp.models.NewsModel

interface Response {
    fun getNews(): List<NewsModel>
}
