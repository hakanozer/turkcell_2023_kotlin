package com.mustafaunlu.htmlnewsapp.service

import com.mustafaunlu.htmlnewsapp.models.NewsModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements

class ResponseImpl : Response {
    private val newsList = mutableListOf<NewsModel>()
    private val timeout = 15000
    private val url = "https://www.haberler.com/"

    override fun getNews(): List<NewsModel> {
        try {
            val doc: Document = runBlocking(Dispatchers.IO) {
                Jsoup.connect(url).timeout(timeout).get()
            }
            val newsHeadlines: Elements = doc.getElementsByAttribute("data-headlinenumber")

            for (headline in newsHeadlines) {
                val title = headline.attr("title")
                val detailLink = headline.attr("abs:href")
                val image = headline.getElementsByTag("img").attr("data-src")

                if (title.isNotEmpty() && detailLink.isNotEmpty() && image.isNotEmpty()) {
                    val news = NewsModel(title, detailLink, image)
                    newsList.add(news)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return newsList
    }
}
