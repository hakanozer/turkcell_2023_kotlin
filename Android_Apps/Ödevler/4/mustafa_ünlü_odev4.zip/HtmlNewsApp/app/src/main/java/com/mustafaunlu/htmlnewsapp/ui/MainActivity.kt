package com.mustafaunlu.htmlnewsapp.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.htmlnewsapp.R
import com.mustafaunlu.htmlnewsapp.service.Response
import com.mustafaunlu.htmlnewsapp.service.ResponseImpl

class MainActivity : AppCompatActivity() {
    private val response: Response = ResponseImpl()
    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.title = getString(R.string.main_activity_actionbar_title)

        recyclerView = findViewById(R.id.news_recyclerview)
        val newsList = response.getNews()
        val adapter = NewsAdapter(newsList, ::onItemClicked)
        recyclerView.adapter = adapter
    }

    private fun onItemClicked(url: String) {
        val intent = Intent(this, NewsDetailActivity::class.java)
        intent.putExtra("url", url)
        startActivity(intent)
    }
}
