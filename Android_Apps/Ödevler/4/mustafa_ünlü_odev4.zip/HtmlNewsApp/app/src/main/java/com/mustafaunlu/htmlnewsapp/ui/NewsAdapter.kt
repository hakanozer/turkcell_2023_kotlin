package com.mustafaunlu.htmlnewsapp.ui

import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.htmlnewsapp.R
import com.mustafaunlu.htmlnewsapp.models.NewsModel
import com.mustafaunlu.htmlnewsapp.utils.loadurl

class NewsAdapter(private val newsList: List<NewsModel>, private val onItemClicked: (String) -> Unit) : RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val view = View.inflate(parent.context, R.layout.listview_item, null)
        return NewsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return newsList.size
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        holder.bind(newsList[position])
    }

    inner class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val newsImage: ImageView = itemView.findViewById(R.id.news_image)
        private val newsTitle: TextView = itemView.findViewById(R.id.news_title)
        fun bind(news: NewsModel) {
            newsTitle.text = news.title
            newsImage.loadurl(news.image)
            itemView.setOnClickListener {
                onItemClicked(news.detailLink)
            }
        }
    }
}
