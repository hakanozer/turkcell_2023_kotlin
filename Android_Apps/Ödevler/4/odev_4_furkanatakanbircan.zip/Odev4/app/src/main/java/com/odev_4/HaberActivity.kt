package com.odev_4

import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class HaberActivity : AppCompatActivity() {

    lateinit var haberWebView: WebView
    var arr = mutableListOf<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_haber)


        haberWebView=findViewById(R.id.haberWebView)
        intent.getStringExtra("data")?.let {
            haberWebView.loadUrl(it)
            haberWebView.setWebViewClient(customWebViewClient())
            haberWebView.settings.javaScriptEnabled=true

        }
    }
    class customWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {

            return super.shouldOverrideUrlLoading(view, request)
        }

        override fun onPageFinished(view: WebView?, url: String?) {

            super.onPageFinished(view, url)
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {

            super.onPageStarted(view, url, favicon)
        }


    }

}