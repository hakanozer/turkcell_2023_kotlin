package com.odev_4

data class Hrefs(val href:String)
