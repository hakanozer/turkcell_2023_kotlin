package com.odev_4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.annotation.MainThread
import androidx.core.view.isNotEmpty
import com.odev_4.Result
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    lateinit var haberListView:ListView
    //lateinit var list:MutableList<News>
    //var arr= mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        haberListView=findViewById(R.id.haberListView)
        val result =Result()
        GlobalScope.launch {
            val list=result.news()
            val listHref=result.newsHref()

            this@MainActivity.runOnUiThread(java.lang.Runnable {
                try {

                    val adapterNewsList=ListHaberAdapter(context =this@MainActivity , arrayList = list)
                    haberListView.adapter=adapterNewsList
                    adapterNewsList.notifyDataSetChanged()
                    haberListView.setOnItemClickListener{ adapterView,view,i,l ->

                        var intent = Intent(this@MainActivity,HaberActivity::class.java)
                        intent.putExtra("data",listHref.get(i).href)//result.hreflifuncction olcak arr yerine
                        startActivity(intent)
                        true


                    }
                } catch (ex: Exception) {
                    ex.printStackTrace()
                }
            })
        }


        //val run = Runnable {

        /*
        GlobalScope.launch {
            val list=result.news()
            val listHref=result.newsHref()


            val adapterNewsList=ListHaberAdapter(context =this@MainActivity , arrayList = list)
            haberListView.adapter=adapterNewsList
            adapterNewsList.notifyDataSetChanged()
            haberListView.setOnItemClickListener{ adapterView,view,i,l ->

                var intent = Intent(this@MainActivity,HaberActivity::class.java)
                intent.putExtra("data",listHref.get(i))//result.hreflifuncction olcak arr yerine
                startActivity(intent)
                true


            }


        }

         */
         /*
        Log.d("test","run blocking start")
        runBlocking {
            launch {
                delay(5000)
                list = result.news()



            }

        }

         */

        /*Log.d("test","run blocking stop")
        val adapterNewsList=ListHaberAdapter(context = this, arrayList = list)
        haberListView.adapter=adapterNewsList
*/
       /* var adapterHaber=
                ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,arrHaber)
            haberListView.adapter=adapterHaber
        */


       //Thread(run).start()
    }


    }
