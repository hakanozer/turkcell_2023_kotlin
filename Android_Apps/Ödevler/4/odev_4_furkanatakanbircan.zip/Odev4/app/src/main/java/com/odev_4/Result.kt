package com.odev_4

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements

class Result {

    fun news():MutableList<News>{
        val arr= mutableListOf<News>()
        val url ="https://www.haberler.com/"
        val doc:Document = Jsoup.connect(url).timeout(150000).get()

        val elements:Elements = doc.getElementsByAttribute("data-headlinenumber")
        for (item in elements) {

            val img = item.getElementsByTag("img")

            val href = img.attr("abs:href")
            val title = img.attr("alt")
            val src = img.attr("data-src")
            if (title != " " && href != " " && src != " ") {
                val news = News(title, src, href)
                arr.add(news)
            }
        }
        return arr
    }

    fun newsHref():MutableList<Hrefs>{
        val arr1 = mutableListOf<Hrefs>()
        val url="https://www.haberler.com/"
        val doc:Document = Jsoup.connect(url).timeout(150000).get()

        val elements:Elements=doc.getElementsByAttribute("data-headlinenumber")
        for (item in elements) {
            val img = item.getElementsByTag("img")

            val href = item.attr("abs:href")

            //val src = img.attr("data-src")

            if ( href!= " " ) {

                val hrefs= Hrefs(href)
                arr1.add(hrefs)
            }
        }
        return arr1
    }

}