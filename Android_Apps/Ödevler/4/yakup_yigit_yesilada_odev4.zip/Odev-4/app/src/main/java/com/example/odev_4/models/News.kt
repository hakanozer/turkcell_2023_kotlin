package com.example.odev_4.models

data class News(
    val title : String,
    val src : String,
    val href : String,
)
