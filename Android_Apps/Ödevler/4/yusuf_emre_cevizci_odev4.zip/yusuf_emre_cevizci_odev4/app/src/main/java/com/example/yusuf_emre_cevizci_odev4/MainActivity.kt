package com.example.yusuf_emre_cevizci_odev4

import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso

class MainActivity : AppCompatActivity() {

    private lateinit var newsList: ListView
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val result = Result()
        val run = Runnable {
            val list = result.news()
            runOnUiThread {
                val adapter = object : ArrayAdapter<News>(this, R.layout.list_item_news, R.id.textView, list) {
                    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                        var view = convertView
                        if (view == null) {
                            view = LayoutInflater.from(context).inflate(R.layout.list_item_news, parent, false)
                        }
                        val titleView = view!!.findViewById<TextView>(R.id.textView)
                        val imageView = view.findViewById<ImageView>(R.id.imageView)

                        titleView.text = list[position].title
                        Picasso.get().load(list[position].img).into(imageView)

                        return view
                    }
                }
                val listView: ListView = findViewById(R.id.newsListView)
                listView.adapter = adapter

                listView.onItemClickListener =
                    AdapterView.OnItemClickListener { parent, view, position, id ->
                        val webView: WebView = findViewById(R.id.webView)
                        webView.visibility = android.view.View.VISIBLE
                        listView.visibility = android.view.View.GONE
                        webView.loadUrl(list[position].href)
                    }
            }
        }
        Thread(run).start()
    }

    override fun onBackPressed() {
        val webView: WebView = findViewById(R.id.webView)
        if (webView.visibility == android.view.View.VISIBLE && webView.canGoBack()) {
            webView.goBack()
        } else {
            webView.visibility = android.view.View.GONE
            val listView: ListView = findViewById(R.id.newsListView)
            listView.visibility = android.view.View.VISIBLE
        }
    }
}

