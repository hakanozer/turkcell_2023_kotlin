package com.example.yusuf_emre_cevizci_odev4

data class News(val title:String, val img:String, val href:String){
    override fun toString(): String {
        return title
    }
}
