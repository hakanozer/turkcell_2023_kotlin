package com.works.currency_homework.models

data class CurrencyModel(
    //val unit : String,
    val Isim : String,
    //val CurrencyName : String,
    val ForexBuying : String,
    val ForexSelling : String,
    val BanknoteBuying : String,
    val BanknoteSelling : String
)
