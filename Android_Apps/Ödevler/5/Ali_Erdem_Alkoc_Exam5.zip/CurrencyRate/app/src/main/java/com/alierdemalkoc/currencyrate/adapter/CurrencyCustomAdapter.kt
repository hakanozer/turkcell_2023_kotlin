package com.alierdemalkoc.currencyrate.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.alierdemalkoc.currencyrate.R
import com.alierdemalkoc.currencyrate.model.Currency

class CurrencyCustomAdapter (private val context: Activity, private val list: List<Currency>) : ArrayAdapter<Currency>(context, R.layout.dropdown_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.dropdown_item, null, true)

        val r_title = rootView.findViewById<TextView>(R.id.titleText)

        val currency = list.get(position)

        r_title.text = currency.Isim

        return rootView
    }

}