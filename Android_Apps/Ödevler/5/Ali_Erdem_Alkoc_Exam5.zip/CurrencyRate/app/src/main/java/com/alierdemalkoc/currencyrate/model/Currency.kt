package com.alierdemalkoc.currencyrate.model

data class Currency(
    val Isim: String,
    val ForexBuying: String,
    val ForexSelling: String,
    val BanknoteBuying: String,
    val BanknoteSelling: String,
    val DateTarih: String
){
    override fun toString(): String {
        return "$Isim"
    }
}
