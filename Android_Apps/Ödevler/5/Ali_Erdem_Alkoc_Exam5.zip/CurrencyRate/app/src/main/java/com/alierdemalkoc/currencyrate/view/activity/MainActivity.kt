package com.alierdemalkoc.currencyrate.view.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import com.alierdemalkoc.currencyrate.R
import com.alierdemalkoc.currencyrate.adapter.CurrencyCustomAdapter
import com.alierdemalkoc.currencyrate.databinding.ActivityMainBinding
import com.alierdemalkoc.currencyrate.service.CurrencyService

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    val currencyService = CurrencyService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        val customAdapter = CurrencyCustomAdapter(this, currencyService.getCurrency())
        binding.autoCompleteTextView.setAdapter(customAdapter)
        binding.autoCompleteTextView.setOnItemClickListener { adapterView, view, i, l ->
            binding.forexB.text = currencyService.getCurrency()[i].ForexBuying
            binding.forexS.text = currencyService.getCurrency()[i].ForexSelling
            binding.banknoteB.text = currencyService.getCurrency()[i].BanknoteBuying
            binding.banknoteS.text = currencyService.getCurrency()[i].BanknoteSelling
            binding.dateText.text = currencyService.getCurrency()[i].DateTarih



        }
    }
}