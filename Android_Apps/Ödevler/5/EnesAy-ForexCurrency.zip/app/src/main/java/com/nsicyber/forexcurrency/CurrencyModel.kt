package com.nsicyber.forexcurrency

data class CurrencyModel(
    val Name:String,
    val ForexBuying:String,
    val ForexSelling:String,
    val BankSelling:String,
    val BankBuying:String
)
