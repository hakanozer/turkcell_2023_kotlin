package com.nsicyber.forexcurrency

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements

class CurrencyService {

    fun getCurrency () : Map<*,*>{
        var date=""
        val arr = mutableListOf<CurrencyModel>()
        val url = "https://www.tcmb.gov.tr/kurlar/today.xml"
        val doc: Document = Jsoup.connect(url).timeout(15000).ignoreContentType(true).get()
        val elements: Elements = doc.getElementsByTag("Tarih_Date")
        for ( item in elements ) {
            val tempDate = item.attr("Tarih").toString()
            date = tempDate
            val COMMON = item.getElementsByTag("Currency")
            COMMON.forEach{
                val Name = it.getElementsByTag("CurrencyName").text()
                val ForexBuy = it.getElementsByTag("ForexBuying").text()
                val ForexSell = it.getElementsByTag("ForexSelling").text()
                val BankBuy = it.getElementsByTag("BanknoteBuying").text()
                val BankSell = it.getElementsByTag("BanknoteSelling").text()
               val currency = CurrencyModel(Name = Name, ForexBuying = ForexBuy, ForexSelling = ForexSell, BankSelling = BankSell, BankBuying = BankBuy)
               arr.add(currency)

            }

        }
        return mapOf("data" to arr,"date" to date)
    }


}