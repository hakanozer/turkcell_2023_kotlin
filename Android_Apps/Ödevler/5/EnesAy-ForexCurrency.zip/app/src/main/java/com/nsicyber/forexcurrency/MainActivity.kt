package com.nsicyber.forexcurrency

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.util.AttributeSet
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import com.nsicyber.forexcurrency.databinding.ActivityMainBinding
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        FetchCurrencyTask().execute()
    }




fun activeCopyClick(view:TextView){
    view.setOnClickListener {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Copied Text", view.text.toString())
        clipboard.setPrimaryClip(clip) }
}

    private inner class FetchCurrencyTask : AsyncTask<Void, Void, List<CurrencyModel>>() {
        override fun doInBackground(vararg params: Void?): List<CurrencyModel> {
            val xml = CurrencyService()
            var data=xml.getCurrency()
            binding.button.text=data["date"].toString()
            return data["data"] as List<CurrencyModel>
        }

        override fun onPostExecute(result: List<CurrencyModel>?) {
            super.onPostExecute(result)

            result?.let { arr ->
                for (item in arr) {
                    Log.d("item", item.Name)
                    Log.d("item", item.BankBuying)
                }

                val popupMenu = PopupMenu(this@MainActivity, binding.button)

                for (obj in arr) {
                    popupMenu.menu.add(obj.Name)
                }

                popupMenu.setOnMenuItemClickListener { menuItem ->


                    val objName = menuItem.title.toString()
                    val selectedObj = arr.find { obj -> obj.Name == objName }
                    binding.forexBuy.text = selectedObj?.ForexBuying ?: "No Data"
                    binding.forexSell.text = selectedObj?.ForexSelling ?: "No Data"
                    binding.bankBuy.text = selectedObj?.BankBuying ?: "No Data"
                    binding.bankSell.text = selectedObj?.BankSelling ?: "No Data"
                    binding.currencyName.text=selectedObj?.Name
                    activeCopyClick(binding.forexBuy)
                    activeCopyClick(binding.forexSell)
                    activeCopyClick(binding.bankBuy)
                    activeCopyClick(binding.bankSell)



                    true
                }



                binding.button.setOnClickListener { popupMenu.show() }
            }
        }
    }





}
