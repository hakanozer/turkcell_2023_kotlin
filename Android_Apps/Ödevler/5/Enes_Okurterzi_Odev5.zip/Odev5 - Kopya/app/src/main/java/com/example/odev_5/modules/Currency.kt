package com.example.odev_5.modules

data class Currency (
    val Isim: String,
    val CurrencyName: String,
    val ForexBuying: String,
    val ForexSelling: String,
    val BanknoteBuying: String,
    val BanknoteSelling: String,
)