package com.example.jsoupxmlparser.model

data class Currency(
    val currencyName : String,
    val forexBuying : String,
    val forexSelling : String,
    val banknoteBuying : String,
    val banknoteSelling : String,
)
