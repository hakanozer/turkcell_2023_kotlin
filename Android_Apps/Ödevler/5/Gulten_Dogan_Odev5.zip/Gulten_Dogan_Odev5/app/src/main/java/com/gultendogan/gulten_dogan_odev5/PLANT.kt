package com.gultendogan.gulten_dogan_odev5

data class PLANT(
    val COMMON:String,
    val BOTANICAL:String,
    val ZONE:String,
    val LIGHT:String,
    val PRICE:String,
)