package com.serapercel.dovizkuru.model

data class Currency(
    val Isim: String,
    val CurrencyName: String,
    val ForexBuying: String,
    val ForexSelling: String,
    val BanknoteBuying: String,
    val BanknoteSelling: String
    )
