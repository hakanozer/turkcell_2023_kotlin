package com.cankarademir.cankarademir_odev5.models

data class Currency(
    val Isim:String,
    val ForexBuying:String,
    val ForexSelling:String,
    val BanknoteBuying:String,
    val BanknoteSelling:String,
)