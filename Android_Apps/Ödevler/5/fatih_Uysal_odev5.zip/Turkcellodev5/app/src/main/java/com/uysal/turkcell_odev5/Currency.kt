package com.uysal.turkcell_odev5

data class Currency(
    val name : String,
    val forexBuying : String,
    val forexSelling : String,
    val banknoteBuying : String,
    val banknoteSelling : String
)
