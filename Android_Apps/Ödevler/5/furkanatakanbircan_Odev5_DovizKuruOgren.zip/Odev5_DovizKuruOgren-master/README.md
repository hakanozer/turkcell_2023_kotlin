# Odev5_DovizKuruOgren
## T.C. Merkez Bankasından alınan Döviz Fiyatlarını Gösterir.
![appPhoto](https://github.com/atakanbircan/Odev5_DovizKuruOgren/blob/master/app/src/main/res/drawable/third.jpeg)
![appPhoto](https://github.com/atakanbircan/Odev5_DovizKuruOgren/blob/master/app/src/main/res/drawable/first.jpeg)
![appPhoto](https://github.com/atakanbircan/Odev5_DovizKuruOgren/blob/master/app/src/main/res/drawable/second.jpeg)
