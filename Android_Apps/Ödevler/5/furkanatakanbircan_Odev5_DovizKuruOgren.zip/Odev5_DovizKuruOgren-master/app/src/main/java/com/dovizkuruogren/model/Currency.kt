package com.dovizkuruogren.model

data class Currency(
    val isim:String,
    val forexBuying:String,
    val forexSelling:String,
    val banknoteBuying:String,
    val banknoteSelling:String
)
