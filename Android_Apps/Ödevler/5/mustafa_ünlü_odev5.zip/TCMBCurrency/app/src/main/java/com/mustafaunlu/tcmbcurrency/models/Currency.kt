package com.mustafaunlu.tcmbcurrency.models

data class Currency(
    val currencyCode: String,
    val unit: String,
    val isim: String,
    val currencyName: String,
    val forexBuying: String,
    val forexSelling: String,
    val banknoteBuying: String,
    val banknoteSelling: String,
    val crossRateUSD: String,
    val crossRateOther: String,
)
