package com.mustafaunlu.tcmbcurrency.models

data class TarihDate(
    val currency: List<Currency>,
    val tarih: String,
    val date: String,
    val bultenNo: String,
)
