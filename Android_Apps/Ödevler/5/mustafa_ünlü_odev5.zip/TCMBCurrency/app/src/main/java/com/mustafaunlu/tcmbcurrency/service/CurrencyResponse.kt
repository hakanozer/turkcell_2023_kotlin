package com.mustafaunlu.tcmbcurrency.service

import com.mustafaunlu.tcmbcurrency.models.Currency
import com.mustafaunlu.tcmbcurrency.models.TarihDate
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements

class CurrencyResponse {
    private val currencyList = mutableListOf<Currency>()
    private lateinit var doc: Document
    fun getCurrencyResponse(): TarihDate {
        val url = "https://www.tcmb.gov.tr/kurlar/today.xml"
        val timeout = 15000
        doc =
            runBlocking(kotlinx.coroutines.Dispatchers.IO) {
                Jsoup.connect(url).timeout(timeout).ignoreContentType(true).get()
            }
        val tarihDateElements = doc.getElementsByTag("Tarih_Date")

        val currencyResponse = TarihDate(
            getCurrencyList(),
            tarihDateElements.attr("Tarih"),
            tarihDateElements.attr("Date"),
            tarihDateElements.attr("Bulten_No"),

        )
        return currencyResponse
    }

    private fun getCurrencyList(): List<Currency> {
        val currencyElements: Elements = doc.getElementsByTag("Currency")
        for (element in currencyElements) {
            val currencyCode = element.attr("CurrencyCode")
            val unit = element.getElementsByTag("Unit").text()
            val isim = element.getElementsByTag("Isim").text()
            val currencyName = element.getElementsByTag("CurrencyName").text()
            val forexBuying = element.getElementsByTag("ForexBuying").text()
            val forexSelling = element.getElementsByTag("ForexSelling").text()
            val banknoteBuying = element.getElementsByTag("BanknoteBuying").text()
            val banknoteSelling = element.getElementsByTag("BanknoteSelling").text()
            val crossRateUSD = element.getElementsByTag("CrossRateUSD").text()
            val crossRateOther = element.getElementsByTag("CrossRateOther").text()
            val currency = Currency(
                currencyCode,
                unit,
                isim,
                currencyName,
                forexBuying,
                forexSelling,
                banknoteBuying,
                banknoteSelling,
                crossRateUSD,
                crossRateOther,
            )
            currencyList.add(currency)
        }
        return currencyList
    }
}
