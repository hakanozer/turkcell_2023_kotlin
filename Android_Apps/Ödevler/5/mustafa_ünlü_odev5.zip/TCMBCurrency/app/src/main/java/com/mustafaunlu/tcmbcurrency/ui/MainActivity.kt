package com.mustafaunlu.tcmbcurrency.ui

import android.os.Bundle
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import com.mustafaunlu.tcmbcurrency.R
import com.mustafaunlu.tcmbcurrency.databinding.ActivityMainBinding
import com.mustafaunlu.tcmbcurrency.service.CurrencyResponse

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var selectedCurrency: String

    private val response = CurrencyResponse().getCurrencyResponse()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = getString(R.string.actionbar_title)
        binding.dateInfo.text = getString(R.string.date_info, response.tarih)

        binding.dovizKurSecBtn.setOnClickListener {
            showPopup(it)
        }
    }

    private fun showPopup(view: View) {
        val popup = PopupMenu(this, view)
        val inflater: MenuInflater = popup.menuInflater
        inflater.inflate(R.menu.menu_item, popup.menu)
        response.currency.forEach {
            popup.menu.add(it.isim)
        }
        popup.show()

        popup.setOnMenuItemClickListener(::popUpClickListenerLogic)
    }

    private fun popUpClickListenerLogic(item: MenuItem?): Boolean {
        selectedCurrency = item?.title.toString()
        val selectedCurrencyObject = response.currency.find { it.isim == selectedCurrency }

        selectedCurrencyObject?.let {
            binding.apply {
                dovizKurSecBtn.text = selectedCurrency
                spAlisFiyat.text = getPriceString(selectedCurrencyObject.forexBuying)
                spSatisFiyat.text = getPriceString(selectedCurrencyObject.forexSelling)
                bankaAlisFiyat.text = getPriceString(selectedCurrencyObject.banknoteBuying)
                bankaSatisFiyat.text = getPriceString(selectedCurrencyObject.banknoteSelling)
            }
        }

        return true
    }
    private fun getPriceString(price: String): String {
        return if (price.isEmpty()) {
            getString(R.string.fiyat_yok)
        } else {
            getString(R.string.tl_form, price)
        }
    }
}
