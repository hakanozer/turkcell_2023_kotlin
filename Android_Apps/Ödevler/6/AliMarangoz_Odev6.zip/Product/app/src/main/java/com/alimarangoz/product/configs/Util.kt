package com.alimarangoz.product.configs

import com.alimarangoz.product.models.Data

class Util {
    companion object {
        var user: Data? = null
    }
}