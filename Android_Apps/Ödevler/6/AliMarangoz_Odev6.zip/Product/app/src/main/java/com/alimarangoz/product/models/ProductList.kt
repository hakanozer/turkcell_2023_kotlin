package com.alimarangoz.product.models

data class ProductList(
    val products: List<Product>
)
