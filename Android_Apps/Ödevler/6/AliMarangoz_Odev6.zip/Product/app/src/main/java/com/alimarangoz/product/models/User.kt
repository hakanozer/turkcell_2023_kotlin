package com.alimarangoz.product.models

data class User(
    val username: String,
    val password: String
)
