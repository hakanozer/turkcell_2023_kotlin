package com.alierdemalkoc.products.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Gallery
import android.widget.ImageView
import android.widget.TextView
import com.alierdemalkoc.products.R
import com.alierdemalkoc.products.model.Products
import com.bumptech.glide.Glide

class ProductsCustomAdapter(private val context: Activity, private val list: List<Products>) : ArrayAdapter<Products>(context, R.layout.custom_grid_item, list)
{
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_grid_item, null, true)

        val r_title = rootView.findViewById<TextView>(R.id.item_name)
        val r_price = rootView.findViewById<TextView>(R.id.item_price)
        val r_image = rootView.findViewById<ImageView>(R.id.grid_image)

        val product = list.get(position)

        r_title.text = "${product.title}"
        r_price.text = "${product.price}"
        Glide.with(rootView)
            .load(product.thumbnail)
            .centerCrop()
            .into(r_image)

        return rootView
    }
}