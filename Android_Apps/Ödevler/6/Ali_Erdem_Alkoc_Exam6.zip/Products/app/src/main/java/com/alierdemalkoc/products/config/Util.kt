package com.alierdemalkoc.products.config

import com.alierdemalkoc.products.model.UserDetail

class Util {
    companion object {
        var user:UserDetail? = null
    }
}