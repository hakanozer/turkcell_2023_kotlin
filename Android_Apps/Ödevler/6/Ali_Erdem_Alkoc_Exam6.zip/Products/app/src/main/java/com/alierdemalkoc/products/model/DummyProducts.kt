package com.alierdemalkoc.products.model

data class DummyProducts (
    val products: List<Products>,
    val total: Long,
    val skip: Long,
    val limit: Long
)
