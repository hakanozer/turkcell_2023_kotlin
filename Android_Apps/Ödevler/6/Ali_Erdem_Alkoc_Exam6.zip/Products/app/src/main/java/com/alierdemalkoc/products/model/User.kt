package com.alierdemalkoc.products.model

data class User(
    val username: String,
    val password: String
)
