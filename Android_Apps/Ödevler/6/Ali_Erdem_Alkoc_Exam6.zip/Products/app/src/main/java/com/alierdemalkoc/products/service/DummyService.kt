package com.alierdemalkoc.products.service

import com.alierdemalkoc.products.model.DummyProducts
import com.alierdemalkoc.products.model.Products
import com.alierdemalkoc.products.model.User
import com.alierdemalkoc.products.model.UserDetail
import retrofit2.Call
import retrofit2.http.*

interface DummyService {

    @GET("products/search")
    fun search(@Query("q") query: String) : Call<DummyProducts>

    @GET("products")
    fun getProducts(@Query("limit") limit: Int): Call<DummyProducts>

    @POST("/auth/login")
    fun login( @Body user: User): Call<UserDetail>

    @GET("products/{id}")
    fun singleProduct( @Path("id") id: Int ) : Call<Products>

}