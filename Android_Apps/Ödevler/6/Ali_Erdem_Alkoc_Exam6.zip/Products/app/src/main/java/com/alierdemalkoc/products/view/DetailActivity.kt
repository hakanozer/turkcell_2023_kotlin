package com.alierdemalkoc.products.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import com.alierdemalkoc.products.R
import com.alierdemalkoc.products.config.ApiClient
import com.alierdemalkoc.products.model.Products
import com.alierdemalkoc.products.service.DummyService
import com.bumptech.glide.Glide
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    lateinit var productTitle: TextView
    lateinit var stock: TextView
    lateinit var price: TextView
    lateinit var productImage: ImageView
    lateinit var category: TextView
    lateinit var dummyService: DummyService
    var productList = mutableListOf<Products>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        productTitle = findViewById(R.id.productTitle)
        stock = findViewById(R.id.stockText)
        price = findViewById(R.id.priceText)
        category = findViewById(R.id.categoryText)
        productImage = findViewById(R.id.productImage)

        dummyService = ApiClient.getClient().create(DummyService::class.java)


        val intent = getIntent()
        val id = intent.getIntExtra("productId",0)
        dummyService.singleProduct(id).enqueue(object: Callback<Products>{
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                val product = response.body()
                if (product != null) {
                    productTitle.text = product.title
                    stock.text = product.stock.toString()
                    price.text = product.price.toString()
                    category.text = product.category
                    Glide.with(this@DetailActivity)
                        .load(product.thumbnail)
                        .centerCrop()
                        .into(productImage)
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.d("Detail Error", t.toString())
            }

        })

    }
}