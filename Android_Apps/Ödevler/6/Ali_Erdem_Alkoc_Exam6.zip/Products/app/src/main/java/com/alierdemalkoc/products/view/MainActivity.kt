package com.alierdemalkoc.products.view

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import com.alierdemalkoc.products.R
import com.alierdemalkoc.products.config.ApiClient
import com.alierdemalkoc.products.config.Util
import com.alierdemalkoc.products.model.User
import com.alierdemalkoc.products.model.UserDetail
import com.alierdemalkoc.products.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var dummyService: DummyService
    lateinit var username: EditText
    lateinit var password: EditText
    lateinit var loginButton: Button

    lateinit var sharedPreferences: SharedPreferences
    lateinit var editor: SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("users", MODE_PRIVATE)
        editor = sharedPreferences.edit()

        username = findViewById(R.id.usernameText)
        password = findViewById(R.id.passwordText)
        loginButton = findViewById(R.id.loginButton)
        val usernameSP = sharedPreferences.getString("username", "")
        username.setText(usernameSP)

        dummyService = ApiClient.getClient().create(DummyService::class.java)
        loginButton.setOnClickListener {
            if (username.text.isNotEmpty() || password.text.isNotEmpty()){
                val user = User(username.text.toString(),password.text.toString())
                dummyService.login(user).enqueue(object: Callback<UserDetail>{
                    override fun onResponse(
                        call: Call<UserDetail>,
                        response: Response<UserDetail>
                    ) {
                        val user = response.body()
                        if (user != null){
                            Util.user = user

                            editor.putString("username", user.username)
                        }
                        val intent = Intent(this@MainActivity, ProductsActivity::class.java)
                        startActivity(intent)
                        finish()
                    }

                    override fun onFailure(call: Call<UserDetail>, t: Throwable) {
                        Log.d("Login error", t.toString())
                    }

                })
            }
        }

    }
}