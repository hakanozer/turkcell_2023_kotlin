package com.alierdemalkoc.products.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.TextView
import com.alierdemalkoc.products.R
import com.alierdemalkoc.products.adapter.ProductsCustomAdapter
import com.alierdemalkoc.products.config.ApiClient
import com.alierdemalkoc.products.model.DummyProducts
import com.alierdemalkoc.products.model.Products
import com.alierdemalkoc.products.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductsActivity : AppCompatActivity() {
    lateinit var gridView: GridView
    lateinit var dummyService: DummyService
    var productList = mutableListOf<Products>()
    var productListUpdate = mutableListOf<Products>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)

        gridView = findViewById(R.id.productsGrid)
        var searchButton = findViewById<Button>(R.id.searchButton)
        var searchText = findViewById<EditText>(R.id.searchText)
        var productsTitle = findViewById<TextView>(R.id.productsTitle)

        dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.getProducts(10).enqueue(object: Callback<DummyProducts>{
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                for(product in response.body()!!.products){
                    productList.add(product)
                }
                val customAdapter = ProductsCustomAdapter(this@ProductsActivity, productList)
                gridView.adapter = customAdapter
                gridView.setOnItemClickListener { adapterView, view, i, l ->
                    val intent = Intent(this@ProductsActivity, DetailActivity::class.java)
                    intent.putExtra("id", productList[i].id)
                    startActivity(intent)
                }
            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                Log.d("Error", "${t}")
            }

        })

        searchButton.setOnClickListener {
            val search = searchText.text.toString()
            dummyService.search(search).enqueue(object: Callback<DummyProducts>{
                override fun onResponse(
                    call: Call<DummyProducts>,
                    response: Response<DummyProducts>
                ) {
                    for(product in response.body()!!.products){
                        productListUpdate.add(product)
                    }
                    val customUpdateAdapter = ProductsCustomAdapter(this@ProductsActivity, productListUpdate)
                    gridView.adapter = customUpdateAdapter
                    gridView.setOnItemClickListener { adapterView, view, i, l ->
                        val intent = Intent(this@ProductsActivity, DetailActivity::class.java)
                        intent.putExtra("id", productListUpdate[i].id)
                        startActivity(intent)
                    }
                }

                override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                    Log.d("Error", "${t}")
                }

            })
        }

    }
}