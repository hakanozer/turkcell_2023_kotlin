package com.emirk.emirkarabeyodev6.configs

import com.emirk.emirkarabeyodev6.model.JWTData

class Util {

    companion object {
        var user: JWTData? = null
    }

}