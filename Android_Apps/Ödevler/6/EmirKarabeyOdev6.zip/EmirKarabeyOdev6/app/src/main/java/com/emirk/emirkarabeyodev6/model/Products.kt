package com.emirk.emirkarabeyodev6.model

data class Products (
    val products : List<Product>
)