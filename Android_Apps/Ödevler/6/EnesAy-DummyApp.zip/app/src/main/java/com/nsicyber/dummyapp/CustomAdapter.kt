package com.nsicyber.dummyapp

class CustomAdapter {
}