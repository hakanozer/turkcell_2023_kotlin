package com.nsicyber.dummyapp.activities

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nsicyber.dummyapp.R
import com.nsicyber.dummyapp.databinding.ActivityDetailBinding
import com.nsicyber.dummyapp.databinding.ActivityMainBinding
import com.nsicyber.dummyapp.models.ProductModel

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        val view = binding.root

        setContentView(view)
        val bundle = intent.extras
        val myData = bundle?.getString("data")

        var product= Gson().fromJson<ProductModel>(myData, object : TypeToken<ProductModel>() {}.type)

        binding.titleText.text=product.title
        binding.priceText.text="₺ "+product.price.toString()
        binding.stockText.text="Stock: "+product.stock.toString()
        binding.ratingText.text="Rating: "+product.rating.toString()
        Glide.with(this).load(product.thumbnail).into(binding.thumbnail)
        binding.description.text=product.description

        binding.recyclerView.layoutManager = StaggeredGridLayoutManager(1,RecyclerView.VERTICAL)
        binding.recyclerView.adapter = GalleryAdapter(product.images!!,this)
    }
}

class GalleryAdapter(private val myList: List<String>,var context: Context) : RecyclerView.Adapter<PhotoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.gallery_item, parent, false)
        return PhotoViewHolder(view,myList,context)
    }


    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val currentItem = myList[position]
        Glide.with(context)
            .load(currentItem)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .into(holder.image)
    }


    override fun getItemCount() = myList.size
}

class PhotoViewHolder(itemView: View, list: List<String>, context: Context) : RecyclerView.ViewHolder(itemView) {
    val image: ImageView = itemView.findViewById(R.id.imageView)
}
