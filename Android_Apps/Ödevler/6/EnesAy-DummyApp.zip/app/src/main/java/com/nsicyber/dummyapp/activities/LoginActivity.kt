package com.nsicyber.dummyapp.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.nsicyber.dummyapp.R
import com.nsicyber.dummyapp.databinding.ActivityDetailBinding
import com.nsicyber.dummyapp.databinding.ActivityLoginBinding
import com.nsicyber.dummyapp.models.LoginRequest
import com.nsicyber.dummyapp.models.LoginResponse
import com.nsicyber.dummyapp.models.ProductModel
import com.nsicyber.dummyapp.models.ProductResponse
import com.nsicyber.dummyapp.network.RetrofitCallback
import com.nsicyber.dummyapp.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.button.setOnClickListener {
            val username = binding.usernameText.text.toString()
            val password = binding.passwordText.text.toString()

            // Check if username and password are not empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            } else {
getData(LoginRequest().apply {
    this.password=password
    this.username=username
})
            }

            }




    }
    fun getData(body:LoginRequest) {
        val call = RetrofitClient.retrofitInterface(this).login(body)
        call.enqueue(RetrofitCallback(this, object : Callback<LoginResponse?> {

            override fun onResponse(
                call: Call<LoginResponse?>,
                response: Response<LoginResponse?>
            ) {
                if (response.code() == 200) {

                   println(response.body())
                    val intent = Intent(this@LoginActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }

            override fun onFailure(call: Call<LoginResponse?>, t: Throwable) {
                Toast.makeText(this@LoginActivity, t.message, Toast.LENGTH_SHORT).show()
            }

        }))
    }





}