package com.nsicyber.dummyapp.activities

import android.content.Context
import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.nsicyber.dummyapp.R
import com.nsicyber.dummyapp.databinding.ActivityMainBinding
import com.nsicyber.dummyapp.models.ProductModel
import com.nsicyber.dummyapp.models.ProductResponse
import com.nsicyber.dummyapp.network.RetrofitCallback
import com.nsicyber.dummyapp.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    var products: ArrayList<ProductModel>? = arrayListOf()

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root

        setContentView(view)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        getData()
    }



    fun configureProducts() {

        val adapter = MyAdapter(products!!, this)
        binding.recyclerView.adapter = adapter
        adapter.notifyDataSetChanged()

        binding.button.setOnClickListener {
            if(binding.searchText.text.toString()=="")
            {
                adapter.clear()
                getData()
            }
            else{
                adapter.clear()
                searchData(binding.searchText.text.toString())

            }
        }
    }


    fun getData() {
        val call = RetrofitClient.retrofitInterface(this).getProductsWithLimit(10)
        call.enqueue(RetrofitCallback(this, object : Callback<ProductResponse?> {

            override fun onResponse(
                call: Call<ProductResponse?>,
                response: Response<ProductResponse?>
            ) {
                if (response.code() == 200) {

                    products = response.body()?.products as ArrayList<ProductModel>
                    configureProducts()
                }
            }

            override fun onFailure(call: Call<ProductResponse?>, t: Throwable) {
                Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_SHORT).show()
            }

        }))
    }

    fun searchData(key:String) {
        val call = RetrofitClient.retrofitInterface(this).searchProducts(key)
        call.enqueue(RetrofitCallback(this, object : Callback<ProductResponse?> {

            override fun onResponse(
                call: Call<ProductResponse?>,
                response: Response<ProductResponse?>
            ) {
                if (response.code() == 200) {

                    products = response.body()?.products as ArrayList<ProductModel>
                    configureProducts()
                }
            }

            override fun onFailure(call: Call<ProductResponse?>, t: Throwable) {
                Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_SHORT).show()
            }

        }))
    }


}


class MyAdapter(private val dataList: ArrayList<ProductModel>, var context: Context) :
    RecyclerView.Adapter<MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.product_item, parent, false)
        return MyViewHolder(itemView, context)
    }

    fun add(myObject: ProductModel) {
        dataList.add(myObject)
        notifyItemInserted(dataList.size - 1)
    }

    // clear() metodu
    fun clear() {
        dataList.clear()
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(dataList[position])
    }

    override fun getItemCount() = dataList.size
}

class MyViewHolder(itemView: View, var context: Context) : RecyclerView.ViewHolder(itemView) {


    fun bind(product: ProductModel) {
        itemView.setOnClickListener {

            val bundle = Bundle()
            bundle.putString("data", Gson().toJson(product))

            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtras(bundle)

            context.startActivity(intent)

        }
        var imageView: ImageView = itemView.findViewById(R.id.imageView)
        var titleText: TextView = itemView.findViewById(R.id.titleText)
        var priceText: TextView = itemView.findViewById(R.id.priceText)

        Glide.with(context).load(product.thumbnail).into(imageView)
        titleText.text = product.title
        priceText.text = product.price.toString()


    }
}