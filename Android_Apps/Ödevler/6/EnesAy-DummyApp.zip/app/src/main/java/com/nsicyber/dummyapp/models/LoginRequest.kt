package com.nsicyber.dummyapp.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class LoginRequest  : Serializable {


        @SerializedName("username")
        var username: String? = null

        @SerializedName("password")
        var password: String? = null



}