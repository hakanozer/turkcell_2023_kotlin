package com.nsicyber.dummyapp.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ProductResponse  : Serializable {

        @SerializedName("products")
        val products: List<ProductModel>? = null

        @SerializedName("total")
        val total: String? = null

        @SerializedName("skip")
        val skip: String? = null

        @SerializedName("limit")
        val limit: String? = null






}