package com.nsicyber.dummyapp.network

import com.nsicyber.dummyapp.models.LoginRequest
import com.nsicyber.dummyapp.models.LoginResponse
import com.nsicyber.dummyapp.models.ProductResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface RetrofitInterface {


    @POST("/auth/login")
    @Headers(
        "Accept: application/json",
        "Content-Type: application/json"
    )
    fun login(@Body body: LoginRequest): Call<LoginResponse>


    @GET("/products")
    fun getProductsWithLimit(
        @Query("limit") limit: Int?
    ): Call<ProductResponse>


    @GET("/products/search")
    fun searchProducts(
        @Query("q") searchKey: String?
    ): Call<ProductResponse>



    @GET("/products/{productId}")
    fun getProduct(
        @Path(value = "productId") productId: Int?
    ): Call<ProductResponse>






}
