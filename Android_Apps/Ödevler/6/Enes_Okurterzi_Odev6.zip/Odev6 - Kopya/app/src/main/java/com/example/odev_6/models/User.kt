package com.example.odev_6.models

data class User(
    val username: String,
    val password: String
)
