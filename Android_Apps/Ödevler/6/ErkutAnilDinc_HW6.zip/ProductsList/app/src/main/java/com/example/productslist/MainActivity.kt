package com.example.productslist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView.OnItemClickListener
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.example.productslist.adapter.ProductAdapter
import com.example.productslist.configs.ApiClient
import com.example.productslist.models.DummyProduct
import com.example.productslist.models.Product
import com.example.productslist.services.DummyJsonService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var dummyService: DummyJsonService
    lateinit var productListView: ListView
    lateinit var searchEditText: EditText
    lateinit var searchButton: Button
    var list = ArrayList<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        productListView = findViewById(R.id.productListView)
        dummyService = ApiClient.getClient().create(DummyJsonService::class.java)
        searchEditText = findViewById(R.id.searchEditText)
        searchButton = findViewById(R.id.searchBtn)

        dummyService.getTenProducts().enqueue(object : Callback<DummyProduct> {

            override fun onResponse(call: Call<DummyProduct>, response: Response<DummyProduct>) {
                val data = response.body()
                if (data != null) {
                    list.addAll(data.products)
                    val adapter = ProductAdapter(this@MainActivity, list)
                    productListView.adapter = adapter
                    productListView.setOnItemClickListener { adapterView, view, position, id ->
                        intent = Intent(this@MainActivity, ProductDetail::class.java)
                        intent.putExtra("title", list.get(position).title)
                        intent.putExtra("price", list.get(position).price.toString())
                        intent.putExtra("img", list.get(position).images.get(0))
                        intent.putExtra("description", list.get(position).description)
                        intent.putExtra("rating", list.get(position).rating.toString())
                        startActivity(intent)
                    }
                }
            }

            override fun onFailure(call: Call<DummyProduct>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Internet or Server Fail", Toast.LENGTH_LONG)
                    .show()
            }
        })


        searchButton.setOnClickListener {
            var searchItem = searchEditText.text.toString()
            dummyService.search(searchItem).enqueue(object : Callback<DummyProduct> {
                override fun onResponse(
                    call: Call<DummyProduct>,
                    response: Response<DummyProduct>
                ) {
                    val data = response.body()
                    if (data != null) {
                        list.clear()
                        list.addAll(data.products)
                        val adapter = ProductAdapter(this@MainActivity, list)
                        productListView.adapter = adapter
                        productListView.setOnItemClickListener { adapterView, view, position, id ->
                            intent = Intent(this@MainActivity, ProductDetail::class.java)
                            intent.putExtra("title", list.get(position).title)
                            intent.putExtra("price", list.get(position).price.toString())
                            intent.putExtra("img", list.get(position).images.get(0))
                            intent.putExtra("description", list.get(position).description)
                            intent.putExtra("rating", list.get(position).rating.toString())
                            startActivity(intent)
                        }
                    }
                }

                override fun onFailure(call: Call<DummyProduct>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Internet or Server Fail", Toast.LENGTH_LONG)
                        .show()
                }
            })
        }

    }

}