package com.example.productslist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import org.w3c.dom.Text

class ProductDetail : AppCompatActivity() {

    lateinit var productTitleText : TextView
    lateinit var productRatingText : TextView
    lateinit var productDescriptionText : TextView
    lateinit var productPriceText : TextView
    lateinit var productImgView : ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        var productTitle = intent.getStringExtra("title")
        var productPrice = intent.getStringExtra("price")
        var productRating = intent.getStringExtra("rating")
        var productDescription = intent.getStringExtra("description")
        var productImg = intent.getStringExtra("img")

        productTitleText = findViewById(R.id.productTitleText)
        productRatingText = findViewById(R.id.productRatingText)
        productDescriptionText = findViewById(R.id.productDescriptionText)
        productPriceText = findViewById(R.id.productPriceText)
        productImgView = findViewById(R.id.productImageView)

        productTitleText.text = productTitle
        productRatingText.text = productRating
        productPriceText.text = productPrice + "$"
        productDescriptionText.text = productDescription
        Glide.with(this).load(productImg).into(productImgView)
    }
}