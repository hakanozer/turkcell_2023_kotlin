package com.example.productslist.models

data class User(val username: String, val password: String)
