package com.example.productslist.services

import com.example.productslist.models.DummyProduct
import retrofit2.Call
import com.example.productslist.models.User
import com.example.productslist.models.UserInfo
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface DummyJsonService {

    @POST("/auth/login")
    fun login(@Body user : User) : Call<UserInfo>

    @GET("/products?limit=10")
    fun getTenProducts() : Call<DummyProduct>

    @GET("/products/search")
    fun search(@Query("q") product : String) : Call<DummyProduct>
}