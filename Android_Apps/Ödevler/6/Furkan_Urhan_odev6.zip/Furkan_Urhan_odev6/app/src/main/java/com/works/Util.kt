package com.works

import com.works.data.UserData

class Util {

    companion object {
        var user: UserData? = null
    }

}