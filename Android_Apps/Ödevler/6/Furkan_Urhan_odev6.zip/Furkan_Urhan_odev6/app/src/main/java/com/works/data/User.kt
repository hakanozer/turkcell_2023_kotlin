package com.works.data

data class User (
    val username: String,
    val password: String,
)