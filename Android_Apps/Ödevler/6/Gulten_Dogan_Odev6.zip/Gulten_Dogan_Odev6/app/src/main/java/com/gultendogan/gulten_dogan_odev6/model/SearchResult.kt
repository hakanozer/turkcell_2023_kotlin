package com.gultendogan.gulten_dogan_odev6.model

data class SearchResult(val products: List<Product>)