package com.serapercel.uruntanitimuygulamasi

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class DetailActivity : AppCompatActivity() {

    lateinit var tvTitle: TextView
    lateinit var tvPrice: TextView
    lateinit var tvDesc: TextView
    lateinit var tvCategory: TextView

    lateinit var img: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        tvTitle = findViewById(R.id.tvProductTitle)
        tvPrice = findViewById(R.id.tvProductPrice)
        tvDesc = findViewById(R.id.tvProductDesc)
        tvCategory = findViewById(R.id.tvProductCategory)
        img = findViewById(R.id.ivProduct)

        tvTitle.text = ProductsActivity.thisProduct!!.title
        tvPrice.text = ProductsActivity.thisProduct!!.price.toString()
        tvDesc.text = ProductsActivity.thisProduct!!.description
        tvCategory.text = ProductsActivity.thisProduct!!.category
        Glide.with(this).load(ProductsActivity.thisProduct!!.images[0]).into(img)

    }
}