package com.serapercel.uruntanitimuygulamasi

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.serapercel.uruntanitimuygulamasi.adapter.CustomAdapter
import com.serapercel.uruntanitimuygulamasi.configs.ApiClient
import com.serapercel.uruntanitimuygulamasi.configs.Util
import com.serapercel.uruntanitimuygulamasi.models.DummyProducts
import com.serapercel.uruntanitimuygulamasi.models.Product
import com.serapercel.uruntanitimuygulamasi.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductsActivity : AppCompatActivity() {

    lateinit var userName: TextView
    lateinit var dummyService: DummyService
    lateinit var listView: ListView
    lateinit var list: List<Product>
    lateinit var btnSearch: Button
    lateinit var etSearch: EditText

    companion object ThisProduct {
        var thisProduct: com.serapercel.uruntanitimuygulamasi.models.Product? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)

        userName = findViewById(R.id.tvUserName)
        userName.text = Util.user!!.username
        listView = findViewById(R.id.lvProducts)
        btnSearch = findViewById(R.id.btnSearch)
        etSearch = findViewById(R.id.etSearch)

        dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.products().enqueue(object : Callback<DummyProducts> {
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val datas = response.body();
                list = datas!!.products
                val customAdapter = CustomAdapter(this@ProductsActivity, list)
                listView.adapter = customAdapter

            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                Log.e("dummyService", t.toString())
            }
        })


        btnSearch.setOnClickListener {
            dummyService.filter(etSearch.text.toString()).enqueue(object : Callback<DummyProducts> {
                override fun onResponse(
                    call: Call<DummyProducts>,
                    response: Response<DummyProducts>
                ) {
                    val searchData = response.body()
                    val myAdapter = CustomAdapter(this@ProductsActivity, searchData!!.products)
                    listView.adapter = myAdapter
                }

                override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                    Log.e("SearchError", t.toString())
                }

            })
        }
        listView.setOnItemClickListener { adapterView, view, i, l ->
            thisProduct =
                listView.getItemAtPosition(i) as com.serapercel.uruntanitimuygulamasi.models.Product
            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }

    }
}