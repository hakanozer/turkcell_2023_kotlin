package com.serapercel.uruntanitimuygulamasi.configs

import com.serapercel.uruntanitimuygulamasi.models.JWTData

class Util {

    companion object {
        var user: JWTData? = null
    }

}