package com.serapercel.uruntanitimuygulamasi.models

data class JWTData(
    val id: Long? = null,
    val username: String? = null,
    val email: String? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val gender: String? = null,
    val image: String? = null,
    val token: String? = null
)
