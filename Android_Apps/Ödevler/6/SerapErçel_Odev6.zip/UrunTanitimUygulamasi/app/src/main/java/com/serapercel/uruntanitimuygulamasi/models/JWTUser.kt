package com.serapercel.uruntanitimuygulamasi.models

data class JWTUser(
    val username: String,
    val password: String
)
