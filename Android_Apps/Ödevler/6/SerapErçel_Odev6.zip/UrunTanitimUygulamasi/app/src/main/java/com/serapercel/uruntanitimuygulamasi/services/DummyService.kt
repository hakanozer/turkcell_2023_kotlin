package com.serapercel.uruntanitimuygulamasi.services

import com.serapercel.uruntanitimuygulamasi.models.DummyProducts
import com.serapercel.uruntanitimuygulamasi.models.JWTData
import com.serapercel.uruntanitimuygulamasi.models.JWTUser
import com.serapercel.uruntanitimuygulamasi.models.Product
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface DummyService {

    @POST("/auth/login")
    fun login(@Body jwtUser: JWTUser): Call<JWTData>

    @GET("products")
    fun products() : Call<DummyProducts>

    @GET("products/{id}")
    fun singleProduct( @Path("id") id: Int ) : Call<Product>

    @GET("products/search")
    fun filter(@Query("q") keyword: String): Call<DummyProducts>

}