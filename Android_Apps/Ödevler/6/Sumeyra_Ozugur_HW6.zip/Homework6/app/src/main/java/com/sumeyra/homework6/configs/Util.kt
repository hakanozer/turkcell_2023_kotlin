package com.sumeyra.homework6.configs

import com.sumeyra.homework6.model.JWTData


class Util {

    companion object {
        var user: JWTData? = null
    }

}