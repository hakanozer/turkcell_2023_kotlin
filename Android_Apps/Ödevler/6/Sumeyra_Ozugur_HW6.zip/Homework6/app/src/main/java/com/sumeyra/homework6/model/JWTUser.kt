package com.sumeyra.homework6.model

data class JWTUser (
    val username: String,
    val password: String
)
