package com.marangoz.uruntanitimsebahaddinmarangoz

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.bumptech.glide.Glide

class CustomAdapter (private val context: Activity, var list: List<Product>): BaseAdapter() {


    override fun getCount(): Int {
        return list.size
    }

    override fun getItem(p0: Int): Any? {
       return null
    }

    override fun getItemId(p0: Int): Long {
       return 0
    }


    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)

        val titleText = rootView.findViewById<TextView>(R.id.titleText)
        val image = rootView.findViewById<ImageView>(R.id.imageView)
        val card = rootView.findViewById<CardView>(R.id.cardView)



        val product = list[position]

        titleText.text = product.title.toString()
        Glide.with(rootView).load(product.images[0]).into(image)


        card.setOnClickListener(){
            val intent = Intent(context,ProductDetailActivity::class.java)
            intent.putExtra("price",product.price.toString())
            intent.putExtra("title",product.title)
            intent.putExtra("descrimtion",product.description)
            intent.putExtra("image",product.images[0])
            intent.putExtra("brand",product.brand)
            context.startActivity(intent)


        }



        return rootView
    }

}