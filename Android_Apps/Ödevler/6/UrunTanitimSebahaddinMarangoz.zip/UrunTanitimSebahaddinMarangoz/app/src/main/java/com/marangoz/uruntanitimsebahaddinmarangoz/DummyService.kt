package com.marangoz.sendnotification

import com.marangoz.uruntanitimsebahaddinmarangoz.DummyProducts
import com.marangoz.uruntanitimsebahaddinmarangoz.JWTData
import com.marangoz.uruntanitimsebahaddinmarangoz.JWTUser
import com.marangoz.uruntanitimsebahaddinmarangoz.Product
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface DummyService {


    @POST("auth/login")
     fun sendData(
        @Body() jwtuser: JWTUser
    ) : Call<JWTData>


    @GET("products")
    fun tenProduct( @Query("limit") limit : Int) : Call<DummyProducts>

    @GET("products/search")
    fun searchProduct( @Query("q") q : String) : Call<DummyProducts>


}