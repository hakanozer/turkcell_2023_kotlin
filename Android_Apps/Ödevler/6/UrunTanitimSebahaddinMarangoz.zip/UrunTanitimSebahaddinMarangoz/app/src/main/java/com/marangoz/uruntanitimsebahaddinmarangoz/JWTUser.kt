package com.marangoz.uruntanitimsebahaddinmarangoz

data class JWTUser(
    val username: String,
    val password: String
)