package com.marangoz.uruntanitimsebahaddinmarangoz

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.marangoz.sendnotification.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.w3c.dom.Text
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var signInButton : MaterialCardView
    private lateinit var userText : TextInputEditText
    private lateinit var parolaText : TextInputEditText
    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        signInButton = findViewById(R.id.signInButton)
        userText = findViewById(R.id.emailText)
        parolaText = findViewById(R.id.passwordText)


        signInButton.setOnClickListener(){
            val user = userText.text.toString()
            val parola = parolaText.text.toString()

            if (user == "" || parola ==""){
                Toast.makeText(this,"Boş bırakılan Alanlar var",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val JWTUser = JWTUser(user,parola)


                ApiClient.getDummyService().sendData(JWTUser).enqueue(object : Callback<JWTData>{
                    override fun onResponse(call: Call<JWTData>, response: Response<JWTData>) {
                        val jwtData = response.body()

                        if (jwtData != null){
                            startActivity(Intent(this@MainActivity,ProductActivity::class.java))
                            finish()
                        }
                    }

                    override fun onFailure(call: Call<JWTData>, t: Throwable) {
                        TODO("Not yet implemented")
                    }

                })



        }

    }
}