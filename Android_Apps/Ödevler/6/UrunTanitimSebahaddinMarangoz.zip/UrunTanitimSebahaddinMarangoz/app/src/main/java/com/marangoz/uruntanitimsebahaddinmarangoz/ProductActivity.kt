package com.marangoz.uruntanitimsebahaddinmarangoz

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.ListView
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import com.marangoz.sendnotification.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductActivity : AppCompatActivity() {
    private lateinit var listView : ListView
    private lateinit var searchText : TextInputEditText
    private  var customAdapter : CustomAdapter? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)

        listView = findViewById(R.id.lv)
        searchText = findViewById(R.id.searchText)



        tenResult()


        searchText.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {

                if (searchText.text.toString() == ""){
                    tenResult()
                }else{
                    ApiClient.getDummyService().searchProduct(p0.toString()).enqueue(object : Callback<DummyProducts>{
                        override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>
                        ) {
                            val result = response.body()

                            if (result != null){
                                   customAdapter!!.list = result.products
                                   customAdapter!!.notifyDataSetChanged()
                            }


                        }

                        override fun onFailure(call: Call<DummyProducts>, t: Throwable) {

                        }

                    })
                }
                }


        })




    }

    fun tenResult(){
        ApiClient.getDummyService().tenProduct(10).enqueue(object : Callback<DummyProducts>{
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val dummyProducts = response.body()

                if (dummyProducts != null){
                    if (customAdapter == null){
                        customAdapter = CustomAdapter(this@ProductActivity, dummyProducts.products)
                        listView.adapter = customAdapter
                    }else{
                        customAdapter!!.list=dummyProducts.products
                        customAdapter!!.notifyDataSetChanged()

                    }

                }

            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
            }


        })
    }


}