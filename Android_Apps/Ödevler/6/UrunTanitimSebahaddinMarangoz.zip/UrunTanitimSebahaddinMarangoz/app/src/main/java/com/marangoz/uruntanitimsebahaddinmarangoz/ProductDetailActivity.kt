package com.marangoz.uruntanitimsebahaddinmarangoz

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var brandText : TextView
    private lateinit var desText : TextView
    private lateinit var priceText : TextView
    private lateinit var titleText : TextView
    private lateinit var image : ImageView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        brandText = findViewById(R.id.brandText)
        desText = findViewById(R.id.desText)
        priceText = findViewById(R.id.textView8)
        titleText = findViewById(R.id.titleText)
        image = findViewById(R.id.imageView2)

        brandText.text = intent.getStringExtra("brand")
        desText.text = intent.getStringExtra("descrimtion")
        priceText.text = intent.getStringExtra("price") + " TL"
        titleText.text = intent.getStringExtra("title")
        Glide.with(this).load(intent.getStringExtra("image")).into(image)





    }
}