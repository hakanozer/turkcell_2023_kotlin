package com.cankarademir.cankarademir_odev6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class UrunDetayActivity : AppCompatActivity() {

    lateinit var img: ImageView
    lateinit var title: TextView
    lateinit var fiyat: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_urun_detay)

    }

}