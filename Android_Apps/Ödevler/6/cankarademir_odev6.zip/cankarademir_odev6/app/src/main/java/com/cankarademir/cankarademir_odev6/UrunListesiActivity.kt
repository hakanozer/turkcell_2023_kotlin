package com.cankarademir.cankarademir_odev6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import com.cankarademir.cankarademir_odev6.adapter.UrunlerCustomAdapter
import com.cankarademir.cankarademir_odev6.configs.ApiClient
import com.cankarademir.cankarademir_odev6.models.Urunler
import com.cankarademir.cankarademir_odev6.models.UrunData
import com.cankarademir.cankarademir_odev6.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class UrunListesiActivity : AppCompatActivity() {

    lateinit var urunlerListView: ListView
    lateinit var dummyService: DummyService
    lateinit var  customAdapter: ArrayAdapter<UrunData>
    lateinit var btnAra :Button
    companion object{
    lateinit var detayUrunler:UrunData}
    lateinit var textara: EditText

    var urunList= mutableListOf<UrunData>()
    var urunListTemp= mutableListOf<UrunData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_urun_listesi)
        btnAra= findViewById(R.id.buttonara)
        urunlerListView = findViewById(R.id.urunlerListview)
        textara=findViewById(R.id.editTextAra)
        dummyService= ApiClient.getClient().create(DummyService::class.java)
        dummyService.getUrunler().enqueue(object : Callback<Urunler> {
            override fun onResponse(call: Call<Urunler>, response: Response<Urunler>) {
                for(runlevel in response.body()!!.urunler){
                    urunList.add(runlevel)
                }
                customAdapter = UrunlerCustomAdapter(this@UrunListesiActivity,urunList)
                urunlerListView.adapter=customAdapter
            }
            override fun onFailure(call: Call<Urunler>, t: Throwable) {
                Log.e("firstTenProduct", t.toString())
            }
        })

        btnAra.setOnClickListener(btnAraOnClickListener)
        urunlerListView.setOnItemClickListener { adapterView, view, i, l ->
            detayUrunler=urunList.get(i)
            val intent = Intent(this, UrunDetayActivity::class.java)
            startActivity(intent)
        }
    }
    val btnAraOnClickListener= View.OnClickListener {
        val aramaText=textara.text.toString()
        dummyService.ara(aramaText).enqueue(object :Callback<Urunler>{
            override fun onResponse(call: Call<Urunler>, response: Response<Urunler>) {
                urunListTemp=urunList
                urunList.clear()
                for( runlevel in response.body()!!.urunler){
                    urunList.add(runlevel)
                }
                customAdapter.notifyDataSetChanged()
            }
            override fun onFailure(call: Call<Urunler>, t: Throwable) {
            }
        })
    }
}




