package com.cankarademir.cankarademir_odev6.adapter

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.cankarademir.cankarademir_odev6.R
import com.cankarademir.cankarademir_odev6.models.UrunData


class UrunlerCustomAdapter(private val context: Activity, private val urunList: List<UrunData>):ArrayAdapter<UrunData>(context, R.layout.custum_listview_item, urunList ){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = context.layoutInflater.inflate(R.layout.custum_listview_item, null, true)
        val urun = urunList[position]

        val ImageView = view.findViewById<ImageView>(R.id.imgUrun)
        val titleTextView = view.findViewById<TextView>(R.id.txtTitle)
        val brandTextView = view.findViewById<TextView>(R.id.txtBrand)
        val priceTextView = view.findViewById<TextView>(R.id.txtRating)

        Glide.with(context).load(urun.thumbnail).into(ImageView)

        titleTextView.text = urun.title
        brandTextView.text = urun.brand
        priceTextView.text = "${urun.price}"

        return view
    }
}