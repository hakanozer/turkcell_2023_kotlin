package com.cankarademir.cankarademir_odev6.configs

import com.cankarademir.cankarademir_odev6.models.UserData

class Util {
    companion object {
        var user:UserData? = null
    }
}