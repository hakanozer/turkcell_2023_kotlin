package com.cankarademir.cankarademir_odev6.models

data class Urunler(
    val urunler: List<UrunData>,
    val total: Long,
    val skip: Long,
    val limit: Long
)

data class UrunData (
    val id: Long,
    val title: String,
    val description: String,
    val price: Long,
    val discountPercentage: Double,
    val rating: Double,
    val stock: Long,
    val brand: String,
    val category: String,
    val thumbnail: String,
    val images: List<String>
)

