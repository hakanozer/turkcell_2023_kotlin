package com.cankarademir.cankarademir_odev6.models

data class User(
    val username: String,
    val password: String
)
