package com.cankarademir.cankarademir_odev6.services

import com.cankarademir.cankarademir_odev6.models.Urunler
import com.cankarademir.cankarademir_odev6.models.UserData
import com.cankarademir.cankarademir_odev6.models.User
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface DummyService {

    @POST("/auth/login")
    fun login( @Body User: User): Call<UserData>

    @GET("/products?limit=10")
    fun getUrunler(): Call<Urunler>

    @GET("products/search")
    fun ara(@Query("q") query: String):Call<Urunler>
}