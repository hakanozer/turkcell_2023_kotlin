package com.example.turkcell_odev6.Config

import com.example.turkcell_odev6.model.JWTData

class Util {

    companion object {
        var user: JWTData? = null
    }
}