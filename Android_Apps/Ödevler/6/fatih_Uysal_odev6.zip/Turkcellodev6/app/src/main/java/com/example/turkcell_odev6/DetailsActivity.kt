package com.example.turkcell_odev6

import android.annotation.SuppressLint
import android.media.Image
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class DetailsActivity : AppCompatActivity() {
    lateinit var imageView : ImageView
    lateinit var textViewtitle: TextView
     lateinit var textViewDescription: TextView
     lateinit var textViewPrice: TextView
     lateinit var textViewDiscount: TextView
     lateinit var textViewRating: TextView
     lateinit var textViewStock: TextView
     lateinit var textViewBrand: TextView




    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        imageView = findViewById(R.id.imageViewDetails)
        textViewtitle= findViewById(R.id.textViewDetailsTitle)
        textViewDescription= findViewById(R.id.textViewDetailsDescription)
        textViewPrice= findViewById(R.id.textViewDetailsPrice)
        textViewDiscount= findViewById(R.id.textViewDetailsdiscountPercentege)
        textViewRating= findViewById(R.id.textViewDetailsRating)
        textViewStock= findViewById(R.id.textViewDetailsStock)
        textViewBrand= findViewById(R.id.textViewDetailsBrand)


        val productTitle = intent.getStringExtra("title")
        val productDescription =intent.getStringExtra("description")
        val productPrice=intent.getLongExtra("price" , 0)
        val productDiscount = intent.getDoubleExtra("discountPercentege" , 0.0)
        val productRating =intent.getDoubleExtra("rating", 0.0)
        val productStock =intent.getLongExtra("stock" , 0 )
        val productBrand =intent.getStringExtra("brand")
        val productThumbnail =intent.getStringExtra("thumbnail")


        Glide.with(this).load(productThumbnail).into(imageView)
        textViewtitle.setText(productTitle)
        textViewDescription.setText(productDescription)
        textViewPrice.setText("Fiyat :" + productPrice.toString() +"$" )
        textViewDiscount.setText("İndirim miktarı : %$productDiscount")
        textViewRating.setText("Beğeni düzeyi : $productRating" +"/ 5")
        textViewStock.setText("Stok sayısı: "+productStock.toString() + " adet")
        textViewBrand.setText(productBrand)











    }
}