package com.example.turkcell_odev6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.turkcell_odev6.Config.ApiClient
import com.example.turkcell_odev6.Config.Util
import com.example.turkcell_odev6.model.JWTData
import com.example.turkcell_odev6.model.JWTUser
import com.example.turkcell_odev6.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    lateinit var editTextUsername: EditText
    lateinit var editTextPassword: EditText
    lateinit var btnLogin: Button
    lateinit var dummyService: DummyService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editTextUsername = findViewById(R.id.editTextUserName)
        editTextPassword= findViewById(R.id.editTextPassword)
        btnLogin = findViewById(R.id.btnLogin)
        dummyService = ApiClient.getClient().create(DummyService::class.java)
        btnLogin.setOnClickListener(btnOnClickListener)


    }

    val btnOnClickListener = View.OnClickListener {
        val userName = editTextUsername.text.toString()
        val password = editTextPassword.text.toString()
        val jwtUser = JWTUser(userName, password)

        dummyService.login(jwtUser).enqueue(object : Callback<JWTData>{
            override fun onResponse(call: Call<JWTData>, response: Response<JWTData>) {
                val jwtUser = response.body()
                if (jwtUser != null) {
                    Util.user = jwtUser
                    Log.d("jwtUser", jwtUser.toString())


                    val intent = Intent(this@MainActivity, UrunlerActivity::class.java)
                    startActivity(intent)
                    finish()
                }else{
                    showToast()
                }
            }

            override fun onFailure(call: Call<JWTData>, t: Throwable) {
                Log.e("login", t.toString())
                Toast.makeText(this@MainActivity, "Internet or Server Fail", Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun showToast() {
        Toast.makeText(this , "Kullanıcı adı veya şifre yanlış lütfen tekrar deneyiniz." , Toast.LENGTH_SHORT).show()
    }
}