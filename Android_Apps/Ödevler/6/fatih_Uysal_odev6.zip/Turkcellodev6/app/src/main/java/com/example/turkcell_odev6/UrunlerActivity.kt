package com.example.turkcell_odev6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.example.turkcell_odev6.Config.ApiClient
import com.example.turkcell_odev6.adapter.customProductsListAdapter
import com.example.turkcell_odev6.model.DummyProducts
import com.example.turkcell_odev6.model.Product
import com.example.turkcell_odev6.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class UrunlerActivity : AppCompatActivity() {


    lateinit var editText: EditText
    lateinit var listView: ListView
    lateinit var btn : Button
    lateinit var dummyService: DummyService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_urunler)
        editText = findViewById(R.id.editTextUrunler)
        listView = findViewById(R.id.listViewUrunler)
        btn = findViewById(R.id.btnSearch)





        dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.getProducts(10).enqueue(object : Callback<DummyProducts> {
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val datas = response.body()
                val adapter = customProductsListAdapter(this@UrunlerActivity, datas!!.products)
                listView.adapter = adapter


            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                Log.e("login", t.toString())
                Toast.makeText(this@UrunlerActivity, "Internet or Server Fail", Toast.LENGTH_LONG)
                    .show()
            }

        })

        listView.setOnItemClickListener { adapterView, view, i, l ->
            dummyService.singleproducts(i +1 ).enqueue(object: Callback<Product>{
                override fun onResponse(call: Call<Product>, response: Response<Product>) {
                  val datas =  response.body()
                    val intent = Intent(this@UrunlerActivity, DetailsActivity::class.java)
                    intent.putExtra("title" ,datas?.title)
                    intent.putExtra("description" ,datas?.description)
                    intent.putExtra("price" ,datas?.price)
                    intent.putExtra("discountPercentege" ,datas?.discountPercentage)
                    intent.putExtra("rating" ,datas?.rating)
                    intent.putExtra("stock" ,datas?.stock)
                    intent.putExtra("brand" ,datas?.brand)
                    intent.putExtra("thumbnail" ,datas?.thumbnail)

                    startActivity(intent)

                }

                override fun onFailure(call: Call<Product>, t: Throwable) {
                    Log.e("login", t.toString())
                    Toast.makeText(this@UrunlerActivity, "Internet or Server Fail", Toast.LENGTH_LONG)
                        .show()
                }

            })

        }

        btn.setOnClickListener{

            dummyService.products().enqueue(object : Callback<DummyProducts> {
                override fun onResponse(
                    call: Call<DummyProducts>,
                    response: Response<DummyProducts>
                ) {
                    val datas = response.body()

                    for (item in datas!!.products){
                        if(editText.text.toString().lowercase() == item.title.lowercase()){
                            val intent = Intent(this@UrunlerActivity, DetailsActivity::class.java)
                            intent.putExtra("title" ,item?.title)
                            intent.putExtra("description" ,item?.description)
                            intent.putExtra("price" ,item?.price)
                            intent.putExtra("discountPercentege" ,item?.discountPercentage)
                            intent.putExtra("rating" ,item?.rating)
                            intent.putExtra("stock" ,item?.stock)
                            intent.putExtra("brand" ,item?.brand)
                            intent.putExtra("thumbnail" ,item?.thumbnail)
                            startActivity(intent)


                        }
                    }
                }

                override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                    Log.e("login", t.toString())
                    Toast.makeText(
                        this@UrunlerActivity,
                        "Internet or Server Fail",
                        Toast.LENGTH_LONG
                    )
                        .show()
                }

            })
        }


    }
}