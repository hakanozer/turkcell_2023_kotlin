package com.example.turkcell_odev6.model

data class JWTUser (
    val username: String,
    val password: String
    )