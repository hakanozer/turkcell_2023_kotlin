package com.example.turkcell_odev6.service

import com.example.turkcell_odev6.model.DummyProducts
import com.example.turkcell_odev6.model.JWTData
import com.example.turkcell_odev6.model.JWTUser
import com.example.turkcell_odev6.model.Product
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface DummyService {

    @POST("/auth/login")
    fun login( @Body jwtUser: JWTUser): Call<JWTData>

    @GET("products")
    fun getProducts(@Query("limit") limit: Int): Call<DummyProducts>

    @GET("products")
    fun products() : Call<DummyProducts>

    @GET("products/{id}")
    fun singleproducts( @Path("id") id : Int) : Call<Product>
}