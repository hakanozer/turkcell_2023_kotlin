package com.odev6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.odev6.config.ApiClient
import com.odev6.model.Product
import com.odev6.service.ProductService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    lateinit var productService:ProductService
    lateinit var txtTitle:TextView
    lateinit var imgDetail:ImageView
    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        intent.getStringExtra("data")?.let {
            var id =it
            productService = ApiClient.getClient().create(ProductService::class.java)
            val product= productService.singleProduct(id.toInt()).enqueue(object : Callback<Product> {
                override fun onResponse(call: Call<Product>, response: Response<Product>) {
                    txtTitle = findViewById(R.id.textView)
                    imgDetail = findViewById(R.id.imgDetail)
                    val count = response.body()
                    count?.let {
                        txtTitle.text = count.title
                        Glide.with(this@DetailActivity).load(count.images[0])
                            .into(imgDetail)
                    }
                }

                override fun onFailure(call: Call<Product>, t: Throwable) {
                    TODO("Not yet implemented")
                }
            })


        }

    }
}