package com.odev6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.odev6.config.ApiClient
import com.odev6.model.Data
import com.odev6.model.User
import com.odev6.service.UserService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var userService: UserService
    lateinit var edittxtUserName: EditText
    lateinit var edittxtPassword: EditText
    lateinit var logInButton: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        userService = ApiClient.getClient().create(UserService::class.java)

        edittxtUserName=findViewById(R.id.txtUserName)
        edittxtPassword=findViewById(R.id.txtPassword)
        logInButton=findViewById(R.id.btnLogin)

        logInButton.setOnClickListener(btnOnClickListener) // butonu çağırdık






        val user = User("kminchelle","0lelplR")
        userService.login(user).enqueue(object : Callback<Data> {
            override fun onResponse(call: Call<Data>, response: Response<Data>) {
                val User = response.body()
                Log.d("status",response.code().toString())//0-500 arası code dödüdürü 200 lü olanlar başarılırdır.Gerisi hatalı.

            }

            override fun onFailure(call: Call<Data>, t: Throwable) {
                Log.e("login",t.toString()) //base url hatasında ya da internet yokken sunucu yoksa bursaı çalışır. Bu durumlara uygun şekilde kullanıcıya uyarı mesajı verilebilir.
            }


        })
    }

    val btnOnClickListener = View.OnClickListener {
        if (edittxtUserName.text.toString().isEmpty()||edittxtPassword.text.toString().isEmpty()){
            Toast.makeText(this,"Kullanıcı Adı ya da Şifre Girmediniz! ",Toast.LENGTH_LONG).show()
        }
        else {
            var email = edittxtUserName.text.toString()
            var pass = edittxtPassword.text.toString()

            // val user = User(email, pass)
            val user = User("kminchelle","0lelplR")
            userService.login(user).enqueue(object : Callback<Data> {


                override fun onResponse(call: Call<Data>, response: Response<Data>) {
                    val user = response.body()
                    Log.d("status", response.code().toString())
                    if(response.code()==200){

                        val intent = Intent(this@MainActivity, ProductsActivity::class.java)
                        startActivity(intent)
                        finish()
                    }

                }

                override fun onFailure(call: Call<Data>, t: Throwable) {
                    Log.e("login", t.toString())
                    Toast.makeText(this@MainActivity, "Internet or Server Fail", Toast.LENGTH_LONG)
                        .show()
                }
            })
        }
    }
}