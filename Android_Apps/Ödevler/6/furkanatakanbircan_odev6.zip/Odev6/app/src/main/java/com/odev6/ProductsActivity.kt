package com.odev6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.odev6.adapter.ListAdapter
import com.odev6.config.ApiClient
import com.odev6.model.DummyProducts
import com.odev6.model.Product
import com.odev6.service.ProductService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductsActivity : AppCompatActivity() {
    lateinit var listView:ListView
    lateinit var productService:ProductService
    lateinit var txtSearch:TextView
    lateinit var btnAramaYap:Button
    lateinit var list:List<Product>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)
        listView=findViewById(R.id.listViewProducts)
        btnAramaYap =findViewById(R.id.btnAramaYap)
        txtSearch = findViewById(R.id.txtSearch)

        productService =ApiClient.getClient().create(ProductService::class.java)
        productService.getProducts("10").enqueue(object :Callback<DummyProducts>{
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val datas = response.body()?.products
                list=datas!!
                datas?.let {
                    val listAdapter = ListAdapter(this@ProductsActivity, itemList = datas)
                    listAdapter.notifyDataSetChanged()
                    listView.adapter = listAdapter
                    listView.setOnItemClickListener { adapterView, view, i, l ->

                        var intent = Intent(this@ProductsActivity, DetailActivity::class.java)
                        intent.putExtra("data", datas.get(i).id.toString())
                        startActivity(intent)

                        true

                    }
                }

            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                TODO("Not yet implemented")
            }
        } )

        productService.singleProduct(2).enqueue(object:Callback<Product>{
            override fun onResponse(call: Call<Product>, response: Response<Product>) {
                val product =response.body()
                if (product!=null){

                }

            }

            override fun onFailure(call: Call<Product>, t: Throwable) {
                TODO("Not yet implemented")
            }
        })

        btnAramaYap.setOnClickListener {
            txtSearch.text.isNotEmpty().let {
                        for (item in list) {
                            if (!txtSearch.text.equals(item.title)) {
                                Toast.makeText(this, "bu ürün bulunmamaktadır!", Toast.LENGTH_SHORT)
                                    .show()
                            }  else if (txtSearch.text.equals(item.title)){

                                productService.searchProduct(txtSearch.text.toString()).enqueue(
                                    object : Callback<Product> {
                                        override fun onResponse(
                                            call: Call<Product>,
                                            response: Response<Product>
                                        ) {
                                            val deger = response.body()
                                            var intent =
                                                Intent(
                                                    this@ProductsActivity,
                                                    DetailActivity::class.java
                                                )
                                            intent.putExtra("data", deger!!.id)
                                            startActivity(intent)
                                            true
                                        }

                                        override fun onFailure(call: Call<Product>, t: Throwable) {
                                            TODO("Not yet implemented")
                                        }

                                    }
                                )
                            }
                            else{

                            }
                        }
            }
        }
    }


}