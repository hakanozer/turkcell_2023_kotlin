package com.odev6.model

data class User(
    val username: String,
    val password: String
)
