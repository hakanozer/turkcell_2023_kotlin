package com.odev6.service

import com.odev6.model.DummyProducts
import com.odev6.model.Product
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ProductService {
    @GET("products")
    fun getProducts(@Query("limit") limit: String, ) : Call<DummyProducts>

    @GET("products/{id}")
    fun singleProduct( @Path("id") id: Int ) : Call<Product>

    @GET("products")
    fun searchProduct( @Query("search") search: String ) : Call<Product>
}