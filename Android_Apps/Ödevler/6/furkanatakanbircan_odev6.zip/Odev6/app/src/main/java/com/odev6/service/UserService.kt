package com.odev6.service

import com.odev6.model.Data
import com.odev6.model.User
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface UserService {
    @POST("/auth/login")
    fun login(@Body user: User): Call<Data>
}