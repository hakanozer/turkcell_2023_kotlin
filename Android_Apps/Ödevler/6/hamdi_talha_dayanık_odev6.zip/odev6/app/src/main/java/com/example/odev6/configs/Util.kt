package com.example.odev6.configs

import com.example.odev6.models.JWTData

class Util {
    companion object{
        var user : JWTData? = null
    }
}