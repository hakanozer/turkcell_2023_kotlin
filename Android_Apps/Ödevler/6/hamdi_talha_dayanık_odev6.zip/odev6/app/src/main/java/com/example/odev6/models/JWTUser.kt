package com.example.odev6.models

data class JWTUser(
    val username : String,
    val password : String
)
