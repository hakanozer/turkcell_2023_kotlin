package com.mustafaunlu.productapp.models

data class User(
    val username: String,
    val password: String,
)
