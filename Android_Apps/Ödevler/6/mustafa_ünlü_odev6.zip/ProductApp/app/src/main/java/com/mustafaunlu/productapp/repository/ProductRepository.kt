package com.mustafaunlu.productapp.repository

import android.content.Intent
import android.view.View
import android.widget.Toast
import com.mustafaunlu.productapp.models.Product
import com.mustafaunlu.productapp.models.Products
import com.mustafaunlu.productapp.models.User
import com.mustafaunlu.productapp.models.UserResponse
import com.mustafaunlu.productapp.service.ApiClient
import com.mustafaunlu.productapp.ui.LoginActivity
import com.mustafaunlu.productapp.ui.ProductListActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductRepository {
    private val service = ApiClient.productService
    var productList = mutableListOf<Product>()
    var listener: ((List<Product>) -> Unit)? = null

    fun getProducts(rootView: View, limit: Int) {
        service.getProducts(limit).enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    val product = response.body()!!.products
                    productList.addAll(product)
                    listener?.invoke(productList)
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Toast.makeText(rootView.context, "Failed to get products!", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    fun loginUser(rootView: View, user: User) {
        service.login(user).enqueue(object : Callback<UserResponse> {
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                if (response.isSuccessful) {
                    val intent = Intent(rootView.context, ProductListActivity::class.java)
                    rootView.context.startActivity(intent)
                    Toast.makeText(rootView.context, "Giris Basarili!", Toast.LENGTH_SHORT).show()
                    (rootView.context as LoginActivity).finish()
                } else {
                    Toast.makeText(rootView.context, "Giris basarisiz username ve sifrenizi kontrol ediniz!", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                Toast.makeText(rootView.context, "Beklenmedik bir hata internet erisiminizi kontrol ediniz!!", Toast.LENGTH_LONG).show()
            }
        })
    }

    fun getProductsBySearchQuery(rootView: View, query: String) {
        service.searchProducts(query).enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    val product = response.body()!!.products
                    productList.clear()
                    productList.addAll(product)
                    listener?.invoke(productList)
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Toast.makeText(rootView.context, "Failed to get products!", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }
}
