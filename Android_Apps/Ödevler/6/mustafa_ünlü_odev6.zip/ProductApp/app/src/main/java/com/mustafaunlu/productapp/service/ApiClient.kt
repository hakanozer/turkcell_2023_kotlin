package com.mustafaunlu.productapp.service

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    private const val BASE_URL = "https://dummyjson.com/"

    private val client = OkHttpClient.Builder().readTimeout(20, TimeUnit.SECONDS).build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .client(client)
        .build()
    val productService: Service by lazy { retrofit.create(Service::class.java) }
}
