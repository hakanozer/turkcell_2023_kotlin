package com.mustafaunlu.productapp.service

import com.mustafaunlu.productapp.models.Products
import com.mustafaunlu.productapp.models.User
import com.mustafaunlu.productapp.models.UserResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface Service {
    @GET("products")
    fun getProducts(@Query("limit") limit: Int): Call<Products>

    @POST("auth/login")
    fun login(@Body user: User): Call<UserResponse>

    @GET("products/search")
    fun searchProducts(@Query("q") query: String): Call<Products>
}
