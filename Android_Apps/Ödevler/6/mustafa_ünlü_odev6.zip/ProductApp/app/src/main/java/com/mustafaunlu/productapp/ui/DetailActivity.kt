package com.mustafaunlu.productapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mustafaunlu.productapp.databinding.ActivityDetailBinding
import com.mustafaunlu.productapp.models.Product
import com.mustafaunlu.productapp.utils.Constants.INTENT_KEY
import com.mustafaunlu.productapp.utils.loadImage

class DetailActivity : AppCompatActivity() {
    lateinit var binding: ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityDetailBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val product = intent.getParcelableExtra(INTENT_KEY) as? Product

        binding.apply {
            productBrand.text = getString(com.mustafaunlu.productapp.R.string.brand_str, product?.brand)
            productDescription.text = product?.description
            productPrice.text = getString(com.mustafaunlu.productapp.R.string.price_str, product?.price.toString())
            productTitle.text = product?.title
            productDiscount.text = getString(com.mustafaunlu.productapp.R.string.discount_str, product?.discountPercentage.toString())
            productCategory.text = getString(com.mustafaunlu.productapp.R.string.category_str, product?.category)
            productRating.text = getString(com.mustafaunlu.productapp.R.string.rating_str, product?.rating.toString())
            productImg.loadImage(product!!.images[0])
        }
    }
}
