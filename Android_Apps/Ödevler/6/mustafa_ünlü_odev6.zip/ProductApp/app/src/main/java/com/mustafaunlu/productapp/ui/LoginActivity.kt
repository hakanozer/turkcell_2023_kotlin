package com.mustafaunlu.productapp.ui

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mustafaunlu.productapp.R
import com.mustafaunlu.productapp.databinding.ActivityLoginBinding
import com.mustafaunlu.productapp.models.User
import com.mustafaunlu.productapp.repository.ProductRepository
import com.mustafaunlu.productapp.utils.Constants
import com.mustafaunlu.productapp.utils.Constants.SHARED_PREF_DEF
import com.mustafaunlu.productapp.utils.Constants.SHARED_PREF_KEY

class LoginActivity : AppCompatActivity() {
    private val repository = ProductRepository()
    private lateinit var binding: ActivityLoginBinding
    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences(Constants.SHARED_PREF_FILE_NAME, MODE_PRIVATE)
        val savedUsername = sharedPref.getString(SHARED_PREF_KEY, SHARED_PREF_DEF)
        if (savedUsername != null) {
            binding.usernameEdtxt.setText(savedUsername)
        }

        binding.loginBtn.setOnClickListener {
            loginLogic()
        }
    }

    private fun loginLogic() {
        val username = binding.usernameEdtxt.text.toString().trim()
        val password = binding.passwordEdtxt.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, getString(R.string.not_blank), Toast.LENGTH_SHORT).show()
            return
        }

        val user = User(username, password)
        repository.loginUser(binding.root, user)
        sharedPref.edit().putString(SHARED_PREF_KEY, username).apply()
    }
}
