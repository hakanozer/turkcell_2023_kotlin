package com.mustafaunlu.productapp.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mustafaunlu.productapp.databinding.ActivityProductListBinding
import com.mustafaunlu.productapp.repository.ProductRepository
import com.mustafaunlu.productapp.utils.Constants.INTENT_KEY

class ProductListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProductListBinding
    private val repository = ProductRepository()

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = ProductListAdapter(repository.productList) {
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(INTENT_KEY, it)
            startActivity(intent)
        }
        binding.productRecyclerView.adapter = adapter

        repository.listener = {
            adapter.notifyDataSetChanged()
        }
        if (repository.productList.isEmpty()) {
            repository.getProducts(binding.root, 10)
        }

        binding.searchButton.setOnClickListener {
            val query = binding.productSearch.text.toString()
            repository.getProductsBySearchQuery(binding.root, query)
        }
    }
}
