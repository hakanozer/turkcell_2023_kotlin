package com.mustafaunlu.productapp.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.productapp.databinding.ProductListviewItemBinding
import com.mustafaunlu.productapp.models.Product
import com.mustafaunlu.productapp.utils.loadImage

class ProductListAdapter(private val productList: List<Product>, private val onItemClicked: (Product) -> Unit) : RecyclerView.Adapter<ProductListAdapter.ProductViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = ProductListviewItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        holder.bind(product)
        holder.itemView.setOnClickListener {
            onItemClicked(product)
        }
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    inner class ProductViewHolder(private val binding: ProductListviewItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(product: Product) {
            binding.apply {
                productImg.loadImage(product.images[0])
                productTitle.text = product.title
                productDescription.text = product.description
                productPrice.text = "${product.price} TL"
            }
        }
    }
}
