package com.mustafaunlu.productapp.utils

object Constants {
    const val SHARED_PREF_FILE_NAME = "user"
    const val SHARED_PREF_KEY = "username"
    const val SHARED_PREF_DEF = ""
    const val INTENT_KEY = "product"
}
