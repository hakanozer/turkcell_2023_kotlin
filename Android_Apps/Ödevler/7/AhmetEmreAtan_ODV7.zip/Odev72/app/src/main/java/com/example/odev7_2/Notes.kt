package com.example.odev7_2

data class Notes(val id: Int, val title: String, val detail: String)
