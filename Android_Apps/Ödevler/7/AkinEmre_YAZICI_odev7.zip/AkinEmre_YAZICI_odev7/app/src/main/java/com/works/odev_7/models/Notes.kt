package com.works.odev_7.models

data class Notes(
    val NID : Int,
    val Title : String,
    val Detail : String,
    val Date : String
)
