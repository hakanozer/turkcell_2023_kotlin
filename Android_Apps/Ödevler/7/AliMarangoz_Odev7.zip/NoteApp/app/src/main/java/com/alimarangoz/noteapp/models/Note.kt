package com.alimarangoz.noteapp.models

data class Note(
    val nid: Int,
    val title: String,
    val detail: String,
    val date: String
)
