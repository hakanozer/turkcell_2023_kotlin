package com.alierdemalkoc.noteapp.model

data class Note(
    val nid: Int,
    val title: String,
    val detail: String,
    val date: String
)
