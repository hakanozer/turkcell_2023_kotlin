package com.alierdemalkoc.noteapp.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import com.alierdemalkoc.noteapp.R
import com.alierdemalkoc.noteapp.databinding.FragmentDetailBinding
import com.alierdemalkoc.noteapp.databinding.FragmentNotesBinding
import com.alierdemalkoc.noteapp.databinding.FragmentSplashBinding
import com.alierdemalkoc.noteapp.db.DB

class DetailFragment : Fragment() {
    private var _binding : FragmentDetailBinding? = null
    private val binding get() = _binding!!

    lateinit var removeButton: Button
    lateinit var updateButton: Button
    lateinit var titleEditText: EditText
    lateinit var detailEditText: EditText

    lateinit var db: DB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = DB(requireContext())
        updateButton = binding.updateButton
        removeButton = binding.removeButton
        detailEditText = binding.detailEditText
        titleEditText = binding.titleEditText
        val list = db.allNote()
        val id = arguments?.getInt("list")
        titleEditText.setText(id?.let { list.get(it).title.toString() })
        detailEditText.setText(id?.let { list.get(it).detail.toString() })

        updateButton.setOnClickListener {

        }

        removeButton.setOnClickListener {
            
        }


    }
}