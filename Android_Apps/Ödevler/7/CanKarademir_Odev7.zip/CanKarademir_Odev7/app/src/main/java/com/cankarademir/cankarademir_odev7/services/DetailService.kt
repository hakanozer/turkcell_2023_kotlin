package com.cankarademir.cankarademir_odev7.services

import com.cankarademir.cankarademir_odev7.models.Note

class DetailService {
    fun noteServices():List<Note>{

        var list = mutableListOf<Note>()
        return list
    }
}