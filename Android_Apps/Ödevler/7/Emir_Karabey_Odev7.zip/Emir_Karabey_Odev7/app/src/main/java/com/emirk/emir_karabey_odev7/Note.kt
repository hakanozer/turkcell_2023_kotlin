package com.emirk.emir_karabey_odev7

data class Note(val id: Int, val title: String, val detail: String, val date: String)