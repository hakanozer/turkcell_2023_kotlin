package com.example.odev_7.configs

import com.example.odev_7.models.Note

class Util {
    companion object {
        var choosen: Note? = null
    }
}