package com.example.odev_7.ui.detail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.example.odev_7.R
import com.example.odev_7.configs.Util
import com.example.odev_7.models.Note
import com.example.odev_7.services.DB
import com.example.odev_7.ui.main.MainActivity

class DetailActivity : AppCompatActivity() {
    lateinit var txtDetailTitle: TextView
    lateinit var txtDetailDate: TextView
    lateinit var txtDetailContent: TextView
    lateinit var note: Note
    lateinit var db: DB
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        initView()
        setView()
    }

    private fun initView() {
        txtDetailTitle = findViewById(R.id.txtDetailTitle)
        txtDetailDate = findViewById(R.id.txtDetailDate)
        txtDetailContent = findViewById(R.id.txtDetailContent)
        note = Util.choosen!!
    }

    private fun setView() {
        txtDetailTitle.text = note.title
        txtDetailDate.text = note.date
        txtDetailContent.text = note.content
        db = DB(this)
    }

    fun btnDeleteOnClick(view: View) {
        db.deleteNote(note.id)
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

}