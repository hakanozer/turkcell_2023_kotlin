
## Noteit! App

Noteit! is a note application that created by Kotlin and Sql Lite.
  
## Screenshots

| Main Screen | Note Add | Note Detail |
|:-:|:-:|:-:|
| ![Fist](https://github.com/anilerkut/AndroidJavaNewsApp/assets/81919398/1299b254-69c1-4929-a863-1b57e2a0b3fa) | ![3](https://github.com/anilerkut/AndroidJavaNewsApp/assets/81919398/b60f9de9-02ea-49dc-9bbc-553560207304) | ![3](https://github.com/anilerkut/AndroidJavaNewsApp/assets/81919398/3cb0f5e6-fce3-4e08-bfe9-995764b6ca07)