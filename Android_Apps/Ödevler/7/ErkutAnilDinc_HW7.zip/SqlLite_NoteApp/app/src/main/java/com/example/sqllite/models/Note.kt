package com.example.sqllite.models

data class Note(var nid: Int, var title : String,var detail : String , var date : String)
