package com.example.turkcell_odev7

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

class AddNoteActivity : AppCompatActivity() {

    lateinit var textViewAddDate: TextView
    lateinit var textViewAddTitle: EditText
    lateinit var textViewAddDetail: TextView
    lateinit var btnSave :Button
    lateinit var db :DB

    var addScreenTitle : String = ""
    var addScreenDetail: String = ""
    var addScreenDate : String = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)

        textViewAddDate = findViewById(R.id.textViewAddNoteDate)
        textViewAddTitle = findViewById(R.id.textViewAddNoteTitle)
        textViewAddDetail = findViewById(R.id.textViewAddNoteDetail)
        btnSave = findViewById(R.id.btnSave)
    db = DB(this)

        val calender = Calendar.getInstance()
        var selectDate: String

        var date: String = SimpleDateFormat("dd-MM-yyyy").format(Date())
        textViewAddDate.text = date
        textViewAddDate.setOnClickListener {
            val datePickerDialog = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { datePicker, i, i2, i3 ->
                    Log.d("i", i.toString()) //yıl
                    Log.d("i2", (i2 + 1).toString()) // ay
                    Log.d("i3", i3.toString()) // gün
                    date = "$i3-${i2 + 1}-$i"
                    if (i2 < 10) {
                        date = "$i3-0${i2 + 1}-$i"
                    }
                    if (i3 < 10) {
                        date = "0" + date
                    }

                    textViewAddDate.text = date
                },
                calender.get(Calendar.YEAR),
                calender.get(Calendar.MONTH),
                calender.get(Calendar.DAY_OF_MONTH),


                )
            datePickerDialog.show()
        }

        btnSave.setOnClickListener {
            addScreenTitle = textViewAddTitle.text.toString()
            addScreenDetail= textViewAddDetail.text.toString()
            addScreenDate = textViewAddDate.text.toString()
            db.addNote(addScreenTitle , addScreenDetail , addScreenDate )
   Toast.makeText(this , "not başarılı bir şekilde kaydedilmiştir." , Toast.LENGTH_SHORT).show()
            onBackPressed()
        }

    }
}
