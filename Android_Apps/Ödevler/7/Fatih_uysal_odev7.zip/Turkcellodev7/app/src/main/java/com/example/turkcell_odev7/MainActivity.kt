package com.example.turkcell_odev7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


import android.widget.Button
import android.widget.ListView
import androidx.core.view.get
import com.example.turkcell_odev7.models.Note

class MainActivity : AppCompatActivity() {

    lateinit var db: DB
    lateinit var btn: Button
    lateinit var listView: ListView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        btn = findViewById(R.id.btnADD)
        listView = findViewById(R.id.listView)

        db = DB(this)


        btn.setOnClickListener {
            val i = Intent(this, AddNoteActivity::class.java)
            startActivity(i)
        }
        listView.setOnItemClickListener { parent, view, position, id ->
            val i = Intent(this, NoteDetailActivity::class.java)

           positionlist = position


            startActivity(i)

        }

    }

    override fun onResume() {

        var list = db.allNote()
        val adapter = MyListAdapter(this, list)
        listView.adapter = adapter
        super.onResume()
    }


}
 var positionlist : Int = 0