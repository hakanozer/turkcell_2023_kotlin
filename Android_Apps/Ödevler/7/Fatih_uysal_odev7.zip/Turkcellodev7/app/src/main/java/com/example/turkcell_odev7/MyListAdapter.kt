package com.example.turkcell_odev7

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.turkcell_odev7.models.Note

class MyListAdapter(private val context: Activity, private val list: List<Note>)
    : ArrayAdapter<Note>(context, R.layout.custom_list, list) {

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list, null, true)

        val titleText = rootView.findViewById(R.id.list_item_title) as TextView
        val detail = rootView.findViewById(R.id.list_item_detail) as TextView
        val date = rootView.findViewById(R.id.list_item_date) as TextView


        val note = list.get(position)
        titleText.setText(note.title)
        detail.setText(note.detail)
        date.setText(note.date)


        return rootView
    }
}