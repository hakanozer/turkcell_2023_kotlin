package com.example.turkcell_odev7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class NoteDetailActivity : AppCompatActivity() {
    lateinit var db:DB
    lateinit var btnDelete : Button

    lateinit var textTitle : TextView
    lateinit var textDetail : TextView
    lateinit var textDate : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_detail)
        textTitle = findViewById(R.id.textViewNoteTitle)
        textDetail = findViewById(R.id.textViewNoteDetail)
        textDate = findViewById(R.id.textViewNoteDate)
        val nidOrder = intent.getIntExtra("sıra" , 1)
        db = DB(this)
        val list = db.allNote()
        btnDelete = findViewById(R.id.btnDelete)

        positionlist
        textTitle.text = list[positionlist].title
        textDetail.text = list[positionlist].detail
        textDate.text = list[positionlist].date

        btnDelete.setOnClickListener{
            var nid = list[positionlist].nid
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Silme işleminden emin misiniz ? ")
            builder.setPositiveButton("Evet"){dialogInterface, which ->

                db.deleteNote(nid)
                Toast.makeText(this , "not başarılı bir şekilde silinmiştir." , Toast.LENGTH_SHORT).show()
                onBackPressed()
            }
            builder.setNegativeButton("Vazgeç"){dialogInterface, which ->

            }
            val alertDialog: AlertDialog = builder.create()
            alertDialog.setCancelable(false)
            alertDialog.show()


        }
    }
}