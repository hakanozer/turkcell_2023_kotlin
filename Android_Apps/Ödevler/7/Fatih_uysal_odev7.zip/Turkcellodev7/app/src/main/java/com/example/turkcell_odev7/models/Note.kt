package com.example.turkcell_odev7.models

data class Note(
    val nid : Int,
    val title : String,
    val detail : String,
    val date : String
)