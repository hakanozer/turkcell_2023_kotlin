package com.gultendogan.gulten_dogan_odev7.model

data class Note(val title: String, val id: Int, val description: String, val date: String)