package com.gultendogan.gulten_dogan_odev7.utils

object  Constants {

    object Prefs{
        const val INFO = "info"
        const val NEW = "new"
        const val OLD = "old"
    }
}