# Odev7
##SQLite ile local veritabanına veri ekler, siler ve okur.İki ekradan oluşur. 
![appPhoto](https://github.com/atakanbircan/Odev7/blob/master/app/src/main/res/drawable/img1.jpeg)
![appPhoto](https://github.com/atakanbircan/Odev7/blob/master/app/src/main/res/drawable/img2.jpeg)
