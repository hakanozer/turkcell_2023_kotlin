package com.odev_7

data class Note(
    val nid: Int,
    val title: String,
    val detail: String,
    val date: String
)
