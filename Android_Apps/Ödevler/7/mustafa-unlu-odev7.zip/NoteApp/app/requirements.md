
odev Note App yazilacak pazartesi gunune kadadr
Crud islemleri yapilacak
Tasarim kafaya gore yapilacak
           title edit text
           detail edit text
            button datapick
            button save
           Database Listview (sadece title gosterilecek)
           listview'e tiklayinca o itemin detayi gosterilecek


           detayda not tum detaylar gosterilecek
           ayrinti sayfasinda sil butonu olacak
           sil e basinca listviewdanda silinecek

