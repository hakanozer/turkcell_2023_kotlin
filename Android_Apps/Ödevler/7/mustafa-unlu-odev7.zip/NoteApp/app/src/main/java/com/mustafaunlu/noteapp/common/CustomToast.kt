package com.mustafaunlu.noteapp.common

import android.content.Context
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.mustafaunlu.noteapp.R

object CustomToast {
    private fun makeToast(context: Context, message: String): Toast {
        val customToastLayout = View.inflate(context, R.layout.custom_toast, null)
        val customToastText = customToastLayout.findViewById<TextView>(R.id.toast_text)

        val customToast = Toast(context)
        customToastText.text = message
        customToast.duration = Toast.LENGTH_SHORT
        customToast.view = customToastLayout
        return customToast
    }

    fun emptyFieldAlertToast(context: Context) = makeToast(context, "Please fill all fields").show()
}
