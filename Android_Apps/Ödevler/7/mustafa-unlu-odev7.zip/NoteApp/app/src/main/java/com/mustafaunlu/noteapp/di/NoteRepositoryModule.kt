package com.mustafaunlu.noteapp.di

import com.mustafaunlu.noteapp.repository.NoteRepository
import com.mustafaunlu.noteapp.repository.NoteRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped

@Module
@InstallIn(ViewModelComponent::class)
abstract class NoteRepositoryModule {
    @Binds
    @ViewModelScoped
    abstract fun provideNoteRepository(noteRepository: NoteRepositoryImpl): NoteRepository
}
