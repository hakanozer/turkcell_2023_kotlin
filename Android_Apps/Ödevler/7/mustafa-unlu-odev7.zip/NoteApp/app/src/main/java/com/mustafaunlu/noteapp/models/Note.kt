package com.mustafaunlu.noteapp.models

data class Note(
    val id: Int? = null, // null olmasinin onemi yok, db tarafinda otomatik artan bir id olacak
    val title: String,
    val detail: String,
    val date: String,
)
