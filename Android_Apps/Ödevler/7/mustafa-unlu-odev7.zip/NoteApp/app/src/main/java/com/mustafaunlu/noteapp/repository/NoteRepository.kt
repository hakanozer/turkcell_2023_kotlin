package com.mustafaunlu.noteapp.repository

import com.mustafaunlu.noteapp.models.Note
import kotlinx.coroutines.flow.Flow

interface NoteRepository {
    suspend fun addNote(note: Note)
    suspend fun deleteNoteById(id: Int)
    suspend fun getAllNotes(): Flow<List<Note>>
    suspend fun getNoteById(id: Int): Flow<Note>
}
