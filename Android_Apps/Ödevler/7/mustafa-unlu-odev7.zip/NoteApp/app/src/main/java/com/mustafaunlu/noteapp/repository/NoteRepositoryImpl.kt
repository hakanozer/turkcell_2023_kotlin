package com.mustafaunlu.noteapp.repository

import android.annotation.SuppressLint
import android.content.ContentValues
import com.mustafaunlu.noteapp.database.DatabaseHelper
import com.mustafaunlu.noteapp.models.Note
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import javax.inject.Inject

@SuppressLint("Range")
class NoteRepositoryImpl @Inject constructor(dbHelper: DatabaseHelper) : NoteRepository {
    private val writableDb = dbHelper.writableDatabase
    private val readableDb = dbHelper.readableDatabase
    private val notes = mutableListOf<Note>()

    override suspend fun addNote(note: Note) {
        val values = ContentValues().apply {
            put("title", note.title)
            put("detail", note.detail)
            put("date", note.date)
        }
        withContext(Dispatchers.IO) {
            writableDb.insert("notes", null, values)
        }
    }

    override suspend fun deleteNoteById(id: Int) {
        withContext(Dispatchers.IO) {
            writableDb.delete("notes", "id = ?", arrayOf(id.toString()))
        }
    }

    override suspend fun getAllNotes() = flow {
        notes.clear()
        val cursor = readableDb.query("notes", null, null, null, null, null, null)
        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val title = cursor.getString(cursor.getColumnIndex("title"))
            val detail = cursor.getString(cursor.getColumnIndex("detail"))
            val date = cursor.getString(cursor.getColumnIndex("date"))
            notes.add(Note(id, title, detail, date))
        }
        cursor.close()
        emit(notes)
    }.flowOn(Dispatchers.IO)

    override suspend fun getNoteById(id: Int) = flow {
        val cursor = readableDb.query("notes", null, "id = ?", arrayOf(id.toString()), null, null, null)
        cursor.moveToNext()
        val title = cursor.getString(cursor.getColumnIndex("title"))
        val detail = cursor.getString(cursor.getColumnIndex("detail"))
        val date = cursor.getString(cursor.getColumnIndex("date"))
        cursor.close()
        emit(Note(id, title, detail, date))
    }.flowOn(Dispatchers.IO)
}
