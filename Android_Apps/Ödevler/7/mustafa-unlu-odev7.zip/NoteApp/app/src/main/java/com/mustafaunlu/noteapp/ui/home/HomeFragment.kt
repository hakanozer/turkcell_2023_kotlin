package com.mustafaunlu.noteapp.ui.home

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.noteapp.common.CustomToast
import com.mustafaunlu.noteapp.databinding.FragmentHomeBinding
import com.mustafaunlu.noteapp.models.Note
import com.mustafaunlu.noteapp.utils.clearAndFocus
import com.mustafaunlu.noteapp.viewmodel.NoteViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    private val noteViewModel: NoteViewModel by viewModels()
    private val adapter by lazy { NotesAdapter(::onNoteClicked) }
    private lateinit var date: String
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        noteViewModel.allNotes.observe(viewLifecycleOwner) { notes ->
            adapter.updateItems(notes)
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            rvNote.adapter = adapter
            noteViewModel.getAllNotes()
            btnSetDate.setOnClickListener {
                val datePicker = DatePickerDialog(requireContext())
                datePicker.show()
                datePicker.setOnDateSetListener { _, year, month, dayOfMonth ->
                    date = "$dayOfMonth/${month + 1}/$year"
                }
            }

            btnAddNote.setOnClickListener {
                if (!this@HomeFragment::date.isInitialized || date.isEmpty() || etNoteTitle.text.isNullOrEmpty() || etNoteDetail.text.isNullOrEmpty()) {
                    CustomToast.emptyFieldAlertToast(requireContext())
                    return@setOnClickListener
                }
                val note = Note(
                    title = etNoteTitle.text.toString(),
                    detail = etNoteDetail.text.toString(),
                    date = date,
                )
                noteViewModel.addNote(note)
                date = ""
                etNoteTitle.clearAndFocus()
                etNoteDetail.clearAndFocus()
            }
        }
    }

    private fun onNoteClicked(note: Note) {
        findNavController().navigate(HomeFragmentDirections.homeFragmentToDetailFragment(note.id!!))
    }
}


