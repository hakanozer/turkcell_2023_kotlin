package com.mustafaunlu.noteapp.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.noteapp.databinding.ItemNoteBinding
import com.mustafaunlu.noteapp.models.Note

class NotesAdapter(private val onClickedItem: (Note) -> Unit) : RecyclerView.Adapter<NotesAdapter.NoteViewHolder>() {
    private val items = mutableListOf<Note>()

    fun updateItems(newItems: List<Note>) {
        items.apply {
            clear()
            addAll(newItems)
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        return NoteViewHolder(
            ItemNoteBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false,
            ),
        )
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    inner class NoteViewHolder(private var binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Note) {
            with(binding) {
                tvDate.text = item.date
                tvTitle.text = item.title
                root.setOnClickListener { onClickedItem(item) }
            }
        }
    }
}
