package com.mustafaunlu.noteapp.utils

import android.widget.EditText

fun EditText.clearAndFocus() {
    this.text.clear()
    this.requestFocus()
}
