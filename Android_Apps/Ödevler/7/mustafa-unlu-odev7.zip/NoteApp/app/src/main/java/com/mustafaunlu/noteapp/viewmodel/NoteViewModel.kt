package com.mustafaunlu.noteapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.noteapp.models.Note
import com.mustafaunlu.noteapp.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(private val repository: NoteRepository) : ViewModel() {

    private val _allNotes = MutableLiveData<List<Note>>()
    val allNotes: LiveData<List<Note>> get() = _allNotes

    private val _singleNote = MutableLiveData<Note>()
    val singleNote: LiveData<Note> get() = _singleNote

    init {
        getAllNotes()
    }

    fun addNote(note: Note) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addNote(note)
            getAllNotes()
        }
    }

    fun deleteNoteById(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNoteById(id)
        }
    }

    fun getAllNotes() = viewModelScope.launch(Dispatchers.IO) {
        repository.getAllNotes().collect { notes ->
            _allNotes.postValue(notes)
        }
    }

    fun getNoteById(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.getNoteById(id).collect { note ->
            _singleNote.postValue(note)
        }
    }
}
