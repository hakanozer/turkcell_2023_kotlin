package com.example.days_13

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.View
import com.example.days_13.databinding.ActivityDetailBinding
import com.example.days_13.databinding.ActivityMainBinding
import com.example.days_13.models.Note
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        val bundle = intent.extras
        val note = Gson().fromJson<Note>(bundle?.getString("note"), object: TypeToken<Note>() {}.type)

        configure(note)


    }

    fun configure(note:Note) {
        binding.titleText.text=note.title
        binding.descText.text=note.detail
        binding.dateText.text=note.date
binding.deleteButton.setOnClickListener {
    DB(this).deleteNote(note.nid)
    finish()
}
    }

}