package com.example.days_13

import android.R
import android.R.attr.value
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.days_13.databinding.ActivityMainBinding
import com.example.days_13.models.Note
import com.google.gson.Gson
import java.util.Calendar

//@author Enes Ay

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    var adapter: ArrayAdapter<String>? = null
    lateinit var db: DB

    var selectDate = ""
    var notes: List<Note>? = listOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)


        db = DB(this)


        val calender = Calendar.getInstance()

        notes = db.allNote()

        adapter =
            notes?.let { ArrayAdapter(this, R.layout.simple_list_item_1, it.map { it.title }) }

// ListView'e adapter'ımızı atıyoruz
        binding.listView.adapter = adapter
// ListView öğesine bir öğe tıklandığında yapılacak işlemler
        binding.listView.setOnItemClickListener { parent, view, position, id ->
            val clickedNote = notes!![position] // Tıklanan notu al
            onSetClick(clickedNote)
            Toast.makeText(this, "Tıklanan Not Başlığı: ${clickedNote.title}", Toast.LENGTH_SHORT)
                .show()
        }


        binding.dateButton.setOnClickListener(View.OnClickListener {
            val datePickerDialog = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { datePicker, i, i2, i3 ->
                    Log.d("i", i.toString()) // yıl
                    Log.d("i2", (i2 + 1).toString()) // ay
                    Log.d("i3", i3.toString()) // gün
                    var ay = "${i2 + 1}"
                    if (i2 + 1 < 10) {
                        ay = "0${i2 + 1}"
                    }
                    selectDate = "$i3.$ay.$i"
                    binding.dateButton.text = "$i3.$ay.$i"
                },
                calender.get(Calendar.YEAR),
                calender.get(Calendar.MONTH),
                calender.get(Calendar.DAY_OF_MONTH),
            )
            datePickerDialog.show()
        })

        binding.saveButton.setOnClickListener {
            if (selectDate != "") {

                var status = db.addNote(
                    binding.editTitle.text.toString(),
                    binding.editDetail.text.toString(),
                    selectDate
                )
                Log.d("status", status.toString())
                selectDate = ""
                binding.dateButton.text = "Select Date"

                binding.editDetail.setText("")
                binding.editTitle.setText("")
            } else {
                Toast.makeText(this, "Plase Select Date!", Toast.LENGTH_LONG).show()
            }
            notes = db.allNote()
            adapter?.clear()
            adapter?.addAll(notes!!.map { it.title })
            adapter?.notifyDataSetChanged()

        }


    }



    fun onSetClick(data: Note) {
        val mIntent = Intent(this, DetailActivity::class.java)
        val mBundle = Bundle()
        mBundle.putString("note", Gson().toJson(data))
        mIntent.putExtras(mBundle)
        startActivity(mIntent)
    }


    override fun onResume() {
        super.onResume()

        notes = db.allNote()
        adapter?.clear()
        adapter?.addAll(notes!!.map { it.title })
        adapter?.notifyDataSetChanged()
    }
}