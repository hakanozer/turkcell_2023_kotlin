package com.example.days_13.models

data class Note(
    val nid: Int,
    val title: String,
    val detail: String,
    val date: String
)
