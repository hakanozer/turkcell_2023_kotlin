package com.example.odev_7.interfaces

interface IFragmentListener {

}