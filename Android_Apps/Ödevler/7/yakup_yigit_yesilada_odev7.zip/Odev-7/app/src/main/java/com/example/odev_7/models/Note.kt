package com.example.odev_7.models

data class Note(
    val nid : Int,
    val title : String,
    val description : String,
    val createdAt : String,
    val modifiedAt : String?,
)
