package com.cankarademir.cankarademirkisilerimapp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.ListFragment
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.cankarademir.cankarademirkisilerimapp.Main2Activity
import com.cankarademir.cankarademirkisilerimapp.R
import com.cankarademir.cankarademirkisilerimapp.models.Kisilerim
import com.cankarademir.cankarademirkisilerimapp.ui.detail.DetailFragment

class RecyclerViewAdapter : RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>() {

    private var userList = emptyList<Kisilerim>()

    class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtName = view.findViewById<TextView>(R.id.textName)
        val txtPhone = view.findViewById<TextView>(R.id.textPhone)
        fun bind(kisilerim: Kisilerim) {
            txtName.setText(kisilerim.name + " " + kisilerim.surname)
            txtPhone.setText(kisilerim.phone.toString())
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerViewAdapter.MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.custum_item, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerViewAdapter.MyViewHolder, position: Int) {
        val currentUser = userList.get(position)
        holder.bind(currentUser)
        holder.itemView.setOnClickListener(object :View.OnClickListener{
            override fun onClick(v: View?) {
                val activity = v!!.context as Main2Activity
                val detailFragment = DetailFragment()
                activity.supportFragmentManager.beginTransaction().replace(R.id.drawer_layout,detailFragment).addToBackStack(null).commit()
            }

        })
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    fun setData(userList: List<Kisilerim>) {
        this.userList = userList
        notifyDataSetChanged()
    }
}