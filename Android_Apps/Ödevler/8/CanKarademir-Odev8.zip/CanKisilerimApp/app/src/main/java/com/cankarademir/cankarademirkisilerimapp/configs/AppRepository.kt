package com.cankarademir.cankarademirkisilerimapp.configs

import com.cankarademir.cankarademirkisilerimapp.dao.KisilerimDao
import com.cankarademir.cankarademirkisilerimapp.models.Kisilerim

class AppRepository(private val kisilerimDao: KisilerimDao) {

    suspend fun addKisi(Kisi:Kisilerim){
        kisilerimDao.insert(Kisi)
    }
    suspend fun updateKisi(Kisi:Kisilerim){
        kisilerimDao.update(Kisi)
    }
    suspend fun deleteKisi(Kisi:Kisilerim){
        kisilerimDao.delete(Kisi)
    }

}