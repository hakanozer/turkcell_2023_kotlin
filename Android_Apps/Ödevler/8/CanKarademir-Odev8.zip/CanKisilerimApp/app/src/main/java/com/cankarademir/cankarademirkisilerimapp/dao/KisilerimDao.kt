package com.cankarademir.cankarademirkisilerimapp.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.cankarademir.cankarademirkisilerimapp.models.Kisilerim

@Dao
interface KisilerimDao {
    @Query("SELECT * FROM kisilerim_table ")
    fun getAll(): LiveData<List<Kisilerim>>

    @Query("SELECT * FROM kisilerim_table WHERE 'Best Friend'")
    fun getBest(): LiveData<List<Kisilerim>>

    @Query("SELECT * FROM kisilerim_table WHERE 'Family'")
    fun getFamily(): LiveData<List<Kisilerim>>

    @Query("SELECT * FROM kisilerim_table WHERE 'School'")
    fun getSchool(): LiveData<List<Kisilerim>>

    @Query("SELECT * FROM kisilerim_table WHERE 'Work'")
    fun getWork(): LiveData<List<Kisilerim>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(kisilerim: Kisilerim)

    @Delete
    suspend fun delete(kisilerim: Kisilerim)

    @Update
    suspend fun update(kisilerim: Kisilerim)

}