package com.cankarademir.cankarademirkisilerimapp.models

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "kisilerim_table")
data class Kisilerim(
    @PrimaryKey(autoGenerate = true) val nid: Int?,
    @ColumnInfo(name = "name") val name:String?,
    @ColumnInfo(name = "surname") val surname:String?,
    @ColumnInfo(name = "phone") val phone:String?,
    @ColumnInfo(name = "group") val group: String?,
    @ColumnInfo(name = "address") val address:String?
    ):Parcelable
