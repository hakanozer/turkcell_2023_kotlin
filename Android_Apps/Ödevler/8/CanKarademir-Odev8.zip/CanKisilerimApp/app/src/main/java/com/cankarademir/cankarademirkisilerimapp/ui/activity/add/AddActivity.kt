package com.cankarademir.cankarademirkisilerimapp.ui.activity.add

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.Toast
import com.cankarademir.cankarademirkisilerimapp.Main2Activity
import com.cankarademir.cankarademirkisilerimapp.R
import com.cankarademir.cankarademirkisilerimapp.dao.KisilerimDao
import com.cankarademir.cankarademirkisilerimapp.databinding.ActivityAddBinding
import com.cankarademir.cankarademirkisilerimapp.models.Kisilerim
import com.example.days_18.configs.AppDatabase
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class AddActivity : AppCompatActivity() {

    private lateinit var appDB: AppDatabase
    lateinit var binding: ActivityAddBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        binding =ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)
        appDB = AppDatabase.getDatabase(this)


        val adapter = ArrayAdapter.createFromResource(this,R.array.group_spinner,android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.groupSpinner.adapter= adapter


        binding.btnAdd.setOnClickListener{ view ->
            val name = binding.nameEditText.text.toString()
            val surname = binding.surnameEditText.text.toString()
            val address = binding.addressEditText.text.toString()
            val number = binding.editTextPhone.text.toString()
            val selectedGroup = binding.groupSpinner.selectedItem.toString()

            if(name.isNotEmpty() && surname.isNotEmpty() && address.isNotEmpty() && number.isNotEmpty() && selectedGroup.isNotEmpty()){
                val kisilerim =Kisilerim(
                    null, name,surname,number,selectedGroup,address
                )
                GlobalScope.launch(Dispatchers.IO) {
                    appDB.kisilerimDao().insert(kisilerim)
                }
                val snackbar = Snackbar.make(view, "Phone Number Saved..", Snackbar.LENGTH_LONG)
                snackbar.duration = 4000
                snackbar.show()

                Handler().postDelayed({
                    if (snackbar.isShown) {
                        snackbar.dismiss()
                        val intent = Intent(this@AddActivity, Main2Activity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }, 4000)

            }else Toast.makeText(this@AddActivity,"Please Enter Data", Toast.LENGTH_SHORT).show()
        }
    }
}