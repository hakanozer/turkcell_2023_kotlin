package com.cankarademir.cankarademirkisilerimapp.ui.bestfriend

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.cankarademir.cankarademirkisilerimapp.R
import com.cankarademir.cankarademirkisilerimapp.adapters.RecyclerViewAdapter
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentBestFriendBinding
import com.cankarademir.cankarademirkisilerimapp.ui.home.HomeViewModel

class BestFriendFragment : Fragment() {

    private var _binding: FragmentBestFriendBinding? = null
    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var bestFriendViewModel: BestFriendViewModel

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBestFriendBinding.inflate(inflater, container, false)
        val root: View = binding.root

        bestFriendViewModel = ViewModelProvider(this).get(BestFriendViewModel::class.java)

        val recyclerView = binding.recyclerViewBestFriend
        recyclerView.layoutManager = LinearLayoutManager(context)

        recyclerViewAdapter= RecyclerViewAdapter()
        recyclerView.adapter = recyclerViewAdapter

        bestFriendViewModel.readData.observe(viewLifecycleOwner, { kisiList ->
            recyclerViewAdapter.setData(kisiList)
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}