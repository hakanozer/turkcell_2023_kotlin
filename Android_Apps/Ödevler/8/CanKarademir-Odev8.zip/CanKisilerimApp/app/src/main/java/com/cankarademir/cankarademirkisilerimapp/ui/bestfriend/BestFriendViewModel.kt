package com.cankarademir.cankarademirkisilerimapp.ui.bestfriend

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.cankarademir.cankarademirkisilerimapp.configs.AppRepository
import com.cankarademir.cankarademirkisilerimapp.models.Kisilerim
import com.example.days_18.configs.AppDatabase

class BestFriendViewModel(application: Application) : AndroidViewModel(application) {
    private val kisilerimDao = AppDatabase.getDatabase(application).kisilerimDao()
    val readData: LiveData<List<Kisilerim>> = kisilerimDao.getBest()
}
