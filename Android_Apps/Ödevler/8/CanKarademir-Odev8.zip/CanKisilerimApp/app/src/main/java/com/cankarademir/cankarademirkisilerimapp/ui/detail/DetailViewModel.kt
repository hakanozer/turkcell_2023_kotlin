package com.cankarademir.cankarademirkisilerimapp.ui.detail

import androidx.lifecycle.ViewModel

class DetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}