package com.cankarademir.cankarademirkisilerimapp.ui.family

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.cankarademir.cankarademirkisilerimapp.adapters.RecyclerViewAdapter
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentBestFriendBinding
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentFamilyBinding
import com.cankarademir.cankarademirkisilerimapp.ui.bestfriend.BestFriendViewModel

class FamilyFragment : Fragment() {

    private var _binding: FragmentFamilyBinding? = null
    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var familyViewModel: FamilyViewModel

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFamilyBinding.inflate(inflater, container, false)
        val root: View = binding.root

        familyViewModel = ViewModelProvider(this).get(FamilyViewModel::class.java)

        val recyclerView = binding.recyclerViewFamily
        recyclerView.layoutManager = LinearLayoutManager(context)

        recyclerViewAdapter= RecyclerViewAdapter()
        recyclerView.adapter = recyclerViewAdapter

        familyViewModel.readData.observe(viewLifecycleOwner, { kisiList ->
            recyclerViewAdapter.setData(kisiList)
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}