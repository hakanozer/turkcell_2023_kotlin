package com.cankarademir.cankarademirkisilerimapp.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.cankarademir.cankarademirkisilerimapp.adapters.RecyclerViewAdapter
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var homeViewModel: HomeViewModel

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        val recyclerView = binding.recyclerViewHome
        recyclerView.layoutManager = LinearLayoutManager(context)

        recyclerViewAdapter= RecyclerViewAdapter()
        recyclerView.adapter = recyclerViewAdapter

        homeViewModel.readAllData.observe(viewLifecycleOwner, { kisiList ->
            recyclerViewAdapter.setData(kisiList)
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        }
}