package com.cankarademir.cankarademirkisilerimapp.ui.school

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.cankarademir.cankarademirkisilerimapp.adapters.RecyclerViewAdapter
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentBestFriendBinding
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentSchoolBinding
import com.cankarademir.cankarademirkisilerimapp.ui.bestfriend.BestFriendViewModel

class SchoolFragment : Fragment() {

    private var _binding: FragmentSchoolBinding? = null
    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var schoolViewModel: SchoolViewModel

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSchoolBinding.inflate(inflater, container, false)
        val root: View = binding.root

        schoolViewModel = ViewModelProvider(this).get(SchoolViewModel::class.java)

        val recyclerView = binding.recyclerViewSchool
        recyclerView.layoutManager = LinearLayoutManager(context)

        recyclerViewAdapter= RecyclerViewAdapter()
        recyclerView.adapter = recyclerViewAdapter

        schoolViewModel.readData.observe(viewLifecycleOwner, { kisiList ->
            recyclerViewAdapter.setData(kisiList)
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}