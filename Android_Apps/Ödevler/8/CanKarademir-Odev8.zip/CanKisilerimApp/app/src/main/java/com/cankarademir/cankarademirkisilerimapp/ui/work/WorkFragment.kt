package com.cankarademir.cankarademirkisilerimapp.ui.work

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.cankarademir.cankarademirkisilerimapp.R
import com.cankarademir.cankarademirkisilerimapp.adapters.RecyclerViewAdapter
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentBestFriendBinding
import com.cankarademir.cankarademirkisilerimapp.databinding.FragmentWorkBinding
import com.cankarademir.cankarademirkisilerimapp.ui.bestfriend.BestFriendViewModel

class WorkFragment : Fragment() {

    private var _binding: FragmentWorkBinding? = null
    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var workViewModel: WorkViewModel

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWorkBinding.inflate(inflater, container, false)
        val root: View = binding.root

        workViewModel = ViewModelProvider(this).get(WorkViewModel::class.java)

        val recyclerView = binding.recyclerViewWork
        recyclerView.layoutManager = LinearLayoutManager(context)

        recyclerViewAdapter = RecyclerViewAdapter()
        recyclerView.adapter = recyclerViewAdapter

        workViewModel.readData.observe(viewLifecycleOwner, { kisiList ->
            recyclerViewAdapter.setData(kisiList)
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}