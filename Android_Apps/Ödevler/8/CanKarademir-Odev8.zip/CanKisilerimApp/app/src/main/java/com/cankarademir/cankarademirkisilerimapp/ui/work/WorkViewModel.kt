package com.cankarademir.cankarademirkisilerimapp.ui.work

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.cankarademir.cankarademirkisilerimapp.models.Kisilerim
import com.example.days_18.configs.AppDatabase

class WorkViewModel(application: Application) : AndroidViewModel(application) {
    private val kisilerimDao = AppDatabase.getDatabase(application).kisilerimDao()
    val readData: LiveData<List<Kisilerim>> = kisilerimDao.getWork()
}
