package com.example.odev_8.configs

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.odev_8.dao.PersonalCardDao
import com.example.odev_8.models.PersonalCard

@Database(entities = [PersonalCard::class], version = 1)
abstract class AppDatabase: RoomDatabase() {

    abstract fun personelCardDao(): PersonalCardDao

}