package com.example.odev_8.configs

import com.example.odev_8.models.PersonalCard

class Util {
    companion object {
        var chosen: PersonalCard? = null
    }
}