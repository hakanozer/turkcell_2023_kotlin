package com.example.odev_8.ui.school

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.odev_8.configs.DbController
import com.example.odev_8.models.PersonalCard

class SchoolViewModel : ViewModel() {

    var schoolCards: MutableLiveData<List<PersonalCard>> = MutableLiveData()

    fun getByGroup(context: Context){
        schoolCards.value = DbController(context).db.personelCardDao().getByGroup("School")
    }
}