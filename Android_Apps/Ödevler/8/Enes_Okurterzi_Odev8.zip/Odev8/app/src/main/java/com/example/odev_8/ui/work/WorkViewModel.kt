package com.example.odev_8.ui.work

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.odev_8.configs.DbController
import com.example.odev_8.models.PersonalCard

class WorkViewModel : ViewModel() {

    var workCards: MutableLiveData<List<PersonalCard>> = MutableLiveData()

    fun getByGroup(context: Context){
        workCards.value = DbController(context).db.personelCardDao().getByGroup("Work")
    }

}