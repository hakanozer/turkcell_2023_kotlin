package com.furkandursun.kiilerim.database.room

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface ContactDao {

    @Query("SELECT * FROM myContacts ORDER BY nid DESC LIMIT 10")
    suspend fun getContacts(): List<Contact>

    @Query("SELECT * FROM myContacts WHERE nid like :id")
    suspend fun getContact(id: Int): Contact

    @Query("SELECT * FROM myContacts WHERE category like '%' || :search || '%'")
    suspend fun searchCategory(search: String): List<Contact>

    @Query("SELECT * FROM myContacts WHERE firstName like '%' || :search || '%'")
    suspend fun searchFirstName(search: String): List<Contact>

    @Insert
    suspend fun addContact(contact: Contact)

    @Update
    suspend fun updateContact(contact: Contact)

    @Delete
    suspend fun deleteContact(contact: Contact)

}