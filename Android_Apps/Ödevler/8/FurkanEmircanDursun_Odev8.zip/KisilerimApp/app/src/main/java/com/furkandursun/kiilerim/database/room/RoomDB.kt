package com.furkandursun.kiilerim.database.room

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Contact::class], version = 1)
abstract class RoomDB : RoomDatabase() {

    abstract fun contactDAO(): ContactDao

}