package com.furkandursun.kiilerim.ui.add

import android.R
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.databinding.FragmentAddBinding
import com.furkandursun.kiilerim.utils.createDAO
import com.google.android.material.snackbar.Snackbar

class AddFragment : Fragment() {

    private var _binding: FragmentAddBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private lateinit var addViewModel: AddViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        addViewModel =
            ViewModelProvider(this).get(AddViewModel::class.java)
        addViewModel.contactDao = requireContext().createDAO()
        _binding = FragmentAddBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val spinnerAdapter: ArrayAdapter<String> = ArrayAdapter(
            requireContext(),
            R.layout.simple_spinner_item,
            mutableListOf("Family", "Friends", "Work")
        )
        binding.spinner.adapter = spinnerAdapter

        binding.btnAddContact.setOnClickListener {
            if (!binding.etFirstName.text.isNullOrEmpty() || !binding.etLastName.text.isNullOrEmpty()) {
                val category = binding.spinner.selectedItem as String
                val firstName = binding.etFirstName.text.toString()
                val lastName = binding.etLastName.text.toString()
                val address = binding.etAddress.text.toString()
                val phone = binding.etPhoneNum.text.toString()
                val contact = Contact(null, category, firstName, lastName, phone, address)
                addViewModel.add(contact)
                Snackbar.make(it, "Adding Done.", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
            }
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}