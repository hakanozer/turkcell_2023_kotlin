package com.furkandursun.kiilerim.ui.add

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.database.room.ContactDao
import kotlinx.coroutines.launch

class AddViewModel : ViewModel() {
    lateinit var contactDao: ContactDao

    fun add(contact: Contact) {
        viewModelScope.launch {
            contactDao.addContact(contact)
        }
    }
}