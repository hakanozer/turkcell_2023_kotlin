package com.furkandursun.kiilerim.ui.detail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.database.room.ContactDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DetailViewModel : ViewModel() {
    lateinit var contactDao: ContactDao

    var contact = MutableLiveData<Contact>()
    fun getContactSafeCall(id: Int) {
        viewModelScope.launch(Dispatchers.Main) {
            contact.value= contactDao.getContact(id)
        }
    }

    fun updateContact(contact: Contact) {
        CoroutineScope(Dispatchers.Main).launch {
            contactDao.updateContact(contact)
        }
    }

    fun deleteContact(contact: Contact) {
        CoroutineScope(Dispatchers.Main).launch {
            contactDao.deleteContact(contact)
        }
    }

}