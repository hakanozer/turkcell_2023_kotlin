package com.furkandursun.kiilerim.ui.familyCategory

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.database.room.ContactDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FamilyViewModel : ViewModel() {

    lateinit var contactDao: ContactDao

    private val _list = MutableLiveData<List<Contact>>()
    val contactList: LiveData<List<Contact>> get() = _list

    fun getList() {
        CoroutineScope(Dispatchers.Main).launch {
            _list.value = contactDao.searchCategory("Family")
        }
    }
}