package com.furkandursun.kiilerim.ui.friendsCategory

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.furkandursun.kiilerim.R
import com.furkandursun.kiilerim.adapter.ContactAdapter
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.databinding.FragmentFriendsBinding
import com.furkandursun.kiilerim.utils.createDAO

class FriendsFragment : Fragment() {

    private var _binding: FragmentFriendsBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    lateinit var contactList: List<Contact>
    private lateinit var friendsViewModel: FriendsViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        friendsViewModel =
            ViewModelProvider(this).get(FriendsViewModel::class.java)
        friendsViewModel.contactDao = requireContext().createDAO()

        _binding = FragmentFriendsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        friendsViewModel.getList()

        friendsViewModel.contactList.observe(viewLifecycleOwner) {
            contactList = it
            val adapter = ContactAdapter(requireActivity(), contactList)
            binding.lvFriends.adapter = adapter
        }
        binding.lvFriends.setOnItemClickListener { _, _, position, _ ->
            val navController = findNavController()
            val bundle = Bundle()
            bundle.putInt(
                "id",
                contactList[position].nid!!
            )
            navController.navigate(R.id.nav_detail, bundle)
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}