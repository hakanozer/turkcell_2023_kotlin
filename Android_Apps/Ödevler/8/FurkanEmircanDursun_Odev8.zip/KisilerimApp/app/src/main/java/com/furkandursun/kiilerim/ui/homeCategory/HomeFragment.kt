package com.furkandursun.kiilerim.ui.homeCategory

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.furkandursun.kiilerim.R
import com.furkandursun.kiilerim.adapter.ContactAdapter
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.databinding.FragmentHomeBinding
import com.furkandursun.kiilerim.utils.createDAO

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    lateinit var list: List<Contact>
    lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)
        homeViewModel.contactDao = requireContext().createDAO()

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        homeViewModel.getList()

        homeViewModel.list.observe(viewLifecycleOwner) {
            list = it
            val adapter = ContactAdapter(requireActivity(), list)
            binding.lvHomeContacts.adapter = adapter
        }

        binding.svSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                // Arama gönderildiğinde burası çalışır
                homeViewModel.search(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                // Arama metni değiştiğinde burası çalışır
                homeViewModel.search(newText)
                return true
            }
        })

        binding.lvHomeContacts.setOnItemClickListener { _, _, position, _ ->
            val navController = findNavController()
            val bundle = Bundle()
            bundle.putInt(
                "id",
                list[position].nid!!
            ) // Argümanı bundle'a ekle, istediğiniz veriyi ekleyebilirsiniz
            navController.navigate(R.id.nav_detail, bundle)
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}