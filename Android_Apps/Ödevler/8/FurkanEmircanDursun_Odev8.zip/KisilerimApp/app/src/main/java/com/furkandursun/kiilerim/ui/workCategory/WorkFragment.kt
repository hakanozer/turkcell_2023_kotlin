package com.furkandursun.kiilerim.ui.workCategory

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.furkandursun.kiilerim.R
import com.furkandursun.kiilerim.adapter.ContactAdapter
import com.furkandursun.kiilerim.database.room.Contact
import com.furkandursun.kiilerim.databinding.FragmentWorkBinding
import com.furkandursun.kiilerim.utils.createDAO

class WorkFragment : Fragment() {

    private var _binding: FragmentWorkBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    lateinit var contactList: List<Contact>
    private lateinit var workViewModel: WorkViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        workViewModel =
            ViewModelProvider(this).get(WorkViewModel::class.java)
        workViewModel.contactDao = requireContext().createDAO()
        _binding = FragmentWorkBinding.inflate(inflater, container, false)
        val root: View = binding.root
        workViewModel.getList()

        workViewModel.contactList.observe(viewLifecycleOwner) {
            contactList = it
            val adapter = ContactAdapter(requireActivity(), contactList)
            binding.lvWork.adapter = adapter
        }
        binding.lvWork.setOnItemClickListener { _, _, position, _ ->
            val navController = findNavController()
            val bundle = Bundle()
            bundle.putInt(
                "id",
                contactList[position].nid!!
            )
            navController.navigate(R.id.nav_detail, bundle)
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}