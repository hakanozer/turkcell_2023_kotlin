package com.furkandursun.kiilerim.utils

import android.content.Context
import androidx.room.Room
import com.furkandursun.kiilerim.database.room.ContactDao
import com.furkandursun.kiilerim.database.room.RoomDB

fun Context.createDAO(): ContactDao {
    val db = Room.databaseBuilder(this, RoomDB::class.java, "myContacts.sqlite").build()
    return db.contactDAO()
}