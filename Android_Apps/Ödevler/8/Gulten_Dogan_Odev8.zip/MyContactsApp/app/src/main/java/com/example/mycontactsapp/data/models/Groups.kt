package com.example.mycontactsapp.data.models

enum class Groups {
    FAMILY,
    FRIENDS,
    WORK,
    OTHER
}