package com.altindas.mehmettalhaaltindasodev8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.room.Room
import com.altindas.homework8.config.AppDatabase
import com.altindas.homework8.model.Card
import com.altindas.mehmettalhaaltindasodev8.databinding.ActivityAddCardBinding
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class AddCardActivity : AppCompatActivity() {
    companion object{
        lateinit var latest_fragment:Fragment
    }
    private lateinit var binding: ActivityAddCardBinding
    lateinit var card_group:String
    lateinit var appDb:AppDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        appDb=AppDatabase.getDatabase(this)

        binding = ActivityAddCardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.saveButton.setOnClickListener {
            writeData()
        }
        val URL = "https://cdn4.iconfinder.com/data/icons/top-search-7/128/_user_account_profile_head_person_avatar-512.png"
        Glide.with(this).load(URL).into( binding.addImage)

        binding.addSpinner.onItemSelectedListener=object :AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
            card_group=parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }


    private fun writeData(){
        val cardname=binding.addName.text.toString()
        val cardphone=binding.addPhone.text.toString()
        val cardmail=binding.addMail.text.toString()
        val cardgroup=card_group
        if(cardname.isNotEmpty()&&cardphone.isNotEmpty()&&cardmail.isNotEmpty()){
            val card = Card(
                null,cardname,cardphone,cardmail,cardgroup
            )
            GlobalScope.launch (Dispatchers.IO){
                appDb.cardDao().insert(card)
            }
           // Snackbar.make(v.requireView(), "Kişi kaydı başarılı.", Snackbar.LENGTH_LONG).setDuration(3000).show()

            finish()
        }else{
     //       Snackbar.make(v.requireView(), "Lütfen bilgileri eksiksik giriniz.", Snackbar.LENGTH_LONG).setDuration(3000).show()
        }
    }

}

