package com.altindas.mehmettalhaaltindasodev8

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.fragment.app.FragmentActivity
import com.altindas.homework8.config.AppDatabase
import com.altindas.homework8.model.Card
import com.altindas.mehmettalhaaltindasodev8.adapter.CardListAdapter
import com.altindas.mehmettalhaaltindasodev8.ui.home.HomeFragment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CommonFunctions {
    fun getLastItems(cards: List<Card>,card_group: String): List<Card> {
        val filteredCards= mutableListOf<Card>()
        for (i in cards.size - 1 downTo cards.size-10) {
            Log.d("getlastitem",cards[i].cardGroup.toString())
            if(i==0){
                break
            }else{
                when (card_group) {
                    "Aile" -> {
                        if(cards[i].cardGroup=="Aile"){
                            filteredCards.add(cards[i])
                        }
                    }
                    "Okul" -> {
                        if(cards[i].cardGroup=="Okul"){
                            filteredCards.add(cards[i])
                        }
                    }
                    "Arkadaşlar" -> {
                        if(cards[i].cardGroup=="Arkadaşlar"){
                            filteredCards.add(cards[i])
                        }
                    }
                    "İş" -> {
                        if(cards[i].cardGroup=="İş"){
                            filteredCards.add(cards[i])
                        }
                    }
                    "Halı Saha" -> {
                        if(cards[i].cardGroup=="Halı Saha"){
                            filteredCards.add(cards[i])
                        }
                    }
                    else -> filteredCards.add(cards[i])
                }
            }
        }
        return filteredCards
    }
    fun readData(appDb:AppDatabase,listView:ListView, Frag:FragmentActivity,card_group:String) {
        lateinit var cards:List<Card>
        GlobalScope.launch(Dispatchers.IO) {
            cards=appDb.cardDao().getAll()
            val filteredCards=getLastItems(cards,card_group)
            Log.d("filteredcard",filteredCards.toString())
            displayData(listView,filteredCards,Frag)
        }
    }

    suspend fun displayData(listView:ListView, cards: List<Card>, Frag:FragmentActivity) {
        withContext(Dispatchers.Main){

            var adapter_card = CardListAdapter(Frag,cards)
            listView.adapter =adapter_card
            adapter_card.notifyDataSetChanged()
        }
    }
    fun startDetailedCardActivity(position: Int,v: View,appDb: AppDatabase,activity: Activity,context:Context,card_group:String) {
        lateinit var cards:List<Card>
        GlobalScope.launch(Dispatchers.IO) {
            cards=appDb.cardDao().getAll()
            val filteredCards=getLastItems(cards,card_group)

            val intent = Intent(activity, DetailedCardActivity::class.java)
            HomeFragment.selectedCard = Card(
                filteredCards[position].nid,
                filteredCards[position].name,
                filteredCards[position].phoneNumber,
                filteredCards[position].mail,
                filteredCards[position].cardGroup
            )
            Log.d("detail",HomeFragment.selectedCard.toString())
            context.startActivity(intent)
        }

    }

    fun cardListSearch(appDb: AppDatabase,text_field:EditText,list_View:ListView,Frag: FragmentActivity,card_group:String) {
        lateinit var cards:List<Card>

        val user_input=text_field.text.toString()
        if(user_input.isNotEmpty()){
            GlobalScope.launch(Dispatchers.IO) {
                cards=appDb.cardDao().searchTitle(user_input)
                displayData(list_View,cards,Frag)
            }
        }else{
            readData(appDb,list_View,Frag, card_group)
        }

    }
}

