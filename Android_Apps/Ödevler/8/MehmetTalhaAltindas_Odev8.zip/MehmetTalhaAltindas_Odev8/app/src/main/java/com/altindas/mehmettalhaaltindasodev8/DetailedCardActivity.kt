package com.altindas.mehmettalhaaltindasodev8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import com.altindas.homework8.config.AppDatabase
import com.altindas.homework8.model.Card
import com.altindas.mehmettalhaaltindasodev8.databinding.ActivityAddCardBinding
import com.altindas.mehmettalhaaltindasodev8.databinding.ActivityDetailedCardBinding
import com.altindas.mehmettalhaaltindasodev8.ui.home.HomeFragment
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DetailedCardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailedCardBinding
    lateinit var appDb:AppDatabase
    lateinit var card_group:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        binding = ActivityDetailedCardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        appDb=AppDatabase.getDatabase(this)

        Log.d("spinner","${HomeFragment.selectedCard}")


        binding.cardName.setText(HomeFragment.selectedCard.name)
        binding.cardMail.setText(HomeFragment.selectedCard.mail)
        binding.cardPhone.setText(HomeFragment.selectedCard.phoneNumber)
        val URL = "https://cdn4.iconfinder.com/data/icons/top-search-7/128/_user_account_profile_head_person_avatar-512.png"
        Glide.with(this).load(URL).into( binding.addImage)
        binding.buttonEdit.setOnClickListener {editData(HomeFragment.selectedCard.nid)}
        binding.buttonDelete.setOnClickListener { deleteData() }
        binding.cardSpinner.setSelection(spinnerInitialize(HomeFragment.selectedCard.cardGroup!!))
        binding.cardSpinner.onItemSelectedListener=object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                card_group=parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

        }
    }

    private fun deleteData() {
        val card=Card(HomeFragment.selectedCard.nid,
            HomeFragment.selectedCard.name,
            HomeFragment.selectedCard.phoneNumber,
            HomeFragment.selectedCard.mail,
            HomeFragment.selectedCard.cardGroup
            )

        GlobalScope.launch (Dispatchers.IO){
            appDb.cardDao().delete(card)
        }
        finish()

    }

    private fun spinnerInitialize(inputGroup:String): Int {
        val card_groups=resources.getStringArray(R.array.card_groups)
        return  when (inputGroup) {
            card_groups[0].toString() -> 0
            card_groups[1].toString() -> 1
            card_groups[2].toString() -> 2
            card_groups[3].toString() -> 3
            card_groups[4].toString() -> 4
            else -> 0
        }
    }

    private fun editData(nid:Int?) {

        val cardname=binding.cardName.text.toString()
        val cardphone=binding.cardPhone.text.toString()
        val cardmail=binding.cardMail.text.toString()
        val cardgroup=card_group

        if(cardname.isNotEmpty()&&cardphone.isNotEmpty()&&cardmail.isNotEmpty()){
            GlobalScope.launch (Dispatchers.IO){
                appDb.cardDao().update(cardname,cardphone,cardmail,cardgroup,nid!!)
            }
            finish()
        }else{
//            Snackbar.make(, "Lütfen bilgileri eksiksik giriniz.", Snackbar.LENGTH_LONG).setDuration(3000).show()
            Toast.makeText(this,"Lütfen bilgileri eksiksik giriniz", Toast.LENGTH_SHORT).show()
        }


    }

}