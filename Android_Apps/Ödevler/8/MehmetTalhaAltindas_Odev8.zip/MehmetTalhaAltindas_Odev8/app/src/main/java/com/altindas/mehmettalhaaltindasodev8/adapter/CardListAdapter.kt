package com.altindas.mehmettalhaaltindasodev8.adapter

import android.app.Activity
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.altindas.homework8.model.Card
import com.altindas.mehmettalhaaltindasodev8.R
import com.bumptech.glide.Glide

class CardListAdapter(private val context: Activity, private val list: List<Card>) : ArrayAdapter<Card>(context, R.layout.custom_listview, list)
{
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_listview, null, true)

        val p_name = rootView.findViewById<TextView>(R.id.person_name)
        val p_group = rootView.findViewById<TextView>(R.id.person_group)
        val p_phone = rootView.findViewById<TextView>(R.id.person_phone)
        val p_mail = rootView.findViewById<TextView>(R.id.person_mail)

        val p_image = rootView.findViewById<ImageView>(R.id.grid_image)

        val card = list.get(position)
        Log.d("adapterr",card.toString())
        p_name.text = card.name
        p_group.text = card.cardGroup
        p_phone.text = card.phoneNumber
        p_mail.text = card.mail
        //p_image.setImageDrawable(context.getDrawable(R.drawable.profile_icon))
        val URL = "https://cdn4.iconfinder.com/data/icons/top-search-7/128/_user_account_profile_head_person_avatar-512.png"
        Glide.with(rootView).load(URL).into(p_image)




        return rootView
    }
}