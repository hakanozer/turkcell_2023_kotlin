package com.altindas.homework8.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.altindas.homework8.model.Card

@Dao
interface CardDao {
    @Insert
    suspend fun insert( card: Card) : Long

    @Query("select * from card")
    fun getAll() : List<Card>

    @Query("select * from card where name like :title ")
    suspend fun searchTitle( title: String ) : List<Card>

    @Query("select * from card where cardGroup like :cardGroup ")
    suspend fun searchCardGroup( cardGroup: String ) : List<Card>

    @Query("select * from card where nid =:nid")
    suspend fun findById( nid: Int ) : Card

    @Delete
    suspend fun delete(card: Card)

    @Query("UPDATE card SET name=:name_in,phoneNumber=:phoneNumber_in,mail=:mail_in,cardgroup=:cardgroup_in WHERE nid LIKE:nid_in")
    suspend fun update( name_in: String,phoneNumber_in:String,mail_in:String,cardgroup_in:String,nid_in: Int)
}