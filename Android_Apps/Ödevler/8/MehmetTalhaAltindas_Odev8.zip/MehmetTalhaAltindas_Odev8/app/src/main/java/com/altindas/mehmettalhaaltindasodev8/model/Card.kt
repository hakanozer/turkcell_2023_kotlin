package com.altindas.homework8.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "card")
data class Card(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "nid")
    val nid: Int?,
    val name:String?,
    val phoneNumber:String?,
    val mail:String?,
    val cardGroup:String?
)
