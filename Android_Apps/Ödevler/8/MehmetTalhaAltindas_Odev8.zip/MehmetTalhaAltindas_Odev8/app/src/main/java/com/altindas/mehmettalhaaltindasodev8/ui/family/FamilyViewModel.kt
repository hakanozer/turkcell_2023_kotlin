package com.altindas.mehmettalhaaltindasodev8.ui.family

import androidx.lifecycle.ViewModel

class FamilyViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}