package com.altindas.mehmettalhaaltindasodev8.ui.football

import androidx.lifecycle.ViewModel

class FootballViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}