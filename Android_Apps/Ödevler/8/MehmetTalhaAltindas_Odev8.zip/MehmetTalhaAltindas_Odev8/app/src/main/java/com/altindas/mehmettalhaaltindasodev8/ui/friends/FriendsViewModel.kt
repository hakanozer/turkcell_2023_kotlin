package com.altindas.mehmettalhaaltindasodev8.ui.friends

import androidx.lifecycle.ViewModel

class FriendsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}