package com.altindas.mehmettalhaaltindasodev8.ui.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.altindas.homework8.config.AppDatabase
import com.altindas.homework8.model.Card
import com.altindas.mehmettalhaaltindasodev8.AddCardActivity
import com.altindas.mehmettalhaaltindasodev8.CommonFunctions
import com.altindas.mehmettalhaaltindasodev8.DetailedCardActivity
import com.altindas.mehmettalhaaltindasodev8.adapter.CardListAdapter
import com.altindas.mehmettalhaaltindasodev8.databinding.FragmentHomeBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeFragment : Fragment() {
    companion object{
        lateinit var selectedCard:Card
    }
    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var appDb: AppDatabase
    lateinit var adapter_card:CardListAdapter
    lateinit var filteredCard:List<Card>
    var a=CommonFunctions()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root



        appDb=AppDatabase.getDatabase(this.requireContext())
        binding.cardList.setOnItemClickListener { parent, view, position, id ->
            a.startDetailedCardActivity(position,view,appDb,this.requireActivity(),requireContext(),"Home")
        }


        binding.searchButton.setOnClickListener {
            a.cardListSearch(appDb,binding.searchText,binding.cardList,requireActivity(),"Home")
        }
        return root
    }

    override fun onResume() {
        super.onResume()
        a.readData(appDb,binding.cardList,requireActivity(),"Home")

    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    /*
    private fun cardListSearch() {
        lateinit var cards:List<Card>
        val user_input=binding.searchText.text.toString()
        if(user_input.isNotEmpty()){
            GlobalScope.launch(Dispatchers.IO) {
                cards=appDb.cardDao().searchTitle(user_input)
                displayData(cards)
            }
        }else{
            readData()
        }

    }

    private fun startDetailedCardActivity(position: Int,v:View) {
        lateinit var cards:List<Card>
        GlobalScope.launch(Dispatchers.IO) {
            cards=filteredCard
            Log.d("intent",position.toString())
            Log.d("intent",cards[position].toString())

            val intent = Intent(activity, DetailedCardActivity::class.java)
            selectedCard=Card(
                cards[position].nid,
                cards[position].name,
                cards[position].phoneNumber,
                cards[position].mail,
                cards[position].cardGroup
            )
            startActivity(intent)
        }
    }

    private fun getLastItems(cards: List<Card>): List<Card> {

        val filteredCards= mutableListOf<Card>()
        for (i in cards.size - 1 downTo cards.size-10) {
            println(cards[i])
            if(i==0){
                break
            }else{
                filteredCards.add(cards[i])
            }
        }
        filteredCard=filteredCards
        return filteredCards
    }



    private fun readData() {
        lateinit var cards:List<Card>
        GlobalScope.launch(Dispatchers.IO) {
            cards=appDb.cardDao().getAll()
            val filteredCards=getLastItems(cards)

            displayData(filteredCards)
        }
    }

    private suspend fun displayData(cards: List<Card>) {
       withContext(Dispatchers.Main){
           adapter_card = CardListAdapter(requireActivity(),cards)
           binding.cardList.adapter =adapter_card
           adapter_card.notifyDataSetChanged()
       }
    }

     */


}