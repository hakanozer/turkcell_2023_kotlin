package com.altindas.mehmettalhaaltindasodev8.ui.school

import android.content.Intent
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.altindas.homework8.config.AppDatabase
import com.altindas.homework8.model.Card
import com.altindas.mehmettalhaaltindasodev8.AddCardActivity
import com.altindas.mehmettalhaaltindasodev8.CommonFunctions
import com.altindas.mehmettalhaaltindasodev8.DetailedCardActivity
import com.altindas.mehmettalhaaltindasodev8.R
import com.altindas.mehmettalhaaltindasodev8.adapter.CardListAdapter
import com.altindas.mehmettalhaaltindasodev8.databinding.FragmentFamilyBinding
import com.altindas.mehmettalhaaltindasodev8.databinding.FragmentSchoolBinding
import com.altindas.mehmettalhaaltindasodev8.databinding.FragmentWorkBinding
import com.altindas.mehmettalhaaltindasodev8.ui.home.HomeFragment
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class School : Fragment() {

    companion object {
        fun newInstance() = School()
    }

    private lateinit var viewModel: SchoolViewModel
    private lateinit var appDb: AppDatabase
    lateinit var adapter_card: CardListAdapter
    private var _binding: FragmentSchoolBinding? = null
    private val binding get() = _binding!!
    lateinit var filteredCard:List<Card>
    var a= CommonFunctions()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSchoolBinding.inflate(inflater, container, false)
        val root: View = binding.root

        appDb=AppDatabase.getDatabase(this.requireContext())
        binding.cardList.setOnItemClickListener { parent, view, position, id ->
            a.startDetailedCardActivity(position,view,appDb,this.requireActivity(),requireContext(),"Okul")
        }


        binding.searchButton.setOnClickListener {
            a.cardListSearch(appDb,binding.searchText,binding.cardList,requireActivity(),"Okul")
        }
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(SchoolViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onResume() {
        super.onResume()

        a.readData(appDb,binding.cardList,requireActivity(),"Okul")
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }



}