package com.altindas.mehmettalhaaltindasodev8.ui.school

import androidx.lifecycle.ViewModel

class SchoolViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}