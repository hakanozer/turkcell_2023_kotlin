package com.altindas.mehmettalhaaltindasodev8.ui.work

import androidx.lifecycle.ViewModel

class WorkViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}