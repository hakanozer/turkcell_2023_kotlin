package com.example.orhan_ucar_odev8.ui.aile

import androidx.lifecycle.ViewModel

class AileViewModel : ViewModel() {

}