package com.example.orhan_ucar_odev8.ui.anasayfa

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AnasayfaViewModel : ViewModel() {

}
