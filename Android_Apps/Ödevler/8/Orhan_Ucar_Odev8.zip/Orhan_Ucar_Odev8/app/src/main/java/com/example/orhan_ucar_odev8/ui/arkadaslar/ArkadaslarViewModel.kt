package com.example.orhan_ucar_odev8.ui.arkadaslar

import androidx.lifecycle.ViewModel

class ArkadaslarViewModel : ViewModel() {

}