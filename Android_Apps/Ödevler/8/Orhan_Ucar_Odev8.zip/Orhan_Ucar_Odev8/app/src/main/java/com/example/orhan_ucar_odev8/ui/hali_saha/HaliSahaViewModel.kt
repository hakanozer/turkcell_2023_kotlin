package com.example.orhan_ucar_odev8.ui.hali_saha

import androidx.lifecycle.ViewModel

class HaliSahaViewModel : ViewModel() {
}