package com.example.orhan_ucar_odev8.ui.`is`

import androidx.lifecycle.ViewModel

class IsViewModel : ViewModel() {
}