package com.example.orhan_ucar_odev8.ui.okul

import androidx.lifecycle.ViewModel

class OkulViewModel : ViewModel() {

}