package com.example.orhan_ucar_odev8.ui.turkcell

import androidx.lifecycle.ViewModel

class TurkcellViewModel : ViewModel() {
}