package com.mustafaunlu.contactmanager

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ContactApplication : Application()