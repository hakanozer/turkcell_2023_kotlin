package com.example.firebase_login_example

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.firebase_login_example.models.Place

class Adapter(private val placeList : ArrayList<Place>) : RecyclerView.Adapter<Adapter.MyViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.placecard,
            parent,false)
        return MyViewHolder(itemView)

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val currentitem = placeList[position]

        holder.placetitle.text = currentitem.title
        holder.placecity.text = currentitem.city
        holder.placenote.text = currentitem.note

    }

    override fun getItemCount(): Int {

        return placeList.size
    }


    class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){

        val placetitle : TextView = itemView.findViewById(R.id.tvplaceName)
        val placecity : TextView = itemView.findViewById(R.id.tvcityName)
        val placenote : TextView = itemView.findViewById(R.id.tvnotes)

    }

}