package com.example.firebase_login_example

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebase_login_example.models.Place
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class PlaceList : AppCompatActivity() {

    private lateinit var dbref : DatabaseReference
    private lateinit var placeRecyclerview : RecyclerView
    private lateinit var placeArrayList : ArrayList<Place>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_place_list)


        placeRecyclerview = findViewById(R.id.placeList)
        placeRecyclerview.layoutManager = LinearLayoutManager(this)
        placeRecyclerview.setHasFixedSize(true)

        placeArrayList = arrayListOf<Place>()
        getUserData()
    }

    private fun getUserData() {

        dbref = FirebaseDatabase.getInstance().getReference("Users")

        dbref.addValueEventListener(object : ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {

                if (snapshot.exists()){

                    for (userSnapshot in snapshot.children){


                        val user = userSnapshot.getValue(Place::class.java)
                        placeArrayList.add(user!!)

                    }

                    placeRecyclerview.adapter = Adapter(placeArrayList)


                }

            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }


        })

    }
}