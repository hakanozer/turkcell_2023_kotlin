package com.example.firebase_login_example.models

data class Place(
    val title: String?,
    val city: String?,
    val note: String?
)
