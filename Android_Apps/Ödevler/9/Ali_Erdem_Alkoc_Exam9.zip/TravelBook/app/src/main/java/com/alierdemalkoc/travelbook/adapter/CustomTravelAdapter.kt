package com.alierdemalkoc.travelbook.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.alierdemalkoc.travelbook.R
import com.alierdemalkoc.travelbook.model.Travel
import com.alierdemalkoc.travelbook.model.TravelKey

class CustomTravelAdapter (private val context: Activity, private val list: List<TravelKey>) : ArrayAdapter<TravelKey>(context, R.layout.custom_list_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)

        val r_title = rootView.findViewById<TextView>(R.id.r_title)
        val r_city = rootView.findViewById<TextView>(R.id.r_city)

        val travel = list.get(position)

        r_title.text = "${travel.travel.title}"
        r_city.text = "${travel.travel.city}"

        return rootView
    }

}