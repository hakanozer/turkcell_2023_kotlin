package com.alierdemalkoc.travelbook.model

data class Travel(
    val title: String = "",
    val city: String = "",
    val notes: String = ""
)

data class TravelKey(
    val key: String,
    val travel: Travel
)
