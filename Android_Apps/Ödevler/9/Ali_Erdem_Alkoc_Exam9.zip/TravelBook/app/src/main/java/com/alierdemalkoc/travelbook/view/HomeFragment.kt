package com.alierdemalkoc.travelbook.view

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.alierdemalkoc.travelbook.adapter.CustomTravelAdapter
import com.alierdemalkoc.travelbook.databinding.FragmentHomeBinding
import com.alierdemalkoc.travelbook.model.Travel
import com.alierdemalkoc.travelbook.model.TravelKey
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import java.util.*


class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    private lateinit var database: FirebaseDatabase
    lateinit var listView: ListView
    lateinit var addButton: Button
    var uid: String = ""
    var key: String = ""
    var travelKeyList = arrayListOf<TravelKey>()
    lateinit var customTravelAdapter: CustomTravelAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = Firebase.auth
        database = FirebaseDatabase.getInstance()
        databaseReference = database.reference.push()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addButton = binding.addButton
        listView = binding.travelList
        customTravelAdapter = CustomTravelAdapter(requireActivity(), travelKeyList)
        listView.adapter = customTravelAdapter
        addButton.setOnClickListener {
            val title = binding.titleText.text.toString()
            val city = binding.cityText.text.toString()
            val notes = binding.notesText.text.toString()
            if (TextUtils.isEmpty(title)){
                binding.titleText.error = "Please Insert Title"
                return@setOnClickListener
            } else if (TextUtils.isEmpty(city)){
                binding.cityText.error = "Please Insert City"
                return@setOnClickListener
            } else if (TextUtils.isEmpty(notes)){
                binding.notesText.error = "Please Insert Note"
            } else{
                val travel = Travel(title, city, notes)
                val userId = auth.currentUser?.uid
                databaseReference.child(userId!!)
                uid = databaseReference.push().key.toString()
                databaseReference.child(uid).setValue(travel).addOnSuccessListener {
                    Toast.makeText(requireContext(), "Added succesfully", Toast.LENGTH_LONG).show()
                }.addOnFailureListener {
                    Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_LONG).show()
                }
            }


        }

        val userId = auth.currentUser?.uid
        databaseReference.orderByChild(userId!!).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                travelKeyList.clear()
                if ( snapshot.exists() ) {
                    snapshot.children.forEach {
                        val travel = it.getValue(Travel::class.java)
                        Log.d("key", it.key.toString())
                        key = it.key.toString()
                        val travelKey = TravelKey(key, travel!!)
                        travelKeyList.add(travelKey)
                    }
                }
                customTravelAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("err", error.toString())
            }
        })

        listView.setOnItemLongClickListener { adapterView, view, i, l ->
            val builder = AlertDialog.Builder(requireContext())
            builder.setTitle("Remove")
            builder.setMessage("Do you want to remove?")
            key = travelKeyList[i].key
            builder.setPositiveButton("Yes", DialogInterface.OnClickListener { dialog, which ->
                databaseReference.child(key).removeValue()
            })
            builder.setNegativeButton("No", DialogInterface.OnClickListener { dialogInterface, i ->
                Toast.makeText(requireContext(), "Cancelled", Toast.LENGTH_LONG).show()
            })
            builder.show()
            true
        }



}
}