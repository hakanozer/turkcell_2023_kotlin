package com.alierdemalkoc.travelbook.view

import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.alierdemalkoc.travelbook.R
import com.alierdemalkoc.travelbook.databinding.FragmentSignUpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class SignUpFragment : Fragment() {
    private var _binding: FragmentSignUpBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    private lateinit var database: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        databaseReference = database.reference.child("Profile")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSignUpBinding.inflate(inflater,container,false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.signUpButton.setOnClickListener {
            val nameAndSurname = binding.nameSurnameText.text.toString()
            val newPassword = binding.newPasswordText.text.toString()
            val newEmail = binding.newEmailText.text.toString()
            if (TextUtils.isEmpty(nameAndSurname)) {
                binding.nameSurnameText.error = "Please insert name and surname!"
                return@setOnClickListener
            } else if (TextUtils.isEmpty(newPassword)) {
                binding.newPasswordText.error = "Please insert password"
                return@setOnClickListener
            } else if (TextUtils.isEmpty(newEmail)) {
                binding.newEmailText.error = "please insert email"
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(binding.newEmailText.text.toString(), binding.newPasswordText.text.toString())
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val currentUser = auth.currentUser
                        val currentUserDb = currentUser?.let { databaseReference.child(it.uid) }
                        currentUserDb?.child("nameAndSurname")?.setValue(binding.nameSurnameText.text.toString())
                        Toast.makeText(requireContext(),"Succes Sign Up", Toast.LENGTH_SHORT).show()
                        auth.signOut()
                        findNavController().navigate(R.id.signUpToLogin)
                    } else {
                        Toast.makeText(
                            requireContext(), "Authentication failed.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}