package com.nsicyber.travel2share.Customs

object Constants {
    var currentUser:String=""
}