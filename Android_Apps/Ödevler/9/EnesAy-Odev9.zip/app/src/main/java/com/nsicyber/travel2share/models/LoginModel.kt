package com.nsicyber.travel2share.models

class LoginModel {
}