package com.nsicyber.travel2share.models

data class NoteModel (var title:String="",var location:String="",var note:String="")