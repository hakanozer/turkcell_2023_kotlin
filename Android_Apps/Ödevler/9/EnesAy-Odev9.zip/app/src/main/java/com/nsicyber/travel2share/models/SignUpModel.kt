package com.nsicyber.travel2share.models

data class SignUpModel (var title:String,var location:String,var note:String)