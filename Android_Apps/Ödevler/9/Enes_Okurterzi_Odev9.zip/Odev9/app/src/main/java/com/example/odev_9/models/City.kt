package com.example.odev_9.models

import com.google.firebase.Timestamp


data class City (
    var title: String = "",
    var content: String = "",
    var timestamp: Timestamp = Timestamp.now()
        )


