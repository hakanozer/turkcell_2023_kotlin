package com.example.odev_9.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.odev_9.configs.Util
import com.example.odev_9.databinding.ActivityCityDetailsBinding
import com.example.odev_9.models.City
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentReference

class CityDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCityDetailsBinding

    private var title: String? = null
    private var content: String? = null
    private var docId: String? = null
    private var isEditMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCityDetailsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        editMode()

        binding.saveCityButton.setOnClickListener { saveCity() }

    }

    private fun editMode() {
        title = intent.getStringExtra("title")
        content = intent.getStringExtra("content")
        docId = intent.getStringExtra("docId")

        if (docId != null) {
            isEditMode = true
        }

        if (isEditMode) {
            binding.cityTitleText.setText(title)
            binding.cityContentText.setText(content)
            binding.pageTitle.text = "Edit your city"
        }
    }

    private fun saveCity() {
        binding.apply {
            val cityTitle = cityTitleText.text.toString()
            val cityContent = cityContentText.text.toString()

            if (cityTitle.isEmpty()) {
                cityTitleText.error = "Title is required"
                return
            }
            val city = City(cityTitle, cityContent, Timestamp.now())

            saveCityToFirebase(city)

        }
    }

    private fun saveCityToFirebase(city: City) {
        var documentReference : DocumentReference = if (isEditMode) {
            Util.getCollectionReferenceForCities().document(docId!!)
        }else {
            Util.getCollectionReferenceForCities().document()
        }

        documentReference.set(city).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                if (isEditMode) {
                    Util.showToast(this, "City updated successfully")
                } else {
                    Util.showToast(this, "City added successfully")
                }
                finish()
            } else {
                if (isEditMode) {
                    Util.showToast(this, "Failed while updating city")
                }else {
                    Util.showToast(this, "Failed while adding city")
                }

            }
        }
    }

}