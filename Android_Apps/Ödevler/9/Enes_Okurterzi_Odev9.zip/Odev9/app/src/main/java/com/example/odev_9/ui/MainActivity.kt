package com.example.odev_9.ui

import android.content.Intent
import android.os.Bundle
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.odev_9.adapter.CityAdapter
import com.example.odev_9.configs.Util
import com.example.odev_9.databinding.ActivityMainBinding
import com.example.odev_9.models.City
import com.firebase.ui.firestore.FirestoreRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.Query

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cityAdapter: CityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.addNoteBtn.setOnClickListener {
            startActivity(Intent(this, CityDetailsActivity::class.java))
        }

        binding.menuBtn.setOnClickListener { showMenu() }

        setupRecyclerView()

    }

    private fun setupRecyclerView() {
        val query = Util.getCollectionReferenceForCities()
            .orderBy("timestamp", Query.Direction.DESCENDING)

        val options = FirestoreRecyclerOptions.Builder<City>()
            .setQuery(query, City::class.java).build()

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        cityAdapter = CityAdapter(options, this)
        binding.recyclerView.adapter = cityAdapter

    }

    private fun showMenu() {
        val popupMenu = PopupMenu(this,binding.menuBtn)
        popupMenu.menu.add("Logout")
        popupMenu.show()

        popupMenu.setOnMenuItemClickListener {
            if (it.title == "Logout") {
                FirebaseAuth.getInstance().signOut()
                startActivity(Intent(this,LoginActivity::class.java))
                finish()
            }
            true
        }
    }

    override fun onStart() {
        super.onStart()
        cityAdapter.startListening()
    }

    override fun onStop() {
        super.onStop()
        cityAdapter.stopListening()
    }

    override fun onResume() {
        super.onResume()
        cityAdapter.notifyDataSetChanged()
    }

}