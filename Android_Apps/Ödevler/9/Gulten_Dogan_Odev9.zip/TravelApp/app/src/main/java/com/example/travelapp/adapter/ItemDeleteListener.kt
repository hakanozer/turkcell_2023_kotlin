package com.example.travelapp.adapter

interface ItemDeleteListener {
    fun onItemDelete(position: Int)
}