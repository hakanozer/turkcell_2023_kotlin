package com.serapercel.travelapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.serapercel.travelapp.databinding.ListItemBinding
import com.serapercel.travelapp.model.Travel

class TravelAdapter(
    private val travelList: MutableList<Travel>) :
    RecyclerView.Adapter<TravelAdapter.TravelViewHolder>() {

    inner class TravelViewHolder(binding: ListItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val binding: ListItemBinding

        init {
            this.binding = binding
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TravelViewHolder {
        val from = LayoutInflater.from(parent.context)
        val binding = ListItemBinding.inflate(from, parent, false)
        return TravelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TravelViewHolder, position: Int) {
        val travel = travelList[position]
        holder.binding.tvTitle.text = travel.title
        holder.binding.tvCity.text = travel.city
        holder.binding.tvDesc.text = travel.desc

    }

    override fun getItemCount(): Int = travelList.size
}
