package com.serapercel.travelapp.model

data class Travel(val title:String,val city:String,val desc:String,val id:String)
