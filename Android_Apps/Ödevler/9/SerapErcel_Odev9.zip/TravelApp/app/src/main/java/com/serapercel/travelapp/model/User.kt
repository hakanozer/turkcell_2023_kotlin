package com.serapercel.travelapp.model

data class User(
    val email: String,
    val password: String,
    val uuid: String? = null
)
