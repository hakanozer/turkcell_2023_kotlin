package com.serapercel.travelapp.ui.fragment.addTravel

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.serapercel.travelapp.R
import com.serapercel.travelapp.databinding.FragmentAddTravelBinding

class AddTravelFragment : Fragment() {

    private var _binding: FragmentAddTravelBinding? = null
    private val binding get() = _binding!!
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddTravelBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnAddTravel.setOnClickListener {
            val title = binding.etTitle.text.toString()
            val desc = binding.etDesc.text.toString()
            val city = binding.etCity.text.toString()
            if (title.isNotEmpty() && city.isNotEmpty() && desc.isNotEmpty()) {
                addTravel(title, city, desc)
            } else {
                Toast.makeText(
                    requireContext(),
                    "Bilgileri Eksiksiz Giriniz!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun addTravel(title: String, city: String, desc: String) {
        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        val data = hashMapOf(
            "title" to title,
            "city" to city,
            "description" to desc,
        )
        firestore.collection("Users").document(firebaseAuth.currentUser!!.uid)
            .collection("My_Visit_List").document().set(data).addOnSuccessListener {
                findNavController().navigate(R.id.action_addTravelFragment_to_homeFragment)
            }.addOnFailureListener {
                Toast.makeText(requireContext(), "${it.message}", Toast.LENGTH_SHORT)
                    .show()
            }
    }
}