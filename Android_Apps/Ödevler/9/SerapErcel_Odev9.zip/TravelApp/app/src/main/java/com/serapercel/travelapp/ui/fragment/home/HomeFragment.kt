package com.serapercel.travelapp.ui.fragment.home

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.serapercel.travelapp.R
import com.serapercel.travelapp.adapter.TravelAdapter
import com.serapercel.travelapp.databinding.FragmentHomeBinding
import com.serapercel.travelapp.model.Travel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    private var travelList = mutableListOf<Travel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        getTravels()

        binding.rvTravels.layoutManager = LinearLayoutManager(requireContext())
        val adapter = TravelAdapter(travelList)
        binding.rvTravels.adapter = adapter

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.fabAdd.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_addTravelFragment)
        }

        binding.btnSignOut.setOnClickListener {
            signOut()
            findNavController().navigate(R.id.action_homeFragment_to_signInFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    private fun getTravels() {
        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
        // travelList.clear()

        val currentUserUid = firebaseAuth.currentUser!!.uid

        val query = firestore.collection("Users").document(currentUserUid)
            .collection("My_Visit_List")

        query.addSnapshotListener { snapshot, exception ->
            if (exception != null) {
                return@addSnapshotListener
            } else {
                for (document in snapshot?.documents ?: emptyList()) {
                    val title = document.getString("title") ?: ""
                    val city = document.getString("city") ?: ""
                    val desc = document.getString("description") ?: ""
                    val uid = document.id
                    Log.d("uuid", uid)

                    val visit = Travel(title, city, desc, uid)
                    travelList.add(visit)

                }
                val adapter = TravelAdapter(travelList)
                binding.rvTravels.adapter = adapter
            }
        }
    }

    private fun signOut() {
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseAuth.signOut()
    }

}