package com.serapercel.travelapp.ui.fragment.signIn

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.serapercel.travelapp.R
import com.serapercel.travelapp.databinding.FragmentSignInBinding

class SignInFragment : Fragment() {

    private var _binding: FragmentSignInBinding? = null
    private val binding get() = _binding!!
    private lateinit var email: String
    private lateinit var password: String
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSignInBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.signIn.setOnClickListener {
            email = binding.email.text.toString()
            password = binding.password.text.toString()
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Bilgilerinizi Giriniz!",
                    Toast.LENGTH_SHORT
                ).show()
            } else login(email, password)
        }

        binding.tvforgotPassword.setOnClickListener {
            email = binding.email.text.toString()
            if (email.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Mail Adresinizi Giriniz!",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                forgotPassword(email)
            }
        }

        binding.signUp.setOnClickListener {
            findNavController().navigate(R.id.action_signInFragment_to_signUpFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun login(email: String, password: String) {
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                Toast.makeText(
                    requireContext(),
                    "Giriş Başarılı!",
                    Toast.LENGTH_SHORT
                ).show()
                findNavController().navigate(R.id.action_signInFragment_to_homeFragment)
            }.addOnFailureListener {
                Toast.makeText(
                    requireContext(),
                    it.message,
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    private fun forgotPassword(email: String) {
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseAuth.sendPasswordResetEmail(email)
            .addOnSuccessListener {
                Toast.makeText(
                    requireContext(),
                    "Şifre yenileme maili gönderildi!",
                    Toast.LENGTH_LONG
                ).show()
            }.addOnFailureListener {
                Toast.makeText(
                    requireContext(),
                    "Error: ${it.message.toString()}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}