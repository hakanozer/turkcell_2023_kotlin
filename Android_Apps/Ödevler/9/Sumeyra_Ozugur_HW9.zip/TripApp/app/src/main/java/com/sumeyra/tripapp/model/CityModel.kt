package com.sumeyra.tripapp.model

data class CityModel(val docId: String, val id:String, val title:String, val cityName:String, val notes:String)
