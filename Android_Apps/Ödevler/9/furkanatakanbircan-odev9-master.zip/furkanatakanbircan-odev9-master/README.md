# GezilecekYerlerApp

#
## Firebase auth ve realtime database kullanılarak kullanıcı kayıt,giriş,çıkış ve  ihtiyaçlara göre gittiği şehirler hakkında not alabildiği ve bunların databasede tutulduğu uygulamadır.


| Tool              |Version |
| ---               | ---    | 
|   Android SDK     | 33     |
|   JAVA            | 1.8    | 
| Firebase Database | 20.0.4 | 
| Firebase-auth     | 22.0.0 |


| Fotoğraf 1 | Fotoğraf 2 | Fotoğraf 3 |  Fotoğraf 4| Fotoğraf 5 |  Fotoğraf 6|
| --- | --- | --- | --- | --- | --- |
| ![appPhoto](https://github.com/atakanbircan/furkanatakanbircan-odev9/assets/57329064/4b0875c3-304b-4989-b2a8-80fcc052f417) |![appPhoto](https://github.com/atakanbircan/furkanatakanbircan-odev9/assets/57329064/d284de7a-7287-4a17-8290-025d79961744) |![appPhoto](https://github.com/atakanbircan/furkanatakanbircan-odev9/assets/57329064/ab160a41-a939-4266-bba4-443ca62182d1) |![appPhoto](https://github.com/atakanbircan/furkanatakanbircan-odev9/assets/57329064/ee238002-dfb0-4eaa-9af7-6e1ab884eea9) |![appPhoto](https://github.com/atakanbircan/furkanatakanbircan-odev9/assets/57329064/408a3966-c225-4a5c-b96d-b95a9855946c)) |![appPhoto](https://github.com/atakanbircan/furkanatakanbircan-odev9/assets/57329064/23124fb8-f4ad-4578-a26a-6d9e1f753df6) |














