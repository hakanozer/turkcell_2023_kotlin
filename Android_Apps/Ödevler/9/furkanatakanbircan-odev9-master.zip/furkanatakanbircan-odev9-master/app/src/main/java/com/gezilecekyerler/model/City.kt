package com.gezilecekyerler.model

data class City(
    val title:String,
    val detail:String
)
