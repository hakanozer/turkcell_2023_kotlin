package com.gezilecekyerler.model

import java.util.UUID

data class User(
    var userName:String,
    var userEmail:String,
    var userPassword:String
)
