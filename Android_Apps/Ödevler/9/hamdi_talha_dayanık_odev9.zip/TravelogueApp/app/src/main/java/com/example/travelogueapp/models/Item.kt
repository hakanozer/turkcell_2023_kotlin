package com.example.travelogueapp.models

data class Item(
    val itemId: String,
    val title: String,
    val city: String,
    val notes: String
)
