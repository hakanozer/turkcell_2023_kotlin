package com.mustafaunlu.travelerapp.data.model

data class Place(
    val uid: String? = null,
    val documentId: String? = null,
    val title: String? = null,
    val description: String? = null,
    val city: String? = null,
    val date: String? = null,
)
