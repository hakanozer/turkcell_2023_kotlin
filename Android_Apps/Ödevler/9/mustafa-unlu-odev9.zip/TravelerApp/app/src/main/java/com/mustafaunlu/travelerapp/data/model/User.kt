package com.mustafaunlu.travelerapp.data.model

data class User(
    val uid: String,
    val email: String,
    val password: String,
    val name: String,
    val surname: String,
)
