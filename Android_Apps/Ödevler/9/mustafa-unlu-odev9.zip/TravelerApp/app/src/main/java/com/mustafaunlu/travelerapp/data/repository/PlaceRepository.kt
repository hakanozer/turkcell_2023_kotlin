package com.mustafaunlu.travelerapp.data.repository

import com.google.firebase.firestore.QuerySnapshot
import com.mustafaunlu.travelerapp.data.model.Place

interface PlaceRepository {

    fun addPlace(
        title: String,
        description: String,
        city: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    )

    fun deletePlace(
        documentId: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    )

    fun getPlaceByCurrentUid(
        uid: String,
        onSuccess: (List<Place>) -> Unit,
        onFailure: (String) -> Unit,
    )

    fun getCurrentUserUid(): String

    fun snapshotToList(
        querySnapshot: QuerySnapshot?,
        list: (List<Place>) -> Unit,
    )
}
