package com.mustafaunlu.travelerapp.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.mustafaunlu.travelerapp.data.model.Place
import com.mustafaunlu.travelerapp.utils.getDateTimeAsFormattedString
import javax.inject.Inject

class PlaceRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
) : PlaceRepository {
    override fun addPlace(
        title: String,
        description: String,
        city: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    ) {
        val placeModel = hashMapOf(
            "uid" to auth.currentUser?.uid.orEmpty(),
            "title" to title,
            "description" to description,
            "city" to city,
            "date" to getDateTimeAsFormattedString(),
        )

        firestore.collection("Places").add(placeModel)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it.message.orEmpty()) }
    }

    override fun deletePlace(
        documentId: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    ) {
        firestore.collection("Places").document(documentId).delete().addOnSuccessListener {
            onSuccess()
        }.addOnFailureListener {
            onFailure(it.message.orEmpty())
        }
    }

    override fun getPlaceByCurrentUid(
        uid: String,
        onSuccess: (List<Place>) -> Unit,
        onFailure: (String) -> Unit,
    ) {
        firestore.collection("Places").whereEqualTo("uid", uid).get().addOnSuccessListener { documents ->
            snapshotToList(documents) { onSuccess(it) }
        }.addOnFailureListener {
            onFailure(it.message.orEmpty())
        }
    }

    override fun getCurrentUserUid(): String {
        return auth.currentUser?.uid.orEmpty()
    }

    override fun snapshotToList(querySnapshot: QuerySnapshot?, list: (List<Place>) -> Unit) {
        val tempList = arrayListOf<Place>()

        querySnapshot?.let {
            it.forEach { document ->
                tempList.add(
                    Place(
                        document.data["uid"] as String?,
                        document.id,
                        document.data["title"] as String?,
                        document.data["description"] as String?,
                        document.data["city"] as String?,
                        document.data["date"] as String?,
                    ),
                )
            }

            list(
                tempList.sortedByDescending { Place ->
                    Place.date
                },
            )
        }
    }
}
