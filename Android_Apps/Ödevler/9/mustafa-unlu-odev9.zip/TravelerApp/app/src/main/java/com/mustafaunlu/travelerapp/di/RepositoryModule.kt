package com.mustafaunlu.travelerapp.di

import com.mustafaunlu.travelerapp.data.repository.AuthRepository
import com.mustafaunlu.travelerapp.data.repository.AuthRepositoryImpl
import com.mustafaunlu.travelerapp.data.repository.PlaceRepository
import com.mustafaunlu.travelerapp.data.repository.PlaceRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped

@InstallIn(ViewModelComponent::class)
@Module
abstract class RepositoryModule {

    @Binds
    @ViewModelScoped
    abstract fun bindPlaceRepository(
        placeRepositoryImpl: PlaceRepositoryImpl,
    ): PlaceRepository

    @Binds
    @ViewModelScoped
    abstract fun bindAuthRepository(
        authRepositoryImpl: AuthRepositoryImpl,
    ): AuthRepository
}
