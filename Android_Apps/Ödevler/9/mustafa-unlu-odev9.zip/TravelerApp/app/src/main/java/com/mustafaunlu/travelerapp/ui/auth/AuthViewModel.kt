package com.mustafaunlu.travelerapp.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.travelerapp.data.repository.AuthRepository
import com.mustafaunlu.travelerapp.utils.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repository: AuthRepository,
) : ViewModel() {

    private val _signUp = MutableLiveData<UiState<String>>()
    val signUp: LiveData<UiState<String>> get() = _signUp

    private val _signIn = MutableLiveData<UiState<String>>()
    val signIn: LiveData<UiState<String>> get() = _signIn

    private val _forgotPassword = MutableLiveData<UiState<String>>()
    val forgotPassword: LiveData<UiState<String>> get() = _forgotPassword

    fun signUp(email: String, password: String) {
        viewModelScope.launch {
            _signUp.postValue(UiState.Loading)
            repository.signUpWithEmailAndPassword(
                email,
                password,
                onSuccess = {
                    _signUp.postValue(UiState.Success("Success"))
                },
                onFailure = {
                    _signUp.postValue(UiState.Failure(it))
                },
            )
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            _signIn.postValue(UiState.Loading)
            repository.signInWithEmailAndPassword(
                email,
                password,
                onSuccess = {
                    _signIn.postValue(UiState.Success("Success"))
                },
                onFailure = {
                    _signIn.postValue(UiState.Failure(it))
                },
            )
        }
    }

    fun forgotPassword(email: String) {
        viewModelScope.launch {
            _forgotPassword.postValue(UiState.Loading)
            repository.forgotPassword(
                email,
                onSuccess = {
                    _forgotPassword.postValue(UiState.Success("Success"))
                },
                onFailure = {
                    _forgotPassword.postValue(UiState.Failure(it))
                },
            )
        }
    }
}
