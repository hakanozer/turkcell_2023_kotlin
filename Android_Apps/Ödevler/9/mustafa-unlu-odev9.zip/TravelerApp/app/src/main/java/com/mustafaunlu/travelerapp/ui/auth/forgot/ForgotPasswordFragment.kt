package com.mustafaunlu.travelerapp.ui.auth.forgot

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.mustafaunlu.travelerapp.R
import com.mustafaunlu.travelerapp.databinding.FragmentForgotPasswordBinding
import com.mustafaunlu.travelerapp.ui.auth.AuthViewModel
import com.mustafaunlu.travelerapp.utils.UiState
import com.mustafaunlu.travelerapp.utils.showSnack
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ForgotPasswordFragment : Fragment() {

    private lateinit var binding: FragmentForgotPasswordBinding
    private val viewModel: AuthViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentForgotPasswordBinding.inflate(inflater, container, false)
        (activity as AppCompatActivity).supportActionBar?.hide()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observe()
        binding.btnResetPassword.setOnClickListener {
            checkEmail { email ->
                viewModel.forgotPassword(email)
            }
        }
    }

    private fun observe() {
        viewModel.forgotPassword.observe(viewLifecycleOwner) {
            when (it) {
                is UiState.Success -> {
                    requireView().showSnack(getString(R.string.reset_password_email_sent))
                }
                is UiState.Loading -> {
                    requireView().showSnack(getString(R.string.loading))
                }
                is UiState.Failure -> {
                    requireView().showSnack(it.error ?: getString(R.string.error))
                }
            }
        }
    }

    private fun checkEmail(
        onSuccess: (String) -> Unit,
    ) {
        val email = binding.forgotMailEdttxt.text.toString()

        if (email.isNotEmpty()) {
            onSuccess(email)
        } else {
            requireView().showSnack(getString(R.string.email_cannot_be_empty))
        }
    }
}
