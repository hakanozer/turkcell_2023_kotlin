package com.mustafaunlu.travelerapp.ui.auth.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.travelerapp.R
import com.mustafaunlu.travelerapp.databinding.FragmentLoginBinding
import com.mustafaunlu.travelerapp.ui.auth.AuthViewModel
import com.mustafaunlu.travelerapp.utils.UiState
import com.mustafaunlu.travelerapp.utils.gone
import com.mustafaunlu.travelerapp.utils.showSnack
import com.mustafaunlu.travelerapp.utils.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AuthViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        (activity as AppCompatActivity).supportActionBar?.hide()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observer()
        binding.apply {
            btnSignIn.setOnClickListener {
                checkEmailAndPassword { email, password ->
                    viewModel.signIn(email, password)
                }
            }

            btnSignUp.setOnClickListener {
                findNavController().navigate(R.id.signupFragment)
            }

            btnForgotPassword.setOnClickListener {
                findNavController().navigate(R.id.forgotPasswordFragment)
            }
        }
    }

    private fun observer() {
        viewModel.signIn.observe(viewLifecycleOwner) {
            when (it) {
                is UiState.Success -> {
                    requireView().showSnack(getString(R.string.sign_in_success))
                    findNavController().navigate(R.id.homeFragment)
                }

                is UiState.Failure -> {
                    binding.progressBar.gone()
                    requireView().showSnack(it.error ?: getString(R.string.error))
                }

                is UiState.Loading -> {
                    binding.apply {
                        progressBar.visible()
                        btnForgotPassword.isEnabled = false
                        btnSignIn.isEnabled = false
                        btnSignUp.isEnabled = false
                    }
                }
            }
        }
    }

    private fun checkEmailAndPassword(
        onSuccess: (String, String) -> Unit,
    ) {
        val email = binding.username.text.toString()
        val password = binding.password.text.toString()

        if (email.isNotEmpty() && password.isNotEmpty()) {
            onSuccess(email, password)
        } else {
            requireView().showSnack(getString(R.string.fields_cannot_be_empty))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
