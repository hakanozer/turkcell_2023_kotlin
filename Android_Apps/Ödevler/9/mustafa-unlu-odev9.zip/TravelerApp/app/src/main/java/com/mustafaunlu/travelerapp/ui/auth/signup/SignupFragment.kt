package com.mustafaunlu.travelerapp.ui.auth.signup

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.travelerapp.R
import com.mustafaunlu.travelerapp.databinding.FragmentSignupBinding
import com.mustafaunlu.travelerapp.ui.auth.AuthViewModel
import com.mustafaunlu.travelerapp.utils.UiState
import com.mustafaunlu.travelerapp.utils.showSnack
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SignupFragment : Fragment() {
    private var _binding: FragmentSignupBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AuthViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentSignupBinding.inflate(inflater, container, false)
        (activity as AppCompatActivity).supportActionBar?.hide()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observer()
        binding.btnCreateAccount.setOnClickListener {
            checkEmptyFields { email, password ->
                viewModel.signUp(email, password)
            }
        }
    }

    private fun observer() {
        viewModel.signUp.observe(viewLifecycleOwner) {
            when (it) {
                is UiState.Loading -> {
                    binding.btnCreateAccount.isEnabled = false
                }
                is UiState.Success -> {
                    requireView().showSnack(getString(R.string.sign_up_success))
                    findNavController().navigate(R.id.loginFragment)
                }
                is UiState.Failure -> {
                    requireView().showSnack(it.error ?: "Error")
                }
            }
        }
    }

    private fun checkEmptyFields(
        onSuccess: (String, String) -> Unit,
    ) {
        val email = binding.username.text.toString()
        val password = binding.password.text.toString()
        val name = binding.name.text.toString()
        val surname = binding.surname.text.toString()

        if (email.isNotEmpty() && password.isNotEmpty() && name.isNotEmpty() && surname.isNotEmpty()) {
            onSuccess(email, password)
        } else {
            requireView().showSnack(getString(R.string.fields_cannot_be_empty))
        }
    }
}
