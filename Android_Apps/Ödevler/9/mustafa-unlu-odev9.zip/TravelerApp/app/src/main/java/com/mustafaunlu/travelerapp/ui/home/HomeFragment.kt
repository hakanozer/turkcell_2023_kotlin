package com.mustafaunlu.travelerapp.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.travelerapp.R
import com.mustafaunlu.travelerapp.databinding.FragmentHomeBinding
import com.mustafaunlu.travelerapp.utils.UiState
import com.mustafaunlu.travelerapp.utils.focus
import com.mustafaunlu.travelerapp.utils.gone
import com.mustafaunlu.travelerapp.utils.showSnack
import com.mustafaunlu.travelerapp.utils.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private val viewModel: HomeViewModel by viewModels()
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        (activity as AppCompatActivity).supportActionBar?.apply {
            title = getString(R.string.home_actionbar_title)
            show()
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.addPlace.observe(viewLifecycleOwner) {
            when (it) {
                is UiState.Loading -> {
                    binding.btnSave.isEnabled = false
                    binding.progressBar.visible()
                }
                is UiState.Success -> {
                    binding.progressBar.gone()
                    binding.btnSave.isEnabled = true
                }
                is UiState.Failure -> {
                    binding.progressBar.gone()
                    requireView().showSnack(it.error!!)
                    binding.btnSave.isEnabled = false
                }
            }
        }
        binding.apply {
            btnSave.setOnClickListener {
                checkEmptyFields { title, description, city ->
                    viewModel.addPlace(title, description, city)
                    findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToPlaceFragment())
                }
                binding.apply {
                    descriptionEdttxt.focus()
                    cityEdttxt.focus()
                    titleEdttxt.focus()
                }
            }
        }
    }
    private fun checkEmptyFields(
        onSuccess: (String, String, String) -> Unit,
    ) {
        val title = binding.titleEdttxt.text.toString()
        val description = binding.descriptionEdttxt.text.toString()
        val city = binding.cityEdttxt.text.toString()

        if (title.isNotEmpty() && description.isNotEmpty() && city.isNotEmpty()) {
            onSuccess(title, description, city)
        } else {
            requireView().showSnack(getString(R.string.fields_cannot_be_empty))
        }
    }
}
