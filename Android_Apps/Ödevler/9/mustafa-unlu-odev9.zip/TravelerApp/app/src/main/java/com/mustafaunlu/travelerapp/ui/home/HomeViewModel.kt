package com.mustafaunlu.travelerapp.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.travelerapp.data.repository.PlaceRepository
import com.mustafaunlu.travelerapp.utils.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: PlaceRepository,
) : ViewModel() {

    private val _addPlace = MutableLiveData<UiState<String>>()
    val addPlace: LiveData<UiState<String>> get() = _addPlace

    fun addPlace(title: String, description: String, city: String) {
        viewModelScope.launch {
            _addPlace.value = UiState.Loading
            repository.addPlace(
                title,
                description,
                city,
                onSuccess = {
                    _addPlace.postValue(UiState.Success("Success"))
                },
                onFailure = {
                    _addPlace.postValue(UiState.Failure(it))
                },
            )
        }
    }
}
