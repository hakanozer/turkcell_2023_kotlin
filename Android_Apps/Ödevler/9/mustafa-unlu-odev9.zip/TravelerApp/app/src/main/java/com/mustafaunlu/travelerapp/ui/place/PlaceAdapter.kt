package com.mustafaunlu.travelerapp.ui.place

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.travelerapp.data.model.Place
import com.mustafaunlu.travelerapp.databinding.PlaceItemBinding

class PlaceAdapter(private val itemList: List<Place>, private val onItemLongClicked: (String) -> Unit) :
    RecyclerView.Adapter<PlaceAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = PlaceItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: PlaceAdapter.ViewHolder, position: Int) {
        holder.bind(itemList[position])
    }

    inner class ViewHolder(private val binding: PlaceItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(place: Place) {
            binding.apply {
                title.text = place.title
                description.text = place.description
                city.text = place.city
                root.setOnLongClickListener {
                    onItemLongClicked(place.documentId!!)
                    true
                }
            }
        }
    }
}
