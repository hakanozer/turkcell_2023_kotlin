package com.mustafaunlu.travelerapp.ui.place

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.mustafaunlu.travelerapp.R
import com.mustafaunlu.travelerapp.data.model.Place
import com.mustafaunlu.travelerapp.databinding.FragmentPlaceBinding
import com.mustafaunlu.travelerapp.utils.UiState
import com.mustafaunlu.travelerapp.utils.showConfirmationDialog
import com.mustafaunlu.travelerapp.utils.showSnack
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PlaceFragment : Fragment() {

    private lateinit var binding: FragmentPlaceBinding
    private val viewModel: PlaceViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentPlaceBinding.inflate(inflater, container, false)
        (activity as AppCompatActivity).supportActionBar?.apply {
            title = getString(R.string.place_fragmenet_actionbar_title)
            show()
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observer()
    }

    private fun observer() {
        viewModel.placeList.observe(viewLifecycleOwner) {
            when (it) {
                is UiState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
                is UiState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    val placeList = it.data
                    setupRecyclerView(placeList)
                }
                is UiState.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    requireView().showSnack(it.error ?: getString(R.string.error))
                }
            }
        }

        viewModel.deletePlaceState.observe(viewLifecycleOwner) {
            when (it) {
                is UiState.Loading -> Unit
                is UiState.Success -> {
                    requireView().showSnack(getString(R.string.place_deleted))
                }
                is UiState.Failure -> {
                    requireView().showSnack(it.error ?: getString(R.string.error))
                }
            }
        }
    }

    private fun setupRecyclerView(list: List<Place>) {
        binding.placeRv.apply {
            adapter = PlaceAdapter(list, ::onItemLongClicked)
        }
    }

    private fun onItemLongClicked(placeDocId: String) {
        showConfirmationDialog(getString(R.string.alertdialog_txt)) {
            viewModel.deletePlace(placeDocId)
            viewModel.getPlaces()
        }
    }
}
