package com.mustafaunlu.travelerapp.ui.place

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.travelerapp.data.model.Place
import com.mustafaunlu.travelerapp.data.repository.PlaceRepository
import com.mustafaunlu.travelerapp.utils.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlaceViewModel @Inject constructor(
    private val repository: PlaceRepository,
) : ViewModel() {

    private val _placeList = MutableLiveData<UiState<List<Place>>>(UiState.Loading)
    val placeList: LiveData<UiState<List<Place>>> get() = _placeList

    private val _deletePlaceState = MutableLiveData<UiState<String>>()
    val deletePlaceState: LiveData<UiState<String>> get() = _deletePlaceState

    init {
        getPlaces()
    }

    fun getPlaces() {
        viewModelScope.launch {
            _placeList.value = UiState.Loading
            repository.getPlaceByCurrentUid(
                getCurrentUserUid(),
                onSuccess = {
                    _placeList.value = UiState.Success(it)
                },
                onFailure = {
                    _placeList.value = UiState.Failure(it)
                },
            )
        }
    }

    private fun getCurrentUserUid(): String {
        return repository.getCurrentUserUid()
    }

    fun deletePlace(placeDocId: String) {
        viewModelScope.launch {
            repository.deletePlace(
                placeDocId,
                onSuccess = {
                    _deletePlaceState.value = UiState.Success("Place deleted")
                },
                onFailure = {
                    _deletePlaceState.value = UiState.Failure(it)
                },
            )
        }
    }
}
