package com.mustafaunlu.travelerapp.utils

import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.mustafaunlu.travelerapp.R

fun Fragment.showConfirmationDialog(message: String, onConfirm: () -> Unit) {
    AlertDialog.Builder(requireContext())
        .setMessage(message)
        .setPositiveButton(getString(R.string.dialog_yes)) { _, _ -> onConfirm.invoke() }
        .setNegativeButton(getString(R.string.diaglog_no), null)
        .show()
}
