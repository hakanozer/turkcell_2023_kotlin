package com.mustafaunlu.travelerapp.utils

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun getDateTimeAsFormattedString(): String {
    val dateFormat: DateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("tr"))
    val date = Date()
    return dateFormat.format(date).toString()
}
