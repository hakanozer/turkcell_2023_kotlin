package com.mustafaunlu.travelerapp.utils

import android.view.View
import android.widget.EditText
import com.google.android.material.snackbar.Snackbar

fun View.visible() {
    visibility = View.VISIBLE
}

fun View.gone() {
    visibility = View.GONE
}

fun View.showSnack(text: String) = Snackbar.make(this, text, 1000).show()

fun EditText.focus() {
    this.text.clear()
    requestFocus()
}
