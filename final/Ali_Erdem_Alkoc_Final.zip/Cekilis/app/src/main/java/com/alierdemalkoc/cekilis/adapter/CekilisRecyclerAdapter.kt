package com.alierdemalkoc.cekilis.adapter

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.alierdemalkoc.cekilis.R
import com.alierdemalkoc.cekilis.databinding.CekilisListItemBinding
import com.alierdemalkoc.cekilis.model.Cekilis
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.Glide.with

class CekilisRecyclerAdapter (private val cekilisList: List<Cekilis>) :
    RecyclerView.Adapter<CekilisRecyclerAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val binding = CekilisListItemBinding.bind(itemView)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cekilis_list_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            tvCekilisTitle.text = cekilisList[position].title
            tvEnter.text = cekilisList[position].entryPrice
            tvTime.text = cekilisList[position].timeToLeft
            tvTotal.text = cekilisList[position].total
            with(holder.itemView.context).load("https://www.kimkazandi.com${cekilisList.get(position).img}")
                .transition(DrawableTransitionOptions.withCrossFade()).centerCrop()
                .timeout(75000)
                .into(imgCekilis)
        }
        holder.binding.tvCekilisTitle.setOnClickListener {
            val navController = Navigation.findNavController(holder.itemView)
            val bundle = Bundle()
            bundle.putString("url", cekilisList[position].urlDetail)
            navController.navigate(R.id.nav_main, bundle)
        }
    }

    override fun getItemCount() = cekilisList.size
}