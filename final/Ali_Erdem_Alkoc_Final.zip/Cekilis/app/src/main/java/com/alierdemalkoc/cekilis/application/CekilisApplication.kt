package com.alierdemalkoc.cekilis.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CekilisApplication: Application() {

}