package com.alierdemalkoc.cekilis.db

import androidx.room.*
import com.alierdemalkoc.cekilis.model.Cekilis
import com.alierdemalkoc.cekilis.model.CekilisDetails
import java.util.*

@Dao
interface CekilisDao {

    @Insert
    suspend fun add(cekilis: Cekilis) : Long

    @Query("select * from cekilis")
    suspend fun getAll() : List<Cekilis>

    @Query("select * from cekilis where nid =:nid")
    suspend fun findById(nid: Int) : Cekilis

    @Query("select * from cekilis where url =:url")
    suspend fun getAllByUrl(url: String) : List<Cekilis>

    @Query("select * from cekilis where url =:url")
    suspend fun getByUrl(url: String) : Cekilis

    @Query("select * from cekilis where isFav == 1")
    suspend fun getFollowings(isFav: Boolean) : List<Cekilis>

    @Delete
    suspend fun delete(contact: Cekilis)

    @Update
    suspend fun update(cekilis: Cekilis)

    @Query("SELECT (SELECT COUNT(*) FROM cekilis) == 0")
    suspend fun isEmpty(): Boolean

    @Query("select * from cekilis where date == 1")
    suspend fun upToDate(date: Date): Boolean
}