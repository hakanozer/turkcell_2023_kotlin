package com.alierdemalkoc.cekilis.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.alierdemalkoc.cekilis.model.Cekilis

@Database(entities = [Cekilis::class], version = 1, exportSchema = false)
abstract class CekilisDatabase : RoomDatabase() {

    abstract fun cekilisDao(): CekilisDao

}