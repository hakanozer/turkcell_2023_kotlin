package com.alierdemalkoc.cekilis.di

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.alierdemalkoc.cekilis.db.CekilisDao
import com.alierdemalkoc.cekilis.db.CekilisDatabase
import com.alierdemalkoc.cekilis.repo.CekilisRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.util.prefs.Preferences
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideCekilisDatabase(@ApplicationContext context: Context): CekilisDatabase =
        Room.databaseBuilder(context, CekilisDatabase::class.java, "CekilisDB")
            .fallbackToDestructiveMigration().build()

    @Provides
    @Singleton
    fun provideCekilisDao(cekilisDatabase: CekilisDatabase): CekilisDao = cekilisDatabase.cekilisDao()


    @Singleton
    @Provides
    fun provideCekilisRepo(cekilisDao: CekilisDao): CekilisRepository {
        return CekilisRepository(cekilisDao)
    }

}