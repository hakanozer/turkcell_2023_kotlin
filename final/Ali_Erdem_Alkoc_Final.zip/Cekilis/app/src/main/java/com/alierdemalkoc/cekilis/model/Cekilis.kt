package com.alierdemalkoc.cekilis.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cekilis")
data class Cekilis(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "nid")
    val nid: Int?,

    val title: String?,
    val timeToLeft: String?,
    val img: String?,
    val total: String?,
    val entryPrice: String?,
    val url: String?,
    val detailTitle: String?,
    val titleDetail: String?,
    val start: String?,
    val last: String?,
    val withdraw: String?,
    val date: String?,
    val min: String?,
    val totalPrice: String?,
    val giftSize: String?,
    val urlDetail: String?,
    var isFav: Boolean = false

)

@Entity(tableName = "cekilisDetails")
data class CekilisDetails(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "nid")
    val nid: Int?,
    val detailTitle: String?,
    val titleDetail: String?,
    val start: String?,
    val last: String?,
    val withdraw: String?,
    val date: String?,
    val min: String?,
    val totalPrice: String?,
    val giftSize: String?,
    val url: String?

)

