package com.alierdemalkoc.cekilis.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.alierdemalkoc.cekilis.db.CekilisDao
import com.alierdemalkoc.cekilis.model.Cekilis
import com.alierdemalkoc.cekilis.model.CekilisDetails
import dagger.hilt.android.internal.Contexts
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements
import java.security.KeyManagementException
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class CekilisRepository @Inject constructor(
    private val cekilisDao: CekilisDao
) {
    val cekilisList: MutableLiveData<List<Cekilis>> = MutableLiveData()

    suspend fun getAllByUrl(url: String) {
        cekilisList.postValue(cekilisDao.getAllByUrl(url))
    }

    fun getByUrl(url: String) : Cekilis{
        return getByUrl(url)
    }

    fun returnCekilisList(): MutableLiveData<List<Cekilis>> = cekilisList

    suspend fun addCekilis(cekilis: Cekilis) = cekilisDao.add(cekilis)
    suspend fun updateCekilis(cekilis: Cekilis) = cekilisDao.update(cekilis)
    suspend fun getFollowings(isFav: Boolean = true){
        cekilisList.postValue(cekilisDao.getFollowings(true))
    }

    suspend fun isEmpty() = cekilisDao.isEmpty()

    suspend fun getCekilis(){
        val urls = listOf("https://www.kimkazandi.com/cekilisler",
            "https://www.kimkazandi.com/cekilisler/yeni-baslayanlar",
        "https://www.kimkazandi.com/cekilisler/bedava-katilim",
        "https://www.kimkazandi.com/cekilisler/araba-kazan",
        "https://www.kimkazandi.com/cekilisler/telefon-tablet-kazan",
        "https://www.kimkazandi.com/cekilisler/tatil-kazan")
        for (url in urls){
            val doc: Document = Jsoup.connect(url).timeout(60000).sslSocketFactory(socketFactory()).ignoreContentType(true).get()
            val elements: Elements = doc.getElementsByClass("col-sm-3 col-lg-3 item")
            for (item in elements){
                val img = item.getElementsByClass("img")
                val details = item.getElementsByClass("title d-flex")
                val alt = img.select("img[src]")
                val it = item.select("a[href]")
                val urlDetail = it.attr("href").toString()
                val title = alt.attr("alt").toString()
                val src = alt.attr("src").toString()
                for (detail in details){
                    val dts1 = detail.getElementsByAttributeValue("class", "date d-flex")
                        .select("span")
                        .first()
                        ?.text()
                    val dts2 = detail.getElementsByAttributeValue("class", "date d-flex")
                        .select("span")
                        .last()
                        ?.text()
                    val dts3 = detail.getElementsByClass("kosul_fiyat").text()
                    Log.d("url", urlDetail)
                    val cekilisDetail = getCekilisDetail("https://www.kimkazandi.com$urlDetail")
                    val cekilis = Cekilis(null, title, dts1, src, dts2, dts3, url, cekilisDetail.detailTitle, cekilisDetail.titleDetail, cekilisDetail.start, cekilisDetail.last, cekilisDetail.withdraw, cekilisDetail.date, cekilisDetail.min, cekilisDetail.totalPrice, cekilisDetail.giftSize, urlDetail)
                    addCekilis(cekilis)
                    Log.d("çekiliş", cekilis.toString())
                }
            }
        }
    }

   fun getCekilisDetail(detailUrl: String) : CekilisDetails{
        val docD: Document =
            Jsoup.connect(detailUrl).timeout(60000).sslSocketFactory(socketFactory()).ignoreContentType(true).get()

        val title = docD.selectFirst("div.container > h1")?.text()

           val detail =
               docD.getElementsByClass("secondGallery").select(".scrollbar-dynamic").get(0).text()
            val start =
                docD.getElementsByClass("info mainSocial").select(".kalanSure").get(1).text()
            val last = docD.getElementsByClass("info mainSocial").select(".kalanSure").get(2).text()
            val withdraw =
                docD.getElementsByClass("info mainSocial").select(".kalanSure").get(3).text()
            val date =
                docD.getElementsByClass("info mainSocial").select(".kalanSure").get(4).text()
            val min =
                docD.getElementsByClass("info mainSocial").select(".kalanSure").get(5).text()
            val totalGift =
                docD.getElementsByClass("info mainSocial").select(".kalanSure").get(6).text()
            val giftSize =
                docD.getElementsByClass("info mainSocial").select(".kalanSure").get(7).text()

        val cekilisDetail = CekilisDetails(
            null,
            title,
            detail,
            start,
            last,
            withdraw,
            date,
            min,
            totalGift,
            giftSize,
            detailUrl
        )
       return cekilisDetail
    }

    private fun socketFactory(): SSLSocketFactory {
        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            @Throws(CertificateException::class)
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
            }

            @Throws(CertificateException::class)
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> {
                return arrayOf()
            }
        })

        try {
            val sslContext = SSLContext.getInstance("TLS")
            sslContext.init(null, trustAllCerts, java.security.SecureRandom())
            return sslContext.socketFactory
        } catch (e: Exception) {
            when (e) {
                is RuntimeException, is KeyManagementException -> {
                    throw RuntimeException("Failed to create a SSL socket factory", e)
                }
                else -> throw e
            }
        }
    }

    suspend fun upToDate(date: Date): Boolean {
       return cekilisDao.upToDate(date)
    }
}