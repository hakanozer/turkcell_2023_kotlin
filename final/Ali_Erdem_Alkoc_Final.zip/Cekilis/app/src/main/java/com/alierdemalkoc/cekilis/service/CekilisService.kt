package com.alierdemalkoc.cekilis.service

import android.util.Log
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements


interface CekilisService {

    fun getCekilis() {
        val url = "https://www.kimkazandi.com/cekilisler"
        val doc:Document = Jsoup.connect(url).timeout(15000).ignoreContentType(true).get()
        val elements: Elements = doc.getElementsByClass("row")
        for (item in elements){
            Log.d("item", item.toString())
        }


        /*val arr = mutableListOf<Cekilis>()
        val url = "https://www.tcmb.gov.tr/kurlar/today.xml"
        val doc:Document = Jsoup.connect(url).timeout(15000).ignoreContentType(true).get()
        val elements: Elements = doc.getElementsByTag("Currency")
        for( item in elements ) {
            val Isim = item.getElementsByTag("Isim").text()
            val ForexBuying = item.getElementsByTag("ForexBuying").text()
            val ForexSelling = item.getElementsByTag("ForexSelling").text()
            val BanknoteBuying = item.getElementsByTag("BanknoteBuying").text()
            val BanknoteSelling = item.getElementsByTag("BanknoteSelling").text()
            val DateTarih = doc.getElementsByTag("Tarih_Date")


            val cekilis = Cekilis(null, ForexBuying, ForexSelling, BanknoteBuying, BanknoteSelling, DateTarih.toString());
            arr.add(cekilis)
        }
        return arr*/

    }
}