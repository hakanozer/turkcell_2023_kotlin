package com.alierdemalkoc.cekilis.view.car

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.alierdemalkoc.cekilis.R
import com.alierdemalkoc.cekilis.adapter.CekilisRecyclerAdapter
import com.alierdemalkoc.cekilis.databinding.FragmentBeginnersBinding
import com.alierdemalkoc.cekilis.databinding.FragmentCarBinding
import com.alierdemalkoc.cekilis.view.beginners.BeginnersViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CarFragment : Fragment() {
    private val viewModel: CarViewModel by viewModels()

    private var _binding: FragmentCarBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getCekilis()
        viewModel.cekilisList.observe(viewLifecycleOwner){
            Log.d("observe", it.toString())
            binding.rvCar.adapter = CekilisRecyclerAdapter(it)
        }
    }

}