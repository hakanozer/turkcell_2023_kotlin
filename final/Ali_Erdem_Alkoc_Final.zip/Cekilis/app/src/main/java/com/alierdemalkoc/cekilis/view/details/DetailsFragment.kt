package com.alierdemalkoc.cekilis.view.details

import android.opengl.Visibility
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.viewModelScope
import com.alierdemalkoc.cekilis.R
import com.alierdemalkoc.cekilis.databinding.FragmentBeginnersBinding
import com.alierdemalkoc.cekilis.databinding.FragmentDetailsBinding
import com.alierdemalkoc.cekilis.view.beginners.BeginnersViewModel
import com.bumptech.glide.Glide

class DetailsFragment : Fragment() {
    private val viewModel: DetailsViewModel by viewModels()

    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val detailUrl = arguments?.getString("url")
        val cekilis = viewModel.getCekilisDetail(detailUrl!!)
        if (cekilis.isFav){
            binding.followBtn.visibility = View.GONE
        }
        binding.detailTitle.text = cekilis.detailTitle
        binding.titleDetail.text = cekilis.titleDetail
        binding.date.text = "İlan Tarihi: ${cekilis.date}"
        binding.start.text = "Başlama Tarihi: ${cekilis.start}"
        binding.last.text = "Bitiş Tarihi: ${cekilis.last}"
        binding.withDraw.text = "Çekiliş Tarihi: ${cekilis.withdraw}"
        binding.min.text = "Giriş Ücreti: ${cekilis.min}"
        binding.total.text = "Toplam Hediye: ${cekilis.total}"
        binding.gift.text = "Hediye Sayısı: ${cekilis.giftSize}"
        Glide.with(requireContext()).load("https://www.kimkazandi.com${cekilis.img}").centerCrop().into(binding.detailImg)
        binding.followBtn.setOnClickListener {
            binding.followBtn.visibility = View.GONE
            cekilis.isFav = true
            viewModel.updateCekilis(cekilis)
        }
    }

}