package com.alierdemalkoc.cekilis.view.details

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alierdemalkoc.cekilis.model.Cekilis
import com.alierdemalkoc.cekilis.repo.CekilisRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailsViewModel @Inject constructor(private val cekilisRepository: CekilisRepository) : ViewModel() {

    var cekilisList: LiveData<List<Cekilis>> = cekilisRepository.cekilisList
    lateinit var cekilis: Cekilis

    init {
        cekilisList = cekilisRepository.returnCekilisList()
    }

    fun getCekilisDetail(detailUrl: String) : Cekilis{
        viewModelScope.launch(Dispatchers.IO) {
            cekilis = cekilisRepository.getByUrl(detailUrl)
        }
        return cekilis
    }

    fun updateCekilis(cekilis: Cekilis){
        viewModelScope.launch {
            cekilisRepository.updateCekilis(cekilis)
        }
    }
}