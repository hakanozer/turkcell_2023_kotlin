package com.alierdemalkoc.cekilis.view.draws

import android.app.Application
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.util.Log
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alierdemalkoc.cekilis.model.Cekilis
import com.alierdemalkoc.cekilis.repo.CekilisRepository
import com.bumptech.glide.Glide.init
import dagger.hilt.android.internal.Contexts.getApplication
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class DrawsViewModel @Inject constructor(private val cekilisRepository: CekilisRepository) : ViewModel() {
    var cekilisList: LiveData<List<Cekilis>> = cekilisRepository.cekilisList

    init {
        cekilisList = cekilisRepository.returnCekilisList()
    }

    fun getCekilis(date: Date){
        viewModelScope.launch(IO) {
            if (cekilisRepository.isEmpty()){
                Log.d("null", "null")
                cekilisRepository.getCekilis()
            } else if (cekilisRepository.upToDate(date)){
                Log.d("update", "update")
                cekilisRepository.getCekilis()
            }
            cekilisRepository.getAllByUrl("https://www.kimkazandi.com/cekilisler")
        }


    }
}