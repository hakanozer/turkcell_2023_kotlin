package com.alierdemalkoc.cekilis.view.followings

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alierdemalkoc.cekilis.model.Cekilis
import com.alierdemalkoc.cekilis.repo.CekilisRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FollowingsViewModel @Inject constructor(private val cekilisRepository: CekilisRepository): ViewModel() {
    var cekilisList: LiveData<List<Cekilis>> = cekilisRepository.cekilisList

    init {
        cekilisList = cekilisRepository.returnCekilisList()
    }

    fun getCekilis(){
        viewModelScope.launch(Dispatchers.IO) {
            cekilisRepository.getFollowings(true)
        }
    }
}