package com.cekilisapp

import android.content.Context
import android.util.Log
import com.squareup.picasso.Picasso
import okhttp3.OkHttpClient
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.*
import com.squareup.picasso.OkHttp3Downloader


class PicassoTrustAll private constructor(context: Context) {
    init {
        val client = OkHttpClient()
        client.hostnameVerifier()
        val trustAllCerts: Array<TrustManager> = arrayOf<TrustManager>(object : X509TrustManager {
            @Throws(CertificateException::class)
            override fun checkClientTrusted(
                x509Certificates: Array<X509Certificate?>?,
                s: String?
            ) {
            }

            @Throws(CertificateException::class)
            override fun checkServerTrusted(
                x509Certificates: Array<X509Certificate?>?,
                s: String?
            ) {
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> {
                return arrayOf()
            }


        })
        try {
            val sc: SSLContext = SSLContext.getInstance("TLS")
            sc.init(null, trustAllCerts, SecureRandom())
            client.sslSocketFactory()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mInstance = Picasso.Builder(context)
            .downloader(OkHttp3Downloader(client))
            .listener { picasso, uri, exception -> Log.e("PICASSO", exception.toString()) }.build()
    }

    companion object {
        private var mInstance: Picasso? = null
        fun getInstance(context: Context): Picasso? {
            if (mInstance == null) {
                PicassoTrustAll(context)
            }
            return mInstance
        }
    }
}