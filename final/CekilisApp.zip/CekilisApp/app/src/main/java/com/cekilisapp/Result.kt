package com.cekilisapp

import com.cekilisapp.models.DataType
import com.cekilisapp.models.Raffle
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.select.Elements
import java.security.KeyManagementException
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager


class Result {


    fun raffles(url:String,dataType: DataType): MutableList<Raffle> {
        val arr = mutableListOf<Raffle>()
        val doc:Document= Jsoup.connect(url).timeout(15000).sslSocketFactory(socketFactory()).get()


        val elements: Elements = doc.getElementsByClass("col-sm-3 col-lg-3 item")


        for (element in elements) {
            val imgSrc = element.select("div.img img").attr("abs:src")
            val aHref = element.select("div a[href]").attr("abs:href")
            val h4Text = element.select("div a[href] h4").text()
            val dateText = element.select("div.title span.date.d-flex")

            val duration = element.select("div.title span.date.d-flex i.icon.icon-time").first()?.parent()?.ownText()?.trim() ?: ""
            val gift = element.select("div.title span.date.d-flex i.icon.icon-gift").first()?.parent()?.ownText()?.trim() ?: ""
            val price = element.select("div.title span.date.kosul_fiyat.d-flex i.icon.icon-price").first()?.parent()?.ownText()?.trim() ?: ""


            println("imgSrc: $imgSrc")
            println("aHref: $aHref")
            println("h4Text: $h4Text")
            println("dateText: $dateText")
            println("iconTime: $duration")
            println("iconGift: $gift")
            println("iconPrice: $price")
            println("-------------")
            var raffle = Raffle(imgSrc,aHref, h4Text, duration, gift, price,dataType,false)
            arr.add(raffle)
        }
        return arr


            }


    }

    fun socketFactory(): SSLSocketFactory {
        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            @Throws(CertificateException::class)
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
            }

            @Throws(CertificateException::class)
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> {
                return arrayOf()
            }
        })

        try {
            val sslContext = SSLContext.getInstance("TLS")
            sslContext.init(null, trustAllCerts, java.security.SecureRandom())
            return sslContext.socketFactory
        } catch (e: Exception) {
            when (e) {
                is RuntimeException, is KeyManagementException -> {
                    throw RuntimeException("Failed to create a SSL socket factory", e)
                }
                else -> throw e
            }
        }



}