package com.cekilisapp.adapter

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.R
import com.cekilisapp.gorselIndir
import com.cekilisapp.models.Raffle
import com.cekilisapp.placeHolderYap
import com.cekilisapp.ui.detail.DetailActivity


class RaffleRecyclerAdapter(val listRaffles:ArrayList<Raffle>):
    RecyclerView.Adapter<RaffleRecyclerAdapter.AllRafflesViewHolder>() {




    class AllRafflesViewHolder(itemView:View):RecyclerView.ViewHolder(itemView){
        val title :TextView = itemView.findViewById(R.id.txtTitleRecyclerAdapter )
        val image :ImageView= itemView.findViewById(R.id.imageViewRecyclerAdapter)
        val time :TextView= itemView.findViewById(R.id.txtTimeRecyclerAdapter)
        val gift :TextView = itemView.findViewById(R.id.txtGiftAllMoneyRecyclerAdapter)
        val price :TextView = itemView.findViewById(R.id.txtPriceRecyclerAdapter)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AllRafflesViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.raffle_recycler_row,parent,false)
        return AllRafflesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listRaffles.size
    }

    override fun onBindViewHolder(holder: AllRafflesViewHolder, position: Int) {
        holder.title.text=listRaffles[position].titleOfRaffle
        holder.image.gorselIndir(listRaffles[position].imgSrc, placeHolderYap(holder.itemView.context))

        holder.gift.text=listRaffles[position].gift
        holder.price.text=listRaffles[position].price
        holder.time.text=listRaffles[position].duration

        holder.image.scaleType = ImageView.ScaleType.CENTER_CROP

        // burdan setOnClickListener yapcam detay sayfası için..

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context,DetailActivity::class.java)

            intent.putExtra("ahref",listRaffles[position].detailHref)
            intent.putExtra("title",listRaffles[position].titleOfRaffle)
            intent.putExtra("time",listRaffles[position].duration)
            intent.putExtra("gift",listRaffles[position].gift)
            intent.putExtra("price",listRaffles[position].price)
            intent.putExtra("favorite",listRaffles[position].favorite)
            intent.putExtra("uuid",listRaffles[position].uuid)

            context.startActivity(intent)

        }

    }

    fun updateRaffleList(newRaffleList:List<Raffle>){
        this.listRaffles.clear()
        this.listRaffles.addAll(newRaffleList)
        this.notifyDataSetChanged()     //freagmentta live data ile bu fonk çağırcam!!
    }

}