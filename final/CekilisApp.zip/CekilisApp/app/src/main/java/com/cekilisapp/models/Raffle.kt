package com.cekilisapp.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity
data class Raffle (


    @ColumnInfo(name="image_src")
    val imgSrc:String,
    @ColumnInfo(name="detail_page_href")
    val detailHref:String,
    @ColumnInfo(name = "title")
    val titleOfRaffle: String,
    //val dataText:String,
    @ColumnInfo(name="duration")
    val duration:String,
    @ColumnInfo(name = "gift")
    val gift:String,
    @ColumnInfo(name = "price")
    val price:String,
    @ColumnInfo(name = "data_type")
    val dataType: DataType?,
    @ColumnInfo(name = "is_favorite")
    val favorite :Boolean?
    ) {

    @PrimaryKey(autoGenerate = true)
    var uuid: Int = 0
}
enum class DataType {
    TYPE_tumcekilisler,
    TYPE_yenibaslayanlar,
    TYPE_bedavakatilim,
    TYPE_arabakazan,
    TYPE_telefonkazan,
    TYPE_tatilkazan
}



