package com.cekilisapp.service

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.cekilisapp.models.Raffle

@Database(entities = arrayOf(Raffle::class), version = 1)
abstract class RaffleDB: RoomDatabase() {

    abstract fun raffleDao() : RaffleDao

    companion object{

        @Volatile private var instance : RaffleDB? = null


        private val lock = Any()
        operator fun invoke(context: Context) = instance?: synchronized(lock) {   // for just one works the time at threads
            instance?: createDatabase(context).also {
                instance = it
            }

        }

        private fun createDatabase(context:Context) = Room.databaseBuilder(
            context.applicationContext,RaffleDB::class.java,"raffledatabase").build()
    }

}