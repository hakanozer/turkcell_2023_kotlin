package com.cekilisapp.service

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.cekilisapp.models.DataType
import com.cekilisapp.models.Raffle
@Dao
interface RaffleDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(vararg raffle:Raffle):List<Long>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll1(vararg raffle:Raffle):List<Long>
   // @Insert
    //suspend fun insert(raffle: Raffle): Long
    @Query("UPDATE raffle set is_favorite=:favorite WHERE uuid=:uuid")
    fun setFavorit(favorite:Boolean,uuid:Long)


    @Query("SELECT * FROM raffle ")
    suspend fun getAllRaffles():List<Raffle>

    @Query("SELECT * FROM raffle WHERE data_type =:datatype")
    suspend fun getbyType(datatype:DataType):List<Raffle>





    /*@Query("DELETE FROM raffle WHERE uuid = :raffleId")
    suspend fun deleteRaffle(raffleId:Int)
    
     */

    @Query("DELETE  FROM raffle")
    suspend fun deleteAllRaffles()




}