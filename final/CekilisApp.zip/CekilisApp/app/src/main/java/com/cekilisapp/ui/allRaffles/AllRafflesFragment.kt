package com.cekilisapp.ui.allRaffles

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.adapter.RaffleRecyclerAdapter

import com.cekilisapp.databinding.FragmentAllrafflesBinding
import com.cekilisapp.models.Raffle


class AllRafflesFragment : Fragment() {

    private var _binding: FragmentAllrafflesBinding? = null
    private lateinit var allRafflesViewModel: AllRafflesViewModel
    private lateinit var allRaffleRecycler:RecyclerView
    private val raffleRecyclerAdapter=RaffleRecyclerAdapter(arrayListOf())
        //Raffle("adjdhasd","adşlkdamd","şaldsadk","15","6515","56454")))

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        //allRafflesViewModel =
          //  ViewModelProvider(this).get(AllRafflesViewModel::class.java)

        _binding = FragmentAllrafflesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //val textView: TextView = binding.textHome
        //allRafflesViewModel.text.observe(viewLifecycleOwner) {
          //  textView.text = it
        //}
        //val result = com.cekilisapp.Result()
        //result.raffles("https://www.kimkazandi.com/cekilisler")
        //allRafflesViewModel.getRaffles("https://www.kimkazandi.com/cekilisler")
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        allRafflesViewModel = ViewModelProvider(this).get(AllRafflesViewModel::class.java)
        allRafflesViewModel.refreshData("https://www.kimkazandi.com/cekilisler")

        allRaffleRecycler = binding.allRafflesRecyclerView
        allRaffleRecycler.layoutManager=LinearLayoutManager(context)
        allRaffleRecycler.adapter=raffleRecyclerAdapter

        observeLiveData()
    }

    fun observeLiveData(){
        allRafflesViewModel.arrLiveData.observe(viewLifecycleOwner,Observer{ raffle->
            raffle?.let{
                // recyclerBesinAdapter.besinListesiniGuncelle(besinler) bu benzeri yapı koycam
             raffleRecyclerAdapter.updateRaffleList(raffle)


            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}