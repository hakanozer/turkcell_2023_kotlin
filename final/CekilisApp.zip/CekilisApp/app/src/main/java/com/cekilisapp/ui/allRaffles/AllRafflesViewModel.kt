package com.cekilisapp.ui.allRaffles

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cekilisapp.Result
import com.cekilisapp.models.DataType
import com.cekilisapp.models.Raffle
import com.cekilisapp.service.RaffleDB
import com.cekilisapp.ui.BaseViewModel
import com.cekilisapp.util.CustomSharedPreferences
import io.reactivex.disposables.CompositeDisposable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AllRafflesViewModel(application: Application) : BaseViewModel(application) {
    val arrLiveData = MutableLiveData<List<Raffle>>()
    private var customSharedPreferences = CustomSharedPreferences(getApplication())
    private var refreshTime = 0.1 * 60 * 10 * 1000 * 1000 * 1000L

    private  val disposable = CompositeDisposable()
    /*private val _text = MutableLiveData<String>().apply {
        value = "This is tüm çekilişler Fragment"
    }

     */
    //private val arrLiveData = MutableLiveData<MutableList<Raffle>>()


    //val text: LiveData<String> = _text


    val result = Result()
    //viewModelScope.launch

    fun refreshData(url:String){

        val updateTime = customSharedPreferences.getTime()
        if (updateTime !=null && updateTime !=0L && System.nanoTime()-updateTime<refreshTime) {
            getDataFromByType()
        }else{
            verileriInternettenAl(url)
        }
        //dataStoreInSQLite()

    }

    private fun getDataFromSQLite(){
        viewModelScope.launch {
            val raffleList = RaffleDB(getApplication()).raffleDao().getAllRaffles()
            showRaffles(raffleList)
            Toast.makeText(getApplication(),"Raffles From SQLite",Toast.LENGTH_LONG).show()
        }

    /*launch {
            val raffles = RaffleDB(getApplication()).raffleDao().getAllRaffles()
            //showRaffles(raffles)

            Toast.makeText(getApplication(),"Raffles From SQLite",Toast.LENGTH_LONG).show()
        }

         */
    }
    private fun getDataFromByType() {
        viewModelScope.launch {
            val raffleList =
                RaffleDB(getApplication()).raffleDao().getbyType(DataType.TYPE_tumcekilisler)
            showRaffles(raffleList)
            Toast.makeText(getApplication(), "Raffles From SQLite", Toast.LENGTH_LONG).show()
        }
    }

    private fun verileriInternettenAl(url:String){
        launch {
            withContext(Dispatchers.Default) {
                val currentRaffle = result.raffles(url,DataType.TYPE_tumcekilisler)
            }

            val currentRaffle: List<Raffle> = withContext(Dispatchers.Default) {
                result.raffles(url,DataType.TYPE_tumcekilisler)
            }
            val newList= arrayListOf<Raffle>()
            withContext(Dispatchers.Main){
                for (item in currentRaffle){
                    if (!item.detailHref.isNullOrEmpty()&&!item
                            .titleOfRaffle.isNullOrEmpty()){
                        newList.add(item)
                        //dataStoreInSQLite(newList)  //?
                    }

                    arrLiveData.value=newList.toList()
                    if (newList.isNotEmpty()) {
                        dataStoreInSQLite(newList)
                    }

                }
            }
        }
    }

    private fun dataStoreInSQLite(list:ArrayList<Raffle>){
        val dataType = DataType.TYPE_tumcekilisler.toString()
        launch {
            val dao = RaffleDB(getApplication()).raffleDao()
            dao.deleteAllRaffles()



            val listLong = dao.insertAll(*list.toTypedArray())
            var i = 0
            //while (i< list.size){
            /*  for (item in list){
              item.uuid = listLong[i].toInt()
              //list[i].uuid = listLong[i].toInt()
                i = i+1
            }
             */
            /*while (i<list.size){
                list[i].uuid = listLong[i].toInt()
                i=i+1
            }

             */
            list.forEachIndexed { index, raffle ->
                raffle.uuid = listLong[index].toInt()
            }
            showRaffles(list)
        }

        customSharedPreferences.saveTime(System.nanoTime())
    }

    private fun showRaffles(rafflesList:List<Raffle>){
        arrLiveData.value=rafflesList

    }

   /* fun getRaffles(url:String){
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                val abc = result.raffles(url)
                arrLiveData.value=abc

            }
            }
    }

    */

}