package com.cekilisapp.ui.detail


import android.net.http.SslError
import android.os.Bundle
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.cekilisapp.R
import com.cekilisapp.databinding.ActivityDetailBinding
import com.cekilisapp.databinding.ActivityRafflesFollowedListBinding
import com.cekilisapp.service.RaffleDB
import kotlin.properties.Delegates


class DetailActivity : AppCompatActivity() {
    lateinit var btn :Button
    lateinit var webView: WebView
    lateinit var binding: ActivityDetailBinding
    var  isTrue by Delegates.notNull<Boolean>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        btn = binding.button
        val detailHref = intent.getStringExtra("ahref")
        val favorite = intent.getStringExtra("favorite")
        val uuid = intent.getStringExtra("uuid")
        webView=findViewById(R.id.webView)
        btn.text = getText(favorite.toBoolean())


        btn.setOnClickListener {
            val dao = RaffleDB(getApplication()).raffleDao()
            favorite?.let {
                dao.setFavorit(!it.toBoolean(), uuid!!.toLong())

                btn.text=getText(!it.toBoolean())

            }

        }


        detailHref?.let {

            val webViewClient = object : WebViewClient() {
                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
                    handler.proceed() // Ignore SSL certificate errors
                }
            }
            webView.loadUrl(it)
            webView.webViewClient = webViewClient
            webView.settings.javaScriptEnabled=true




        }

    }
    private  fun  getText(isFavorit:Boolean):String{
        if(isFavorit){
            return "Çıkar"
        }else{
            return "Favori Listeme Ekle"
        }
    }


    fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
        handler.proceed()
    }






}