package com.cekilisapp.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.lifecycle.lifecycleScope
import com.cekilisapp.R
import com.cekilisapp.databinding.ActivityRafflesFollowedListBinding
import com.cekilisapp.models.Raffle
import com.cekilisapp.service.RaffleDB
import kotlinx.coroutines.launch

class RafflesFollowedListActivity : AppCompatActivity() {
    lateinit var  raffleList : List<Raffle>
    lateinit var binding: ActivityRafflesFollowedListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRafflesFollowedListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lifecycleScope.launch {

            raffleList = RaffleDB(getApplication()).raffleDao().getAllRaffles()

            val adapter = ArrayAdapter(this@RafflesFollowedListActivity,android.R.layout.simple_list_item_1,raffleList)
            binding.followedRaffleList.adapter = adapter
        }


    }
}