package com.cekilisapp.ui.freeJoin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.R
import com.cekilisapp.adapter.RaffleRecyclerAdapter
import com.cekilisapp.databinding.FragmentFreeJoinBinding

class FreeJoin : Fragment() {

    private var _binding: FragmentFreeJoinBinding?=null
    private lateinit var freeJoinViewModel: FreeJoinViewModel
    private lateinit var freeJoinRecyclerView: RecyclerView
    private val freeJoinRecyclerAdapter = RaffleRecyclerAdapter(arrayListOf())


    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentFreeJoinBinding.inflate(inflater,container,false)
        val root:View = binding.root

        //return inflater.inflate(R.layout.fragment_free_join, container, false)
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        freeJoinViewModel = ViewModelProvider(this).get(FreeJoinViewModel::class.java)
        freeJoinViewModel.refreshData("https://www.kimkazandi.com/cekilisler/bedava-katilim")

        freeJoinRecyclerView = binding.freeJoinRecyclerView
        freeJoinRecyclerView.layoutManager = LinearLayoutManager(context)
        freeJoinRecyclerView.adapter = freeJoinRecyclerAdapter

        observeLiveData()

    }
    fun observeLiveData(){
        freeJoinViewModel.arrLiveData.observe(viewLifecycleOwner, Observer{
                raffle->
            raffle?.let {
                freeJoinRecyclerAdapter.updateRaffleList(raffle)
            }
        })
    }

}