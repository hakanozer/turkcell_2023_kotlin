package com.cekilisapp.ui.newStarters

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.adapter.RaffleRecyclerAdapter
import com.cekilisapp.databinding.FragmentNewstartersBinding

class NewStartersFragment : Fragment() {

    private var _binding: FragmentNewstartersBinding? = null
    private lateinit var newStartersViewModel: NewStartersViewModel
    private lateinit var newStarterRecyclerView:RecyclerView
    private val newStarterRecyclerAdapter=RaffleRecyclerAdapter(arrayListOf())

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        //val newStartersViewModel =
          //  ViewModelProvider(this).get(NewStartersViewModel::class.java)

        _binding = FragmentNewstartersBinding.inflate(inflater, container, false)
        val root: View = binding.root


        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        newStartersViewModel = ViewModelProvider(this).get(NewStartersViewModel::class.java)
        newStartersViewModel.refreshData("https://www.kimkazandi.com/cekilisler/yeni-baslayanlar")

        newStarterRecyclerView = binding.newStartersRecyclerView
        newStarterRecyclerView.layoutManager=LinearLayoutManager(context)
        newStarterRecyclerView.adapter = newStarterRecyclerAdapter

        observeLiveData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun observeLiveData(){
        newStartersViewModel.arrLiveData.observe(viewLifecycleOwner, Observer{
                raffle->
            raffle?.let {
                newStarterRecyclerAdapter.updateRaffleList(raffle)
            }
        })
    }
}