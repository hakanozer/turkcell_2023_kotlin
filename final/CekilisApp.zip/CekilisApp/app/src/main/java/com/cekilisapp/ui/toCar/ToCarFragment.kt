package com.cekilisapp.ui.toCar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.adapter.RaffleRecyclerAdapter
import com.cekilisapp.databinding.FragmentTocarBinding
import com.cekilisapp.ui.newStarters.NewStartersViewModel

class ToCarFragment : Fragment() {

    private var _binding: FragmentTocarBinding? = null
    private lateinit var toCarViewModel: ToCarViewModel
    private lateinit var toCarRecyclerView: RecyclerView
    private val toCarRecyclerAdapter= RaffleRecyclerAdapter(arrayListOf())

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val toCarViewModel =
            ViewModelProvider(this).get(ToCarViewModel::class.java)

        _binding = FragmentTocarBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //val textView: TextView = binding.textSlideshow
        //toCarViewModel.text.observe(viewLifecycleOwner) {
          //  textView.text = it }
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toCarViewModel = ViewModelProvider(this).get(ToCarViewModel::class.java)
        toCarViewModel.refreshData("https://www.kimkazandi.com/cekilisler/araba-kazan")

        toCarRecyclerView = binding.toCarRecyclerView
        toCarRecyclerView.layoutManager = LinearLayoutManager(context)
        toCarRecyclerView.adapter = toCarRecyclerAdapter

        observeLiveData()

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun observeLiveData(){
        toCarViewModel.arrLiveData.observe(viewLifecycleOwner, Observer{
                raffle->
            raffle?.let {
                toCarRecyclerAdapter.updateRaffleList(raffle)
            }
        })
    }
}