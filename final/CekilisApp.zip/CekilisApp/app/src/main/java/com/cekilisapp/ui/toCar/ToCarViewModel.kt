package com.cekilisapp.ui.toCar

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cekilisapp.Result
import com.cekilisapp.models.DataType
import com.cekilisapp.models.Raffle
import com.cekilisapp.service.RaffleDB
import com.cekilisapp.ui.BaseViewModel
import com.cekilisapp.util.CustomSharedPreferences
import io.reactivex.disposables.CompositeDisposable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ToCarViewModel(application: Application) : BaseViewModel(application){

    val arrLiveData = MutableLiveData<List<Raffle>>()
    private var customSharedPreferences = CustomSharedPreferences(getApplication())
    private var refreshTime = 0.1 * 60 * 10 * 1000 * 1000 * 1000L

    private  val disposable = CompositeDisposable()



    val result = Result()

    //viewModelScope.launch

    fun refreshData(url:String){


        val updateTime = customSharedPreferences.getTime()
        if (updateTime !=null && updateTime !=0L && System.nanoTime()-updateTime<refreshTime) {
            getDataFromByType()
        }else{
            verileriInternettenAl(url)
        }


    }


    private fun getDataFromByType() {
        viewModelScope.launch {
            val raffleList =
                RaffleDB(getApplication()).raffleDao().getbyType(DataType.TYPE_arabakazan)
            showRaffles(raffleList)
            Toast.makeText(getApplication(), "Raffles From SQLite", Toast.LENGTH_LONG).show()
        }
    }

    private fun verileriInternettenAl(url:String){
        launch {
            withContext(Dispatchers.Default) {
                val currentRaffle = result.raffles(url,DataType.TYPE_arabakazan)
            }

            val currentRaffle: List<Raffle> = withContext(Dispatchers.Default) {
                result.raffles(url,DataType.TYPE_arabakazan)
            }
            val newList= arrayListOf<Raffle>()
            withContext(Dispatchers.Main){
                for (item in currentRaffle){
                    if (!item.detailHref.isNullOrEmpty()&&!item
                            .titleOfRaffle.isNullOrEmpty()){
                        newList.add(item)
                        //dataStoreInSQLite(newList)  //?
                    }

                    arrLiveData.value=newList.toList()
                    if (newList.isNotEmpty()) {
                        dataStoreInSQLite(newList)
                    }

                }
            }
        }
    }

    private fun dataStoreInSQLite(list:ArrayList<Raffle>){

        launch {
            val dao = RaffleDB(getApplication()).raffleDao()
            dao.deleteAllRaffles()



            val listLong = dao.insertAll(*list.toTypedArray())
            var i = 0

            list.forEachIndexed { index, raffle ->
                raffle.uuid = listLong[index].toInt()
            }
            showRaffles(list)
        }

        customSharedPreferences.saveTime(System.nanoTime())
    }

    private fun showRaffles(rafflesList:List<Raffle>){
        arrLiveData.value=rafflesList

    }


}