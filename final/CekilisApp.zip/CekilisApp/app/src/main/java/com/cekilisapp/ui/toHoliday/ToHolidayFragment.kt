package com.cekilisapp.ui.toHoliday

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.adapter.RaffleRecyclerAdapter
import com.cekilisapp.databinding.FragmentToHolidayBinding



class ToHolidayFragment : Fragment() {

    private var _binding: FragmentToHolidayBinding? = null
    private lateinit var toHolidayViewModel: ToHolidayViewModel
    private lateinit var toHolidayRecyclerView: RecyclerView
    private val toHolidayRecyclerAdapter= RaffleRecyclerAdapter(arrayListOf())

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        //val toHolidayViewModel =
            //ViewModelProvider(this).get(ToHolidayViewModel::class.java)

        _binding = FragmentToHolidayBinding.inflate(inflater, container, false)
        val root: View = binding.root

       // val textView: TextView = binding.textHome
        //toHolidayViewModel.text.observe(viewLifecycleOwner) {
         //   textView.text = it
        //}
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toHolidayViewModel = ViewModelProvider(this).get(ToHolidayViewModel::class.java)
        toHolidayViewModel.refreshData("https://www.kimkazandi.com/cekilisler/tatil-kazan")

        toHolidayRecyclerView = binding.toHolidayRecyclerView
        toHolidayRecyclerView.layoutManager= LinearLayoutManager(context)
        toHolidayRecyclerView.adapter=toHolidayRecyclerAdapter

        observeLiveData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun observeLiveData(){
        toHolidayViewModel.arrLiveData.observe(viewLifecycleOwner, Observer{
                raffle->
            raffle?.let {
                toHolidayRecyclerAdapter.updateRaffleList(raffle)
            }
        })
    }
}