package com.cekilisapp.ui.toPhone

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.get
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cekilisapp.R
import com.cekilisapp.adapter.RaffleRecyclerAdapter
import com.cekilisapp.databinding.FragmentToPhoneBinding


class ToPhoneFragment : Fragment() {


    private var _binding : FragmentToPhoneBinding?=null
    private lateinit var toPhoneViewModel: ToPhoneViewModel
    private lateinit var toPhoneRecyclerView: RecyclerView
    private val toPhoneRecyclerAdapter = RaffleRecyclerAdapter(arrayListOf())

    private val binding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        _binding = FragmentToPhoneBinding.inflate(inflater,container,false)
        val root:View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toPhoneViewModel = ViewModelProvider(this).get(ToPhoneViewModel::class.java)
        toPhoneViewModel.refreshData("https://www.kimkazandi.com/cekilisler/telefon-tablet-kazan")
        toPhoneRecyclerView= binding.toPhoneRecyclerView
        toPhoneRecyclerView.layoutManager = LinearLayoutManager(context)
        toPhoneRecyclerView.adapter= toPhoneRecyclerAdapter

        observeLiveData()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    fun observeLiveData(){
        toPhoneViewModel.arrLiveData.observe(viewLifecycleOwner, Observer{
                raffle->
            raffle?.let {
                toPhoneRecyclerAdapter.updateRaffleList(raffle)
            }
        })
    }




}