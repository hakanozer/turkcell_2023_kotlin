package com.cekilisapp

import android.content.Context
import android.widget.ImageView
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.squareup.picasso.OkHttp3Downloader
import com.squareup.picasso.Picasso
import com.squareup.picasso.RequestCreator
import okhttp3.OkHttpClient
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/*
fun ImageView.gorselIndir(url:String?, placeHolder: CircularProgressDrawable){

    val options= RequestOptions().placeholder(placeHolder).error(R.mipmap.ic_launcher_round)

    Glide.with(context).setDefaultRequestOptions(options).load(url).into(this)

}
fun placeHolderYap(context: Context):CircularProgressDrawable {
    return CircularProgressDrawable(context).apply {
        strokeWidth = 8f
        centerRadius = 40f
        start()
    }
}

 */

fun ImageView.gorselIndir(url: String?, placeHolder: CircularProgressDrawable) {
   /* val picasso: RequestCreator = Picasso.get().load(url)
    picasso.placeholder(placeHolder)
    picasso.error(R.mipmap.ic_launcher_round)
    picasso.into(this)*/

    getPicassoUnsafeCertificate(context).load(url).fit().centerCrop().into(this)
  /*  PicassoTrustAll.getInstance(context)
        ?.load(url)
        ?.into(this);*/
}

fun placeHolderYap(context: Context): CircularProgressDrawable {
    return CircularProgressDrawable(context).apply {
        strokeWidth = 8f
        centerRadius = 40f
        start()
    }
}


fun getUnsafeOkHttpClient(): OkHttpClient {
    // Create a trust manager that does not validate certificate chains
    val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
        override fun checkClientTrusted(
            chain: Array<out X509Certificate>?,
            authType: String?
        ) {
        }

        override fun checkServerTrusted(
            chain: Array<out X509Certificate>?,
            authType: String?
        ) {
        }

        override fun getAcceptedIssuers() = arrayOf<X509Certificate>()
    })

    // Install the all-trusting trust manager
    val sslContext = SSLContext.getInstance("SSL")
    sslContext.init(null, trustAllCerts, java.security.SecureRandom())
    // Create an ssl socket factory with our all-trusting manager
    val sslSocketFactory = sslContext.socketFactory

    return OkHttpClient.Builder()
        .sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
        .hostnameVerifier(HostnameVerifier { _, _ -> true })

        .build()
}

fun getPicassoUnsafeCertificate(context: Context): Picasso {
    val client = getUnsafeOkHttpClient()
    val picasso = Picasso.Builder(context).downloader(OkHttp3Downloader(client)).build()
    picasso.isLoggingEnabled = true
    return picasso
}