package com.emirk.turkcellemirkarabeyfinal.data.local.raffle

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity

@Dao
interface RaffleDao {
    @Insert
    suspend fun insert(raffle: RaffleEntity)

    @Query("DELETE FROM raffle WHERE raffleTitle=:raffleTitle")
    suspend fun deleteRaffle(raffleTitle: String)

    @Query("SELECT * FROM raffle")
    fun getAllRaffles(): List<RaffleEntity>

    @Insert
    suspend fun insertNewJoiner(newJoinerEntity: NewJoinerEntity)

    @Query("SELECT * FROM newjoiner")
    fun getAllNewJoiner(): List<NewJoinerEntity>

    @Insert
    suspend fun insertFree(freeEntity: FreeEntity)

    @Query("SELECT * FROM free")
    fun getAllFree(): List<FreeEntity>

    @Insert
    suspend fun insertWinCar(winCarEntity: WinCarEntity)

    @Query("SELECT * FROM wincar")
    fun getAllWinCar(): List<WinCarEntity>

    @Insert
    suspend fun insertWinPhone(winPhoneEntity: WinPhoneEntity)

    @Query("SELECT * FROM winphone")
    fun getAllWinPhone(): List<WinPhoneEntity>

    @Insert
    suspend fun insertWinHoliday(winHolidayEntity: WinHolidayEntity)

    @Query("SELECT * FROM winholiday")
    fun getAllWinHoliday(): List<WinHolidayEntity>

    @Insert
    suspend fun insertFavorite(favoriteEntity: FavoriteEntity)

    @Query("SELECT * FROM favorite")
    fun getAllFavorite(): List<FavoriteEntity>
    @Query("DELETE FROM favorite WHERE raffleTitle=:raffleTitle")
    suspend fun deleteFavorite(raffleTitle: String)
}