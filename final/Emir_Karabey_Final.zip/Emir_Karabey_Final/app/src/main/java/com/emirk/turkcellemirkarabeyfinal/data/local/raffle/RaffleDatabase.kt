package com.emirk.turkcellemirkarabeyfinal.data.local.raffle

import androidx.room.Database
import androidx.room.RoomDatabase
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity

@Database(
    entities = [RaffleEntity::class,NewJoinerEntity::class,FreeEntity::class,WinCarEntity::class
               ,WinPhoneEntity::class,WinHolidayEntity::class,FavoriteEntity::class],
    version = 1
)
abstract class RaffleDatabase: RoomDatabase() {
    abstract fun raffleDao(): RaffleDao
}