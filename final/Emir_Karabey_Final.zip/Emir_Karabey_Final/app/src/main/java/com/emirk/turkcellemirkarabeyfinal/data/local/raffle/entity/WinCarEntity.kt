package com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wincar")
data class WinCarEntity(
    @PrimaryKey(autoGenerate = true) val uid: Int = 0,
    @ColumnInfo(name = "imageUrl") var imageUrl: String,
    @ColumnInfo(name = "raffleTitle") val raffleTitle: String,
    @ColumnInfo(name = "day") val day: String,
    @ColumnInfo(name = "gift") val gift: String,
    @ColumnInfo(name = "price") val price: String
)