package com.emirk.turkcellemirkarabeyfinal.data.repository

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.RaffleDao
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.domain.repository.RaffleRepository
import javax.inject.Inject


class RaffleRepositoryImpl @Inject constructor(
    private val raffleDao: RaffleDao
) : RaffleRepository {
    override suspend fun getRaffles(): List<RaffleEntity> {
        return raffleDao.getAllRaffles()
    }

    override suspend fun addRaffle(raffleEntity: RaffleEntity) {
        raffleDao.insert(raffle = raffleEntity)
    }

    override suspend fun deleteRaffle(raffleTitle: String) {
        raffleDao.deleteRaffle(raffleTitle = raffleTitle)
    }

    override suspend fun getNewJoiner(): List<NewJoinerEntity> {
        return raffleDao.getAllNewJoiner()
    }

    override suspend fun addNewJoiner(newJoinerEntity: NewJoinerEntity) {
        raffleDao.insertNewJoiner(newJoinerEntity = newJoinerEntity)
    }
}