package com.emirk.turkcellemirkarabeyfinal.di

import com.emirk.turkcellemirkarabeyfinal.data.repository.RaffleRepositoryImpl
import com.emirk.turkcellemirkarabeyfinal.domain.repository.RaffleRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun raffleRepository(RaffleRepositoryImpl: RaffleRepositoryImpl): RaffleRepository
}