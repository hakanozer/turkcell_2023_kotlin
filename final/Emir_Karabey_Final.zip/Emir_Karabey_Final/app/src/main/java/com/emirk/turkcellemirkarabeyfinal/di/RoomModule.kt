package com.emirk.turkcellemirkarabeyfinal.di

import android.content.Context
import androidx.room.Room
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.RaffleDao
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.RaffleDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

const val RAFFLE_DATABASE_NAME = "raffle"

@[Module InstallIn(SingletonComponent::class)]
object RoomModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): RaffleDatabase {
        return Room.databaseBuilder(context, RaffleDatabase::class.java, RAFFLE_DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideDao(
        db: RaffleDatabase
    ): RaffleDao = db.raffleDao()
}