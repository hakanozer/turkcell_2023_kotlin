package com.emirk.turkcellemirkarabeyfinal.domain.repository

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity

interface RaffleRepository {
    suspend fun getRaffles(): List<RaffleEntity>
    suspend fun addRaffle(raffleEntity: RaffleEntity)
    suspend fun deleteRaffle(raffleTitle: String)

    suspend fun getNewJoiner(): List<NewJoinerEntity>
    suspend fun addNewJoiner(newJoinerEntity: NewJoinerEntity)
}