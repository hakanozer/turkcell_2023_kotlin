package com.emirk.turkcellemirkarabeyfinal.domain.use_case

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.domain.repository.RaffleRepository
import javax.inject.Inject

class AddRaffleUseCase @Inject constructor(
    private val repository: RaffleRepository
) {
    suspend operator fun invoke(
        raffleEntity: RaffleEntity
    ) {
        repository.addRaffle(raffleEntity)
    }
}