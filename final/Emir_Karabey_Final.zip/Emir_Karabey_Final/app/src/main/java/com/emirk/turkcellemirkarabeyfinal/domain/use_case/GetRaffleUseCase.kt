package com.emirk.turkcellemirkarabeyfinal.domain.use_case

import com.emirk.common.Resource
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.domain.repository.RaffleRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.IOException
import javax.inject.Inject

class GetRaffleUseCase @Inject constructor(
    private val repository: RaffleRepository
) {
    operator fun invoke(
    ): Flow<Resource<List<RaffleEntity>>> = flow {
        try {
            emit(Resource.Loading())
            val tracks = repository.getRaffles()
            emit(Resource.Success(data = tracks))
        } catch (e: IOException) {
            emit(Resource.Error(message = e.localizedMessage))
        }
    }
}