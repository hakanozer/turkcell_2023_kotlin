package com.emirk.turkcellemirkarabeyfinal.presentation.follow

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.FragmentFollowBinding
import com.emirk.turkcellemirkarabeyfinal.presentation.follow.adapter.FollowAdapter
import com.emirk.turkcellemirkarabeyfinal.presentation.follow.adapter.FollowClickListener
import com.emirk.turkcellemirkarabeyfinal.presentation.raffle_detail.RaffleDetailViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FollowFragment : Fragment() {

    private var _binding: FragmentFollowBinding? = null
    private val binding get() = _binding!!
    private val viewModel: RaffleDetailViewModel by viewModels()
    private lateinit var adapter: FollowAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentFollowBinding.inflate(inflater, container, false)
        viewModel.getFavorite()
        initRecyclerViewAdapters()
        collectEvent()
        return binding.root
    }

    private fun initRecyclerViewAdapters() {
        adapter = FollowAdapter(object : FollowClickListener {
            override fun onItemClick(favoriteEntity: FavoriteEntity) {
                findNavController().navigate(
                    FollowFragmentDirections.actionNavFollowToRaffleDetailFragment(
                        imageUrl = favoriteEntity.imageUrl,
                        title = favoriteEntity.raffleTitle,
                        day = favoriteEntity.day,
                        gift = favoriteEntity.gift,
                        price = favoriteEntity.price
                    )
                )
            }
        })
        setupRecyclerViews()
    }

    private fun setupRecyclerViews() = with(binding) {
        rvRaffle.layoutManager = LinearLayoutManager(context)
        rvRaffle.adapter = adapter
    }

    private fun collectEvent() = binding.apply {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { uiState ->
                    if (!uiState.raffles.isNullOrEmpty()) {
                        Log.v("Follow", uiState.raffles[0].raffleTitle)
                        adapter.submitList(uiState.raffles)
                    }
                }
            }
        }
    }
}