package com.emirk.turkcellemirkarabeyfinal.presentation.follow

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.RaffleDao
import com.emirk.turkcellemirkarabeyfinal.presentation.raffle_detail.RaffleDetailUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FollowViewModel @Inject constructor(
    private val dao: RaffleDao
): ViewModel(){

    private val _uiState = MutableStateFlow(RaffleDetailUiState())
    val uiState: StateFlow<RaffleDetailUiState> = _uiState.asStateFlow()

    fun getFavorite() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update { state ->
            state.copy(raffles = dao.getAllFavorite(), isLoading = false)
        }
    }
}