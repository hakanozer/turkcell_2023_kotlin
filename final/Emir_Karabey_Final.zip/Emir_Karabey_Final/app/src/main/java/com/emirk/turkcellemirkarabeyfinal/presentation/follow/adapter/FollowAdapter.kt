package com.emirk.turkcellemirkarabeyfinal.presentation.follow.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class FollowAdapter (
    private val followClickListener: FollowClickListener
) : ListAdapter<FavoriteEntity, FollowViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<FavoriteEntity>() {
            override fun areItemsTheSame(
                oldItem: FavoriteEntity,
                newItem: FavoriteEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: FavoriteEntity,
                newItem: FavoriteEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return FollowViewHolder(binding, followClickListener)
    }

    override fun onBindViewHolder(holder: FollowViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}