package com.emirk.turkcellemirkarabeyfinal.presentation.follow.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity

interface FollowClickListener {
    fun onItemClick(favoriteEntity: FavoriteEntity)
}