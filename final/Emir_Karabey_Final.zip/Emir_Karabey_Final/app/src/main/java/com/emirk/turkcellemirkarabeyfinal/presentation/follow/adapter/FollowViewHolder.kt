package com.emirk.turkcellemirkarabeyfinal.presentation.follow.adapter

import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding
import com.emirk.util.Constants

class FollowViewHolder (
    private val binding: ItemRaffleBinding,
    private val followClickListener: FollowClickListener
) : RecyclerView.ViewHolder(binding.root) {
    fun bind(favoriteEntity: FavoriteEntity) = binding.apply {

        Glide.with(binding.ivRaffle)
            .load(Constants.BASE_URL +favoriteEntity.imageUrl)
            .into(binding.ivRaffle)

        tvRaffleTitle.text = favoriteEntity.raffleTitle
        tvDay.text = favoriteEntity.day
        tvGift.text = favoriteEntity.gift
        tvPrice.text = favoriteEntity.price

        itemView.setOnClickListener {
            followClickListener.onItemClick(favoriteEntity = favoriteEntity)
        }
    }
}