package com.emirk.turkcellemirkarabeyfinal.presentation.free

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.FragmentFreeBinding
import com.emirk.turkcellemirkarabeyfinal.presentation.free.adapter.FreeAdapter
import com.emirk.turkcellemirkarabeyfinal.presentation.free.adapter.FreeClickListener
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FreeFragment : Fragment() {

    private var _binding: FragmentFreeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val viewModel: FreeViewModel by viewModels()
    private lateinit var adapter: FreeAdapter
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val freeViewModel =
            ViewModelProvider(this).get(FreeViewModel::class.java)

        _binding = FragmentFreeBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerViewAdapters()
        viewModel.getFree()
        collectEvent()
    }
    private fun initRecyclerViewAdapters() {
        adapter = FreeAdapter(object : FreeClickListener {
            override fun onItemClick(raffle: FreeEntity) {
                findNavController().navigate(
                    FreeFragmentDirections.actionNavFreeToRaffleDetailFragment(
                    imageUrl = raffle.imageUrl,
                    title = raffle.raffleTitle,
                    day = raffle.day,
                    gift = raffle.gift,
                    price = raffle.price
                ))
            }
        })
        setupRecyclerViews()
    }

    private fun setupRecyclerViews() = with(binding) {
        rvRaffle.layoutManager = LinearLayoutManager(context)
        rvRaffle.adapter = adapter
    }

    private fun collectEvent() = binding.apply {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { uiState ->
                    if (uiState.isLoading) {
                        //pb show
                    } else {
                        //pb gone
                        if (!uiState.raffles.isNullOrEmpty()) {
                            adapter.submitList(uiState.raffles)
                        }
                    }

                    uiState.userMessage?.let {
                        //tv error show
                    }
                }
            }
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}