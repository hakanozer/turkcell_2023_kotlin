package com.emirk.turkcellemirkarabeyfinal.presentation.free

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity

data class FreeUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<FreeEntity>? = emptyList(),
)