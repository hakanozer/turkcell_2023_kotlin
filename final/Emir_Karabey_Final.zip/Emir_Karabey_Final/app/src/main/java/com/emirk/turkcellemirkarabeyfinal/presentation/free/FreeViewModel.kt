package com.emirk.turkcellemirkarabeyfinal.presentation.free

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.RaffleDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FreeViewModel @Inject constructor(
    private val dao: RaffleDao
): ViewModel() {

    private val _uiState = MutableStateFlow(FreeUiState())
    val uiState: StateFlow<FreeUiState> = _uiState.asStateFlow()

    fun getFree() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update { state ->
            state.copy(raffles = dao.getAllFree(), isLoading = false)
        }
    }
}