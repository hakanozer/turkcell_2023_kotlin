package com.emirk.turkcellemirkarabeyfinal.presentation.free.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class FreeAdapter (
    private val freeClickListener: FreeClickListener
) : ListAdapter<FreeEntity, FreeViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<FreeEntity>() {
            override fun areItemsTheSame(
                oldItem: FreeEntity,
                newItem: FreeEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: FreeEntity,
                newItem: FreeEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FreeViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return FreeViewHolder(binding, freeClickListener)
    }

    override fun onBindViewHolder(holder: FreeViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}