package com.emirk.turkcellemirkarabeyfinal.presentation.free.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity

interface FreeClickListener {
    fun onItemClick(raffle: FreeEntity)
}