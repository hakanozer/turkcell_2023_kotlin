package com.emirk.turkcellemirkarabeyfinal.presentation.home

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.FragmentHomeBinding
import com.emirk.turkcellemirkarabeyfinal.presentation.home.adapter.RaffleAdapter
import com.emirk.turkcellemirkarabeyfinal.presentation.home.adapter.RaffleClickListener
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.Calendar
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var adapter: RaffleAdapter

    val PREFS_NAME = "MyPrefs"
    val LAST_LOGIN_TIME = "last_login_time"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerViewAdapters()
        viewModel.getFavorite()
        collectEvent()
        if (isDataExist(requireContext())) {
            val isPastThreeHours = checkLoginTime(requireContext())
            if (isPastThreeHours) {
                runBlocking {
                    GlobalScope.launch(Dispatchers.IO) {
                        fetchDraws()
                        fetchNewJoiner()
                        fetchFree()
                        fetchWinCar()
                        fetchWinPhone()
                        fetchWinHoliday()
                    }
                }
                saveLoginTime(requireContext())
            } else {
            }
        } else {
            runBlocking {
                GlobalScope.launch(Dispatchers.IO) {
                    fetchDraws()
                    fetchNewJoiner()
                    fetchFree()
                    fetchWinCar()
                    fetchWinPhone()
                    fetchWinHoliday()
                }
            }
            saveLoginTime(requireContext())
        }
    }

    fun checkLoginTime(context: Context): Boolean {
        val sharedPrefs: SharedPreferences =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastLoginTimeMillis = sharedPrefs.getLong(LAST_LOGIN_TIME, 0)
        val currentTimeMillis = Calendar.getInstance().timeInMillis

        val diffHours = (currentTimeMillis - lastLoginTimeMillis) / (1000 * 60 * 60)

        return diffHours >= 3
    }

    fun saveLoginTime(context: Context) {
        val sharedPrefs: SharedPreferences =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPrefs.edit()
        val currentTimeMillis = Calendar.getInstance().timeInMillis
        editor.putLong(LAST_LOGIN_TIME, currentTimeMillis)
        editor.apply()
    }

    fun isDataExist(context: Context): Boolean {
        val sharedPrefs: SharedPreferences =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return sharedPrefs.contains(LAST_LOGIN_TIME)
    }

    private fun initRecyclerViewAdapters() {
        adapter = RaffleAdapter(object : RaffleClickListener {
            override fun onItemClick(raffle: RaffleEntity) {
                findNavController().navigate(
                    HomeFragmentDirections.actionNavHomeToRaffleDetailFragment(
                        imageUrl = raffle.imageUrl,
                        title = raffle.raffleTitle,
                        day = raffle.day,
                        gift = raffle.gift,
                        price = raffle.price
                    )
                )
            }
        })
        setupRecyclerViews()
    }

    private fun setupRecyclerViews() = with(binding) {
        rvRaffle.layoutManager = LinearLayoutManager(context)
        rvRaffle.adapter = adapter
    }

    private fun collectEvent() = binding.apply {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { uiState ->
                    if (uiState.isLoading) {
                        //pb show
                    } else {
                        //pb gone
                        if (!uiState.raffles.isNullOrEmpty()) {
                            adapter.submitList(uiState.raffles)
                        }
                    }

                    uiState.userMessage?.let {
                        //tv error show
                    }
                }
            }
        }
    }

    fun fetchDraws() {
        System.setProperty("jsse.enableSNIExtension", "false")
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate>? = null

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val sslSocketFactory = sslContext.socketFactory
        val html = Jsoup.connect("https://www.kimkazandi.com/cekilisler")
            .sslSocketFactory(sslSocketFactory).get()

        //cekilis resimleri
        val imageElements = html.select("div > a > img")
        val imageUrls = imageElements.map { it.attr("src") }


        //cekilis basliklari
        val divElements = html.select("div")
        val titleList = mutableListOf<String>()

        for (divElement in divElements) {
            val anchorTag = divElement.selectFirst("a")
            val h4Element = anchorTag?.selectFirst("h4")
            val title = h4Element?.text()

            if (title != null) {
                titleList.add(title)
            }
            for (title in titleList) {
                //Log.v("HomeFragment",title)
            }
        }

        //cekilis span
        val divElementsSpan = html.select("div.title")
        val spanList = mutableListOf<String>()

        for (divElement in divElementsSpan) {
            val spanElements = divElement.select("span")
            for (spanElement in spanElements) {
                val text = spanElement.ownText()
                spanList.add(text)
            }
        }

        for (i in 0..7) {
            //image için i+1 den başla diğerlerini i den ver
            val raffle = RaffleEntity(
                imageUrl = imageUrls[i + 1],
                raffleTitle = titleList[i],
                day = spanList[i * 3],
                gift = spanList[(i * 3) + 1],
                price = spanList[(i * 3) + 2]
            )
            // çekmeyide yazıp test et
            viewModel.addFavorite(raffle)
        }
    }

    fun fetchNewJoiner() {
        System.setProperty("jsse.enableSNIExtension", "false")
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate>? = null

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val sslSocketFactory = sslContext.socketFactory
        val html = Jsoup.connect("https://www.kimkazandi.com/cekilisler/yeni-baslayanlar")
            .sslSocketFactory(sslSocketFactory).get()

        //cekilis resimleri
        val imageElements = html.select("div > a > img")
        val imageUrls = imageElements.map { it.attr("src") }


        //cekilis basliklari
        val divElements = html.select("div")
        val titleList = mutableListOf<String>()

        for (divElement in divElements) {
            val anchorTag = divElement.selectFirst("a")
            val h4Element = anchorTag?.selectFirst("h4")
            val title = h4Element?.text()

            if (title != null) {
                titleList.add(title)
            }
            for (title in titleList) {
                Log.v("NewJoiner", title)
            }
        }

        //cekilis span
        val divElementsSpan = html.select("div.title")
        val spanList = mutableListOf<String>()

        for (divElement in divElementsSpan) {
            val spanElements = divElement.select("span")
            for (spanElement in spanElements) {
                val text = spanElement.ownText()
                spanList.add(text)
            }
        }

        for (i in 0..7) {
            //image için i+1 den başla diğerlerini i den ver
            val newJoiner = NewJoinerEntity(
                imageUrl = imageUrls[i + 1],
                raffleTitle = titleList[i],
                day = spanList[i * 3],
                gift = spanList[(i * 3) + 1],
                price = spanList[(i * 3) + 2]
            )
            // çekmeyide yazıp test et
            viewModel.addNewJoiner(newJoiner)
        }
    }

    fun fetchFree() {
        System.setProperty("jsse.enableSNIExtension", "false")
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate>? = null

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val sslSocketFactory = sslContext.socketFactory
        val html = Jsoup.connect("https://www.kimkazandi.com/cekilisler/bedava-katilim")
            .sslSocketFactory(sslSocketFactory).get()

        //cekilis resimleri
        val imageElements = html.select("div > a > img")
        val imageUrls = imageElements.map { it.attr("src") }


        //cekilis basliklari
        val divElements = html.select("div")
        val titleList = mutableListOf<String>()

        for (divElement in divElements) {
            val anchorTag = divElement.selectFirst("a")
            val h4Element = anchorTag?.selectFirst("h4")
            val title = h4Element?.text()

            if (title != null) {
                titleList.add(title)
            }
        }

        //cekilis span
        val divElementsSpan = html.select("div.title")
        val spanList = mutableListOf<String>()

        for (divElement in divElementsSpan) {
            val spanElements = divElement.select("span")
            for (spanElement in spanElements) {
                val text = spanElement.ownText()
                spanList.add(text)
            }
        }

        for (i in 0..7) {
            val free = FreeEntity(
                imageUrl = imageUrls[i + 1],
                raffleTitle = titleList[i],
                day = spanList[i * 3],
                gift = spanList[(i * 3) + 1],
                price = spanList[(i * 3) + 2]
            )
            // çekmeyide yazıp test et
            viewModel.addFree(free)
        }
    }

    fun fetchWinCar() {
        System.setProperty("jsse.enableSNIExtension", "false")
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate>? = null

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val sslSocketFactory = sslContext.socketFactory
        val html = Jsoup.connect("https://www.kimkazandi.com/cekilisler/araba-kazan")
            .sslSocketFactory(sslSocketFactory).get()

        //cekilis resimleri
        val imageElements = html.select("div > a > img")
        val imageUrls = imageElements.map { it.attr("src") }


        //cekilis basliklari
        val divElements = html.select("div")
        val titleList = mutableListOf<String>()

        for (divElement in divElements) {
            val anchorTag = divElement.selectFirst("a")
            val h4Element = anchorTag?.selectFirst("h4")
            val title = h4Element?.text()

            if (title != null) {
                titleList.add(title)
            }
        }

        val divElementsSpan = html.select("div.title")
        val spanList = mutableListOf<String>()

        for (divElement in divElementsSpan) {
            val spanElements = divElement.select("span")
            for (spanElement in spanElements) {
                val text = spanElement.ownText()
                spanList.add(text)
            }
        }

        for (i in 0..5) {
            val winCar = WinCarEntity(
                imageUrl = imageUrls[i + 1],
                raffleTitle = titleList[i],
                day = spanList[i * 3],
                gift = spanList[(i * 3) + 1],
                price = spanList[(i * 3) + 2]
            )
            // çekmeyide yazıp test et
            viewModel.addWinCar(winCar)
        }
    }

    fun fetchWinPhone() {
        System.setProperty("jsse.enableSNIExtension", "false")
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate>? = null

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val sslSocketFactory = sslContext.socketFactory
        val html = Jsoup.connect("https://www.kimkazandi.com/cekilisler/telefon-tablet-kazan")
            .sslSocketFactory(sslSocketFactory).get()

        val imageElements = html.select("div > a > img")
        val imageUrls = imageElements.map { it.attr("src") }


        val divElements = html.select("div")
        val titleList = mutableListOf<String>()

        for (divElement in divElements) {
            val anchorTag = divElement.selectFirst("a")
            val h4Element = anchorTag?.selectFirst("h4")
            val title = h4Element?.text()

            if (title != null) {
                titleList.add(title)
            }
        }

        val divElementsSpan = html.select("div.title")
        val spanList = mutableListOf<String>()

        for (divElement in divElementsSpan) {
            val spanElements = divElement.select("span")
            for (spanElement in spanElements) {
                val text = spanElement.ownText()
                spanList.add(text)
            }
        }

        for (i in 0..7) {
            val winPhoneEntity = WinPhoneEntity(
                imageUrl = imageUrls[i + 1],
                raffleTitle = titleList[i],
                day = spanList[i * 3],
                gift = spanList[(i * 3) + 1],
                price = spanList[(i * 3) + 2]
            )
            viewModel.addWinPhone(winPhoneEntity)
        }
    }

    fun fetchWinHoliday() {
        System.setProperty("jsse.enableSNIExtension", "false")
        System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2")

        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate>? = null

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val sslSocketFactory = sslContext.socketFactory
        val html = Jsoup.connect("https://www.kimkazandi.com/cekilisler/tatil-kazan")
            .sslSocketFactory(sslSocketFactory).get()

        val imageElements = html.select("div > a > img")
        val imageUrls = imageElements.map { it.attr("src") }


        val divElements = html.select("div")
        val titleList = mutableListOf<String>()

        for (divElement in divElements) {
            val anchorTag = divElement.selectFirst("a")
            val h4Element = anchorTag?.selectFirst("h4")
            val title = h4Element?.text()

            if (title != null) {
                titleList.add(title)
            }
        }

        val divElementsSpan = html.select("div.title")
        val spanList = mutableListOf<String>()

        for (divElement in divElementsSpan) {
            val spanElements = divElement.select("span")
            for (spanElement in spanElements) {
                val text = spanElement.ownText()
                spanList.add(text)
            }
        }

        for (i in 0..1) {
            val winHolidayEntity = WinHolidayEntity(
                imageUrl = imageUrls[i + 1],
                raffleTitle = titleList[i],
                day = spanList[i * 3],
                gift = spanList[(i * 3) + 1],
                price = spanList[(i * 3) + 2]
            )
            viewModel.addWinHoliday(winHolidayEntity)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}