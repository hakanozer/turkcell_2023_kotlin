package com.emirk.turkcellemirkarabeyfinal.presentation.home

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity

data class HomeUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<RaffleEntity>? = emptyList(),
)