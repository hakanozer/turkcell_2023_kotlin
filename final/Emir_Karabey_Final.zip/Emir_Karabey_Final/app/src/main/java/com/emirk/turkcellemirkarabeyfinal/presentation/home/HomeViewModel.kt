package com.emirk.turkcellemirkarabeyfinal.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emirk.common.Resource
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.RaffleDao
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FreeEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity
import com.emirk.turkcellemirkarabeyfinal.domain.use_case.AddRaffleUseCase
import com.emirk.turkcellemirkarabeyfinal.domain.use_case.GetRaffleUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val addRaffleUseCase: AddRaffleUseCase,
    private val getRaffleUseCase: GetRaffleUseCase,
    private val dao: RaffleDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    fun addFavorite(raffleEntity: RaffleEntity) = viewModelScope.launch {
        addRaffleUseCase.invoke(raffleEntity = raffleEntity)
    }

    fun getFavorite() = viewModelScope.launch(Dispatchers.IO) {
        getRaffleUseCase.invoke().collect { result ->
            when (result) {
                is Resource.Error -> {
                    _uiState.update { state ->
                        state.copy(userMessage = result.message)
                    }
                }

                is Resource.Loading -> {
                    _uiState.update { state ->
                        state.copy(isLoading = true)
                    }
                }

                is Resource.Success -> {
                    _uiState.update { state ->
                        state.copy(raffles = result.data, isLoading = false)
                    }
                }
            }
        }
    }

    fun addNewJoiner(newJoinerEntity: NewJoinerEntity) = viewModelScope.launch {
        dao.insertNewJoiner(newJoinerEntity = newJoinerEntity)
    }

    fun addFree(freeEntity: FreeEntity) = viewModelScope.launch {
        dao.insertFree(freeEntity = freeEntity)
    }

    fun addWinCar(winCarEntity: WinCarEntity) = viewModelScope.launch {
        dao.insertWinCar(winCarEntity = winCarEntity)
    }

    fun addWinPhone(winPhoneEntity: WinPhoneEntity) = viewModelScope.launch {
        dao.insertWinPhone(winPhoneEntity = winPhoneEntity)
    }

    fun addWinHoliday(winHolidayEntity: WinHolidayEntity) = viewModelScope.launch {
        dao.insertWinHoliday(winHolidayEntity = winHolidayEntity)
    }
}