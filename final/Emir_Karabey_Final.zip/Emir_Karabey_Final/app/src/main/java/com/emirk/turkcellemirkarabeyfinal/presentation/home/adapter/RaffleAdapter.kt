package com.emirk.turkcellemirkarabeyfinal.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class RaffleAdapter(
    private val raffleClickListener: RaffleClickListener
) : ListAdapter<RaffleEntity, RaffleViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<RaffleEntity>() {
            override fun areItemsTheSame(
                oldItem: RaffleEntity,
                newItem: RaffleEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: RaffleEntity,
                newItem: RaffleEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RaffleViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return RaffleViewHolder(binding, raffleClickListener)
    }

    override fun onBindViewHolder(holder: RaffleViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}