package com.emirk.turkcellemirkarabeyfinal.presentation.home.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity

interface RaffleClickListener {
    fun onItemClick(raffle: RaffleEntity)
}