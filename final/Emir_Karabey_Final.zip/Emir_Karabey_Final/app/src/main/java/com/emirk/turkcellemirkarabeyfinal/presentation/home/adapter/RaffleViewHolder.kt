package com.emirk.turkcellemirkarabeyfinal.presentation.home.adapter

import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.RaffleEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding
import com.emirk.util.Constants.BASE_URL

class RaffleViewHolder(
    private val binding: ItemRaffleBinding,
    private val raffleClickListener: RaffleClickListener
) : RecyclerView.ViewHolder(binding.root) {
    fun bind(raffle: RaffleEntity) = binding.apply {

        Glide.with(binding.ivRaffle)
            .load(BASE_URL+raffle.imageUrl)
            .into(binding.ivRaffle)

        tvRaffleTitle.text = raffle.raffleTitle
        tvDay.text = raffle.day
        tvGift.text = raffle.gift
        tvPrice.text = raffle.price

        itemView.setOnClickListener {
            raffleClickListener.onItemClick(raffle = raffle)
        }
    }
}