package com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.FragmentNewjoinerBinding
import com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner.adapter.NewJoinerAdapter
import com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner.adapter.NewJoinerClickListener
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class NewJoinerFragment : Fragment() {

    private var _binding: FragmentNewjoinerBinding? = null
    private val binding get() = _binding!!
    private val viewModel: NewJoinerViewModel by viewModels()
    private lateinit var adapter: NewJoinerAdapter
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNewjoinerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerViewAdapters()
        viewModel.getNewJoiner()
        collectEvent()
    }
    private fun initRecyclerViewAdapters() {
        adapter = NewJoinerAdapter(object : NewJoinerClickListener {
            override fun onItemClick(raffle: NewJoinerEntity) {
                findNavController().navigate(
                    NewJoinerFragmentDirections.actionNavNewToRaffleDetailFragment(
                    imageUrl = raffle.imageUrl,
                    title = raffle.raffleTitle,
                    day = raffle.day,
                    gift = raffle.gift,
                    price = raffle.price
                ))
            }
        })
        setupRecyclerViews()
    }

    private fun setupRecyclerViews() = with(binding) {
        rvRaffle.layoutManager = LinearLayoutManager(context)
        rvRaffle.adapter = adapter
    }

    private fun collectEvent() = binding.apply {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { uiState ->
                    if (uiState.isLoading) {
                        //pb show
                    } else {
                        //pb gone
                        if (!uiState.raffles.isNullOrEmpty()) {
                            adapter.submitList(uiState.raffles)
                        }
                    }

                    uiState.userMessage?.let {
                        //tv error show
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}