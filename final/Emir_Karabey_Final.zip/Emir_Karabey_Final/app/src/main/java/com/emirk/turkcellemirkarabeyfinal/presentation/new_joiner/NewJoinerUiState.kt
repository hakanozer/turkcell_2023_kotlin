package com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity

data class NewJoinerUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<NewJoinerEntity>? = emptyList(),
)