package com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class NewJoinerAdapter (
    private val newJoinerClickListener: NewJoinerClickListener
) : ListAdapter<NewJoinerEntity, NewJoinerViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<NewJoinerEntity>() {
            override fun areItemsTheSame(
                oldItem: NewJoinerEntity,
                newItem: NewJoinerEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: NewJoinerEntity,
                newItem: NewJoinerEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewJoinerViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return NewJoinerViewHolder(binding, newJoinerClickListener)
    }

    override fun onBindViewHolder(holder: NewJoinerViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}