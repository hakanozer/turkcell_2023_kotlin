package com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity

interface NewJoinerClickListener {
    fun onItemClick(raffle: NewJoinerEntity)
}