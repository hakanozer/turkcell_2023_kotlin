package com.emirk.turkcellemirkarabeyfinal.presentation.new_joiner.adapter

import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.NewJoinerEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding
import com.emirk.util.Constants.BASE_URL

class NewJoinerViewHolder (
    private val binding: ItemRaffleBinding,
    private val newJoinerClickListener: NewJoinerClickListener
) : RecyclerView.ViewHolder(binding.root) {
    fun bind(raffle: NewJoinerEntity) = binding.apply {

        Glide.with(binding.ivRaffle)
            .load(BASE_URL+raffle.imageUrl)
            .into(binding.ivRaffle)

        tvRaffleTitle.text = raffle.raffleTitle
        tvDay.text = raffle.day
        tvGift.text = raffle.gift
        tvPrice.text = raffle.price

        itemView.setOnClickListener {
            newJoinerClickListener.onItemClick(raffle = raffle)
        }
    }
}