package com.emirk.turkcellemirkarabeyfinal.presentation.raffle_detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.emirk.turkcellemirkarabeyfinal.R
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.FragmentRaffleDetailBinding
import com.emirk.util.Constants
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class RaffleDetailFragment : Fragment() {

    private var _binding: FragmentRaffleDetailBinding? = null
    private val binding get() = _binding!!
    private val args: RaffleDetailFragmentArgs by navArgs()
    private val viewModel: RaffleDetailViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentRaffleDetailBinding.inflate(inflater, container, false)
        viewModel.getFavorite()
        collectEvent()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Glide.with(binding.ivRaffle)
            .load(Constants.BASE_URL + args.imageUrl)
            .into(binding.ivRaffle)
        binding.tvRaffleTitle.text = args.title
        binding.tvDay.text = args.day
        binding.tvGift.text = args.gift
        binding.tvPrice.text = args.price

        binding.btnFav.setOnClickListener {
            if (it.background.equals(R.drawable.baseline_favorite_24)) {
                viewModel.deleteFavorite(raffleTitle = args.title)
                it.setBackgroundResource(R.drawable.baseline_favorite_border_24)
            } else {
                val favoriteEntity = FavoriteEntity(
                    imageUrl = args.imageUrl,
                    raffleTitle = args.title,
                    day = args.day,
                    gift = args.gift,
                    price = args.price
                )
                viewModel.addFavorite(favoriteEntity = favoriteEntity)
                it.setBackgroundResource(R.drawable.baseline_favorite_24)
            }
        }
    }

    private fun collectEvent() = binding.apply {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { uiState ->
                    uiState.raffles!!.forEach {
                        if (it.raffleTitle == args.title) {
                                binding.btnFav.setBackgroundResource(R.drawable.baseline_favorite_24)
                        }else{
                            binding.btnFav.setBackgroundResource(R.drawable.baseline_favorite_border_24)
                        }
                    }
                }
            }
        }
    }
}