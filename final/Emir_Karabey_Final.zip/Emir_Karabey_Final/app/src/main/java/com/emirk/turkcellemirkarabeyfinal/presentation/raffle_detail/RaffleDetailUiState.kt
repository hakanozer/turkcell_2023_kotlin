package com.emirk.turkcellemirkarabeyfinal.presentation.raffle_detail

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.FavoriteEntity

data class RaffleDetailUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<FavoriteEntity>? = emptyList(),
)