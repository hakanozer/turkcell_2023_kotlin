package com.emirk.turkcellemirkarabeyfinal.presentation.win_car

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity

data class WinCarUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<WinCarEntity>? = emptyList(),
)