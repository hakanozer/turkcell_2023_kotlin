package com.emirk.turkcellemirkarabeyfinal.presentation.win_car.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class WinCarAdapter (
    private val winCarClickListener: WinCarClickListener
) : ListAdapter<WinCarEntity, WinCarViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<WinCarEntity>() {
            override fun areItemsTheSame(
                oldItem: WinCarEntity,
                newItem: WinCarEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: WinCarEntity,
                newItem: WinCarEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WinCarViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return WinCarViewHolder(binding, winCarClickListener)
    }

    override fun onBindViewHolder(holder: WinCarViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}