package com.emirk.turkcellemirkarabeyfinal.presentation.win_car.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinCarEntity

interface WinCarClickListener {
    fun onItemClick(raffle: WinCarEntity)
}