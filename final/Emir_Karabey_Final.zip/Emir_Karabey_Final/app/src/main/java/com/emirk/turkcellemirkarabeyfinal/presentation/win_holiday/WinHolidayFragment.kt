package com.emirk.turkcellemirkarabeyfinal.presentation.win_holiday

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.FragmentWinHolidayBinding
import com.emirk.turkcellemirkarabeyfinal.presentation.win_holiday.adapter.WinHolidayAdapter
import com.emirk.turkcellemirkarabeyfinal.presentation.win_holiday.adapter.WinHolidayClickListener
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class WinHolidayFragment : Fragment() {

    private var _binding: FragmentWinHolidayBinding? = null
    private val binding get() = _binding!!
    private val viewModel: WinHolidayViewModel by viewModels()
    private lateinit var adapter: WinHolidayAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWinHolidayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerViewAdapters()
        viewModel.getWinHoliday()
        collectEvent()
    }
    private fun initRecyclerViewAdapters() {
        adapter = WinHolidayAdapter(object : WinHolidayClickListener {
            override fun onItemClick(raffle: WinHolidayEntity) {
                findNavController().navigate(
                    WinHolidayFragmentDirections.actionNavWinholidayToRaffleDetailFragment(
                    imageUrl = raffle.imageUrl,
                    title = raffle.raffleTitle,
                    day = raffle.day,
                    gift = raffle.gift,
                    price = raffle.price
                ))
            }
        })
        setupRecyclerViews()
    }

    private fun setupRecyclerViews() = with(binding) {
        rvRaffle.layoutManager = LinearLayoutManager(context)
        rvRaffle.adapter = adapter
    }

    private fun collectEvent() = binding.apply {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { uiState ->
                    if (uiState.isLoading) {
                        //pb show
                    } else {
                        //pb gone
                        if (!uiState.raffles.isNullOrEmpty()) {
                            adapter.submitList(uiState.raffles)
                        }
                    }

                    uiState.userMessage?.let {
                        //tv error show
                    }
                }
            }
        }
    }
}