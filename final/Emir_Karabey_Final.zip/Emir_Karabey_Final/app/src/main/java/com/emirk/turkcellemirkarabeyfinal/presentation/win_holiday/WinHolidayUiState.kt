package com.emirk.turkcellemirkarabeyfinal.presentation.win_holiday

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity

data class WinHolidayUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<WinHolidayEntity>? = emptyList(),
)