package com.emirk.turkcellemirkarabeyfinal.presentation.win_holiday.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class WinHolidayAdapter (
    private val winHolidayClickListener: WinHolidayClickListener
) : ListAdapter<WinHolidayEntity, WinHolidayViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<WinHolidayEntity>() {
            override fun areItemsTheSame(
                oldItem: WinHolidayEntity,
                newItem: WinHolidayEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: WinHolidayEntity,
                newItem: WinHolidayEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WinHolidayViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return WinHolidayViewHolder(binding, winHolidayClickListener)
    }

    override fun onBindViewHolder(holder: WinHolidayViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}