package com.emirk.turkcellemirkarabeyfinal.presentation.win_holiday.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinHolidayEntity

interface WinHolidayClickListener {
    fun onItemClick(raffle: WinHolidayEntity)
}