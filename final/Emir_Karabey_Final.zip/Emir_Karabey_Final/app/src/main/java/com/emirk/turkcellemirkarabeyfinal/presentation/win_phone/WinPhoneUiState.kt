package com.emirk.turkcellemirkarabeyfinal.presentation.win_phone

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity

data class WinPhoneUiState(
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val raffles: List<WinPhoneEntity>? = emptyList(),
)