package com.emirk.turkcellemirkarabeyfinal.presentation.win_phone.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding

class WinPhoneAdapter (
    private val winPhoneClickListener: WinPhoneClickListener
) : ListAdapter<WinPhoneEntity, WinPhoneViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<WinPhoneEntity>() {
            override fun areItemsTheSame(
                oldItem: WinPhoneEntity,
                newItem: WinPhoneEntity
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: WinPhoneEntity,
                newItem: WinPhoneEntity
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WinPhoneViewHolder {
        val binding = ItemRaffleBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return WinPhoneViewHolder(binding, winPhoneClickListener)
    }

    override fun onBindViewHolder(holder: WinPhoneViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}