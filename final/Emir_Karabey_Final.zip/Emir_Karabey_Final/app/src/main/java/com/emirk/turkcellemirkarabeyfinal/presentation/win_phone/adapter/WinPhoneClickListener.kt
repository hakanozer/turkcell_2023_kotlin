package com.emirk.turkcellemirkarabeyfinal.presentation.win_phone.adapter

import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity

interface WinPhoneClickListener {
    fun onItemClick(raffle: WinPhoneEntity)
}