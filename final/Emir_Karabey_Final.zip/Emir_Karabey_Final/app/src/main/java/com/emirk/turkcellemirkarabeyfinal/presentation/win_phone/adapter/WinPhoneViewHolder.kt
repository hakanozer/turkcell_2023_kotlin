package com.emirk.turkcellemirkarabeyfinal.presentation.win_phone.adapter

import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.emirk.turkcellemirkarabeyfinal.data.local.raffle.entity.WinPhoneEntity
import com.emirk.turkcellemirkarabeyfinal.databinding.ItemRaffleBinding
import com.emirk.util.Constants

class WinPhoneViewHolder  (
    private val binding: ItemRaffleBinding,
    private val winPhoneClickListener: WinPhoneClickListener
) : RecyclerView.ViewHolder(binding.root) {
    fun bind(raffle: WinPhoneEntity) = binding.apply {

        Glide.with(binding.ivRaffle)
            .load(Constants.BASE_URL +raffle.imageUrl)
            .into(binding.ivRaffle)

        tvRaffleTitle.text = raffle.raffleTitle
        tvDay.text = raffle.day
        tvGift.text = raffle.gift
        tvPrice.text = raffle.price

        itemView.setOnClickListener {
            winPhoneClickListener.onItemClick(raffle = raffle)
        }
    }
}