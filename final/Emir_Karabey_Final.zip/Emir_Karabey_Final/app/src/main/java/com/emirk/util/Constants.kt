package com.emirk.util

object Constants {
    const val BASE_URL = "https://www.kimkazandi.com"
}