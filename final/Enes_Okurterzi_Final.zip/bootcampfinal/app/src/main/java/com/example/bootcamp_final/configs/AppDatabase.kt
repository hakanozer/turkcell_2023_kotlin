package com.example.bootcamp_final.configs

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.bootcamp_final.dao.CekilisDao
import com.example.bootcamp_final.models.Cekilis

@Database(entities = [Cekilis::class], version = 1)
abstract class AppDatabase: RoomDatabase(){

    abstract fun cekilisDao(): CekilisDao

}