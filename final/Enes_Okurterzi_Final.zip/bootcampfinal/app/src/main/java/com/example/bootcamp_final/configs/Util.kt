package com.example.bootcamp_final.configs

import com.example.bootcamp_final.models.Cekilis

class Util {
    companion object {
        var chosen: Cekilis? = null
    }
}