package com.example.bootcamp_final.ui.bedavakatilim

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bootcamp_final.configs.DbController
import com.example.bootcamp_final.models.Cekilis

class BedavaKatilimViewModel : ViewModel() {

    val bedavaKatilimCekilis: MutableLiveData<List<Cekilis>> = MutableLiveData()

    fun getbedavaKatilimCekilis(context: Context) {
        val dbCekilis = DbController(context).db
        bedavaKatilimCekilis.value = dbCekilis.cekilisDao().getByPage("BedavaKatilim")
        dbCekilis.close()
    }

}