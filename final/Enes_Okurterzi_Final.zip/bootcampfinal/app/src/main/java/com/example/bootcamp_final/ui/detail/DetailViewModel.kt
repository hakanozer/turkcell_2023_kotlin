package com.example.bootcamp_final.ui.detail

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.bootcamp_final.configs.DbController
import com.example.bootcamp_final.models.Cekilis

class DetailViewModel : ViewModel() {

    fun getByTitle(context: Context, cekilis: Cekilis) {
        val dbCekilis = DbController(context).db
        val getByTitleCekilis = dbCekilis.cekilisDao().getByTitle(cekilis.title!!)

        for (item in getByTitleCekilis) {
            item.following = cekilis.following
            dbCekilis.cekilisDao().update(item)
        }

        dbCekilis.close()
    }

}