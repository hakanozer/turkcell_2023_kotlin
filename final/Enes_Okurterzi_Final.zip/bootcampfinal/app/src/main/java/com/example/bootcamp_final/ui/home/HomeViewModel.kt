package com.example.bootcamp_final.ui.home

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bootcamp_final.configs.DbController
import com.example.bootcamp_final.models.Cekilis

class HomeViewModel : ViewModel() {

    val homeCekilis: MutableLiveData<List<Cekilis>> = MutableLiveData()

    fun getHomeCekilis(context: Context) {
        val dbCekilis = DbController(context).db
        homeCekilis.value = dbCekilis.cekilisDao().getByPage("Cekilisler")
        dbCekilis.close()
    }
}