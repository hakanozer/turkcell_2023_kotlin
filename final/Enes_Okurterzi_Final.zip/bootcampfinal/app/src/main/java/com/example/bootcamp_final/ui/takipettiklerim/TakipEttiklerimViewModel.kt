package com.example.bootcamp_final.ui.takipettiklerim

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bootcamp_final.configs.DbController
import com.example.bootcamp_final.models.Cekilis

class TakipEttiklerimViewModel : ViewModel() {

    val takipEttiklerimCekilis: MutableLiveData<List<Cekilis>> = MutableLiveData()

    fun getTakipEttiklerimCekilis(context: Context) {
        val dbCekilis = DbController(context).db
        takipEttiklerimCekilis.value = dbCekilis.cekilisDao().getByFollowingGroupByPage(true)
        dbCekilis.close()
    }

}