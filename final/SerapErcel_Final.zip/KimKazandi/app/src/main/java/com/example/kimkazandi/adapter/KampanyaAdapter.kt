package com.example.kimkazandi.adapter

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.kimkazandi.R
import com.example.kimkazandi.model.Kampanya

class KampanyaAdapter(
    private val kampanyaList: MutableList<Kampanya>,
    val context: Context,
    val fragment: String
) :
    RecyclerView.Adapter<KampanyaAdapter.KampanyaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KampanyaViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.list_item,
            parent,
            false
        )
        return KampanyaViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: KampanyaViewHolder, position: Int) {
        val currentKampanya = kampanyaList[position]

        holder.titleTextView.text = currentKampanya.baslik
        holder.timeTextView.text = currentKampanya.zaman
        holder.tlTextView.text = currentKampanya.hediyeMiktari
        holder.priceTextView.text = currentKampanya.fiyat

        Glide.with(context)
            .load("https://www.kimkazandi.com" + currentKampanya.resim)
            .into(holder.imageView)

        holder.titleTextView.setOnClickListener {
            val bundle = Bundle()
            bundle.putSerializable("link", currentKampanya.link)

            when (fragment) {
                "cekilisler" -> Navigation.findNavController(holder.itemView)
                    .navigate(R.id.action_nav_cekilis_to_detayFragment, bundle)

                "bedavaKatilim" -> Navigation.findNavController(holder.itemView)
                    .navigate(R.id.action_nav_bedavaKatilim_to_detayFragment, bundle)

                "arabaKazan" -> Navigation.findNavController(holder.itemView)
                    .navigate(R.id.action_nav_arabaKazan_to_detayFragment, bundle)

                "tatilKazan" -> Navigation.findNavController(holder.itemView)
                    .navigate(R.id.action_nav_tatilKazan_to_detayFragment, bundle)

                "telefonTabletKazan" -> Navigation.findNavController(holder.itemView)
                    .navigate(R.id.action_nav_telefonTabletKazan_to_detayFragment, bundle)

                "yeniBaslalayanlar" -> Navigation.findNavController(holder.itemView)
                    .navigate(R.id.action_nav_yeniBaslayanlar_to_detayFragment, bundle)
            }
        }
    }

    override fun getItemCount(): Int {
        return kampanyaList.size
    }

    inner class KampanyaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.itemImageView)
        val titleTextView: TextView = itemView.findViewById(R.id.itemTitleTextView)
        val timeTextView: TextView = itemView.findViewById(R.id.itemTimeTextView)
        val tlTextView: TextView = itemView.findViewById(R.id.itemTlTextView)
        val priceTextView: TextView = itemView.findViewById(R.id.itemPriceTextView)
    }
}