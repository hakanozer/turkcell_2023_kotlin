package com.example.kimkazandi.model

data class Kampanya(
    val baslik: String,
    val zaman: String,
    val hediyeMiktari: String,
    val fiyat: String,
    val resim: String,
    val link: String
)
