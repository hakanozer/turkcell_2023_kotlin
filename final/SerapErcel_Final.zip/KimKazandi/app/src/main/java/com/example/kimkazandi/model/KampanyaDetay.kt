package com.example.kimkazandi.model

data class KampanyaDetay(
    val baslik: String?,
    val detay: String?,
    val baslangicTarihi: String?,
    val sonKatilimTarihi: String?,
    val cekilisTarihi: String?,
    val ilanTarihi: String?,
    val minHarcamaTutari: String?,
    val toplamHediyeDegeri: String?,
    val toplamHediyeSayisi: String?,
    val resim: String?
)
