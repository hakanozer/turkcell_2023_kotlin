package com.example.kimkazandi.ui.arabaKazan

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kimkazandi.adapter.KampanyaAdapter
import com.example.kimkazandi.databinding.FragmentArabaKazanBinding

class ArabaKazanFragment : Fragment() {

    private var _binding: FragmentArabaKazanBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val arabaKazanViewModel =
            ViewModelProvider(this).get(ArabaKazanViewModel::class.java)

        _binding = FragmentArabaKazanBinding.inflate(inflater, container, false)
        val root: View = binding.root

        arabaKazanViewModel.kampanyalar.observe(viewLifecycleOwner) {
            val layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            binding.arabaKazanRecyclerView.layoutManager = layoutManager
            val adapter = KampanyaAdapter(it, requireContext(),"arabaKazan")
            binding.arabaKazanRecyclerView.adapter = adapter
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}