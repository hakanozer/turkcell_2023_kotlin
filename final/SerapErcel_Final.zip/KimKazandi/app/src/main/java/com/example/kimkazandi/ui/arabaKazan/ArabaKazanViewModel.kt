package com.example.kimkazandi.ui.arabaKazan

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kimkazandi.Result
import com.example.kimkazandi.model.Kampanya
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ArabaKazanViewModel : ViewModel() {

    private val url = "https://www.kimkazandi.com/cekilisler/araba-kazan"

    private val _kampanyalar = MutableLiveData<MutableList<Kampanya>>(mutableListOf())
    val kampanyalar: LiveData<MutableList<Kampanya>> = _kampanyalar

    init {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                Result().kampanyalariAl(url)
            }
            _kampanyalar.value = result
        }
    }
}