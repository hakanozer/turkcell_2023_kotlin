package com.example.kimkazandi.ui.bedavaKatilim

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kimkazandi.adapter.KampanyaAdapter
import com.example.kimkazandi.databinding.FragmentBedavaKatilimBinding

class BedavaKatilimFragment : Fragment() {

    private var _binding: FragmentBedavaKatilimBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val bedavaKatilimViewModel =
            ViewModelProvider(this).get(BedavaKatilimViewModel::class.java)

        _binding = FragmentBedavaKatilimBinding.inflate(inflater, container, false)
        val root: View = binding.root

        bedavaKatilimViewModel.kampanyalar.observe(viewLifecycleOwner) {
            val layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            binding.bedavaKatilimRecyclerView.layoutManager = layoutManager
            val adapter = KampanyaAdapter(it, requireContext(), "bedavaKatilim")
            binding.bedavaKatilimRecyclerView.adapter = adapter
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}