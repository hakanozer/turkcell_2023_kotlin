package com.example.kimkazandi.ui.detay

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.kimkazandi.databinding.FragmentDetayBinding

class DetayFragment : Fragment() {

    private var _binding: FragmentDetayBinding? = null
    private val binding get() = _binding!!

    private lateinit var link: String
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        link = arguments?.getString("link").toString()
        val detayViewModel =
            ViewModelProvider(this).get(DetayViewModel::class.java)
        detayViewModel.kampanyaDetay(link)


        _binding = FragmentDetayBinding.inflate(inflater, container, false)

        detayViewModel.kampanyaDetay.observe(viewLifecycleOwner) { kampanyaDetay ->

            Glide.with(requireContext())
                .load("https://www.kimkazandi.com" + kampanyaDetay.resim)
                .into(binding.detailImageView)

            binding.detailTitleTextView.text = kampanyaDetay.baslik
            binding.detailDescTextView.text = kampanyaDetay.detay
            binding.tableTextView1.text = kampanyaDetay.baslangicTarihi
            binding.tableTextView2.text = kampanyaDetay.sonKatilimTarihi
            binding.tableTextView3.text = kampanyaDetay.cekilisTarihi
            binding.tableTextView4.text = kampanyaDetay.ilanTarihi
            binding.tableTextView5.text = kampanyaDetay.minHarcamaTutari
            binding.tableTextView6.text = kampanyaDetay.toplamHediyeDegeri
            binding.tableTextView7.text = kampanyaDetay.toplamHediyeSayisi
        }

        binding.followButton.setOnClickListener {
            binding.followButton.visibility = View.INVISIBLE
            binding.unfollowButton.visibility = View.VISIBLE
        }
        binding.unfollowButton.setOnClickListener {
            binding.unfollowButton.visibility = View.INVISIBLE
            binding.followButton.visibility = View.VISIBLE
        }
        return binding.root
    }
}