package com.example.kimkazandi.ui.detay

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kimkazandi.Result
import com.example.kimkazandi.model.KampanyaDetay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetayViewModel : ViewModel() {

    private val _kampanyaDetay = MutableLiveData<KampanyaDetay>()
    val kampanyaDetay: LiveData<KampanyaDetay> = _kampanyaDetay

    fun kampanyaDetay(url: String) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                Result().kampanyaDetayiAl(url)
            }
            _kampanyaDetay.value = result
        }
    }
}