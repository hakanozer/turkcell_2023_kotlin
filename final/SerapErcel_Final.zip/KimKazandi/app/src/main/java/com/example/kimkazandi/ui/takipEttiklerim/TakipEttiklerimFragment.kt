package com.example.kimkazandi.ui.takipEttiklerim

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.kimkazandi.databinding.FragmentTakipEttiklerimBinding

class TakipEttiklerimFragment : Fragment() {

    private var _binding: FragmentTakipEttiklerimBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val takipEttiklerimViewModel =
            ViewModelProvider(this).get(TakipEttiklerimViewModel::class.java)

        _binding = FragmentTakipEttiklerimBinding.inflate(inflater, container, false)
        val root: View = binding.root

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}