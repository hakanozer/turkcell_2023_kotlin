package com.example.kimkazandi.ui.takipEttiklerim

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TakipEttiklerimViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is takip ettiklerim Fragment"
    }
    val text: LiveData<String> = _text
}