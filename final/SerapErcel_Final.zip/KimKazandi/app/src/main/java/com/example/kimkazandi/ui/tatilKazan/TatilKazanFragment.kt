package com.example.kimkazandi.ui.tatilKazan

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kimkazandi.adapter.KampanyaAdapter
import com.example.kimkazandi.databinding.FragmentTatilKazanBinding

class TatilKazanFragment : Fragment() {

    private var _binding: FragmentTatilKazanBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val tatilKazanViewModel =
            ViewModelProvider(this).get(TatilKazanViewModel::class.java)

        _binding = FragmentTatilKazanBinding.inflate(inflater, container, false)
        val root: View = binding.root

        tatilKazanViewModel.kampanyalar.observe(viewLifecycleOwner) {
            val layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            binding.tatilKazanRecyclerView.layoutManager = layoutManager
            val adapter = KampanyaAdapter(it, requireContext(),"tatilKazan")
            binding.tatilKazanRecyclerView.adapter = adapter
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}