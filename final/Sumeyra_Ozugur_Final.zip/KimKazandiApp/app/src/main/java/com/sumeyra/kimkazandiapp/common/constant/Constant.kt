package com.sumeyra.kimkazandiapp.common.constant

object Constant {
    val beginner = "https://www.kimkazandi.com/cekilisler/yeni-baslayanlar"
    val winCar = "https://www.kimkazandi.com/cekilisler/araba-kazan"
    val freeParticaipation = "https://www.kimkazandi.com/cekilisler/bedava-katilim"
    val winPhone = "https://www.kimkazandi.com/cekilisler/telefon-tablet-kazan"
    val winVacation = "https://www.kimkazandi.com/cekilisler/tatil-kazan"
}