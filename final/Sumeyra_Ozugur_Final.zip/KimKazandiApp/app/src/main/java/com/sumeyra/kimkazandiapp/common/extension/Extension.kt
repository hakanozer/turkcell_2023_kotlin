package com.sumeyra.kimkazandiapp.common.extension

import android.view.View
import android.widget.ImageView
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.sumeyra.kimkazandiapp.model.*
import com.sumeyra.kimkazandiapp.room.*

fun ImageView.loadImage(url: String) { //url can be string or int
    Glide.with(this)
        .load(url)
        .into(this)
}

fun Navigation.sent(v: View, id: Int) = findNavController(v).navigate(id)

suspend fun List<FreeParticipationRoomModel>.storeFreeParticipationRoom(participationDao: FreeParticipationDao) {
    participationDao.apply {
        deleteAll()
        if (isNotEmpty()) {
            addAll(*this@storeFreeParticipationRoom.toTypedArray())
        }
    }
}


suspend fun List<PhoneTabletRoomModel>.storePhoneTabletRoom(phoneTabletDao: PhoneTabletDao) {
    phoneTabletDao.apply {
        deleteAll()
        if (isNotEmpty()) {
            addAll(*this@storePhoneTabletRoom.toTypedArray())
        }
    }

}

suspend fun List<WinCarRoomModel>.storeCarTabletRoom(winCarDao: WinCarDao) {
    winCarDao.apply {
        deleteAll()
        if (isNotEmpty()) {
            addAll(*this@storeCarTabletRoom.toTypedArray())
        }
    }
}

suspend fun List<BeginnersRoomModel>.storeBeginnerTabletRoom(beginnerDao: BeginnersDao) {
    beginnerDao.apply {
        deleteAll()
        if (isNotEmpty()) {
            addAll(*this@storeBeginnerTabletRoom.toTypedArray())
        }
    }
}


suspend fun List<WinVacationRoomModel>.storeWinVacationTabletRoom(winVacationDao: WinVacationDao) {
    winVacationDao.apply {
        deleteAll()
        if (isNotEmpty()) {
            addAll(*this@storeWinVacationTabletRoom.toTypedArray())
        }
    }
}

