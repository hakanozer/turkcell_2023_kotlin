package com.sumeyra.kimkazandiapp.common.resource

sealed class NetworkResource<out T> {
    object Loading : NetworkResource<Nothing>()
    data class Success<out T>(val data: T) : NetworkResource<T>()
    data class Error(val message: String) : NetworkResource<Nothing>()
}