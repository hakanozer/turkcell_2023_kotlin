package com.sumeyra.kimkazandiapp.common.time

import android.content.Context
import android.content.SharedPreferences

class TimerManager(private val context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("TimerPrefs", Context.MODE_PRIVATE)


    fun saveStartTime(url:String) {
        val currentTimeMillis = System.currentTimeMillis()
        sharedPreferences.edit().putLong(url, currentTimeMillis).apply()
    }

    fun getElapsedTimeInMiliseconds(url: String): Long {
        val startTime = sharedPreferences.getLong(url, 0)
        if (startTime > 0) {
            val currentTimeMillis = System.currentTimeMillis()
            val elapsedTimeInMillis = currentTimeMillis - startTime
            return elapsedTimeInMillis
        }
        return 0
    }
}

