package com.sumeyra.kimkazandiapp.di

import android.content.Context
import androidx.room.Room
import com.sumeyra.kimkazandiapp.room.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object LocaleModule {

    @Provides
    @Singleton
    fun provideFollowDatabase(@ApplicationContext context: Context): LotteryDatabase =
        Room.databaseBuilder(context, LotteryDatabase::class.java, "lottery_database")
            .fallbackToDestructiveMigration().build()


    @Provides
    @Singleton
    fun provideFollowDao(favProductDatabase: LotteryDatabase): FollowDao =
        favProductDatabase.followDao()

    @Provides
    @Singleton
    fun provideLotteryDao(favProductDatabase: LotteryDatabase): BeginnersDao =
        favProductDatabase.beginnersDao()

    @Provides
    @Singleton
    fun provideParticipationDao(favProductDatabase: LotteryDatabase): FreeParticipationDao =
        favProductDatabase.freeParticipationDao()

    @Provides
    @Singleton
    fun providePhoneTabletDao(favProductDatabase: LotteryDatabase): PhoneTabletDao =
        favProductDatabase.phoneTabletDao()

    @Provides
    @Singleton
    fun provideWinCarDao(favProductDatabase: LotteryDatabase): WinCarDao =
        favProductDatabase.winCarDao()


    @Provides
    @Singleton
    fun provideWinVacationDao(favProductDatabase: LotteryDatabase): WinVacationDao =
        favProductDatabase.winVacationDao()
}



