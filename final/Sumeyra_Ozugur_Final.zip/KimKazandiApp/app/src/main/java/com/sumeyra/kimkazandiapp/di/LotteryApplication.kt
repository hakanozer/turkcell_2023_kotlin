package com.sumeyra.kimkazandiapp.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LotteryApplication: Application()