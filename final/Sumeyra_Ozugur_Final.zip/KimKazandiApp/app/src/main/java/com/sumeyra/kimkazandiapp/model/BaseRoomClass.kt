package com.sumeyra.kimkazandiapp.model

import androidx.room.ColumnInfo

open class BaseRoomClass(
    @ColumnInfo("beginner_img")
    var img: String = "",
    @ColumnInfo("beginner_title")
    var title: String = "",
    var iconTime: String = "",
    var iconGift: String = "",
    var iconPrice: String = "",
    var isFollow: Boolean = false

)

