package com.sumeyra.kimkazandiapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "beginner_table",  primaryKeys = ["beginner_id", "beginner_img"] )
data class BeginnersRoomModel(

    @ColumnInfo("beginner_id")
    val id:Int =0

):Parcelable,BaseRoomClass()