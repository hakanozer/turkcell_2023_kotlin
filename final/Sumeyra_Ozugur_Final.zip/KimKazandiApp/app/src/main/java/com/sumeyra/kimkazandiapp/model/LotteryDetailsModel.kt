package com.sumeyra.kimkazandiapp.model

data class LotteryDetailsModel(val img:String,
                               val title:String= "No found",
                               val startDate:String,
                               val lastDate:String,
                               val drawDate:String,
                               val listingDate:String,
                               val minAmount:String,
                               val totalGiftValue:String,
                               val totalGiftNumber: String,
                               val paragraph: String ="Data is not coming",
)