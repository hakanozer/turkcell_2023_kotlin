package com.sumeyra.kimkazandiapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "follow_table",  primaryKeys = ["follow_id", "follow_img"] )
open class LotteryModel(

    @ColumnInfo("follow_id")
    val id:Int =0,
    @ColumnInfo("follow_img")
    val img:String,
    @ColumnInfo("follow_title")
    val title:String,
    val iconTime:String,
    val iconGift:String,
    val iconPrice:String,
    var isFollow:Boolean =false

):Parcelable