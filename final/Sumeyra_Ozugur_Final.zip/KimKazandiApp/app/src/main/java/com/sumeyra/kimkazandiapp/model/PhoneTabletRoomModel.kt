package com.sumeyra.kimkazandiapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "phone_table",  primaryKeys = ["phone_id", "phone_img"] )
data class PhoneTabletRoomModel(

    @ColumnInfo("phone_id")
    val id:Int =0,
    @ColumnInfo("phone_img")
    val img:String,
    @ColumnInfo("phone_title")
    val title:String,
    val iconTime:String,
    val iconGift:String,
    val iconPrice:String,
    var isFollow:Boolean =false

):Parcelable