package com.sumeyra.kimkazandiapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "car_table",  primaryKeys = ["car_id", "car_img"] )
data class WinCarRoomModel(

    @ColumnInfo("car_id")
    val id:Int =0,
    @ColumnInfo("car_img")
    val img:String,
    @ColumnInfo("car_title")
    val title:String,
    val iconTime:String,
    val iconGift:String,
    val iconPrice:String,
    var isFollow:Boolean =false

):Parcelable