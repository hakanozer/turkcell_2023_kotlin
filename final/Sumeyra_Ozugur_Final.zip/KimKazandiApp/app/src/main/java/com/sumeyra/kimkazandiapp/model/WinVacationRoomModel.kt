package com.sumeyra.kimkazandiapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "vacation_table",  primaryKeys = ["vacation_id", "vacation_img"] )
data class WinVacationRoomModel(

    @ColumnInfo("vacation_id")
    val id:Int =0,
    @ColumnInfo("vacation_img")
    val img:String,
    @ColumnInfo("vacation_title")
    val title:String,
    val iconTime:String,
    val iconGift:String,
    val iconPrice:String,
    var isFollow:Boolean =false

):Parcelable