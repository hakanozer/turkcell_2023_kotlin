package com.sumeyra.kimkazandiapp.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.sumeyra.kimkazandiapp.common.constant.Constant
import com.sumeyra.kimkazandiapp.common.extension.*
import com.sumeyra.kimkazandiapp.common.time.TimerManager
import com.sumeyra.kimkazandiapp.model.*
import com.sumeyra.kimkazandiapp.room.*
import org.jsoup.Connection
import org.jsoup.Jsoup
import javax.inject.Inject

class LotteryRepository @Inject constructor(
    private val followDao: FollowDao,
    private val lotteryDao: BeginnersDao,
    private val participationDao: FreeParticipationDao,
    private val phoneTabletDao: PhoneTabletDao,
    private val winCarDao: WinCarDao,
    private val winVacationDao: WinVacationDao,
    private val timerManager: TimerManager
) {

    val lotteryList: MutableList<LotteryModel> = mutableListOf()
    val readAllFollow: LiveData<List<LotteryModel>> = followDao.getAllFollow()



    private suspend fun getLotteryDataFromJsoup(url: String): List<LotteryModel> {

        val document = Jsoup.connect(url).get()

        if (!document.outerHtml().isNullOrEmpty()) {

            val itemElements = document.select("div.row > div.col-sm-3.col-lg-3")

            for (itemElement in itemElements) {
                val imgUrl = itemElement.selectFirst("div.img > div > a > img")?.absUrl("src")
                val title = itemElement.selectFirst("h4")?.text()
                val date = itemElement.selectFirst("span.date:eq(0)")?.text()
                val gift = itemElement.selectFirst("span.date:has(i.icon-gift)")?.text()
                val price = itemElement.selectFirst("span.date.kosul_fiyat")?.text()
                val followList = followDao.getFollowTitles().orEmpty()

                if (title != null && price != null && date != null && gift != null && imgUrl != null) {
                    val lottery = LotteryModel(
                        img = imgUrl,
                        title = title,
                        iconTime = date,
                        iconGift = gift,
                        iconPrice = price,
                        isFollow = followList.contains(title)
                    )

                    lotteryList.add(lottery)
                }
            }
            timerManager.saveStartTime(url)
        }
        when (url) {
            Constant.beginner -> storeBeginnersRoom(lotteryList.map { lottery ->
                BeginnersRoomModel().apply {
                    img = lottery.img
                    title = lottery.title
                    iconTime = lottery.iconTime
                    iconGift = lottery.iconGift
                    iconPrice = lottery.iconPrice
                    isFollow = lottery.isFollow

                }

            })
            Constant.freeParticaipation -> storeFreeParticipationRoom(lotteryList.map { lottery ->
                FreeParticipationRoomModel(
                    img = lottery.img,
                    title = lottery.title,
                    iconTime = lottery.iconTime,
                    iconGift = lottery.iconGift,
                    iconPrice = lottery.iconPrice,
                    isFollow = lottery.isFollow
                )
            })

            Constant.winCar -> storeWinCarRoom(lotteryList.map { lottery ->
                WinCarRoomModel(
                    img = lottery.img,
                    title = lottery.title,
                    iconTime = lottery.iconTime,
                    iconGift = lottery.iconGift,
                    iconPrice = lottery.iconPrice,
                    isFollow = lottery.isFollow
                )
            })


            Constant.winVacation -> storeWinVacationRoom(lotteryList.map { lottery ->
                WinVacationRoomModel(
                    img = lottery.img,
                    title = lottery.title,
                    iconTime = lottery.iconTime,
                    iconGift = lottery.iconGift,
                    iconPrice = lottery.iconPrice,
                    isFollow = lottery.isFollow
                )
            })


            Constant.winPhone -> storePhoneTabletRoom(lotteryList.map { lottery ->
                PhoneTabletRoomModel(
                    img = lottery.img,
                    title = lottery.title,
                    iconTime = lottery.iconTime,
                    iconGift = lottery.iconGift,
                    iconPrice = lottery.iconPrice,
                    isFollow = lottery.isFollow
                )
            })
        }
        Log.v("jsoup", "jsoupdan gelen veri")

        return lotteryList
    }

    private suspend fun storeBeginnersRoom(beginnersList: List<BeginnersRoomModel>) {
        beginnersList.storeBeginnerTabletRoom(lotteryDao)
    }

    private suspend fun storeFreeParticipationRoom(freeParticipationList: List<FreeParticipationRoomModel>) {
        freeParticipationList.storeFreeParticipationRoom(participationDao)
    }

    private suspend fun storePhoneTabletRoom(phoneTabletList: List<PhoneTabletRoomModel>) {
        phoneTabletList.storePhoneTabletRoom(phoneTabletDao)
    }

    private suspend fun storeWinCarRoom(winCarList: List<WinCarRoomModel>) {
        winCarList.storeCarTabletRoom(winCarDao)
    }

    private suspend fun storeWinVacationRoom(winVacationList: List<WinVacationRoomModel>) {
        winVacationList.storeWinVacationTabletRoom(winVacationDao)
    }


    //read from room
    private suspend fun readAllDataFromRoom(url:String){
        Log.v("Rooom","room")

       val data =   when(url){
           Constant.beginner -> { lotteryDao.getAllData().map {
                LotteryModel(
                    it.id,
                    it.img,
                    it.title,
                    it.iconTime,
                    it.iconGift,
                    it.iconPrice,
                    isFollow = it.isFollow
                )
            }}
           Constant.freeParticaipation-> {participationDao.getAllData().map {
               LotteryModel(
                   it.id,
                   it.img,
                   it.title,
                   it.iconTime,
                   it.iconGift,
                   it.iconPrice,
                   isFollow = it.isFollow
               )

           }}
           Constant.winCar ->{ winCarDao.getAllData().map {
               LotteryModel(
                   it.id,
                   it.img,
                   it.title,
                   it.iconTime,
                   it.iconGift,
                   it.iconPrice,
                   isFollow = it.isFollow
               )
           }}
           Constant.winVacation ->{ winVacationDao.getAllData().map {
               LotteryModel(
                   it.id,
                   it.img,
                   it.title,
                   it.iconTime,
                   it.iconGift,
                   it.iconPrice,
                   isFollow = it.isFollow
               )
           }}
           Constant.winPhone -> {phoneTabletDao.getAllData().map {
               LotteryModel(
                   it.id,
                   it.img,
                   it.title,
                   it.iconTime,
                   it.iconGift,
                   it.iconPrice,
                   isFollow = it.isFollow
               )
           }}


           else -> emptyList()
       }
        lotteryList.addAll(data)

    }


    suspend fun decide(url: String): List<LotteryModel> {
        lotteryList.clear()
        val refreshTime = 3 * 60 * 60 * 1000L // 3 saat
        val updateTime = timerManager.getElapsedTimeInMiliseconds(url)
        if (updateTime >= refreshTime || updateTime == 0L)
            getLotteryDataFromJsoup(url) else {
            readAllDataFromRoom(url)
        }

        return lotteryList
    }

   //Detaile Page
    fun geyLotteryDetaileFromJsoup(url: String): LotteryDetailsModel? {
        var lottery: LotteryDetailsModel? = null

        val document =
            Jsoup.connect(url).method(Connection.Method.GET).ignoreContentType(true).get()

        val title = document.selectFirst("div.container > h1")?.text()

        val img = document.selectFirst("div.row > img.img-responsive")?.absUrl("src")
        val startDate =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(1) > h4")?.text()
        val lastDate =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(2) > h4")?.text()

        val drawDate =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(3) > h4")?.text()

        val listingDate =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(4) > h4")?.text()


        val minAmount =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(5) > h4")?.text()


        val totalGiftValue =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(6) > h4")?.text()


        val totalGiftNumber =
            document.selectFirst("div.brandDesc > div.kalanSure:nth-child(7) > h4")?.text()

        val paragraph = document.select("div.campDesc").select("p")?.text()

        if (title != null && img != null && startDate != null && lastDate != null && listingDate != null &&
            drawDate != null && minAmount != null && totalGiftValue != null && totalGiftNumber != null && paragraph != null
        ) {

            lottery = LotteryDetailsModel(
                img,
                title,
                startDate,
                lastDate,
                listingDate,
                drawDate,
                minAmount,
                totalGiftValue,
                totalGiftNumber,
                paragraph
            )

        }

        return lottery

    }

    suspend fun addToFollow(follow: LotteryModel) = followDao.addToFollow(follow)

    suspend fun deleteFromFollow(follow: LotteryModel) = followDao.deleteFromFollow(follow)

    suspend fun updateFollow(follow: LotteryModel) = followDao.updateLottery(follow)
}







