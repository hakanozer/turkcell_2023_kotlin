package com.sumeyra.kimkazandiapp.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sumeyra.kimkazandiapp.model.BeginnersRoomModel

@Dao
interface BeginnersDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAll(vararg lottery: BeginnersRoomModel): List<Long>
    @Query("SELECT * FROM beginner_table ORDER BY beginner_id ASC")
    suspend fun getAllData():List<BeginnersRoomModel>

    @Query("DELETE FROM beginner_table")
    suspend fun deleteAll()
}