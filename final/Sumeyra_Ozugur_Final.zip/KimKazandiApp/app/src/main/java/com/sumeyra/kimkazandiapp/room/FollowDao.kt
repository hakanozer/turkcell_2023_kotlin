package com.sumeyra.kimkazandiapp.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sumeyra.kimkazandiapp.model.LotteryModel

@Dao
interface FollowDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToFollow(follow: LotteryModel)

    @Query("SELECT * FROM follow_table ORDER BY follow_id ASC")
    fun getAllFollow(): LiveData<List<LotteryModel>>

    @Query("SELECT follow_title FROM follow_table")
    suspend fun getFollowTitles(): List<String>?

    @Update
    suspend fun updateLottery(follow: LotteryModel)

    @Delete
    suspend fun deleteFromFollow(follow: LotteryModel)
}