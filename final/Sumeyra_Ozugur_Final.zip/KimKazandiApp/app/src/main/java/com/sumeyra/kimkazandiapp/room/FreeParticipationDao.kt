package com.sumeyra.kimkazandiapp.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sumeyra.kimkazandiapp.model.BeginnersRoomModel
import com.sumeyra.kimkazandiapp.model.FreeParticipationRoomModel

@Dao
interface FreeParticipationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAll(vararg lottery: FreeParticipationRoomModel): List<Long>

    @Query("SELECT * FROM participation_table ORDER BY participation_id ASC")
    suspend fun getAllData():List<FreeParticipationRoomModel>

    @Query("DELETE FROM participation_table")
    suspend fun deleteAll()
}