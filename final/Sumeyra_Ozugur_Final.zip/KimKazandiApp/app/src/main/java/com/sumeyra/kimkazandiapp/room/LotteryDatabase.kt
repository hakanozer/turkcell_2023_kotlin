package com.sumeyra.kimkazandiapp.room

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sumeyra.kimkazandiapp.model.*

@Database(entities = [LotteryModel::class,
                      BeginnersRoomModel::class,
                     FreeParticipationRoomModel::class,
                     PhoneTabletRoomModel::class,
                     WinCarRoomModel::class,
                     WinVacationRoomModel::class], version = 6, exportSchema = false)
abstract class LotteryDatabase : RoomDatabase() {
    abstract fun followDao(): FollowDao
    abstract fun beginnersDao(): BeginnersDao
    abstract fun freeParticipationDao(): FreeParticipationDao
    abstract fun phoneTabletDao(): PhoneTabletDao
    abstract fun winCarDao(): WinCarDao
    abstract fun winVacationDao(): WinVacationDao

}