package com.sumeyra.kimkazandiapp.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sumeyra.kimkazandiapp.model.BeginnersRoomModel
import com.sumeyra.kimkazandiapp.model.FreeParticipationRoomModel
import com.sumeyra.kimkazandiapp.model.PhoneTabletRoomModel

@Dao
interface PhoneTabletDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAll(vararg lottery: PhoneTabletRoomModel): List<Long>


    @Query("SELECT * FROM phone_table ORDER BY phone_id ASC")
    suspend fun getAllData():List<PhoneTabletRoomModel>

    @Query("DELETE FROM phone_table")
    suspend fun deleteAll()
}