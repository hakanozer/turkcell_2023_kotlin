package com.sumeyra.kimkazandiapp.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sumeyra.kimkazandiapp.model.BeginnersRoomModel
import com.sumeyra.kimkazandiapp.model.PhoneTabletRoomModel
import com.sumeyra.kimkazandiapp.model.WinCarRoomModel

@Dao
interface WinCarDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAll(vararg lottery: WinCarRoomModel): List<Long>


    @Query("SELECT * FROM car_table ORDER BY car_id ASC")
    suspend fun getAllData():List<WinCarRoomModel>

    @Query("DELETE FROM car_table")
    suspend fun deleteAll()
}