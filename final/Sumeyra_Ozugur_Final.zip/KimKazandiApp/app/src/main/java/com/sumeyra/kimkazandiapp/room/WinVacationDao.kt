package com.sumeyra.kimkazandiapp.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sumeyra.kimkazandiapp.model.BeginnersRoomModel
import com.sumeyra.kimkazandiapp.model.PhoneTabletRoomModel
import com.sumeyra.kimkazandiapp.model.WinCarRoomModel
import com.sumeyra.kimkazandiapp.model.WinVacationRoomModel

@Dao
interface WinVacationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAll(vararg lottery: WinVacationRoomModel): List<Long>


    @Query("SELECT * FROM vacation_table ORDER BY vacation_id ASC")
    suspend fun getAllData():List<WinVacationRoomModel>

    @Query("DELETE FROM vacation_table")
    suspend fun deleteAll()
}