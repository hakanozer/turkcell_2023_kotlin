package com.sumeyra.kimkazandiapp.ui.detaile


import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.sumeyra.kimkazandiapp.R
import com.sumeyra.kimkazandiapp.common.extension.loadImage
import com.sumeyra.kimkazandiapp.databinding.FragmentDetaileBinding
import com.sumeyra.kimkazandiapp.delegete.viewBinding
import com.sumeyra.kimkazandiapp.model.LotteryModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class DetaileFragment : Fragment(R.layout.fragment_detaile) {
    private val binding by viewBinding(FragmentDetaileBinding::bind)
    private val viewModel: DetaileViewModel by viewModels()
    private val args: DetaileFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val type = args.item

        initObserver(type.title)

        with(binding){
            ivDetaile.loadImage(type.img)

            btnFollow.setOnClickListener {

                if(type.isFollow){
                    type.isFollow =false
                    val updateFollow = LotteryModel(type.id,type.img,type.title,type.iconTime,type.iconGift,type.iconPrice,type.isFollow)
                    viewModel.deleteFromFollow(updateFollow)
                    btnFollow.setBackgroundResource(R.drawable.ic_favorite)
                    viewModel.updateFollow(updateFollow)
                }else{
                    type.isFollow= true
                    val updateFollow = LotteryModel(type.id,type.img,type.title,type.iconTime,type.iconGift,type.iconPrice,
                        isFollow = type.isFollow
                    )
                    viewModel.addToFollow(updateFollow)
                    btnFollow.setBackgroundResource(R.drawable.ic_full_fav)
                    viewModel.updateFollow(updateFollow)
                }
            }

            if(type.isFollow) binding.btnFollow.setBackgroundResource(R.drawable.ic_full_fav)
            else binding.btnFollow.setBackgroundResource(R.drawable.ic_favorite)


        }
    }

    private fun convertTitleToUrl(title:String):String{
        val a =  title.replace(" ", "-")
        return a.replace("'", "-").lowercase()
    }

    private fun initObserver(title: String){
        val urlParamater= title?.let { convertTitleToUrl(title) }
        viewModel.getAllLotte("https://www.kimkazandi.com/kampanya/${urlParamater}")
        viewModel.lottery.observe(viewLifecycleOwner){
            it?.let {
                with(binding) {
                    tvTitle.text = it.title
                    tvStartDate.text = it.startDate
                    tvEndDate.text = it.lastDate
                    tvDrawDate.text = it.drawDate
                    tvAnnouncementDate.text = it.listingDate
                    tvMinSpendingAmount.text = it.minAmount
                    tvTotalPrizeValue.text = it.totalGiftValue
                    tvTotalPrizeNumber.text = it.totalGiftNumber
                    tvParagraph.text = it.paragraph

                }
            }
        }
    }
}