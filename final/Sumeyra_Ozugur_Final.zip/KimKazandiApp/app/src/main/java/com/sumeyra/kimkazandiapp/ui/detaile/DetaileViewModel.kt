package com.sumeyra.kimkazandiapp.ui.detaile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sumeyra.kimkazandiapp.model.LotteryDetailsModel
import com.sumeyra.kimkazandiapp.model.LotteryModel
import com.sumeyra.kimkazandiapp.repository.LotteryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetaileViewModel @Inject constructor(private val repository: LotteryRepository): ViewModel() {


    private val _lottery = MutableLiveData<LotteryDetailsModel>()
    val lottery: LiveData<LotteryDetailsModel> get() = _lottery



    fun getAllLotte(url: String) = viewModelScope.launch(Dispatchers.IO) {
        _lottery.postValue(repository.geyLotteryDetaileFromJsoup(url))
    }

    fun addToFollow(follow: LotteryModel) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addToFollow(follow)
        }
    }

    fun deleteFromFollow(follow: LotteryModel) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFromFollow(follow)
        }
    }

    fun updateFollow(follow: LotteryModel){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateFollow(follow)

        }
    }

}