package com.sumeyra.kimkazandiapp.ui.group

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.kimkazandiapp.common.extension.loadImage
import com.sumeyra.kimkazandiapp.databinding.ItemGroupBinding
import com.sumeyra.kimkazandiapp.model.LotteryModel

class SharedAdapter(private val onItemClick:(item:LotteryModel)->Unit) :
    ListAdapter<LotteryModel, SharedAdapter.ViewHolder>(DiffCallback()) {

    private var filteredList: List<LotteryModel> = listOf()

    fun setLotteryList(lotteryList: List<LotteryModel>) {
        filteredList = lotteryList.filter {
            it.title != null && it.iconTime != null && it.iconGift != null && it.iconPrice != null
        }
        submitList(filteredList)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemGroupBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
    }

    inner class ViewHolder(private val binding: ItemGroupBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(lottery: LotteryModel) = with(binding) {

            root.setOnClickListener {
                onItemClick(lottery)
            }
            lotteryImage.loadImage(lottery.img)
            lotteryTitle.text = lottery.title
            lotteryPrice.text = lottery.iconPrice
            lotteryTime.text = lottery.iconTime
            lotteryReward.text = lottery.iconGift
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<LotteryModel>() {
        override fun areItemsTheSame(oldItem: LotteryModel, newItem: LotteryModel) =
            oldItem.title == newItem.title

        override fun areContentsTheSame(oldItem: LotteryModel, newItem: LotteryModel) =
            oldItem == newItem
    }
}