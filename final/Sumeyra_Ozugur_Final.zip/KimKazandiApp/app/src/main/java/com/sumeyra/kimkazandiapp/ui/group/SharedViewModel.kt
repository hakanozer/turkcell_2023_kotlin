package com.sumeyra.kimkazandiapp.ui.group

import androidx.lifecycle.*
import com.sumeyra.kimkazandiapp.model.LotteryModel
import com.sumeyra.kimkazandiapp.repository.LotteryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SharedViewModel @Inject constructor(private val repository: LotteryRepository): ViewModel() {


    private val _lottery = MutableLiveData<List<LotteryModel>>()
    val lottery: LiveData<List<LotteryModel>> get() = _lottery


    fun getAllLottery(url: String) = viewModelScope.launch(Dispatchers.IO) {
        _lottery.postValue(repository.decide(url))
    }

}