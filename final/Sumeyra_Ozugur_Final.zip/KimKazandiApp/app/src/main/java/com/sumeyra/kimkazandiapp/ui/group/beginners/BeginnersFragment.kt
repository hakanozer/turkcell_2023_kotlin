package com.sumeyra.kimkazandiapp.ui.group.beginners

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.sumeyra.kimkazandiapp.R
import com.sumeyra.kimkazandiapp.common.constant.Constant
import com.sumeyra.kimkazandiapp.databinding.FragmentBeginnersBinding
import com.sumeyra.kimkazandiapp.delegete.viewBinding
import com.sumeyra.kimkazandiapp.model.LotteryModel
import com.sumeyra.kimkazandiapp.ui.group.SharedAdapter
import com.sumeyra.kimkazandiapp.ui.group.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BeginnersFragment : Fragment(R.layout.fragment_beginners) {
    private val binding by viewBinding(FragmentBeginnersBinding::bind)
    private val viewModel: SharedViewModel by viewModels()
    private val adapter by lazy { SharedAdapter(onItemClick= ::onItemClick) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recyclerview.adapter = adapter
        viewModel.getAllLottery(Constant.beginner)
        initObserver()

    }

    private fun onItemClick(kimKazandiModel: LotteryModel) {
        val action = BeginnersFragmentDirections
        .actionNavYeniBaslayanlarToDetaileFragment(kimKazandiModel)
        findNavController().navigate(action)

    }

    private fun initObserver(){
        viewModel.lottery.observe(viewLifecycleOwner){
            adapter.setLotteryList(it)
        }
    }
}
