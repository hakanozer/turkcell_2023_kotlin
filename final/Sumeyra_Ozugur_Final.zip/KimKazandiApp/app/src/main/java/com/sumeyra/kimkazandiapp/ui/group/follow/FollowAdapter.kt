package com.sumeyra.kimkazandiapp.ui.group.follow

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.kimkazandiapp.common.extension.loadImage
import com.sumeyra.kimkazandiapp.databinding.ItemFollowBinding
import com.sumeyra.kimkazandiapp.model.LotteryModel


class FollowAdapter(private val onItemClick: (item: LotteryModel) -> Unit) :
    androidx.recyclerview.widget.ListAdapter<LotteryModel, FollowAdapter.ViewHolder>(DiffCallback()) {
    private var followList: List<LotteryModel> = listOf()


    inner class ViewHolder(private val binding: ItemFollowBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(lotteryModel: LotteryModel) = with(binding) {
            ivFollow.loadImage(lotteryModel.img)
            tvTitle.text = lotteryModel.title
            lotteryTime.text = lotteryModel.iconTime
            lotteryPrice.text = lotteryModel.iconPrice
            lotteryReward.text =lotteryModel.iconGift

            root.setOnClickListener {
                onItemClick(lotteryModel)
            }
        }

    }


    class DiffCallback : DiffUtil.ItemCallback<LotteryModel>() {
        override fun areItemsTheSame(oldItem: LotteryModel, newItem: LotteryModel) =
            oldItem.title == newItem.title

        override fun areContentsTheSame(oldItem: LotteryModel, newItem: LotteryModel) =
            oldItem == newItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemFollowBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
    }

}