package com.sumeyra.kimkazandiapp.ui.group.follow

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.sumeyra.kimkazandiapp.R
import com.sumeyra.kimkazandiapp.databinding.FragmentFollowBinding
import com.sumeyra.kimkazandiapp.delegete.viewBinding
import com.sumeyra.kimkazandiapp.model.LotteryModel
import com.sumeyra.kimkazandiapp.ui.group.car.WiinCarFragmentDirections
import com.sumeyra.kimkazandiapp.ui.group.vacation.WinVacationFragmentDirections
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FollowFragment : Fragment(R.layout.fragment_follow) {
    private val binding by viewBinding(FragmentFollowBinding::bind)
    private val viewModel: FollowViewModel by viewModels()
    private val adapter by lazy { FollowAdapter(onItemClick = ::onItemClick) }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recyclerview.adapter = adapter
        initializeObserver()
    }

    private fun onItemClick(lotteryModel: LotteryModel) {
        val action = FollowFragmentDirections.actionNavFollowToDetaileFragment(lotteryModel)
        findNavController().navigate(action)

    }

    private fun initializeObserver() {
        viewModel.readAllFollow.observe(viewLifecycleOwner){ favList ->
            if(favList.isEmpty()) {
                binding.tvEmpty.visibility =View.VISIBLE
                adapter.submitList(favList)
            }
            else
            {
                binding.tvEmpty.visibility =View.GONE
                adapter.submitList(favList)
            }
        }
    }

}