package com.sumeyra.kimkazandiapp.ui.group.follow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.sumeyra.kimkazandiapp.model.LotteryModel
import com.sumeyra.kimkazandiapp.repository.LotteryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class FollowViewModel @Inject constructor(private val repository: LotteryRepository) :ViewModel() {

    val readAllFollow: LiveData<List<LotteryModel>> = repository.readAllFollow

}