package com.sumeyra.kimkazandiapp.ui.group.phonetablet

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.sumeyra.kimkazandiapp.R
import com.sumeyra.kimkazandiapp.common.constant.Constant
import com.sumeyra.kimkazandiapp.databinding.FragmentWinPhoneTabletBinding
import com.sumeyra.kimkazandiapp.delegete.viewBinding
import com.sumeyra.kimkazandiapp.model.LotteryModel
import com.sumeyra.kimkazandiapp.ui.group.SharedAdapter
import com.sumeyra.kimkazandiapp.ui.group.SharedViewModel
import com.sumeyra.kimkazandiapp.ui.group.car.WiinCarFragmentDirections
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class WinPhoneTabletFragment : Fragment(R.layout.fragment_win_phone_tablet) {

    private val binding by viewBinding(FragmentWinPhoneTabletBinding::bind)
    private val viewModel: SharedViewModel by viewModels()
    private val adapter by lazy { SharedAdapter(onItemClick = ::onItemClick) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recyclerview.adapter = adapter
        viewModel.getAllLottery(Constant.winPhone)
        initObserver()

    }

    private fun onItemClick(lottery: LotteryModel) {
        val action = WinPhoneTabletFragmentDirections.actionNavTelofonTabletKazanToDetaileFragment(lottery)
        findNavController().navigate(action)

    }

    private fun initObserver() {
        viewModel.lottery.observe(viewLifecycleOwner) {
            adapter.setLotteryList(it)
        }
    }


}