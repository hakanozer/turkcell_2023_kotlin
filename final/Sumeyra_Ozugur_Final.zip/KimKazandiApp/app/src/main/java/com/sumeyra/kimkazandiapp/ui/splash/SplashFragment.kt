package com.sumeyra.kimkazandiapp.ui.splash

import android.animation.Animator
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.navigation.fragment.findNavController
import com.sumeyra.kimkazandiapp.MainActivity
import com.sumeyra.kimkazandiapp.R
import com.sumeyra.kimkazandiapp.databinding.FragmentSplashBinding
import com.sumeyra.kimkazandiapp.delegete.viewBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SplashFragment : Fragment(R.layout.fragment_splash) {

    private val binding by viewBinding(FragmentSplashBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        binding.lottie.addAnimatorListener(object : Animator.AnimatorListener {

            override fun onAnimationEnd(animation: Animator) {
                findNavController().navigate(R.id.action_splashFragment_to_nav_yeni_baslayanlar)
            }

            override fun onAnimationStart(animation: Animator) = Unit
            override fun onAnimationCancel(animation: Animator) = Unit
            override fun onAnimationRepeat(animation: Animator) = Unit

        })
    }
}