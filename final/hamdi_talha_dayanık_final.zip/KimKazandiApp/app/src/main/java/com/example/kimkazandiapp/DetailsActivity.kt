package com.example.kimkazandiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.kimkazandiapp.database.AppDatabase
import com.example.kimkazandiapp.databinding.ActivityDetailsBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailsBinding
    var selectedGiveaway = MainActivity.selectedGiveaway

    lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AppDatabase.getDatabase(applicationContext)

        if (selectedGiveaway.followed == "true"){
            binding.detailsFollowButton.setText("Takibi Bırak")
            binding.detailsFollowButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.baseline_favorite_24,0,0,0)
        }

        val startDate = "Başlangıç Tarihi : ${selectedGiveaway.startDate}"
        val drawDate = "Çekiliş Tarihi : ${selectedGiveaway.drawDate}"
        val endDate = "Son Katılım Tarihi : ${selectedGiveaway.endDate}"
        val announceDate = "İlan Tarihi : ${selectedGiveaway.announceDate}"
        val minSpend = "Min. Harcama Tutarı : ${selectedGiveaway.minSpend}"
        val totalGiftValue = "Toplam Hediye Değeri : ${selectedGiveaway.totalGiftValue}"
        val totalGiftCount = "Toplam Hediye Sayısı : ${selectedGiveaway.totalGiftCount}"

        binding.detailsTitle.text = selectedGiveaway.title
        Glide.with(applicationContext).load(selectedGiveaway.image).into(binding.detailsImage)
        binding.detailsDrawDate.text = drawDate
        binding.detailsEndDate.text = endDate
        binding.detailsAnnounceDate.text = announceDate
        binding.detailsMinSpend.text = minSpend
        binding.detailsStartDate.text = startDate
        binding.detailsTotalGiftCount.text = totalGiftCount
        binding.detailsTotalGiftValue.text = totalGiftValue
        binding.detailsDesc.text = selectedGiveaway.desc

        binding.detailsFollowButton.setOnClickListener {
            if (selectedGiveaway.followed == "true"){
                binding.detailsFollowButton.setText("Takip Et")
                selectedGiveaway.followed = "false"
                binding.detailsFollowButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.baseline_favorite_border_24,0,0,0)
                GlobalScope.launch {
                    db.giveawayDao().updateGiveaway(selectedGiveaway)
                }
            }else{
                binding.detailsFollowButton.setText("Takibi Bırak")
                selectedGiveaway.followed = "true"
                binding.detailsFollowButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.baseline_favorite_24,0,0,0)
                GlobalScope.launch {
                    db.giveawayDao().updateGiveaway(selectedGiveaway)
                }
            }
        }

    }
}