package com.example.kimkazandiapp

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDateTime
import com.example.kimkazandiapp.databinding.ActivityMainBinding
import com.example.kimkazandiapp.models.Giveaway
import com.example.kimkazandiapp.service.Service
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    companion object{
        lateinit var selectedGiveaway: Giveaway
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPref = getSharedPreferences("lastFetch", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()
        val currentTime = LocalDateTime.now()

        setSupportActionBar(binding.appBarMain.toolbar)
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)

        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_yeniBaslayanlar, R.id.nav_bedavaKatilim, R.id.nav_arabaKazan,
                R.id.nav_telefonTabletKazan, R.id.nav_tatilKazan, R.id.nav_takipEttiklerim
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        val service = Service(applicationContext)

        GlobalScope.launch {
            if (!sharedPref.contains("lastFetch")){
                editor.putString("lastFetch", currentTime.toString()).apply()
                service.fetchDataAndWriteToDatabase("yeni-baslayanlar")
                service.fetchDataAndWriteToDatabase("bedava-katilim")
                service.fetchDataAndWriteToDatabase("araba-kazan")
                service.fetchDataAndWriteToDatabase("telefon-tablet-kazan")
                service.fetchDataAndWriteToDatabase("tatil-kazan")
                service.fetchDataAndWriteToDatabase("")
                Log.e("NAVIGATION: ", "BIR")
                withContext(Dispatchers.Main){
                    navController.navigate(R.id.nav_home)
                }
            }else if (Duration.between(LocalDateTime.parse(sharedPref.getString("lastFetch", "")), currentTime).toHours() >= 3){
                editor.putString("lastFetch", currentTime.toString()).apply()
                service.fetchDataAndWriteToDatabase("yeni-baslayanlar")
                service.fetchDataAndWriteToDatabase("bedava-katilim")
                service.fetchDataAndWriteToDatabase("araba-kazan")
                service.fetchDataAndWriteToDatabase("telefon-tablet-kazan")
                service.fetchDataAndWriteToDatabase("tatil-kazan")
                service.fetchDataAndWriteToDatabase("")
                Log.e("NAVIGATION: ", "IKI")
                withContext(Dispatchers.Main){
                    navController.navigate(R.id.nav_home)
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}