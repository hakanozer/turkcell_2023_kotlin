package com.example.contactsapp.adapters

import android.app.Activity
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.kimkazandiapp.R
import com.example.kimkazandiapp.models.Giveaway

class GiveawayAdapter(private val context: Context, private var list: MutableList<Giveaway>) : ArrayAdapter<Giveaway>(context, R.layout.custom_giveaway_item_layout, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = (context as Activity).layoutInflater.inflate(R.layout.custom_giveaway_item_layout, null, true)

        val image = view.findViewById<ImageView>(R.id.g_item_image)
        val title = view.findViewById<TextView>(R.id.g_item_title)
        val time = view.findViewById<TextView>(R.id.g_item_time)
        val value = view.findViewById<TextView>(R.id.g_item_totalGiftValue)
        val min = view.findViewById<TextView>(R.id.g_item_minSpend)

        val giveaway = list.get(position)

        Glide.with(view).load(giveaway.image).into(image)
        title.text = "${giveaway.title}"
        time.text = "${giveaway.remainedTime}"

        value.text = giveaway.totalGiftValue
        min.text = giveaway.minSpend

        return view
    }

    public fun updateGiveawayList(newList: List<Giveaway>){
        list.clear()
        list.addAll(newList)
        this.notifyDataSetChanged()
    }
}