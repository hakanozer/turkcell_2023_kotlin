package com.example.kimkazandiapp.dao

import androidx.room.*
import com.example.kimkazandiapp.models.Giveaway

@Dao
interface GiveawayDao {

    @Insert
    fun insertGiveaway(giveaway: Giveaway) : Long

    @Update
    fun updateGiveaway(giveaway: Giveaway) : Int

    @Query("select * from giveaways where id =:id")
    fun getContactById(id: Int) : Giveaway

    @Query("select * from giveaways where anasayfa = :anasayfa")
    fun getHomepageData(anasayfa: String) : List<Giveaway>

    @Query("select * from giveaways where category like '%' || :cat || '%' order by id limit 8")
    fun getLastEightByCategory(cat: String) : List<Giveaway>

    @Query("select * from giveaways where title like '%' || :searchTerm || '%'")
    fun searchByTitle(searchTerm: String) : List<Giveaway>

    @Query("select * from giveaways where `followed` = :followed")
    fun getFollowedData(followed: String) : List<Giveaway>
}