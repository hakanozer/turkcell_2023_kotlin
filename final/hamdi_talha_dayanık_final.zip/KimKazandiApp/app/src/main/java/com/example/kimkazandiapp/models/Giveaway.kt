package com.example.kimkazandiapp.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "giveaways")
data class Giveaway(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Int?,

    @ColumnInfo(name = "link")
    val link: String?,

    @ColumnInfo(name = "followed")
    var followed: String?,

    @ColumnInfo(name = "anasayfa")
    val anasayfa: String?,

    @ColumnInfo(name = "remainedTime")
    val remainedTime: String?,

    @ColumnInfo(name = "title")
    val title: String?,

    @ColumnInfo(name = "category")
    var category: String?,

    @ColumnInfo(name = "image")
    val image: String?,

    @ColumnInfo(name = "startDate")
    val startDate: String?,

    @ColumnInfo(name = "endDate")
    val endDate: String?,

    @ColumnInfo(name = "drawDate")
    val drawDate: String?,

    @ColumnInfo(name = "announceDate")
    val announceDate: String?,

    @ColumnInfo(name = "minSpend")
    val minSpend: String?,

    @ColumnInfo(name = "totalGiftValue")
    val totalGiftValue: String?,

    @ColumnInfo(name = "totalGiftCount")
    val totalGiftCount: String?,

    @ColumnInfo(name = "desc")
    val desc: String?
)
