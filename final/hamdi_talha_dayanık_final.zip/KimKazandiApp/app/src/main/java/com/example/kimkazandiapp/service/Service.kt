package com.example.kimkazandiapp.service

import android.content.Context
import android.util.Log
import com.example.kimkazandiapp.MainActivity
import com.example.kimkazandiapp.database.AppDatabase
import com.example.kimkazandiapp.models.Giveaway
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.select.Elements
import org.jsoup.select.Selector

class Service(context: Context) {

    val db = AppDatabase.getDatabase(context)

    fun fetchDataAndWriteToDatabase(category: String){
        var mainUrl = "https://www.kimkazandi.com/"
        val doc: Document = Jsoup.connect(mainUrl + "cekilisler/$category").timeout(10000).get()

        val mainDiv: Elements = doc.getElementsByClass("col-lg-12 col-sm-12 campDesc")

        for (item in mainDiv){
            val childDiv = item.getElementsByClass("col-sm-3 col-lg-3 item")
            for (i in childDiv){
                val link = mainUrl + i.select(".img").select("[href]").attr("href")
                val image = mainUrl + i.select(".img").select("[src]").attr("src")
                val title = i.select("h4").text()
                val cat = category
                val remainedTime = i.select("span").get(0).text()
                lateinit var startDate: String
                lateinit var endDate: String
                lateinit var drawDate: String
                lateinit var announceDate: String
                lateinit var minSpend: String
                lateinit var totalGiftValue: String
                lateinit var totalGiftCount: String
                var desc = ""

                val gDoc = Jsoup.connect(link).get()
                val mainDiv2 = gDoc.getElementsByClass("brandDesc")
                for (item2 in mainDiv2){
                    val childDiv2 = item2.getElementsByClass("kalanSure")
                    for (j in childDiv2){
                        val label = j.select("h4").select("label").text()
                        when(label){
                            "Başlangıç Tarihi :" -> startDate = j.select("h4").text().substringAfterLast(" ")
                            "Son Katılım Tarihi :" -> endDate = j.select("h4").text().substringAfterLast(" ")
                            "Çekiliş Tarihi :" -> drawDate = j.select("h4").text().substringAfterLast(" ")
                            "İlan Tarihi :" -> announceDate = j.select("h4").text().substringAfterLast(" ")
                            "Min. Harcama Tutarı :" -> minSpend = j.select("h4").text().substringAfter(":").substringAfter(" ")
                            "Toplam Hediye Değeri :" -> totalGiftValue = j.select("h4").text().substringAfter(":").substringAfter(" ")
                            "Toplam Hediye Sayısı :" -> totalGiftCount = j.select("h4").text().substringAfterLast(" ")
                        }
                    }
                }

                val descDiv = gDoc.getElementsByClass("scrollbar-dynamic")
                desc += "\n \n ${descDiv[0].select("h2").text()}"
                for(k in descDiv[0].select("p")){
                    desc += "\n \n ${k.text()}"
                }
                val descDiv2 = gDoc.getElementsByClass("secondGallery")
                desc += "\n" + descDiv2[0].wholeText().trimStart()



                val list = db.giveawayDao().searchByTitle(title)
                if(list.isEmpty() && cat.isNotEmpty()){
                    val catList = cat
                    val giveaway = Giveaway(null, link, "false", "false", remainedTime, title, catList, image, startDate, endDate, drawDate, announceDate, minSpend, totalGiftValue, totalGiftCount, desc)
                    db.giveawayDao().insertGiveaway(giveaway)
                }else if (list.isNotEmpty() && cat.isNotEmpty()){
                    val catList = list[0].category + ", $cat"
                    val giveaway = Giveaway(list[0].id, link, list[0].followed, "false", remainedTime, title, catList, image, startDate, endDate, drawDate, announceDate, minSpend, totalGiftValue, totalGiftCount, desc)
                    db.giveawayDao().updateGiveaway(giveaway)
                }else if(list.isNotEmpty() && cat.isEmpty()){
                    val giveaway = Giveaway(list[0].id, link, list[0].followed, "true", remainedTime, title, list[0].category, image, startDate, endDate, drawDate, announceDate, minSpend, totalGiftValue, totalGiftCount, desc)
                    db.giveawayDao().updateGiveaway(giveaway)
                }else if(list.isEmpty() && cat.isEmpty()){
                    val catList = ""
                    val giveaway = Giveaway(null, link, "false", "true", remainedTime, title, catList, image, startDate, endDate, drawDate, announceDate, minSpend, totalGiftValue, totalGiftCount, desc)
                    db.giveawayDao().insertGiveaway(giveaway)
                }
            }
        }


    }

}