package com.example.kimkazandiapp.ui.tatil_kazan

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.example.contactsapp.adapters.GiveawayAdapter
import com.example.kimkazandiapp.DetailsActivity
import com.example.kimkazandiapp.MainActivity
import com.example.kimkazandiapp.database.AppDatabase
import com.example.kimkazandiapp.databinding.FragmentTatilKazanBinding
import com.example.kimkazandiapp.models.Giveaway
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TatilKazan : Fragment() {

    private var _binding: FragmentTatilKazanBinding? = null
    private val binding get() = _binding!!

    var giveawayList: MutableList<Giveaway> = mutableListOf()
    lateinit var db: AppDatabase

    companion object {
        fun newInstance() = TatilKazan()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTatilKazanBinding.inflate(inflater, container, false)
        val view = binding.root

        binding.list.setOnItemClickListener { parent, view, position, id ->
            MainActivity.selectedGiveaway = giveawayList[position]
            val i = Intent(requireContext(), DetailsActivity::class.java)
            startActivity(i)
        }

        return view
    }

    override fun onStart() {
        super.onStart()
        db = AppDatabase.getDatabase(requireContext())

        val giveawayAdapter = GiveawayAdapter(requireContext(), giveawayList)
        binding.list.adapter = giveawayAdapter

        (requireContext() as LifecycleOwner).lifecycleScope.launch {
            giveawayList = getData() as MutableList<Giveaway>
            giveawayAdapter.updateGiveawayList(giveawayList)
        }
    }

    suspend fun getData() = withContext(Dispatchers.IO){
        db.giveawayDao().getLastEightByCategory("tatil-kazan")
    }

}