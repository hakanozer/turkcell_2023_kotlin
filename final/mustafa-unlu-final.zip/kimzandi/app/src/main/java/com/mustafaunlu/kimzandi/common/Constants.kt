package com.mustafaunlu.kimzandi.common

object Constants {
    private const val BASE_URL = "https://www.kimkazandi.com"
    const val HOME_URL = "$BASE_URL/cekilisler"
    const val YENI_BSL_URL = "$HOME_URL/yeni-baslayanlar"
    const val BDV_KTLM_URL = "$HOME_URL/bedava-katilim"
    const val ARABA_KZN_URL = "$HOME_URL/araba-kazan"
    const val TLF_TBLT_KZN_URL = "$HOME_URL/telefon-tablet-kazan"
    const val TATIL_URL = "$HOME_URL/tatil-kazan"
    const val SHARED_PREF_FILE_NAME = "userData"
    const val SHARED_PREF_IS_FIRST_KEY = "isFirstLogin"
}
