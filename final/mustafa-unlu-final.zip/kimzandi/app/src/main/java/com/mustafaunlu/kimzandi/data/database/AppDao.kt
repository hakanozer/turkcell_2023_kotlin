package com.mustafaunlu.kimzandi.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya

@Dao
interface AppDao {
    @Insert(entity = Kampanya::class, onConflict = OnConflictStrategy.REPLACE)
    fun insertKampanya(kampanya: List<Kampanya>)

    @Query("SELECT * FROM kampanya WHERE header = :header")
    fun getKampanyaList(header: String): List<Kampanya>

    @Delete(entity = Kampanya::class)
    fun deleteKampanya(kampanya: List<Kampanya>)

    @Query("SELECT * FROM kampanya WHERE timestamp < :expiryTime")
    fun getExpiredData(expiryTime: Long): List<Kampanya>

    @Insert(entity = TakipKampanya::class, onConflict = OnConflictStrategy.REPLACE)
    fun insertTakipKampanya(kampanya: TakipKampanya)

    @Query("SELECT * FROM takip")
    fun getTakipKampanyaList(): List<TakipKampanya>

    @Delete(entity = TakipKampanya::class)
    fun deleteTakipKampanya(kampanya: TakipKampanya)
}
