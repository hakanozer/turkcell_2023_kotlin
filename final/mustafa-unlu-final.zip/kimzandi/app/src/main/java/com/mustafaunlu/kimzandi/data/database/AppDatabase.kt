package com.mustafaunlu.kimzandi.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya

@Database(entities = [Kampanya::class, TakipKampanya::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao
}
