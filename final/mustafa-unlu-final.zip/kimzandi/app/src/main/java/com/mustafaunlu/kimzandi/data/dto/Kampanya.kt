package com.mustafaunlu.kimzandi.data.dto

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "kampanya")
data class Kampanya(
    @PrimaryKey(autoGenerate = true)
    val id: Int? = null,
    val header: String,
    val timestamp: Long,
    val title: String,
    val duration: String,
    val giftAmount: String,
    val price: String,
    val imgUrl: String,
    val itemUrl: String,
) : Parcelable
