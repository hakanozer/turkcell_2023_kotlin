package com.mustafaunlu.kimzandi.data.dto

data class KampanyaDetay(
    val description: String,
    val tableData: Map<String, String>,
)
