package com.mustafaunlu.kimzandi.data.dto

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "takip")
data class TakipKampanya(
    @PrimaryKey(autoGenerate = true)
    val id: Int? = null,
    val title: String,
    val duration: String,
    val giftAmount: String,
    val price: String,
    val imgUrl: String,
    var isFollowed: Boolean,
)
