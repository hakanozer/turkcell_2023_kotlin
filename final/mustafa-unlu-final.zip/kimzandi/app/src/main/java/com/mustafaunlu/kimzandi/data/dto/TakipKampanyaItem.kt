package com.mustafaunlu.kimzandi.data.dto

data class TakipKampanyaItem(
    val takipKampanya: TakipKampanya,
    var isFollowed: Boolean,
)
