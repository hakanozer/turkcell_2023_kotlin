package com.mustafaunlu.kimzandi.data.repository

import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.data.dto.KampanyaDetay
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya

interface Repository {
    fun fetchKampanyaList(baseUrl: String): List<Kampanya>

    fun fetchDetailItem(itemUrl: String): KampanyaDetay?

    fun insertKampanya(kampanya: List<Kampanya>)

    fun getKampanyaList(header: String): List<Kampanya>

    fun deleteKampanya(kampanya: List<Kampanya>)

    fun isKampanyaTimeExpired(): Boolean

    fun fetchTakipKampanyaList(): List<TakipKampanya>

    fun insertTakipKampanya(kampanya: TakipKampanya)

    fun deleteTakipKampanya(kampanya: TakipKampanya)
}
