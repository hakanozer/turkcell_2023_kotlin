package com.mustafaunlu.kimzandi.data.repository

import android.util.Log
import com.mustafaunlu.kimzandi.data.database.AppDao
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.data.dto.KampanyaDetay
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import javax.inject.Inject

class RepositoryImp @Inject constructor(
    private val appDao: AppDao,
) : Repository {
    override fun fetchKampanyaList(baseUrl: String): List<Kampanya> {
        val kampanyalar = ArrayList<Kampanya>()
        try {
            val document = runBlocking(Dispatchers.IO) {
                Jsoup.connect(baseUrl).timeout(10000).get()
            }
            val rows = document.select("div.row > div.col-sm-3.col-lg-3.item")

            for (row in rows) {
                val imageElement = row.select("img[src]").first()
                val imageUrl = imageElement?.absUrl("src")

                val title = row.select("h4").text()
                val duration = row.select("span.date:nth-child(1)").text()
                val giftAmount = row.select("span.date:nth-child(2)").text()
                val price = row.select("span.date.kosul_fiyat").text()

                val itemElement = row.select("a").first()
                val itemUrl = itemElement?.absUrl("href")

                val divElement = document.select("div.green h4").first()
                val header = divElement?.text()

                if (imageUrl.isNullOrEmpty() && title.isNullOrEmpty() && duration.isNullOrEmpty() && giftAmount.isNullOrEmpty() && price.isNullOrEmpty() && itemUrl.isNullOrEmpty()) {
                    continue
                } else {
                    val kampanya = Kampanya(
                        null,
                        header!!.split(" ")[0],
                        System.currentTimeMillis(),
                        title,
                        duration,
                        giftAmount,
                        price,
                        imageUrl!!,
                        itemUrl ?: "",
                    )
                    kampanyalar.add(kampanya)
                }
            }
        } catch (e: Exception) {
            Log.e("RepositoryImp", "fetchKampanyaList: ", e)
        }
        deleteKampanya(kampanyalar)
        insertKampanya(kampanyalar)
        return kampanyalar
    }

    override fun fetchDetailItem(itemUrl: String): KampanyaDetay? {
        try {
            val document = runBlocking(Dispatchers.IO) {
                Jsoup.connect(itemUrl).timeout(10000).get()
            }

            // Description almak için gerekli HTML elementini seçin
            val descriptionElements =
                document.select("div.secondGallery > div.tab-content > div#home > div.scrollbar-dynamic")
            val descriptions = descriptionElements.map { it.text() }
            val descriptionString = descriptions.joinToString(separator = "\n\n")

            // Tablo verilerini almak için gerekli HTML elementini seçin
            val tableElement = document.select("div.brandDesc")
            val tableData = mutableMapOf<String, String>()

            // Tablo verilerini dolaşarak key-value çiftlerini ekleyin
            tableElement.select("div.kalanSure").forEach { dataElement ->
                val label = dataElement.select("label").text()
                val value = dataElement.select("h4").text()
                tableData[label] = value
            }

            return KampanyaDetay(descriptionString, tableData)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return null
    }

    override fun insertKampanya(kampanya: List<Kampanya>) {
        appDao.insertKampanya(kampanya)
    }

    override fun getKampanyaList(header: String): List<Kampanya> {
        return appDao.getKampanyaList(header)
    }

    override fun deleteKampanya(kampanya: List<Kampanya>) {
        appDao.deleteKampanya(kampanya)
    }

    override fun isKampanyaTimeExpired(): Boolean {
        val expiryTime = System.currentTimeMillis() - (3 * 60 * 60 * 1000)
        return appDao.getExpiredData(expiryTime).isNotEmpty()
    }

    override fun fetchTakipKampanyaList(): List<TakipKampanya> {
        return appDao.getTakipKampanyaList()
    }

    override fun insertTakipKampanya(kampanya: TakipKampanya) {
        appDao.insertTakipKampanya(kampanya)
    }

    override fun deleteTakipKampanya(kampanya: TakipKampanya) {
        appDao.deleteTakipKampanya(kampanya)
    }
}
