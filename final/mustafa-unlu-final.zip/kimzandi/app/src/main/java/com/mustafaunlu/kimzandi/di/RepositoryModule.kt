package com.mustafaunlu.kimzandi.di

import com.mustafaunlu.kimzandi.data.repository.Repository
import com.mustafaunlu.kimzandi.data.repository.RepositoryImp
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped

@Module
@InstallIn(ViewModelComponent::class)
abstract class RepositoryModule {

    @Binds
    @ViewModelScoped
    abstract fun bindRepository(
        repository: RepositoryImp,
    ): Repository
}
