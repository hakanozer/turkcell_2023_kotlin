package com.mustafaunlu.kimzandi.ui.araba_kazan

import androidx.navigation.NavDirections
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.ui.base.BaseFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ArabaKazanFragment() : BaseFragment() {

    override val header: String = "Araba"
    override fun createDetailAction(item: Kampanya): NavDirections {
        return ArabaKazanFragmentDirections.actionNavArabaKazanToCekilislerDetailFragment(item)
    }
}
