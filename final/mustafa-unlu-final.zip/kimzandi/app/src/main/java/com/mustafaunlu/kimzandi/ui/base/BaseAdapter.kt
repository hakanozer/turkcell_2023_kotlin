package com.mustafaunlu.kimzandi.ui.base

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.databinding.CekilislerItemBinding
import com.mustafaunlu.kimzandi.utils.loadImage

class BaseAdapter(private val kampanyaList: List<Kampanya>, private val onItemClicked: (Kampanya) -> Unit) : RecyclerView.Adapter<BaseAdapter.CekilislerViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): CekilislerViewHolder {
        val binding = CekilislerItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CekilislerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CekilislerViewHolder, position: Int) {
        holder.bind(kampanyaList[position])
    }

    override fun getItemCount(): Int {
        return kampanyaList.size
    }

    inner class CekilislerViewHolder(private val binding: CekilislerItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(kampanya: Kampanya) {
            binding.apply {
                if (kampanya.duration.isNullOrBlank() || kampanya.price.isNullOrBlank() || kampanya.imgUrl.isNullOrBlank() || kampanya.title.isNullOrBlank() || kampanya.giftAmount.isNullOrBlank()) {
                    return@apply
                } else {
                    kampanyaTitle.text = kampanya.title
                    itemDuration.text = kampanya.duration
                    itemGift.text = kampanya.giftAmount
                    itemPrice.text = kampanya.price
                    kampanyaImg.loadImage(kampanya.imgUrl)
                }
            }
            binding.root.setOnClickListener { onItemClicked(kampanya) }
        }
    }
}
