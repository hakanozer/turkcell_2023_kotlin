package com.mustafaunlu.kimzandi.ui.base

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavDirections
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.kimzandi.common.NetworkResponseState
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.databinding.FragmentBaseBinding
import com.mustafaunlu.kimzandi.utils.gone
import com.mustafaunlu.kimzandi.utils.showToast
import com.mustafaunlu.kimzandi.utils.visible
import com.mustafaunlu.kimzandi.viewmodel.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
abstract class BaseFragment : Fragment() {

    private val viewModel: SharedViewModel by activityViewModels()
    protected lateinit var binding: FragmentBaseBinding

    protected abstract val header: String

    @Inject
    lateinit var sharedPref: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentBaseBinding.inflate(inflater, container, false)
        viewModel.fetchKampanyaList(header)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.kampanyalar.observe(viewLifecycleOwner) {
            when (it) {
                is NetworkResponseState.Success -> {
                    binding.cekilislerProgress.gone()
                    binding.cekilislerRv.adapter = BaseAdapter(it.result, ::onItemClicked)
                }

                NetworkResponseState.Loading -> binding.cekilislerProgress.visible()
                is NetworkResponseState.Error -> {
                    binding.cekilislerProgress.gone()
                    requireView().showToast(it.exception.message!!)
                }
            }
        }
    }

    private fun onItemClicked(item: Kampanya) {
        val action = createDetailAction(item)
        findNavController().navigate(action)
    }

    protected abstract fun createDetailAction(item: Kampanya): NavDirections
}
