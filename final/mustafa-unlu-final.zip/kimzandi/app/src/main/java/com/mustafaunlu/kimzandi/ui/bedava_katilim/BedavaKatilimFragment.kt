package com.mustafaunlu.kimzandi.ui.bedava_katilim

import androidx.navigation.NavDirections
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.ui.base.BaseFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BedavaKatilimFragment() : BaseFragment() {
    override val header: String = "Bedava"

    override fun createDetailAction(item: Kampanya): NavDirections {
        return BedavaKatilimFragmentDirections.actionNavBedavaKatilimToCekilislerDetailFragment(item)
    }
}
