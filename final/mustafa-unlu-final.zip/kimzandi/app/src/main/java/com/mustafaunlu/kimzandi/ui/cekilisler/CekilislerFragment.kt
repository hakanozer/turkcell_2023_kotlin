package com.mustafaunlu.kimzandi.ui.cekilisler

import androidx.navigation.NavDirections
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.ui.base.BaseFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CekilislerFragment() : BaseFragment() {

    override val header: String = "Tüm"

    override fun createDetailAction(item: Kampanya): NavDirections {
        return CekilislerFragmentDirections.actionCekilislerFragmentToCekilislerDetailFragment(item)
    }
}
