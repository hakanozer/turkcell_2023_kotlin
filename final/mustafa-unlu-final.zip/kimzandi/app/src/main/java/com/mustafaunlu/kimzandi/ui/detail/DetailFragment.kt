package com.mustafaunlu.kimzandi.ui.detail

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.navArgs
import com.mustafaunlu.kimzandi.R
import com.mustafaunlu.kimzandi.common.NetworkResponseState
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya
import com.mustafaunlu.kimzandi.data.dto.TakipKampanyaItem
import com.mustafaunlu.kimzandi.databinding.FragmentCekilislerDetailBinding
import com.mustafaunlu.kimzandi.utils.gone
import com.mustafaunlu.kimzandi.utils.loadImage
import com.mustafaunlu.kimzandi.utils.showToast
import com.mustafaunlu.kimzandi.utils.visible
import com.mustafaunlu.kimzandi.viewmodel.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class DetailFragment : Fragment() {
    private lateinit var binding: FragmentCekilislerDetailBinding

    @Inject
    lateinit var sharedPref: SharedPreferences

    private val viewModel: SharedViewModel by activityViewModels()
    private val args: DetailFragmentArgs by navArgs()
    private lateinit var takipKampanyaItem: TakipKampanyaItem

    private val valueTextViewList = mutableListOf<TextView>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentCekilislerDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeKampanyaDetay()
        takipKampanyaItem = TakipKampanyaItem(
            TakipKampanya(
                args.item.id,
                args.item.title,
                args.item.duration,
                args.item.giftAmount,
                args.item.price,
                args.item.imgUrl,
                sharedPref.getBoolean(args.item.id.toString(), false),
            ),
            false,
        )
        updateFollowButton()

        binding.detailFollowBtn.setOnClickListener {
            val isFollowed = !takipKampanyaItem.isFollowed
            takipKampanyaItem.isFollowed = isFollowed

            if (isFollowed) {
                viewModel.insertTakipKampanya(takipKampanyaItem.takipKampanya)
                sharedPref.edit().putBoolean(args.item.id.toString(), true).apply()
            } else {
                viewModel.deleteTakipKampanya(takipKampanyaItem.takipKampanya)
                sharedPref.edit().putBoolean(args.item.id.toString(), false).apply()
            }
            updateFollowButton()
        }
    }

    override fun onResume() {
        super.onResume()
        updateFollowButton()
    }

    private fun setupUI() {
        binding.apply {
            detailDescription.text = args.item.title
            detailImg.loadImage(args.item.imgUrl)
            valueTextViewList.addAll(
                listOf(
                    value1,
                    value2,
                    value3,
                    value4,
                    value5,
                    value6,
                    value7,
                ),
            )
        }
    }

    private fun observeKampanyaDetay() {
        viewModel.kampanyaDetay.observe(viewLifecycleOwner) { response ->
            when (response) {
                is NetworkResponseState.Success -> {
                    binding.progress.gone()
                    binding.detailDescription.text = response.result.description
                    val valueList = response.result.tableData.values.toList()

                    for (i in response.result.tableData.values.indices) {
                        if (i < valueTextViewList.size) {
                            valueTextViewList[i].text = valueList[i]
                        }
                    }
                }

                NetworkResponseState.Loading -> binding.progress.visible()
                is NetworkResponseState.Error -> {
                    binding.progress.gone()
                    requireView().showToast(response.exception.toString())
                }
            }
        }
        viewModel.fetchDetailItem(args.item.itemUrl)
    }

    private fun updateFollowButton() {
        val isFollowed = sharedPref.getBoolean(args.item.id.toString(), false)
        takipKampanyaItem.takipKampanya.isFollowed = isFollowed
        binding.detailFollowBtn.text = if (isFollowed) {
            getString(R.string.takip_ediliyor)
        } else {
            getString(R.string.takip_et)
        }
    }
}
