package com.mustafaunlu.kimzandi.ui.takip_ettiklerim

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.kimzandi.common.NetworkResponseState
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.databinding.FragmentTakipEttiklerimBinding
import com.mustafaunlu.kimzandi.ui.base.BaseAdapter
import com.mustafaunlu.kimzandi.utils.showToast
import com.mustafaunlu.kimzandi.utils.toKampanya
import com.mustafaunlu.kimzandi.viewmodel.SharedViewModel

class TakipEttiklerimFragment : Fragment() {
    private val viewModel: SharedViewModel by activityViewModels()
    private lateinit var binding: FragmentTakipEttiklerimBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentTakipEttiklerimBinding.inflate(inflater, container, false)
        viewModel.fetchTakipKampanyaList()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.kampanyaTakip.observe(viewLifecycleOwner) {
            when (it) {
                is NetworkResponseState.Success -> {
                    val list = ArrayList<Kampanya>()
                    it.result.forEach { takipKampanya ->
                        list.add(takipKampanya.toKampanya())
                    }
                    binding.recyclerView.adapter = BaseAdapter(list, ::onItemClicked)
                }
                NetworkResponseState.Loading -> Unit
                is NetworkResponseState.Error -> requireView().showToast(it.exception.toString())
            }
        }
    }
    private fun onItemClicked(item: Kampanya) {
        val action = TakipEttiklerimFragmentDirections.actionNavTakipEttiklerimToDetailFragment(item)
        findNavController().navigate(action)
    }
}
