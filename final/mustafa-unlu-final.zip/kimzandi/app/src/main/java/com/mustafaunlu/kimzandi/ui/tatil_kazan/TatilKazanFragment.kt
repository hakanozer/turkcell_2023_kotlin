package com.mustafaunlu.kimzandi.ui.tatil_kazan

import androidx.navigation.NavDirections
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.ui.base.BaseFragment

class TatilKazanFragment : BaseFragment() {

    override val header: String = "Tatil"

    override fun createDetailAction(item: Kampanya): NavDirections {
        return TatilKazanFragmentDirections.actionNavTatilKazanToCekilislerDetailFragment(item)
    }
}
