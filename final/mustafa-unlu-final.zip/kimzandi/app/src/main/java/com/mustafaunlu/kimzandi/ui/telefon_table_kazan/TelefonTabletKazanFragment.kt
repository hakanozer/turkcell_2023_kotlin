package com.mustafaunlu.kimzandi.ui.telefon_table_kazan

import androidx.navigation.NavDirections
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.ui.base.BaseFragment

class TelefonTabletKazanFragment : BaseFragment() {

    override val header: String = "Telefon"

    override fun createDetailAction(item: Kampanya): NavDirections {
        return TelefonTabletKazanFragmentDirections.actionNavTelefonTabletKazanToCekilislerDetailFragment(
            item,
        )
    }
}
