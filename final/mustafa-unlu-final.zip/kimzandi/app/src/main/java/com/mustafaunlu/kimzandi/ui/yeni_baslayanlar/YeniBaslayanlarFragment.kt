package com.mustafaunlu.kimzandi.ui.yeni_baslayanlar

import androidx.navigation.NavDirections
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.ui.base.BaseFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class YeniBaslayanlarFragment : BaseFragment() {
    override val header: String = "Yeni"

    override fun createDetailAction(item: Kampanya): NavDirections {
        return YeniBaslayanlarFragmentDirections.actionNavYeniBaslayanlarToCekilislerDetailFragment(
            item,
        )
    }
}
