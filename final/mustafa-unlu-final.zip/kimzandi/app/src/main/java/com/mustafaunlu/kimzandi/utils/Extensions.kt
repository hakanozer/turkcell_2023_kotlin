package com.mustafaunlu.kimzandi.utils

import android.view.View
import android.widget.ImageView
import android.widget.Toast
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya
import com.mustafaunlu.kimzandi.di.GlideApp

fun ImageView.loadImage(url: String) {
    GlideApp.with(this.context)
        .load(url)
        .into(this)
}

fun View.visible() {
    visibility = View.VISIBLE
}

fun View.gone() {
    visibility = View.GONE
}

fun View.showToast(text: String) = Toast.makeText(this.context, text, Toast.LENGTH_SHORT).show()

fun TakipKampanya.toKampanya() = Kampanya(
    id = this.id,
    header = "",
    timestamp = 0L,
    title = this.title,
    duration = this.duration,
    giftAmount = this.giftAmount,
    price = this.price,
    imgUrl = this.imgUrl,
    itemUrl = "",
)
