package com.mustafaunlu.kimzandi.viewmodel

import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.kimzandi.common.Constants
import com.mustafaunlu.kimzandi.common.NetworkResponseState
import com.mustafaunlu.kimzandi.data.dto.Kampanya
import com.mustafaunlu.kimzandi.data.dto.KampanyaDetay
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya
import com.mustafaunlu.kimzandi.data.repository.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SharedViewModel @Inject constructor(
    private val repository: Repository,
    private val sharedPreferences: SharedPreferences,
) : ViewModel() {
    private val _kampanyalar = MutableLiveData<NetworkResponseState<List<Kampanya>>>()
    val kampanyalar: LiveData<NetworkResponseState<List<Kampanya>>> get() = _kampanyalar

    private val _kampanyaDetay = MutableLiveData<NetworkResponseState<KampanyaDetay>>()
    val kampanyaDetay: LiveData<NetworkResponseState<KampanyaDetay>> get() = _kampanyaDetay

    private val _kampanyaTakip = MutableLiveData<NetworkResponseState<List<TakipKampanya>>>()
    val kampanyaTakip: LiveData<NetworkResponseState<List<TakipKampanya>>> get() = _kampanyaTakip

    fun fetchKampanyaList(header: String) {
        val urlList = listOf(
            Constants.HOME_URL,
            Constants.YENI_BSL_URL,
            Constants.BDV_KTLM_URL,
            Constants.ARABA_KZN_URL,
            Constants.TLF_TBLT_KZN_URL,
            Constants.TATIL_URL,
        )
        viewModelScope.launch(Dispatchers.IO) {
            if (isKampanyaTimeExpired() || checkFirstLogin()) {
                for (baseUrl in urlList) {
                    repository.fetchKampanyaList(baseUrl)
                }
                val kampanyaList = repository.getKampanyaList(header)
                _kampanyalar.postValue(NetworkResponseState.Success(kampanyaList))
                sharedPreferences.edit().putBoolean(Constants.SHARED_PREF_IS_FIRST_KEY, false)
                    .apply()
                Log.d("SharedViewModel", "fetchKampanyaList from server: " + kampanyaList.size)
            } else {
                val kampanyaList = repository.getKampanyaList(header)
                _kampanyalar.postValue(NetworkResponseState.Success(kampanyaList))
                Log.d("SharedViewModel", "fetchKampanyaList from db: " + kampanyaList.size)
            }
        }
    }

    fun isKampanyaTimeExpired(): Boolean {
        return repository.isKampanyaTimeExpired()
    }

    fun fetchDetailItem(itemUrl: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val kampanyaDetay = repository.fetchDetailItem(itemUrl)
            _kampanyaDetay.postValue(NetworkResponseState.Success(kampanyaDetay ?: return@launch))
        }
    }

    private fun checkFirstLogin(): Boolean {
        return sharedPreferences.getBoolean(Constants.SHARED_PREF_IS_FIRST_KEY, true)
    }

    fun fetchTakipKampanyaList() {
        viewModelScope.launch(Dispatchers.IO) {
            val takipKampanyaList = repository.fetchTakipKampanyaList()
            if (isKampanyaTimeExpired()) {
                for (takipKampanya in takipKampanyaList) {
                    deleteTakipKampanya(takipKampanya)
                }
            } else {
                _kampanyaTakip.postValue(NetworkResponseState.Success(takipKampanyaList))
            }
        }
    }

    fun insertTakipKampanya(takipKampanya: TakipKampanya) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertTakipKampanya(takipKampanya)
        }
    }

    fun deleteTakipKampanya(takipKampanya: TakipKampanya) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTakipKampanya(takipKampanya)
        }
    }
}
