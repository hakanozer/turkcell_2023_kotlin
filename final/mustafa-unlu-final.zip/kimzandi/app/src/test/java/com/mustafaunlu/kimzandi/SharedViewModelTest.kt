package com.mustafaunlu.kimzandi

import android.content.SharedPreferences
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.mustafaunlu.kimzandi.data.dto.TakipKampanya
import com.mustafaunlu.kimzandi.data.repository.Repository
import com.mustafaunlu.kimzandi.viewmodel.SharedViewModel
import io.mockk.Runs
import io.mockk.clearAllMocks
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.verify
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.TestCoroutineScope
import kotlinx.coroutines.test.runBlockingTest
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@ExperimentalCoroutinesApi
class SharedViewModelTest {

    // Test senaryolarında asenkron işlemleri yönetmek için TestCoroutineDispatcher kullanacağız.
    private val testDispatcher = TestCoroutineDispatcher()

    // Test senaryolarında ViewModel'in asenkron işlemleri gerçekleştirebilmesi için TestCoroutineScope kullanacağız.
    private val testScope = TestCoroutineScope(testDispatcher)

    // ViewModel testlerinde LiveData'nın anında çalışabilmesi için bu kuralı eklememiz gerekiyor.
    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    // Repository'yi ve SharedPreferences'i taklit etmek için Mockk kullanacağız.
    private val repository = mockk<Repository>()
    private val sharedPreferences = mockk<SharedPreferences>()

    // Test edilecek ViewModel
    private lateinit var viewModel: SharedViewModel

    @Before
    fun setup() {
        // Mockk'u kullanarak repository ve sharedPreferences bağımlılıklarını ViewModel'e enjekte ediyoruz.
        viewModel = SharedViewModel(repository, sharedPreferences)
    }

    @After
    fun cleanup() {
        // Testlerin sonunda kullanılan kaynakları temizliyoruz.
        testScope.cleanupTestCoroutines()
        clearAllMocks()
    }

    @Test
    fun `fetchTakipKampanyaList should delete expired takip kampanyalar when kampanya time is expired`() =
        testScope.runBlockingTest {
            // Mockk'u kullanarak gerekli dönüş değerlerini ve davranışları ayarlıyoruz.
            val expiredTakipKampanyalar = listOf(
                TakipKampanya(1, "Kampanya 1", "1", "3", "23.99", "", false),
                TakipKampanya(2, "Kampanya 2", "1", "3", "23.99", "", false),
            )
            every { repository.fetchTakipKampanyaList() } returns expiredTakipKampanyalar
            every { repository.isKampanyaTimeExpired() } returns true
            every { repository.deleteTakipKampanya(any()) } just Runs

            // ViewModel'in fetchTakipKampanyaList işlevini çağırıyoruz.
            viewModel.fetchTakipKampanyaList()

            // ViewModel'in asenkron işlemleri tamamlamasını bekliyoruz.
            testScheduler.apply { advanceTimeBy(1000); runCurrent() }

            // Silme işleminin doğru şekilde çağrıldığını kontrol ediyoruz.
            verify(exactly = expiredTakipKampanyalar.size) { repository.deleteTakipKampanya(any()) }
        }
}

