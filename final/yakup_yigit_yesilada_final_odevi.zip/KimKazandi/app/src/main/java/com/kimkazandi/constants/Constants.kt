package com.kimkazandi.constants

class Constants {
    companion object{
        const val BASE_URL = "https://kimkazandi.com/"
        const val RAFFLES_URL = "${BASE_URL}cekilisler/"
        const val RAFFLE_DETAIL_URL = "${BASE_URL}kampanya/"
    }
}