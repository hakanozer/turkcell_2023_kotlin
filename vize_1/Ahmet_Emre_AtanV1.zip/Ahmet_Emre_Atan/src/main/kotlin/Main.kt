fun main(args: Array<String>) {

/*
        /* SORU 1 */
        print("3 haneli bir sayı girin: ")
        val sayi = readLine()!!.toInt()

        val ilkbasamak = sayi % 10
        val ikincibasamak = (sayi / 10) % 10
        val ucuncubasamak = sayi / 100

        val toplam = ilkbasamak + ikincibasamak + ucuncubasamak

        println("Basamaklar toplamuı: $toplam")


        /* SORU 2 */

        print("3 haneli bir sayı girin: ")
        val sayi1 = readLine()!!.toInt()

        val basamak1 = sayi1 % 10
        val basamak2 = (sayi1 / 10) % 10
        val basamak3 = sayi1 / 100

        println("Ters hali: $basamak1$basamak2$basamak3")

        /* SORU 3 */

        print("N değeri için sayı girin: ")
        val n = readLine()!!.toInt()

        var toplam1 = 0
        for (i in 1..n) {
                toplam1 += i * (i + 1)
        }

        println("1'den $n'e kadar olan serinin toplamı: $toplam1")
*/

        /* SORU 4 */

        println("1'den N'e kadar olan asal sayıların toplamını hesaplamak için N sayısını giriniz:")
        val nsayisi = readLine()!!.toInt()

        val sumOfAllPrimes = getSumOfAllPrimes(nsayisi)
        println("1'den $nsayisi'e kadar olan asal sayıların toplamı: $sumOfAllPrimes")



        /* SORU 5 */

        println(isPrime(7))



        /* SORU 6 */

        //Bu soruyu tam anlamadım hocam o yüzden çözemedim.


        /* SORU 7 */
        /*Class: Bir nesnenin tanımlanması için kullanılır.
        *Object: Tek bir örneği olan bir sınıfın özel bir türüdür.
        *Abstract :  Bir nesnenin tam olarak nasıl görünmesi gerektiğini belirler.
        *Interface : Belirli bir nesnenin davranışlarını belirleyen bir sözleşme görevi görür.
        * */


        /* SORU 8 */
        /*Bir sınıftaki üyelerin erişimini kontrol etmek için kullanılan anahtar kelimelerdir.*/




}


fun getSumOfAllPrimes(nsayisi: Int): Int {
        var sumOfPrimes = 0
        for (i in 1..nsayisi) {
                if (isPrime(i)) {
                        sumOfPrimes += i
                }
        }
        return sumOfPrimes
}



fun isPrime(number: Int): Boolean {
        if (number <= 1) {
                return false
        }
        for (i in 2 until number) {
                if (number % i == 0) {
                        return false
                }
        }
        return true
}