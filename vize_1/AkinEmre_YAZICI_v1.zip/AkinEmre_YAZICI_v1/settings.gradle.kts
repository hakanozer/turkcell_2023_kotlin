
rootProject.name = "AkinEmre_YAZICI_v1"

