package Question6

interface IQuestion6
{
    fun memurMaas (saat : Int) : Double// sabit 1000 + 0.3 katsayılı

    fun mudurMaas (saat : Int) : Double // sabit 3000 + 0.6 katsayalı

    fun genelMudurMaas (saat : Int) : Double// sabit 5000 + 0.8 katsayılı
}