class Question7
{
    //Class
    /*
                Nesne oluşturabildiğimiz içinde standartlar(değişkenler), işlevler (fonksiyonlar) ekleyebildiğimiz
                yapılardır.Constructor kullanarak kendilerine değerler girebilir onları kaydedebiliriz. Bir insan
                classımız olduğunu düşünelim .Ona string türünde isim, int türünde yaş değerleri gibi standartlar
                vererek bunları tekrar tekrar oluşturabiliriz.

    */
    //Object
    /*

            Classdan farkı olarak bir kez oluşturabildiğimiz ve uygulama boyunca açık kalan nesnelerdir.

     */
    //Abstract
    /*


            Eksik , yarım bırakılmış sınıfları soyutlandırmak için kullanılır. Burada sınıfı oluşturdum
         ama daha sonrasında bunu tamamlayacağım gibi bunu başka bir sınıfa miras edindiğimizde bulunan tüm
         metodları override etmek zorundayız.




    */
    //Interface
    /*


            Interface bizim önceden yapacağımız fonksiyonların neler döndüreceğini hangi parametlerini alacağını
        belirttiğimiz bir şablondur. Kendileri gövdesinde işlevler bulunmaz sadece fonksiyonların ön bilgilendirmesi
        gibidir.Daha akıcı ve düzenli bir kod düzenimizin olması ve başkalarının kodumuzu okurken anlayabilmesi için
        önemlidir.


     */
}