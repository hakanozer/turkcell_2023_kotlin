package soru2

interface TerstenYazdir {
    fun sayiTerstenYazdir(sayi: Int)
}