package soru6

class GenelMudur : Personel(5000, 0.8)