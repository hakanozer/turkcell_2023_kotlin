package soru6

class Memur : Personel(1000, 0.3)