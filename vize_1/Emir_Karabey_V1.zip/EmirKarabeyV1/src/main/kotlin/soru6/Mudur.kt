package soru6

class Mudur : Personel(3000, 0.6)