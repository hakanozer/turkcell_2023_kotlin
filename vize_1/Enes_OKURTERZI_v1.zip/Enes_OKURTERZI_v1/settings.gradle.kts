
rootProject.name = "Enes_OKURTERZI_v1"

