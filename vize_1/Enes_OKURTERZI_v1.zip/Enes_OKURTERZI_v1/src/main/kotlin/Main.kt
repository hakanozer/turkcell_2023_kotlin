import questionSix.GenelMudur
import questionSix.Memur
import questionSix.Mudur

fun main(args: Array<String>) {
    val questionOne = QuestionOne(123)
    questionOne.sumAllDigit()

    val questionTwo = QuestionTwo(456)
    questionTwo.printReverse()

    val questionThree = QuestionThree(4)
    questionThree.factorialLooking()

    val questionFour = QuestionFour(10)
    questionFour.getSumOfAllPrimes()

    val questionFive = QuestionFive()
    println(questionFive.isPrime(9))

    val questionSixMemur = Memur()
    questionSixMemur.calculateSalary(10)

    val questionSixMudur = Mudur()
    questionSixMudur.calculateSalary(10)

    val questionSixGenelMudur = GenelMudur()
    questionSixGenelMudur.calculateSalary(10)


}