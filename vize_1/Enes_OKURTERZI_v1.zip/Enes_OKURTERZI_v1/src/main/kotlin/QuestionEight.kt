class QuestionEight {
    /*
    Erişim belirteçleri : Public, private, protected ve internal gibi başına geldikleri class, fonksiyon ya da değişkenlerin görünürlüklerini etkileyen anahtar kelimelerdir.
    Public : Proje içerisindeki her birimden erişime izin verir. Hiçbir belirteç yazılmadığı takdirde default olarak gelir.
    Private : Proje içerisinde sadece bulunduğu class'da erişime izin verir.
    Protected : İnheritance olan classlarda erişime izin verir.
    Internal : Sadece eklendiği modül içerisinde ulaşım sağlamaya izin verir.
     */
}