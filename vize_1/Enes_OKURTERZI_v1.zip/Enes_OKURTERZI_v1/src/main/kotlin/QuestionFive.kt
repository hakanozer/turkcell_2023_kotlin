class QuestionFive(val defaultInt: Int = 1): QuestionFour(defaultInt) {

}