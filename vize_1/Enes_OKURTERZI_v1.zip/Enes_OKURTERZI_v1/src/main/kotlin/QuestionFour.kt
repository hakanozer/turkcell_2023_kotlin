open class QuestionFour(val givenNumber: Int) {
    private var result = 0
    fun getSumOfAllPrimes(){
        for (item in 2..givenNumber){
            if (isPrime(item)) {

                result +=item

            }
        }

        println(result)

    }

    fun isPrime(number: Int): Boolean{

        for (item in 2 until number) {
            if (number.toDouble() % item.toDouble() == 0.0) {
                return false
            }
        }

        return true

    }

}