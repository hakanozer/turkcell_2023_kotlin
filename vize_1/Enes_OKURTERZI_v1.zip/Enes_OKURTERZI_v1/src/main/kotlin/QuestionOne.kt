class QuestionOne (var givenNumber: Int){
    private var result:Int = 0

    fun sumAllDigit(){
        while (givenNumber > 0) {
            result += givenNumber % 10
            givenNumber /= 10
        }

        println(result)

    }
}