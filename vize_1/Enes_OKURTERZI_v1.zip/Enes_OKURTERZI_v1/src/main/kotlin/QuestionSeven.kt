class QuestionSeven {
    /*
    Class : Sınıflar parametre alan içerisine fonksiyon yazılan birimlerdir.
    Object : Nesneler sınıfları referans göstererek oluşturur ve sınıfın özelliklerini taşır.
    Abstract : Soyutluk içerisinde genelde kod bulundurmayan sadece imzadan oluşan method ve sınıflardır.
    Interface : Arayüz tip tanımlamak için kullanılır. İçerisinde bulunan methodların gövdeleri olmaz değişkenlerin değerleri olmaz.
    Bir class sadece bir class'ı extend ederken birden fazla interface'i implement edebilir.
     */
}