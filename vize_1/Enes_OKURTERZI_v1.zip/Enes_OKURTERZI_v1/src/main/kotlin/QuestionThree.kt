class QuestionThree(val givenNumber: Int) {
    private var result:Double = 1.0
    private var dividing:Double = 1.0

    fun factorialLooking(){
        for (item in 1..givenNumber) {
            dividing = 1.0

            for (secondItem in 1..item){
                dividing *= secondItem
            }

            result += item / dividing

        }

        println(result)

    }
}