class QuestionTwo(var givenNumber: Int) {
    fun printReverse(){
        while (givenNumber > 0) {
            print(givenNumber % 10)
            givenNumber /= 10
        }
        println()

    }

}