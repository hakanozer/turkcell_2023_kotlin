package questionSix

interface Employee {
    val baseSalary: Int
    val additionalPercent: Double
    fun calculateSalary(additionalHour: Int)
}