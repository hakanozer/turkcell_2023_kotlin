package questionSix

class GenelMudur:Employee {
    override val baseSalary: Int = 5000
    override val additionalPercent: Double = 0.8

    override fun calculateSalary(additionalHour: Int) {
        println(baseSalary + additionalHour * additionalPercent)
    }
}