package questionSix

class Memur:Employee {
    override val baseSalary = 1000
    override val additionalPercent = 0.3

    override fun calculateSalary(additionalHour: Int) {
        println(baseSalary + additionalHour * additionalPercent)
    }
}