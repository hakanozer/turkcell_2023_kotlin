package questionSix

class Mudur:Employee {
    override val baseSalary: Int = 3000
    override val additionalPercent: Double = 0.6

    override fun calculateSalary(additionalHour: Int) {
        println(baseSalary + additionalHour * additionalPercent)
    }

}