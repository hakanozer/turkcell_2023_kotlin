
rootProject.name = "Erkut_Anil_Dinc_V1"

