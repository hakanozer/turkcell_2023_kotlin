class IsPrime {

    fun isPrime(number: Int) : Boolean{
        var flag = false
        for (i in 2..number/2)
        {
            if(number % i == 0)
            {
                flag = true
                return false
            }
        }
        return true
    }
}