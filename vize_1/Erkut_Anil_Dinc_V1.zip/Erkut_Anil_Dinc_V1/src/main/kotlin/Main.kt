import PersonelSalary.CivilServant
import PersonelSalary.GeneralManager
import PersonelSalary.Manager

fun main(args: Array<String>) {

    var threeDigitSum  = SumofThreeDigitNumber()
    print("Enter your three digit number for sum:")
    val num1 = readln().toInt()
    var result1 = threeDigitSum.sumOfDigits(num1)
    println("Question1: $result1")

    var reverseNum = ReverseThreeDigitNumber()
    print("Enter your three digit number for reverse:")
    val num2 = readln().toInt()
    var result2 = reverseNum.reverseNumber(num2)
    println("Question2: $result2")

    var serialNum = SerialTotal()
    print("Enter your serial sum number:")
    val num3 = readln().toInt()
    var result3 = serialNum.sumOfSerial(num3)
    println("Question3: $result3")

    var sumPrimeNumbers = SumOfAllPrimes()
    var result4 = sumPrimeNumbers.getSumOfAllPrimes(11)
    println("Question 4 Prime Sum: $result4")

    var primeFinder = IsPrime()
    var result5 = primeFinder.isPrime(23)
    println("Question 5 Is Prime: $result5")

    println("Question 6:")
    var servant = CivilServant(3)
    var servantSalary =  servant.calculateServantSalary()
    println("Servant: " + servantSalary)


    var manager = Manager(10)
    var managerSalary =  manager.calculateManagerSalary()
    println("Manager: " +managerSalary)

    var gManager = GeneralManager(8)
    var gManagerSalary =  gManager.calculategManagerSalary()
    println("GeneralManager: "+gManagerSalary)


}