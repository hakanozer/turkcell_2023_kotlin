package PersonelSalary

class CivilServant constructor(var hour : Int) : SalaryCalculation(hour) {

    var servant_ratio = 0.3
    var servantSalary= 1000
    fun calculateServantSalary(): Double {
        return super.calculateSalary(servant_ratio, servantSalary)
    }
}