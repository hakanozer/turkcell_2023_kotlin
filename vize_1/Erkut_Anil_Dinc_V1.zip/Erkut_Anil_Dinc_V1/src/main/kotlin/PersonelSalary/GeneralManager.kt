package PersonelSalary

class GeneralManager constructor(var hour:Int) : SalaryCalculation(hour){
    var gManager_ratio = 0.8
    var gManagerSalary= 5000
    fun calculategManagerSalary(): Double {
        return super.calculateSalary(gManager_ratio, gManagerSalary)
    }
}