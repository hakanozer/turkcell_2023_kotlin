package PersonelSalary

class Manager constructor(var hour : Int) : SalaryCalculation(hour) {

    var manager_ratio = 0.6
    var managerSalary= 3000
    fun calculateManagerSalary(): Double {
        return super.calculateSalary(manager_ratio, managerSalary)
    }
}