package PersonelSalary

open class SalaryCalculation constructor(var workhour : Int) {

    fun calculateSalary(extraRatio: Double, fixSalary: Int): Double {
        var sum = workhour.toDouble()*extraRatio + fixSalary.toDouble()
        return sum
    }
}