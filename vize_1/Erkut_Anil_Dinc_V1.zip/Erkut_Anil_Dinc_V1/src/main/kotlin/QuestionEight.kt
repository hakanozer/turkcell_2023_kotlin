class QuestionEight {

    /*

    Access Modifiers ne iş yapar?
    Erişim belirleyici olarak geçerler. public protected ve private gibi çeşitleri vardır.
    Bunlar oluşturulan değişkenlerin metotların kimler tarafından erişilebileceğini belirler.
    private, protected ve private gibi çeşitleri vardır. public olarak tanımlanan bir değişken
    her sınıftan erişilebilir hale gelir. private ve protected değişkenleri diğer classlara gizler ancak
    bunların farkı protected türünde oluşturulan değişkenler işin içinde miras varsa görülür hale gelir.
    private için bu durum söz konusu değildir.

     */
}