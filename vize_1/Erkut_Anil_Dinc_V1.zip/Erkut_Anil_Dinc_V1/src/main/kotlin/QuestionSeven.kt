class QuestionSeven {

    /*
    Class Nedir?
    İçerisinde methodlar ve değişkenler gibi yetenekler barındıran nesne üretmek
    için gerekli ve tekrar kullanılabilir kod parçası.


    Object Nedir?
    Classlardan constructor yardımı ile üretilen ve üretildiği classların (varsa ata classlarının)
    yeteneklerini kullanabilen nesne.


    Interface Nedir?
    Diğer classlara rehberlik eden bir yapıdır. Bir sınıfın içerisindeki yeteneklerin
    ne olması gerektiğini gösteren plandır. Soyut elemanlardan oluşur. interfacei implemente eden class,
    interfacein tüm methodlarını override etmek zorundadır.Classın bir şablonu bir blueprinti olarak tanımlanabilir.
    Ekstra maaliyetleri yoktur sadece kodun daha düzenli tertipli durmasına yardım ederler.


    Abstrack Nedir?
    Bu tip classlar yine miras alınan classlardır.Ancak abstract keywordü ile işaretli olan methodlar mutlaka
    ve mutlaka miras alınan class tarafından override edilmek zorundadır. Bu tip classlardan obje oluşturulamaz.

     */



}