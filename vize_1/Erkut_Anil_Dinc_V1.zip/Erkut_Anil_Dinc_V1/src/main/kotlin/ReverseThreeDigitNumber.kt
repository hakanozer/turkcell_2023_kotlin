class ReverseThreeDigitNumber {

    fun reverseNumber(number: Int): Int {
        var numberStr = number.toString()
        numberStr = numberStr.reversed()
        var reversedNumber = numberStr.toInt()
        return reversedNumber
    }
}