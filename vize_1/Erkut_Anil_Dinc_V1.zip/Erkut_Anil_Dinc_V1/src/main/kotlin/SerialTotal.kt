class SerialTotal {

    fun sumOfSerial(number: Int): Double {
        var sum = 0.0
        for (i in number downTo 1) {
            var numFact = factorial(i)
            var loopSum = i.toDouble() / numFact.toDouble()
            sum += loopSum
        }
        sum += 1
        return sum
    }

    fun factorial(num: Int): Int {
        var result = 1
        for (i in 2..num) {
            result *= i
        }
        return result
    }
}