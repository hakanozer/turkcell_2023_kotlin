class SumOfAllPrimes {

    fun getSumOfAllPrimes(number: Int) : Int {
        var sum = 0
        for (i in number downTo 1) {
            if (isPrime(i)) {
                sum += i
            }
        }
        return sum - 1 //becase 1 is not prime number
    }

    fun isPrime(number: Int): Boolean {
        var flag = false
        for (i in 2..number / 2) {
            if (number % i == 0) {
                flag = true
                return false
            }
        }
        return true
    }
}