class SumofThreeDigitNumber {

    fun sumOfDigits(number : Int): Int {
        var sum : Int = 0
        var numberStr = number.toString()
        for (digit in numberStr)
        {
            var x = digit.digitToInt()
            sum += x
        }
        return sum
    }
}