
rootProject.name = "Fatih_Uysal_v1"

