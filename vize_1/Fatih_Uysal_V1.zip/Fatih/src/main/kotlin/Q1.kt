fun main() {
    println("Lutfen 3 haneli bir sayi giriniz.")

    var number = 1000
    while (number> 999) {
        println("Sayi Girin : ")
        number = readLine()!!.toInt()
        if(number> 999) {
            println("Lütfen gecerli bir deger giriniz.")

        }
    }

    var result : Int = 0


    for (i in 0.. 2){

        var value = number % 10

        number /= 10

        result += value
    }

println("Sayinin basamaklarındaki rakamların degerleri toplami : $result")

}