fun main() {
    println("Lutfen 3 haneli bir sayi giriniz")

    var number = 1000
    while (number > 999) {
        println("Sayi Girin : ")
        number = readLine()!!.toInt()
        if(number> 999) {
            println("Lütfen gecerli bir deger giriniz.")

        }
    }

  println( number.toString().reversed())
}