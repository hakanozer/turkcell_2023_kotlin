fun main() {
    var result = 1.0
    var nNumber = 6


    for (i in 1..nNumber){

        result += i/factorial(i)
    }
    println("result : $result")



}
fun factorial (number : Int) : Double {
    var result1 : Double =  1.0
    for (i in number downTo 1){
        result1 *= i
    }
    return result1
}