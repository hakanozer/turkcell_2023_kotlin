class Q4 {


    open fun getSumOfAllPrimes( number : Int) : MutableList<Int> {
        var number1 = number
        var list = mutableListOf<Int>()
        while( number1 != 1) {
            if(isPrime(number1)){
                list.add(number1)
            }
            number1--

        }
        return list
    }



     companion object  fun isPrime( number : Int) : Boolean{

        for (i in 2.. number - 1  ){
            if(number % i == 0 ){
                return false
            }
        }
        return true

    }




}


fun main() {
var q = Q4()
    println(q.getSumOfAllPrimes(50))

}



