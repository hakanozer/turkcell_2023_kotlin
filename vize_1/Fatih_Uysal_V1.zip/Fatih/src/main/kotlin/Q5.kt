fun main() {

    println(isPrime(47))
    println(isPrime(50))
    println(isPrime(25))
    println(isPrime(27))
    println(isPrime(7))
    println(isPrime(10))
    println(isPrime(1))

}

 fun isPrime(value : Int) : Boolean {
     if(value< 2) {
         return false
     }
    for (i in 2.. value - 1  ){
        if(value  % i == 0 ){
            return false
        }
    }
    return true
}