package Q6

interface Calisan {

    var payment : Double
    var name : String
    var exHourRate : Double
    var exHour : Int


    fun showMyPayment(hour : Int): Double{

          payment += (hour * exHourRate)
        return payment
    }


    fun bilgilerimiGoster(){
        println("$name isimli calisanın toplam alacagi ucret ${showMyPayment(exHour)}")
    }


}