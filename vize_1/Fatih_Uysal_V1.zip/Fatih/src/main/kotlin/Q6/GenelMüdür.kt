package Q6

class GenelMüdür(override var name: String, override var payment: Double, override var exHour: Int) : Calisan{

    override var exHourRate: Double = 0.8



}