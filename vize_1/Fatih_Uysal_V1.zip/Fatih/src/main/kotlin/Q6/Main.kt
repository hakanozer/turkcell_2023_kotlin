import Q6.GenelMüdür
import Q6.Memur
import Q6.Müdür

fun main(args: Array<String>) {

var calisan1 = Memur("Fatih " , 1000.0 , 10 )
var calisan2 = Müdür("Mahmut" , 3000.0 , 20)
var calisan3 = GenelMüdür("Salih " , 5000.0 ,20)




    calisan1.bilgilerimiGoster()
    calisan2.bilgilerimiGoster()
    calisan3.bilgilerimiGoster()


}