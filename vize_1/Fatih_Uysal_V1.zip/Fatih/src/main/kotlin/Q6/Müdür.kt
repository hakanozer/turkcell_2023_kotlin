package Q6

class Müdür(override var name: String, override var payment: Double, override var exHour: Int) : Calisan {

    override var exHourRate: Double = 0.6
}