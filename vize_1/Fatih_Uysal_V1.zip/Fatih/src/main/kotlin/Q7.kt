

// ---class : nesnesi oluşturulurken dışarıdan deger almamızı sağlayan constructoru bulunan
// benzer türde nesneler üretebilmek için class kavramını kullanırız belli değerleri gruplandırmak için kullanılır.
// ---nesne : classların içinde olabilmeyi sağlayan bir çeşit geçiş anahtarıdır nesne o class ın özelliklerine sahip küçük bir parçasıdır.
// ---abstract : aslında soyut kavramdır abstract olan sınıfların nesnesi oluşturulamaz yalnızca miras alınabilir
// ---interface : bir anlamda şablondur genel subclassların neye benzeyeceğini ne şekilde olacağını interfaceler ile belirleriz
