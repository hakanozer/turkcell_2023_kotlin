//public : aynı dosya içerisindeki tüm sınıfların fonksiyonların görebildiği yapılardır.
//private : class dışı görünemeyen yapılardır.
//protected : class ı miras alanların(alt sınıflar)görebildiği yapılardır.
//internal : package içindeki dosyaların ulaşabildiği yapılardır.