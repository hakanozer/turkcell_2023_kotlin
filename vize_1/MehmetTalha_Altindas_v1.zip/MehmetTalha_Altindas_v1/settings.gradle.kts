
rootProject.name = "MehmetTalha_Altindas_v1"

