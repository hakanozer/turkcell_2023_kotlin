import Question6.GeneralManager
import Question6.Officer


fun main(args: Array<String>) {

    val a=Question1()
    a.calculateDigits(544)
    val b=Question2()
    b.reverseNumber(159)

    val c=Question3()
    var Sonuc3=c.seriesSum(6)
    println("Sonuc3: $Sonuc3")
    val d=Question4()
    val Sonuc4=d.getSumOfAllPrimes(12)
    println("Sonuc4: $Sonuc4")
    val f=Question5()
    val Sonuc5=f.isPrime(5)
    println("Sonuc5: $Sonuc5")
    val ahmet=Officer()
    val sonuc6_1=ahmet.calculateTotalSalary(15)
    println("Sonuç 6-1 $sonuc6_1")

    val mehmet =GeneralManager()
    val sonuc6_2=mehmet.calculateTotalSalary(15)
    println("Sonuç 6-2 $sonuc6_2")

}