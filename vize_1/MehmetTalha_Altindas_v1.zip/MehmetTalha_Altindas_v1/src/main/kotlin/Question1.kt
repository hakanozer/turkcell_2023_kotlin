class Question1 constructor() {

    fun calculateDigits(input:Int) {
        var result: Int = 0
        var digits = mutableListOf<Int>()
        var number = input

        while (number > 0) {
            //Sayının 10 ile bolumundan kalan bize decimal tabanlı bir sayıda bir basamak kaydırmamızı sagliyor.
            result+= number % 10
            digits.add(number % 10)

            number /= 10
        }
        println("${digits[2]}+${digits[1]}+${digits[0]}=$result")
    }
}