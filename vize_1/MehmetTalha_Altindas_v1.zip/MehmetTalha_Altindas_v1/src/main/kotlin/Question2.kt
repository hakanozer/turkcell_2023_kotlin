class Question2 {

    fun reverseNumber(input:Int) {
        var num = input
        var reversed = 0

        while (num != 0) {
            //En sagdan baslayarak digit
            val digit = num % 10
            reversed = (reversed * 10) + digit
            num /= 10
        }

        println("Sayinin Ters Cevirilmis Hali: $reversed")
    }
}