class Question3 {

    fun seriesSum(input:Int):Float{
        var result:Float=0.0f
        var factorialVar:Float=1.0f
        var i:Int=1

        while (i<=input){
            // ((1+1/1!))       1.Asama
            // ((1+1/1!)+2/2!)  2.Asama  result degiskeni parantez ile aynı mantıkta calisiyor
            factorialVar=factorialVar*i
            result+=(i/factorialVar)
            i++
        }
        return result
    }
}
