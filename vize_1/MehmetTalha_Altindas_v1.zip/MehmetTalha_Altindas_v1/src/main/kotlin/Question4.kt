class Question4 {

    fun getSumOfAllPrimes(n:Int):Int{
        var temp_n:Int=n
        var result:Int=0
        while(temp_n!=0){
            val flag=isPrime(temp_n)
            if (flag==true){
                result+=temp_n
            }
            temp_n--
        }
        return result

    }
    fun isPrime(number:Int):Boolean{
        var i:Int=2
        if (number<=1){
            return false
        }
        while (i<=number/2){
            if((number%i)==0){
                return false
            }
            i++
        }
        return true
    }
}