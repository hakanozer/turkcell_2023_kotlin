class Question5 {

    fun isPrime(number:Int):Boolean{
        var i:Int=2
        if (number<=1){
            return false
        }
        while (i<=number/2){
            if((number%i)==0){
                return false
            }
            i++
        }
        return true
    }
}