package Question6

open class Employee(val baseSalary:Int,val overTimeRate: Double) {
    //Employee ust class olarak bulunmakta, ve iki parametreye sahip: basesalary ve overTimeRate
    //calculateTotalSalary fonksiyonu bize toplam maaşı vermektedir.
    open fun calculateTotalSalary(hours:Int):Double{
        val totalSalary:Double=baseSalary+(overTimeRate*hours)
        return totalSalary
    }
}