package Question6

class GeneralManager:Employee(5000,0.8)  {

    override fun calculateTotalSalary(hours: Int): Double {
        return super.calculateTotalSalary(hours)
    }
}