package Question6

class Manager :Employee(3000,0.6)  {

    override fun calculateTotalSalary( hours: Int): Double {
        return super.calculateTotalSalary( hours)
    }
}