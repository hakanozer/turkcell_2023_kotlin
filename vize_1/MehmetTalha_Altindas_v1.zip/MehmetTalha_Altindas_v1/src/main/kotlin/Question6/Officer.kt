package Question6

class Officer :Employee(1000,0.3) {
    val overTimeRate2:Double=0.3
    override fun calculateTotalSalary( hours: Int): Double {

        return super.calculateTotalSalary (hours)
    }

}