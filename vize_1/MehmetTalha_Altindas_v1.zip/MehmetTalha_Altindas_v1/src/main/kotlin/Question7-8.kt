class `Question7-8` {

    /*

    Question7-

        Class:      Benzer özelliklere/metodlara sahip olan değişkenler(Nesneler) için oluşturulmuş olan şablondur.

        Object:     Herhangi bir classtan türetilen nesnelere obje denir.

                    Bu iki konsepti örnek ile açıklamak daha doğru olur diye düşünüyorum. Örneğin arabaların ortak özelliklerini düşünürsek;
                    tekerlek sayısı gibi değişkenler ile beraber motoru çalıştır gibi fonksiyonların hepsini birleştirdiğimiz dosya Class oluyorken,
                    Bu dosyadan aldığımız "Ahmet'in Arabası", "Ali'nin Arabası" gibi programda çalışan nesnelere object denir.

        Abstract:   Bu konseptte miras alınan sınıfta böyle bir metodun sadece tanımını yaparken, alt sınıfta bu metodun override edilmesini zorunlu kılmamıza yarar.

        Interface:  Bir classtaki yazılacak olan metodları önceden belirleyip daha düzenli bir şekilde kod yazmak için kullanılır. Ayrıca belirlenen metodların implementasyonunu da kolaylaştırır.



    ___________________________________________________________________

    Question8-

        Access Modifier'lar bize kod yazarken oluşturulan class,metod ve değişkenlerin erişilebilirliğini ayarlamamızı sağlayarak olası hatalardan kaçınmamızı sağlar.
        Kotlin'de 4 farklı Access Modifier vardır. Bunlar:

        public   — Değişken ya da Class'lar yerden erişilebilir. Öntanımlı olarak tercih edilen modifier budur.
        private  — Değişkenler sadece tanımlandığı sınıftan erişilebilir.Classlar ise bulunduğu dosyada erişilebilir
        protected— Tanımlandığı sınıftan yada o sınıftan türetilen sınıflar tarafından erişilebilir.
        internal — Aynı modül içinde erişilebilir



     */
}