package quesiton_1


fun main() {
    val number: Int = 579
    val digits: Array<Int> = findDigits(number)
    val totalOfDigits: Int = findTotalOfDigits(digits)

    println("The total of the digits: $totalOfDigits")


}

fun findTotalOfDigits(digits: Array<Int>): Int {
    var total: Int = 0
    for (digit in digits) {
        total += digit
    }
    return total
}

fun findDigits(number: Int): Array<Int> {
    val digits: Array<Int> = Array<Int>(3) { 0 }
    var n: Int = number
    var i: Int = -1
    while (n != 0) {
        digits[++i] = n % 10
        n /= 10
    }
    return digits
}
