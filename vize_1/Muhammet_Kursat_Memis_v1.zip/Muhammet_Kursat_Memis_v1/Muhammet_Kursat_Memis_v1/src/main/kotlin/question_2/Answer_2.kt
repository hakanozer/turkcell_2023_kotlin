package question_2

fun main() {
    val number: Int = 123
    val numbersReverse: Int = findNumberReverse(number)

    println("The reverse of the number: $numbersReverse")
}

fun findNumberReverse(number: Int): Int {
    var numberReverse: Int = 0
    var n = number

    while (n != 0) {
        numberReverse = (numberReverse * 10) + n % 10
        n /= 10
    }

    return numberReverse
}
