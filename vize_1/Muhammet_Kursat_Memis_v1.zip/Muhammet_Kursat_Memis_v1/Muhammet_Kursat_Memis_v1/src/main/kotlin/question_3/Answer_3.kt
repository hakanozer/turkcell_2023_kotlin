package question_3

fun main() {
    val N: Int = 4
    var total: Double = 1.0

    for (i in 1.rangeTo(N)) {
        total += i.toDouble() / findFactorial(i).toDouble()
    }

    println("Result: $total")

}

fun findFactorial(number: Int): Int {
    var n: Int = number
    var total: Int = 1

    while (n >= 1) {
        total *= n--
    }

    return total
}
