package question_4


class Calculator(val number: Int) {

    companion object {
        private var total: Int = 0
        fun getSumOfAllPrimes(n: Int): Int {

            for (i in 2..n) {
                if (isPrime(i)) {
                    total += i
                }
            }

            return total
        }
        fun isPrime(number: Int): Boolean {

            if (number < 1) {
                return false
            }
            else {
                for (i in 2 until number) {
                    if (number % i == 0) {
                        return false
                    }
                }
            }

            return true

        }
    }




}


fun main() {
    val result: Int = Calculator.getSumOfAllPrimes(100)
    println("Result: $result")

}

