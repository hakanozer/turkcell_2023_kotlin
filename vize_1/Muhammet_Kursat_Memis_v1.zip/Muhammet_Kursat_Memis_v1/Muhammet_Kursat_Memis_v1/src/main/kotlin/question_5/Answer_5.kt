package question_5

fun main() {
    println("Is the number a prime? ${isPrime(11)}")
}

fun isPrime(number: Int): Boolean {
    if (number <= 1) {
        return false
    }

    for (i in 2..number/2) {
        if (number % i == 0) {
            return false
        }
    }

    return true
}