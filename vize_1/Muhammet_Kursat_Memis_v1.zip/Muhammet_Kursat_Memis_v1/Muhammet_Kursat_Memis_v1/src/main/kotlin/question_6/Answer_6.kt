package question_6

abstract class Employee {
    abstract val ekSaatKatsayisi: Double
    abstract val baseSalary: Double
    abstract fun calculateSalary(): Double
}

class Officer(private val extraHours: Double) : Employee() {
    override val baseSalary: Double = 1000.0
    override val ekSaatKatsayisi: Double = 0.3

    override fun calculateSalary(): Double {
        return baseSalary + ekSaatKatsayisi*extraHours
    }
}

class Manager(private val extraHours: Double) : Employee() {
    override val baseSalary: Double = 3000.0
    override val ekSaatKatsayisi: Double = 0.6

    override fun calculateSalary(): Double {
        return baseSalary + ekSaatKatsayisi*extraHours
    }
}

class GeneralManager(private val extraHours: Double) : Employee() {
    override val baseSalary: Double = 5000.0
    override val ekSaatKatsayisi: Double = 0.8

    override fun calculateSalary(): Double {
        return baseSalary + ekSaatKatsayisi*extraHours
    }
}


fun main() {
    val officer: Officer = Officer(30.0)
    val manager: Manager = Manager(30.0)
    val generalManager: GeneralManager = GeneralManager(30.0)

    println("The salary of the officer: ${officer.calculateSalary()}")
    println("The salary of the manager: ${manager.calculateSalary()}")
    println("The salary of the generalManager: ${generalManager.calculateSalary()}")

}