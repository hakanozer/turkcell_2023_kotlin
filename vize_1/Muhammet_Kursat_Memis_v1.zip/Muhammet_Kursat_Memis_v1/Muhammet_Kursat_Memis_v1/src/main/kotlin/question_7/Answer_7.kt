package question_7


/**
 * Class Nedir ?
 * Class'lar, object oriented programming languages'ların bize, gerçek dünyayı modelleyerek kodlara aktarabilme özelliği
 * sağlayan yapılardır. Bu da bize kodlama yaparken büyük avantajlar ve kolaylıklar sağlar.
 * Class'lar kendi tanımladığımız veri türleri olarak düşünülebilir.
 * Class'lar, içerisinde attribute'ler ve method'lar tanımlanan bir şablon-taslak olarak düşünülebilirler.
 * Attribute'ler, class'ın niteliklerini temsil ederken methodlar class'ın işlevlerini (yapabileceklerini) temsil
 * ederler.

 */


/**
 * Object Nedir?
 * Objeler, soyut olarak tasarlanmış class'lardan üretilen somut nesnelerdir.
 * Objeler, class içerisindeki veriler üzerinden işlem yapmamıza olanak sağlarlar.
 * Classlar, referans tipli veri türleridir ve class'lar üzerinden objeler oluşturulabilir. Oluşturulan bu objeler
 * heap'te tutulur. Objelerin heap'te ne kadar yer tutacakları ise constructor'lar ile belirlenir.
 */

/**
 * Abstract Nedir?
 * Abstract, soyut anlamına gelir ve class'ların başına abstract keywordu ekleyerek Abstract Class'ları kullanmamıza olanak
 * sağlar.
 * Abstract classlar nesne üretilemeyen ve içinde abstract metotlar(içeriği doldurulmamış metotlar) ve/veya
 * abstract attribute'ler (değer atanmamış değişkenler) bulundurabilen classlardır.
 * Abstract class'lar üzerinden doğrudan obje oluşturamayız ancak abstract class'ları inherit eden somut sınıflar üzerinden
 * objeler oluşturabiliriz.
 * Abstract class'lar üzerinden doğrudan nesne üretememize rağmen bu class'ların constructor'lari vardir ve
 * bu class'lari inherit eden somut siniflar üzerinden bir obje oluşturulduğunda abstract class'ların constructorlari,
 * alt class'ların constructor'larindan önce calisir.
 * Abstract class'ları inherit eden somut class'lar, abstract class içindeki abstract member'ları implement etmek zorundadır.
 * Abstract class'lar içerisinde soyut member'lar tanımlayabildiğimiz gibi soyut memberlarda tanımlayabiliriz.
 *
 */

/**
 * Interface Nedir?
 * Interface'lerde abstract class'lar gibi içerisinde soyut yapılar tanımlayabileceğimiz yapılardır.
 * Interface'lerin bir constructor'ı yoktur ve interface'lerden obje oluşturulamaz. Ancak interface'leri implement
 * eden somut class'lardan obje oluşturulabilir.
 * Java-kotlin gibi dillerde class'lar üzerinden multi-inheritance'a izin verilmez ancak bir interface, birden fazla
 * interface'i extend edebilir.
 * Ayrıca kotlinde bir class, birden fazla interface'i implement edebilir.
 * Interface'ler, abstract class'lara göre daha performanslı çalışırlar.
 * Interface'ler, kodun okunabilirliğini ve bakımını kolaylaştırırlar.
 * Interface'ler içinde somut member'larda tanımlanabilir ancak bu çok tavsiye edilen bir şey değildir. Çünkü
 * bu durum kodun okunabilirliğini ve esnekliğini azaltabilir.
 */

