package question_8

/**
 * Erişim Belirleyiciler:
 * Erişim belirleyiciler, class member'ların diğer class'lar-package'ler tarafından nasıl erişilebileceğini
 * belirleyen yapılardır.
 * Erişim belirleyiciler, class member'ın görünürlük derecelerini belirlememize olanak sağlarlar ve bunun nihayetinde
 * kodlarımızın daha güvenli olmasını sağlayabiliriz.
 *
 * Kotlinde erişim belirleyicileri şunlardır:
 *
 * Public: Kotlinde varsayılan bir erişim belirleyicisidir. Public tanımlanan bir yapıya her yerden erişilebilir.
 *
 * Private: Private tanımlanan bir yapıya sadece aynı class içerisinden erişilebilir. Başka bir yapıdan erişilemez.
 *
 * Protected: Protected belirteci kullanarak tanımlanan bir class member'a,
 * aynı sınıf içindeki diğer member'lar ve bu class'ı extend eden alt class'lar üzerinden erişilebilir.
 *
 * Internal: Internal tanımlanan member'lara aynı modülden erişilebilir. Başka bir modülden erişilemez.
 *
 */