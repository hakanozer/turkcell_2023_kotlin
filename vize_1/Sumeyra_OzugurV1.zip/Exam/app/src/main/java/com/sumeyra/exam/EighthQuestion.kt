package com.sumeyra.exam
fun main(){


}

//Erişim belirteçleri (Access Modifiers) ne iş yapar açıklayınız.

// Sınıf veya değişkene kimlerin erişeceğine belirlememize olanak tanır.
// Public ->Herhangi bir yerden erişilmesini sağlar. Default olarak bu geçerlidir.
//Private ->  sadece aynı class ta erşim sağlar
//Protected -> Kalıtım yoluyla erişilebilir.
//Internal ->  Aynı modülü içinde ulaşmasını sağlar.
