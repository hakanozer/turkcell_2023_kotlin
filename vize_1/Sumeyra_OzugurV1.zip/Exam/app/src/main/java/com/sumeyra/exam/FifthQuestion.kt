package com.sumeyra.exam
fun main(){
    val fifthQuestion = FifthQuestion()
    println( fifthQuestion.isPrime(2)) //true
}


class FifthQuestion() {

    fun getSumOfAllPrimes(n: Int): Int {
        var sum = 0
        for (i in 2..n) {
            if (isPrime(i)) {
                sum += i
            }
        }
        return sum
    }

    fun isPrime(number: Int): Boolean {
        if (number < 2) {
            return false
        }
        for (i in 2..number/2) {
            if (number % i == 0) {
                return false
            }
        }
        return true
    }

}


