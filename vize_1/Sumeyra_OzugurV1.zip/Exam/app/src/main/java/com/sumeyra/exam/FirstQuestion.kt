package com.sumeyra.exam
fun main(){
    val firstQuestion = FirstQuestion()
    firstQuestion.calculateDigitSum(123)
}

//Kullanıcıdan 3 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Basamaklarının Toplamını Yazdırıyorsunuz
//Örnek :
//Sayı Girin : 245 2 + 4 + 5 = 11
class FirstQuestion() {

    fun calculateDigitSum(num: Int) {
        var remaningNum: Int
        var number = num
        var sum = 0

        while (number > 0) {
            remaningNum = number % 10
            sum += remaningNum
            number /= 10
        }

        println("sum of digits : $sum")
    }
}


