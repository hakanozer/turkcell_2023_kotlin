package com.sumeyra.exam
fun main(){
    val secondQuestion = SecondQuestion()
    println(secondQuestion.reversedNumber(743))

}

//Kullanıcıdan 3 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Rakamlarını Tersten Yazdırıyorsunuz Örnek :
//Sayı Girin : 743
//347

class SecondQuestion() {

    fun reversedNumber(number:Int):Int {
        val convertString = number.toString()
       return  convertString.reversed().toInt()
    }
}


