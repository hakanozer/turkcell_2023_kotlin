package com.sumeyra.exam
fun main(){
}

//Class, Object , Abstrack, İnterface nedir açıklayınız.

//****Class****
// - Programlama dilinin temel yapı taşlarından biridir.
// Attribute ve methodların özelliklerini bir araya toparlayan şablondur diyebiliriz.
//Karmaşıklığı azaltır bu sayade.
// nesne üretmemizi sağlar


//***Object****
//Sınıflardan üretilir
// Bellekte yer kaplar.
// Programın gereksinim duyduğu tüm veriler nesneler tarafıdan tutulur.

//****Abstract ******
// abstract keywordu kullanılır
// Abstract sınıfın bir instance oluşturamayız
// is - a özellik sahiptir.
//Sınıflar birden faza sınıftan kalıtım alamazlar
//abstractlar aynı zamanda bir sınıftır.


//*** Interface ****
//Sınıflar birden fazla kalıtım alabilirler
// Interface den obje üretilmez
// bir class birden fazla inherit alabilir.
// bunları override etmemiz gerekir.
// constructor içermez










