package com.sumeyra.exam

fun main(){
    val thirdQuestion = ThirdQuestion()
    thirdQuestion.totalSeries(3)
}

//1 + 1/1! + 2/2! + 3/3! + 4/4! + .... + n/n!

class ThirdQuestion() {

    fun totalSeries(n: Int) {
        var sum = 1.0
        var factorial = 1.0

        for (i in 1..n) {
            factorial *= i
            sum += i / factorial
           // println("Sum of the series: $sum")// 2.0, 3.0,3.5
        }

        println("Sum of the series: $sum")
    }
}


