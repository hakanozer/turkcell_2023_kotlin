package com.sumeyra.exam.sixthquestion

class GenelMudur : Personel(0.8) {
    override fun calculateSalary() = 5000 + (ekSaatUcreti * extraHours)
}