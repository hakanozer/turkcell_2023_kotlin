package com.sumeyra.exam.sixthquestion

class Memur : Personel(0.3) {
    override fun calculateSalary() = 1000 + (ekSaatUcreti * extraHours)
}