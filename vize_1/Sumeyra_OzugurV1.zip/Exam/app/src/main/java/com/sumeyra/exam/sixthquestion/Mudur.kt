package com.sumeyra.exam.sixthquestion

class Mudur : Personel(0.6) {
    override fun calculateSalary() = 3000 + (ekSaatUcreti * extraHours)

}