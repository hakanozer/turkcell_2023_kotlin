package com.sumeyra.exam.sixthquestion

abstract class Personel(val ekSaatUcreti: Double) {
    abstract fun calculateSalary(): Double
    var extraHours = 0
}