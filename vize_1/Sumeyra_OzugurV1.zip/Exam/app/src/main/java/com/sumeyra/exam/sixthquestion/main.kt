package com.sumeyra.exam.sixthquestion

fun main(){
    val genelMudur =GenelMudur()
    genelMudur.extraHours = 20
   println( genelMudur.calculateSalary())
}