
rootProject.name = "Sınav"

