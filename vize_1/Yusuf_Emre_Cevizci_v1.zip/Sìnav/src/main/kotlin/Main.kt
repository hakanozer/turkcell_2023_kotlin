import BasamaklariToplami.Companion.toplam
import PrimeSayilar.Companion.getSumOfAllPrimes
import SayiyiCevir.Companion.cevir
import SeriToplami.Companion.seriToplamiHesapla

fun main(args: Array<String>) {
    //Soru 1 test.
    println("Birinci= soru " + toplam(675))

    //Soru 2 test.
    println("İkinci soru = " + cevir(456))

    //Soru 3 test.
    println("Üçüncü soru= " + seriToplamiHesapla(7))

    //Soru 4 test.
    println("Dördüncü soru= " + getSumOfAllPrimes(54))

    //Soru 5 test.
    println("Beşinci soru= " + isPrime(6))

    //Soru 6 test.
    val memur = Memur()
    val mudur = Mudur()
    val genelMudur = GenelMudur()

    val memurMaas = memur.maasHesapla(3)
    val mudurMaas = mudur.maasHesapla(5)
    val genelMudurMaas = genelMudur.maasHesapla(15)

    println("Memur maaşı: $memurMaas")
    println("Müdür maaşı: $mudurMaas")
    println("Genel Müdür maaşı: $genelMudurMaas")
}

//soru 1
class BasamaklariToplami {
    companion object {
        fun toplam(number: Int): Int {
            var toplam = 0
            var sayi = number
            while (sayi > 0) {
                toplam += sayi % 10
                sayi /= 10
            }
            return toplam
        }
    }
}

//soru 2
class SayiyiCevir {
    companion object {
        fun cevir(number: Int): Int {
            var cevrilmisSayi:Int = 0
            val ilkHane = number / 100
            val ikinciHane = (number / 10) % 10
            val ucuncuHane = number % 10

             cevrilmisSayi = ucuncuHane * 100 + ikinciHane * 10 + ilkHane

            return cevrilmisSayi
        }
    }
}

//soru 3
class SeriToplami {
    companion object {
        fun seriToplamiHesapla(number: Int): Float {
            var sum = 1.0
            var faktoriyel = 1

            for (i in 1..number) {
                faktoriyel *= i
                sum += i.toFloat() / faktoriyel
            }

            return sum.toFloat()
        }
    }
}

//soru 4
class PrimeSayilar {
    companion object {
        fun getSumOfAllPrimes(n: Int): Int {
            var toplam = 0
            for (i in 2..n) {
                if (asalMi(i)) {
                    toplam += i
                }
            }
            return toplam
        }

        private fun asalMi(number: Int): Boolean {
            if (number <= 1) {
                return false
            }
            for (i in 2 until number) {
                if (number % i == 0) {
                    return false // Sayı asal değil
                }
            }
            return true // Sayı asal
        }
    }
}

//soru 5
fun isPrime(number: Int): Boolean {
    if (number < 2) return false // 2'den küçük sayılar asal olmadığı için...
    for (i in 2..(number / 2)) {
        if (number % i == 0) {
            return false // Sayı asal değil...
        }
    }
    return true // Sayı asal...
}

//soru 6
abstract class Personel(val maas: Int, val saatlikEkUcret: Double) {
    abstract fun maasHesapla(ekSaat: Int): Double // abstract method

    // Ek saat ücreti hesaplama
    fun ekUcretHesapla(ekSaat: Int): Double {
        return saatlikEkUcret * ekSaat
    }
}

// Memur sınıfı
class Memur : Personel(1000, 0.3) {
    override fun maasHesapla(ekSaat: Int): Double {
        return maas + ekUcretHesapla(ekSaat)
    }
}

// Müdür sınıfı
class Mudur : Personel(3000, 0.6) {
    override fun maasHesapla(ekSaat: Int): Double {
        return maas + ekUcretHesapla(ekSaat)
    }
}

// Genel Müdür sınıfı
class GenelMudur : Personel(5000, 0.8) {
    override fun maasHesapla(ekSaat: Int): Double {
        return maas + ekUcretHesapla(ekSaat)
    }
}

//soru 7
//--CLASS--
//Günlük yaşantımızda karşılaştığımız bir problemi nasıl adım adım ilerleyerek çözüyorsak, bir program yazarken de
//bu şekilde ilerlemek en doğrusudur. Sınıflar gercek hayat ile yakından ilişki kurabileceğimiz yapılardır, çünkü gerçek hayat
//nesnelerden ibarettir. Programımızı monolitik bir yapı yerine, küçük parçalara ayırıp geliştirmek
//çok daha sağlıklıdır. Sınıflar bu nokta çok işlevseldir.
//Sınıflar, bir nesneyi oluşturmak için kullanılan bir şablondur. Sınıf içinde nesnelerin özelliklerini temsil eden
//değişkenlerimiz bulunur.

//--OBJECT--
//Class'lardan oluşturduğumuz örneklemlere obje deriz. Genellikle OOP dillerinde en tepede bir main object class'ı vardır.
//Diğer class'lar bu object class'ından kalıtım alır.

//--ABSTRACT--
//Abstract kavramını açıklamak için öncelikle inheritance'ın ne olduğunu bilmek gerekir. Inheritance: Hiyerarşik bir şekilde
//class'lar bütünüdür. Bizim bir üst class'ımızın attribute'leri ve fonksiyonları alt class tarafından tanınır ama bazen
//bazı fonksiyonlar bu üst class'ın fonksiyonunu kendi belirlemek ister. Bu şekilde class'ların kendine özgü fonksiyonu
//implement eder ama üst class'ındaki fonksiyonun imzasına bağımlı kalmak zorundadır.

//--INTERFACE--
//Programlama dillerinde bir tür yapılardır ve sınıflar arasında bir sözleşme oluşturmak için kullanılır. Bu sözleşme, bir
//sınıfın hangi yöntemleri veya özellikleri uygulaması gerektiğini belirler. Interface'ler, bir sınıfın belirli bir davranışı
//sağlamasına izin vermek için kullanılan yöntemleri belirleyebilirler.


//soru 8
//Erişim belirteçleri, sınıf içerisindeki fonksiyon veya özellik gibi üyelerin diğer kod blokları tarafından erişimlerini
//kısıtlar. Bu belirteçler kod blokları arasındaki erişim düzeylerini kontrol etmek için kullanılır.
//public: Diğer kod bloklarına açıktır.
//private: Başka bir sınıf veya kod bloğu tarafından erişilemez.
//protected: Yalnızca aynı sınıf veya aynı paket içindeki alt sınıflardan erişilebilir.
//default: Sadece aynı paket içindeki kod bloklarından erişilebilir.
