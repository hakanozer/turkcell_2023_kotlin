
rootProject.name = "ali_marangoz_v1"

