class Digit() {

    fun DigitSum(int: Int): Int{

        var yüzler = int / 100;

        var ikiBasamaklıDeğer = int % 100;

        var onlar = ikiBasamaklıDeğer/10;

        var birler = ikiBasamaklıDeğer % 10;

        return (yüzler + onlar + birler)

    }

    fun DigitReverse(int: Int): Int{

        var yüzler = int / 100;

        var ikiBasamaklıDeğer = int % 100;

        var onlar = ikiBasamaklıDeğer/10;

        var birler = ikiBasamaklıDeğer % 10;

        return birler*100+onlar*10+yüzler

    }


}