package EmployeeSalaryCalculator

open class EmployeeImp(var salary: Double) : IEmployee{

    override fun calculateSalary(extraHour: Int): Double {
        return salary;
    }
}