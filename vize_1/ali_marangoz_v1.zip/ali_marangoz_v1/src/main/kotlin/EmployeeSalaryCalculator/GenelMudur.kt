package EmployeeSalaryCalculator

class GenelMudur(salary: Double) : EmployeeImp(salary) {

    override fun calculateSalary(extraHour: Int): Double {
        return super.calculateSalary(extraHour) + (extraHour * 0.8);
    }

}