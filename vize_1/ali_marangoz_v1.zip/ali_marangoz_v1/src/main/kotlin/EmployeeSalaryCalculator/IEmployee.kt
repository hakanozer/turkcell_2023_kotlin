package EmployeeSalaryCalculator

interface IEmployee {

    fun calculateSalary(extraHour: Int): Double

}