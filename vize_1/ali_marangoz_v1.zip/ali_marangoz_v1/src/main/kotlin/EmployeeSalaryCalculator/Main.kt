package EmployeeSalaryCalculator

fun main(args: Array<String>) {

    var employee1 = Memur(1000.0)
    var employee2 = Mudur(3000.0)
    var employee3 = GenelMudur(5000.0)

    println("1000 TL alan Memurun 5 saat fazla çalıştıktan sonraki maaşı: " + employee1.calculateSalary(5))
    println("3000 TL alan Müdürün 5 saat fazla çalıştıktan sonraki maaşı: " + employee2.calculateSalary(5))
    println("5000 TL alan Genel Müdürün 5 saat fazla çalıştıktan sonraki maaşı: " + employee3.calculateSalary(5))

}