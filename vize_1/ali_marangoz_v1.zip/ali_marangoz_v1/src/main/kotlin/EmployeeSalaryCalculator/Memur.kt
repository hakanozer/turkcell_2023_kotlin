package EmployeeSalaryCalculator

class Memur(salary: Double) : EmployeeImp(salary) {
    override fun calculateSalary(extraHour: Int): Double {
        return super.calculateSalary(extraHour) + (extraHour * 0.3);
    }
}