package EmployeeSalaryCalculator

class Mudur(salary: Double) : EmployeeImp(salary) {
    override fun calculateSalary(extraHour: Int): Double {
        return super.calculateSalary(extraHour) + (extraHour * 0.6);
    }
}