package Last2QuestionAnswers;

public class SonSorularCevap {
//    Class:
//    Objelerin kalıpları classlar tarafından tanımlanır. Nesnelerin sahip olabileceği özellikleri(attribute) ve
//    metodları barındırır.
//
//    Object:
//    Sınıfların birer örnekleri olarak, nesnelerin temsil edilmesini sağlar. Objeler sınıf özelliklerine ve
//    metodlarına sahiptirler.
//
//    Abstract:
//    Soyut sınıflar ve soyut metodlar tanımlamak için kullanılır.
//    Soyut sınıfların kullanımı ortak özelliklere sahip sınıfların oluşturulması için oldukça kullanışlıdır.
//
//    Interface:
//    Bir veya daha fazla soyut metod içeren arayüz tanımlamak için kullanılır.
//    Arayüzlerin kullanımı, birçok sınıfın aynı davranışları uygulamasını sağlar.
//    Abstract classtan farklı olarak multi-inheritanceye izin verir.
//
//    Erişim belirteçleri (Access Modifiers):
//    Classların görünürlüğünü belirleyen yapılardır.
//    Sınıfın içindeki öğelerin sınıf dışındaki kod tarafından nasıl erişileceğini belirler.
//    public: Proje içinde her yerde erişilebilir
//    private: Yanlızca tanımlandığı sınıf içinden erişilebilir.
//    protected: Yanlızca tanımlanıdğı sınıf ve alt sınıfları tarafından erişilebilir.
//    internal: Aynı modül içinde herhangi bir yerden erişilebilir.

}
