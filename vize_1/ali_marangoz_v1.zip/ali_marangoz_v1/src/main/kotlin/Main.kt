fun main(args: Array<String>) {

    print("Q1-Sayı Giriniz: ")

    val q1Input = readln().toInt()

    var digitSum = Digit()

    println("Basamak Toplamları: " + digitSum.DigitSum(q1Input)) // Q1

    print("Q2-Sayı Giriniz: ")

    val q2Input = readln().toInt()

    var digitReverse = Digit()

    println("Sayının Tersi: " + digitReverse.DigitReverse(q2Input)) // Q2

    print("Q3-Sayı Giriniz: ")

    val q3Input = readln().toInt()

    var nSeries = Series()

    println("1'den $q3Input 'a kadar olan sayıların seri toplamı: " + nSeries.NSeriesSum(q3Input)) // Q3


    var prime = Prime()

    var getNumberForPrimeSum = 7
    println("$getNumberForPrimeSum sayısına kadar olan asalların toplamı: " + prime.getSumOfAllPrimes(getNumberForPrimeSum)) // Q4  === 7 > (2+3+5+7 = 17)

    var checkParam = 10;

    var primeCheck = Prime.isPrime(checkParam)

    println("$checkParam sayısı asal mıdır?: $primeCheck")





}