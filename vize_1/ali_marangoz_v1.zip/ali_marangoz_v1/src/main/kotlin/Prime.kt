class Prime {

    companion object{

        fun isPrime(number:Int): Boolean{

            for (i in 2..number/2) {
                if (number % i == 0) {
                    return false
                }
            }
            return true

        }
    }

    fun getSumOfAllPrimes(n: Int) : Int{
        var total = 0;

        for (i in 2..n){

            if (isPrime(i)){
                total += i;
            }

        }

        return total;
    }



}