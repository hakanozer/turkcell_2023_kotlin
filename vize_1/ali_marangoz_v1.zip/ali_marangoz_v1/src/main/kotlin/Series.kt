class Series {

    fun NSeriesSum(n:Int): Double{

        var total = 1.0; // 1'i burdan dahil edip 2 den loopa devam edilir.
        var factor = 1.0;

        for (i in 2..n){
            factor *= i
            total += i / factor
        }

        return total;
    }

}