
rootProject.name = "can_karademir_v1"

