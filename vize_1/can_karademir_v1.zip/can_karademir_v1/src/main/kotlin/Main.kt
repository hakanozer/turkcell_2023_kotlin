fun main(args: Array<String>) {

    // Hocam bazı yerlerde tıkanınca internette destek aldım bilginiz olmasını istedim :)
    // 6. soruda temel kalıtım yapısını kurdum ama devamını getiremedim.

    println(" 1. ve 2. soru için: 3 basamaklı bir sayı giriniz. ")
    val sayi = readLine()?.toInt()

    val btoplami = Soru1().btoplama(sayi ?: 0)
    println("Soru1: Basamakların toplamı: $btoplami")

    val tersSayi = Soru2().bcevir(sayi ?: 0)
    println("Soru2: Basamaklarının tersten yazımı: $tersSayi")

    //println("3 soru için bir sayı giriniz. ")
    //val sayi1 = readLine()!!.toInt()
    //val cevap = Soru3().hesapla(sayi1)
    //println(cevap)

    val s4 =Soru4().getSumOfAllPrimes(7)
    println("Soru4: $s4")

    val s5 = Soru5().isPrime(5)
    println("Soru5: $s5")


}