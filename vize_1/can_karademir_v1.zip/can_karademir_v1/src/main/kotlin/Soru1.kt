class Soru1 {

    fun btoplama(x: Int): Int {
        if (x >= 100 && x <= 999) {
            val yuz = x / 100
            val on = (x % 100) / 10
            val bir = x % 10

            val toplam = yuz + on + bir
            return toplam
        } else {
            throw IllegalArgumentException(" 3 haneli bir sayı giriniz.")
        }
    }
}