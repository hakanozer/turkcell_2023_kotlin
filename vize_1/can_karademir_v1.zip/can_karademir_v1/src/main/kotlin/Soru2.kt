class Soru2 {

    fun bcevir(x: Int): Int {
        if (x >= 100 && x <= 999) {
            val yuz = x / 100
            val on = (x % 100) / 10
            val bir = x % 10

            val tersSayi = bir * 100 + on * 10 + yuz
            return tersSayi
        } else {
            throw IllegalArgumentException("3 haneli bir sayı giriniz.")
        }
    }
}