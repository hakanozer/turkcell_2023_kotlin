class Soru3 {

   // yanlış çalışıyor :( hatamı çözemedim

    fun hesapla(x: Int): Double {
        var sonuc: Double= 1.0

        for (i in 1..x) {
            sonuc += i.toDouble() / factoriel(i)
        }
            return sonuc
    }

    fun factoriel(_x:Int): Int {
        var factor = 1
        for (j in 1.._x){
            factor *= _x
        }
        return factor
    }
}