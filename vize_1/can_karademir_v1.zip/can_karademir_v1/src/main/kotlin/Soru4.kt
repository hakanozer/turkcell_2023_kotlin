import java.lang.Math.sqrt

class Soru4 {
    fun getSumOfAllPrimes(n: Int): Int {
        var sonuc = 0
        for (i in 1..n) {
            if (isPrime(i)) {
                sonuc += i
            }
        }
        return sonuc
    }
    fun isPrime(n: Int): Boolean {
        if (n < 2) {
            return false
        }
        for (i in 2..sqrt(n.toDouble()).toInt()) {
            if (n % i == 0) {
                return false
            }
        }
        return true
    }
}