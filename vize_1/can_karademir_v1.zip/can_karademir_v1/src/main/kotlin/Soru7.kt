class Soru7 {
    /*
    Class : Bir nesnenin davranışlarını ve özelliklerini tanımlar ve nesneleri oluşturulmamızı sağlayam yapılardır. Temel olarak nesnelerin özelliklerini belirler.
    Object : Sınıf aracılığıyla üretilirler ve içerisinde bulunan verileri ve özellikleri kullanılabilmesini sağlarlar
    Abstraction : Bir sınıfın bir alt sınıf veya bir nesne tarafından uygulanan ortak özelliklerini tanımlamak için kullanılır.
    Interface : En basit olarak projenin şablonu denilebilir. Bir sınıfın sahip olması gereken metotları ve özellikleri burada tanımlanır.
    */
}