class Soru8 {
    /*
   - Erişim belirteçleri, bir sınıfın, özniteliklerinin veya metotlarının diğer kod bloklarında (sınıflar, öznitelikler veya metotlar) nasıl erişilebileceğini kontrol eder.
   - Erişim belirteçleri, kodun güvenliğini ve bakımını sağlamak için kullanılır.
   -Public Private Protected Internal olmak üzere 4 farklı türü vardır.
   */
}