package soru6

class Gmudur(val fazlacalisma:Int) :calisan() {

    val ucret =5000
    val ekucret =0.8

    override fun maas(): Double {
        var tummaas= ucret+ekucret*fazlacalisma
        return tummaas
    }
}