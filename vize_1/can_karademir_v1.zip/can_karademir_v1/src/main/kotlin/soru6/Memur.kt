package soru6

class Memur(val fazlacalisma:Int) :calisan() {

    val ucret =1000
    val ekucret =0.3

    override fun maas(): Double {
        var tummaas= ucret+ekucret*fazlacalisma
        return tummaas
    }
}