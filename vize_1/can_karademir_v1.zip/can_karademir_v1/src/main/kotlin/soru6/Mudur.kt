package soru6

class Mudur(val fazlacalisma:Int) :calisan() {
    val ucret =3000
    val ekucret =0.6

    override fun maas(): Double {
        var tummaas= ucret+ekucret*fazlacalisma
        return tummaas
    }
}