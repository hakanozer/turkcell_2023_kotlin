package soru6

open class calisan {
    open fun maas():  {
        return
    }
}