
rootProject.name = "fahri_atakan_kutuk_v1"

