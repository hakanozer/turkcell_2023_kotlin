fun main(args: Array<String>) {
    println("==========SORU-1==========")
    soru1().soru1()
    println("==========SORU-2==========")
    soru2().soru2()
    println("==========SORU-3==========")
    soru3().soru3()
    println("==========SORU-4==========")
    soru4().getSumOfAllPrimes(151)
    println("==========SORU-5==========")
    soru5().asalsayi(13)
    println("==========SORU-6==========")
    val memur = Memur(150.0)
    val mudur = Mudur(150.0)
    val genelmudur = GenelMudur(150.0)
    println("Memur Maaşı : ${memur.maasHesaplama()}")
    println("Müdür Maaşı : ${mudur.maasHesaplama()}")
    println("Genel Müdür Maaşı : ${genelmudur.maasHesaplama()}")
    println("==========SORU-7==========")
    println("Soru 7'nin cevabı yorum satırı halinde yazılmıştır.")
    /*
    Bu terimlerin hepsi nesne yönelimli programlama (OOP) kavramlarıdır.

    Class: Bir sınıf, bir nesne veya nesneler grubudur. Sınıflar belirli niteliklerle veya özelliklerle donaltılabilir.
    Belirli işlevlere sahip nesneler üretmek için kullanılır. Bir sınıf ayrı bir tasarım demektir veya ayrı bir şablon
    olarak düşünülebilir.

    Object: Bir sınıftan üretilen bir örnek, bir nesnedir. Sınıfın belirlemiş olduğu özelliklerini taşıyan veri yapısıdır.
    Bir nesne bir sınıftan türetilerek oluşturulur fakat kendi özelliklerini de taşıyabilirler.

    Abstract: Bir tür soyut tamamlanmamış sınıf olarak düşünülebilir. Soyut sınıflarda, sınıfın zellikleri olabilir veya
    hiç taşımayabilir. Ancak bu sınıfların alt sınıflarında tamamlamş olmaları gereken işlevler veya özellikleri içerebilirler.

    İnterface: Bir arayüz, sınıflar arasında belirli bir işlevselliği garanti etmek için kullanılan bir sözleşme gibidir.
    Arayüzler bir sınıfın birden fazla arayüzü uygulamasına olanak tanır.
     */
    println("==========SORU-8==========")
    println("Soru 8'in cevabı yorum satırı halinde yazılmıştır.")
    /*
    Erişim Belirleyiciler -> Private, Protected, İnternal, Public olarak tanımlanır.

    Private: Özel demektir. Sadece yazılan sınıf içerisinden kullanılabilir. Başka bir yerden erişim sağlanamaz.

    Protected: Korunmuş demektir. Yazılan sınıf ve aynı kotlin class/file içerinde oluşturulan sınıflarda erişilebilir.
    Farklı yeni oluşturulan kotlin class/file içerisinde erişime izin vermez.

    İnternal: Sadece keni modülümüz içerisinden ulaşılabilir. Uygulamaya içinde heryerden erişilebilir fakat
    uygulamaya dış bir kütüphane eklendiği takdirde oradan ulaşılamayacaktır.

    Public: Default olarak tanımlanır. Heryerden erişime açıktır.
     */


}