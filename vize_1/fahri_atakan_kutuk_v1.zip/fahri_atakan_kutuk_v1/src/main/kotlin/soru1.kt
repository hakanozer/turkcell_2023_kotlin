class soru1 {
    fun soru1(){
        val sayi = 139
        val yuzler_basamagi = sayi / 100 //yazılan sayının yüzler basamağını yakaladım.
        val onlar_basamagi = (sayi % 100) / 10 //yazılan sayının onlar basamağını yakaladım.
        val birler_basamagi = sayi % 10 //yazılan sayının birler basamağını yakaladım.

        val topla = yuzler_basamagi + onlar_basamagi + birler_basamagi

        println("Sayı : $sayi\n"+"Yüzler Basamağı : $yuzler_basamagi\n"+"Onlar Basamağı : $onlar_basamagi\n"+"Birler Basamağı : $birler_basamagi")
        println("Sayıların Tolamı : $topla")
    }
}