class soru2 {
    fun soru2(){
        val sayi2 = 158
        val tersleme = sayi2.toString().reversed().toInt()
        println("Girilen Sayı : $sayi2\n"+"Terslenmiş Hali : $tersleme")
    }
}