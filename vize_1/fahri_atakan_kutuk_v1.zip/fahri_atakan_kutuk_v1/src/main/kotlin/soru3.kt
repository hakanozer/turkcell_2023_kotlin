class soru3 {
    fun soru3 (){
        val n = 39
        var toplam = 0
        for (i in 1..n){
            toplam += i
        }
        println("Girilen n değeri : $n\n"+"1'den $n değerine kadar olan sayıların toplamı : $toplam")
    }
}