class soru4 {
    fun getSumOfAllPrimes(n: Int) : Int{
        var toplam = 0
        if (n < 2){
            println("Lütfen verdiğiniz n değerini kontrol ediniz. Asal sayılar 2'den başlar.")
        }
        else{
            for (a in 2..n){
                var isPrime = true
                for (b in 2 until a ){
                    if ( a%b == 0 ){
                        isPrime = false
                        break
                    }
                }
                if (isPrime){
                    toplam += a
                }
            }
            //Hocam en küçük asal sayı 2'den başladığı için döngümü 2'den başlattım.
            println("1'den $n değerine kadar olan asal sayıların toplamı : $toplam")
        }
        return toplam
    }
}