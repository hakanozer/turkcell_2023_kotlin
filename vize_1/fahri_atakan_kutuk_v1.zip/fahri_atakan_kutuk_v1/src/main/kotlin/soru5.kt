class soru5 {
    fun asalsayi(sayi: Int) : Boolean{
        var asalmi = true
        if (sayi < 2){
            println("Lütfen verdiğiniz sayi değerini kontrol ediniz. Asal sayılar 2'den başlar.")
        }
        else{
            for (a in 2..sayi){
                for (b in 2 until a ){
                    if ( a % b == 0 ){
                        asalmi = true
                        break
                    }
                    else {
                        asalmi = false
                    }
                }
            }
            if (asalmi == true){
                println("Sayınız Asal Değildir!")
            }
            else{
                println("Sayınız Asaldır!")
            }
        }
        return asalmi
    }
}