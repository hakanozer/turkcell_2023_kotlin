open class soru6 (val maas: Double, open val ekSaat: Double) {
    open fun maasHesaplama(): Double{
        return maas
    }
}

class Memur(override val ekSaat: Double) : soru6(1000.0,ekSaat){
    override fun maasHesaplama(): Double {
        return super.maasHesaplama() + (ekSaat * 0.3)
    }
}

class Mudur(override val ekSaat: Double) : soru6(3000.0,ekSaat){
    override fun maasHesaplama(): Double {
        return super.maasHesaplama() + (ekSaat * 0.6)
    }
}

class GenelMudur(override val ekSaat: Double) : soru6(5000.0,ekSaat){
    override fun maasHesaplama(): Double {
        return super.maasHesaplama() + (ekSaat * 0.8)
    }
}