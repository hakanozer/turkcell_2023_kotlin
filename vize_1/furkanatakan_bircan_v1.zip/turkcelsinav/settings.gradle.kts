
rootProject.name = "sinav1"

