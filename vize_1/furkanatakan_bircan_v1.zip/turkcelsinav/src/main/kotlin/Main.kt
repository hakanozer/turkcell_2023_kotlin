fun main(args: Array<String>) {
    var soru1 = soru1.KullanicidanSayiAlma()
    //soru1.sayi()
    var soru2 = soru2.IkinciSoru()
    //soru2.terstenYazdirma()
    var soru3 = soru3.SeriToplami()
    //soru3.faktoriyelOranliSeri()
    var soru4= soru4.DorduncuSoru()
    //soru4.getSumOfAllPrimes()
    var soru5=soru5.BesinciSoru()


}