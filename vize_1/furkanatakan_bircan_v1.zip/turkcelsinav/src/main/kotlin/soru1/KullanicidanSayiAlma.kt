package soru1

public class KullanicidanSayiAlma {


    fun sayi() {
        println("Lütfen üç haneli bir sayı giriniz:")
        var num = readLine()!!.toInt()

            if (num > 99 && num < 1000) {
                var mod : Int = 0
                var basamakli : Int = num
                var toplam: Int = 0
                for (x in 1..3) {
                    mod = num % 10
                    num = num / 10
                    toplam = toplam+mod
                }
                println(toplam)
            } else {
                println(" üç basamaklı sayı girmediniz!")
            }
        }

}
