package soru2

class IkinciSoru {
 fun terstenYazdirma(){
     println("Lütfen üç hanelibir sayı giriniz: ")
     var num = readLine()!!.toInt()
     var basamak=0
     var modBirler =0
     var modOnlar =0
     var modYüzler =0
     var tersSayi=0

     modBirler=num%10
     num = num/10
     modOnlar=num%10
     num=num/10
     modYüzler=num%10
     tersSayi = tersSayi+modBirler*100+modOnlar*10+modYüzler*1
     println(tersSayi)



 }
}