package soru3

class SeriToplami {

    fun faktoriyelOranliSeri(){
        println("Lütfen bir N sayısı girin: ")
        var nSayi= readLine()!!.toInt()
        var toplam:Double=0.0
        var araDeger=0
        for (item in 1..nSayi){
            araDeger=(nSayi-1)
            toplam = toplam + (1/factorial(araDeger))
        }
        println(toplam+1)
    }
  //  fun faktoriyel(num:Int):Long{
        /*var faktoriyel:Long=1
        var deger:Long =num
        for(i in 1..num){
            faktoriyel=deger*faktoriyel
            deger--
        }
        return faktoriyel
        println(faktoriyel)
*/


            /*return if{
                (num == 1) num.toLong ()
            }else {num*faktoriyel(num-1)}

    }*/
            fun factorial(n: Int): Int {
                return if (n == 1) n.toInt() else n*factorial(n-1)
            }
}