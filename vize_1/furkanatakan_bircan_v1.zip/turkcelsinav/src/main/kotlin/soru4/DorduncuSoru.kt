package soru4;

public class DorduncuSoru {

    fun getSumOfAllPrimes(n:Int=4){
        var toplam=0
        var deger =n
        for (i in 1..n){
            if (isPrime(deger)==true){
                toplam= toplam+deger
            }
            deger--

        }
        println(toplam-1)

    }

    fun  isPrime(num:Int):Boolean{
        var i = 2
        while (i < num) {
            if (num % i == 0) {
                return false
            }
            i += 1
        }
        return true
    }
}
