package soru6

 interface  Calisan {
    fun maasHesabi(eksaat:Int)

      /*  var ekUcret =eksaat*katsayi
        println(maas+ekUcret)
    }*/
}