package soru6

class GenelMudur:Calisan {
    var katsayi=0.8
    var maas=5000
    override fun maasHesabi(eksaat: Int) {
        var ekUcret =eksaat*katsayi
        println(maas+ekUcret)

    }

}