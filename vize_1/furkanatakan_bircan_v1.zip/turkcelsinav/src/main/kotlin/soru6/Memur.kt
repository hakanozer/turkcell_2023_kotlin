package soru6

class Memur:Calisan {
    var katsayi=0.3
    var maas=1000
    override fun maasHesabi(eksaat: Int) {

        var ekUcret =eksaat*katsayi
        println(maas+ekUcret)
    }
}