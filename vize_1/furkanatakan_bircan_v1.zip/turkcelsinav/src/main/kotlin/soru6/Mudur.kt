package soru6;

 class Mudur: Calisan {
  var katsayi=0.6
  var maas=3000
  override fun maasHesabi(eksaat: Int) {
   var ekUcret =eksaat*katsayi
   println(maas+ekUcret)

  }

 }
