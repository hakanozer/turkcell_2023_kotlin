package soru7

class soru7 {

    /*
     Class: nesne tabanlı progrmalamada class lar Object clasıın dan yaratılır.Classlar nesne tabalı programlamanın
     en temel öğlerindendir.

     Object:Oluşturduğumuz classları kullanabilmek ve somut hale getirebilmek için classlardan obje oluştururuz.

     Abstract:Abstract Classlar

     Interface: Interfaceler ile özellikle büyük bir projede çalışırken kendimize bu kısmı referans kabul ederek
      ordaki metodları geliştibiliriz.Ayrıca Abstract class dan farkı birden çok interfac i  bir class a implement
      edebiliriz.


     */
}