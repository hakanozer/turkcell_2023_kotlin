package soru8

class AccessModi {
    /*
       public — Her yerden erişilebilir. public kelimesi halka açık anlamına gelmektedir
        tanımlanan her şey diğer bütün sınıflarlardan erişilebilinir.

      private — Sadece tanımlandığı sınıftan erişilebilir. private özel veya gizli anlamına gelir.

      Bu erişim belirleyicisi ile tanımlanan herhangi bir eleman sadece ve sadece aynı sınıf içerisinden erişilebilir diğer sınıflar erişemez. (Java ile aynı)

       protected — Aynı sınıftan ya da o sınıftan türetilen sınıflar, nesneler tarafından erişilebilir.

       internal —Aynı modül içindeki diğer sınıflar erişebilir
     */
}