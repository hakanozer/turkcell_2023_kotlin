package com.gultendogan.turkcellsinav

import com.gultendogan.turkcellsinav.soru_2.SoruIki
import com.gultendogan.turkcellsinav.soru_1.SoruBir
import com.gultendogan.turkcellsinav.soru_3.SoruUc
import com.gultendogan.turkcellsinav.soru_4.SoruDort
import com.gultendogan.turkcellsinav.soru_5.SoruBes
import com.gultendogan.turkcellsinav.soru_6.GenelMudur
import com.gultendogan.turkcellsinav.soru_6.Memur
import com.gultendogan.turkcellsinav.soru_6.Mudur
import com.gultendogan.turkcellsinav.soru_7.SoruYedi
import com.gultendogan.turkcellsinav.soru_8.SoruSekiz

fun main(args: Array<String>){

    //SORU-1
    println("1.SORUNUN CEVABI")
    var soru1 = SoruBir(245)
    soru1.topla()
    println("\n")

    //SORU-2
    println("2.SORUNUN CEVABI")
    var soru2 = SoruIki(743)
    soru2.terstenYazdir()
    println("\n")

    //SORU-3
    println("3.SORUNUN CEVABI")
    val soru3 = SoruUc.topla(5)
    soru3.nSayiToplami()
    println("\n")

    //SORU-4
    println("4.SORUNUN CEVABI")
    var soru4 = SoruDort.getSumOfAllPrimes(12)
    println("\n")

    //SORU-5
    println("5.SORUNUN CEVABI")
    SoruBes(11)
    println("\n")

    //SORU-6
    println("6.SORUNUN CEVABI")
    val memur = Memur(1000)
    val mudur = Mudur(3000)
    val genelMudur = GenelMudur(5000)

    println("Memur maaşı: ${memur.maasHesapla(10)} TL")
    println("Müdür maaşı: ${mudur.maasHesapla(10)} TL")
    println("Genel Müdür maaşı: ${genelMudur.maasHesapla(10)} TL")
    println("\n")

    //SORU-7
    var soruYedi = SoruYedi()

    //SORU-8
    var soruSekiz = SoruSekiz()
}