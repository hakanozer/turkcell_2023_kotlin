package com.gultendogan.turkcellsinav.soru_1

class SoruBir(var sayi: Int) {

    fun topla(){
        if (sayi in 100..999) {
            var toplam = 0
            while (sayi > 0) {
                toplam += sayi % 10
                sayi /= 10
            }
            println("Basamakların toplamı: $toplam")
        }
    }

}