package com.gultendogan.turkcellsinav.soru_2

class SoruIki(var sayi: Int) {

    fun terstenYazdir(){
        if (sayi in 100..999) {
            val tersi = sayi.toString().reversed().toInt()
            println("Tersten yazılmış hali: $tersi")
        }
    }
}