package com.gultendogan.turkcellsinav.soru_3

class SoruUc private constructor(var sayi: Int) {

    fun nSayiToplami() {
        var toplam = 1.0
        var faktoriyel = 1

        for (i in 2..sayi) {
            faktoriyel *= i
            toplam += i.toDouble() / faktoriyel
        }

        println("Serinin toplamı: $toplam")
    }

    companion object {
        fun topla(sayi: Int): SoruUc {
            if (sayi < 0) {
                println("sayı negatif olamaz")
            }
            return SoruUc(sayi)
        }
    }
}