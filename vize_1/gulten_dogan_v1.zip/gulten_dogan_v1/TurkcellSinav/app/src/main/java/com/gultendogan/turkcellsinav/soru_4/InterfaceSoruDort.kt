package com.gultendogan.turkcellsinav.soru_4

interface InterfaceSoruDort {
    fun getSumOfAllPrimes(n: Int): Int
}