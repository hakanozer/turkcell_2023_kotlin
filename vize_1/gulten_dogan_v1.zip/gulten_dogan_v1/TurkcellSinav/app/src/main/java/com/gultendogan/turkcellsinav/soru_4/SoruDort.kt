package com.gultendogan.turkcellsinav.soru_4

class SoruDort {

    companion object : InterfaceSoruDort {

        override fun getSumOfAllPrimes(n: Int): Int {
            var toplam = 0
            for (i in 1..n) {
                if (isPrime(i)) {
                    toplam += i
                }
            }
            println("Asal sayıların toplamı: $toplam")
            return toplam
        }

        private fun isPrime(sayi: Int): Boolean {
            if (sayi <= 1) {
                return false
            }
            for (i in 2 until sayi) {
                if (sayi % i == 0) {
                    return false
                }
            }
            return true
        }
    }
}