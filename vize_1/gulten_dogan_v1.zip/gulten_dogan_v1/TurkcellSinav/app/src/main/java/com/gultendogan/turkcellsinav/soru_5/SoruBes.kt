package com.gultendogan.turkcellsinav.soru_5

class SoruBes(var sayi: Int) {

    init {
        if (isPrime()) {
            println("$sayi sayısı asaldır")
        } else {
            println("$sayi sayısı asal değildir")
        }
    }

    private fun isPrime(): Boolean {
        if (sayi <= 1) {
            return false
        }
        for (i in 2 until sayi) {
            if (sayi % i == 0) {
                return false
            }
        }
        return true
    }
}