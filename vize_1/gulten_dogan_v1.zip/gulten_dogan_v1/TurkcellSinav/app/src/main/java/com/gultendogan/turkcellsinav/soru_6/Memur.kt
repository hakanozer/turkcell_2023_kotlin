package com.gultendogan.turkcellsinav.soru_6

class Memur(maas: Int) : Personel(maas) {

    override fun maasHesapla(ekSaat: Int): Int {
        val toplamMaas = (maas + ekSaat * 0.3).toInt()
        return toplamMaas
    }
}