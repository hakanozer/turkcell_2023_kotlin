package com.gultendogan.turkcellsinav.soru_6

class Mudur(maas: Int) : Personel(maas) {

    override fun maasHesapla(ekSaat: Int): Int {
        val toplamMaas = (maas + ekSaat * 0.6).toInt()
        return toplamMaas
    }
}