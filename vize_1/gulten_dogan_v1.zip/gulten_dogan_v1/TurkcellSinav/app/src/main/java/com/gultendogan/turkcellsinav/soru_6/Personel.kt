package com.gultendogan.turkcellsinav.soru_6

abstract class Personel(val maas: Int) {

    abstract fun maasHesapla(ekSaat: Int): Int
}