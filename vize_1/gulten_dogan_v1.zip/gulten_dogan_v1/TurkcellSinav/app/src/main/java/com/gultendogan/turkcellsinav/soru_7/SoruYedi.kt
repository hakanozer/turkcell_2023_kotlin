package com.gultendogan.turkcellsinav.soru_7

class SoruYedi {

    //CLASS: Belirli bazı özelliklere sahip nesnelerin bir şablonu. Class'lar kullanılarak objeler oluşturulur.

    //OBJECT: Bir class tan türetilir ve o class ın özelliklerini (metod, değişken vb.) kullanabilir.

    //ABSTRACK: Benzer özelliklere sahip ama farklı davranış gösteren nesneleri bir arada tutmak için kullanılır.
    // Abstrack classtan obje üretilemez.
    //Birden fazla Abstract Class bir sınıfa implement edilemez.

    //INTERFACE: Class ların haberleşmesini sağlar.
    // Abstract tüm classlarda kullanılacak yapıları içerirken Interface’ler nitelik bazlıdır.
    //Bu yüzden spesifik bir özellik içeriliyorsa bu yapıyı Interface’lerde tanımlamalıyız.
    //değildir. Birden fazla interface bir class’a implement edilebilir. Class içerisinde birden fazla
    //Şablon yapıları kurgularken de Abstract class’ları tercih etmeliyiz.
}