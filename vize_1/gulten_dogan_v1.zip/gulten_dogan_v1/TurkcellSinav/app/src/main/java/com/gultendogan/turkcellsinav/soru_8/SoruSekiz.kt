package com.gultendogan.turkcellsinav.soru_8

class SoruSekiz {

    /*
    Bir sınıfın, metodları veya değişkenlerinin hangi durumlarda diğer sınıflardan çağıralacağını
    belirtmek için kullanırız.

    -> public : Tüm sınıflardan erişebilir. Default olarak tüm değişken ve metodlar public tir.

    -> private : Sadece tanımlı olduğu sınıfta kullanılabilir. Başka sınıftan erişilenez

    -> protected : Tanımlanan sınıf ya da alt sınnıflar erişebilir.

    -> internal : Tanımlanan modül içinde erişilebilir.

     */
}