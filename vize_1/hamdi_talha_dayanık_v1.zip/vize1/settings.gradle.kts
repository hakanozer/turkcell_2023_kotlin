
rootProject.name = "vize1"

