import soru1.soru1
import soru2.soru2
import soru3.soru3
import soru4.soru4
import soru6.*

fun main(args: Array<String>) {

    var soru1 = soru1()
    println(soru1.x)
    println(soru1.basamakToplamiHesapla(soru1.x))
    println("------------------------")

    var soru2 = soru2()
    println(soru2.x)
    println(soru2.tersCevir(soru2.x))
    println("------------------------")

    var soru3 = soru3()
    println(soru3.x)
    println(soru3.seriyiHesapla(soru3.x))
    println("------------------------")

    var soru4 = soru4()
    println(soru4.n)
    println(soru4.getSumOfAllPrimes(soru4.n))
    println("------------------------")

    var memur = Memur()
    var mudur = Mudur()
    var genelMudur = GenelMudur()

    println(memur.maasHesapla(1000))
    println(mudur.maasHesapla(1000))
    println(genelMudur.maasHesapla(1000))

}