package soru1

import kotlin.random.Random

class soru1 {
    var x = Random.nextInt(100,999)

    fun basamakToplamiHesapla(x:Int):Int{
        var birler = x % 10
        var onlar  = (x % 100) / 10
        var yuzler =  x / 100

        return birler + onlar + yuzler
    }
}