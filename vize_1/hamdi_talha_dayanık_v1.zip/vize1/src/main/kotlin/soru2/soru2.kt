package soru2

import kotlin.random.Random

class soru2 {
    var x = Random.nextInt(100,999)

    fun tersCevir(x:Int){
        var birler = x % 10
        var onlar  = (x % 100) / 10
        var yuzler =  x / 100

        println("$birler$onlar$yuzler")
    }
}