package soru3

import kotlin.random.Random

class soru3 {

    var x = Random.nextInt(1,10)

    fun seriyiHesapla(n : Int): Float{
        var currentNum = n
        var sum : Float = 0f
        while(currentNum > 1){
            sum += currentNum/faktoriyel(currentNum)
            currentNum--
        }
        sum++
        return sum
    }

    fun faktoriyel(x: Int): Int {
        if (x >= 1)
            return x * faktoriyel(x - 1)
        else
            return 1
    }
}