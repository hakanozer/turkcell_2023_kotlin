package soru4

import kotlin.random.Random

class soru4 {

    //var n = Random.nextInt(1, 100)
    var n = 5

    fun getSumOfAllPrimes(n : Int): Int{
        var sum = 0
        var currentNum = n
        while(currentNum>1){
            if(isPrime(currentNum)){
                sum += currentNum
            }
            currentNum--
        }
        return sum
    }

    companion object{
        fun isPrime(num: Int): Boolean {
            if(num<2) return false
            for (i in 2..num/2) {
                if (num % i == 0) {
                    return false
                }
            }
            return true
        }
    }
}