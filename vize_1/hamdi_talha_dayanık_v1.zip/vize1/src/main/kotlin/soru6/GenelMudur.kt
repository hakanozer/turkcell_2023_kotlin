package soru6

class GenelMudur : Personel(), MaasHesapla{
    override var maas = 5000
    override var ekCarpan = 0.8f

    override fun maasHesapla(ekSaatUcreti: Int):Float{
        var toplamMaas = ekCarpan * ekSaatUcreti + maas
        return toplamMaas
    }
}