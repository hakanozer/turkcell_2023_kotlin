package soru6

interface MaasHesapla {
    fun maasHesapla(ekSaatUcreti: Int):Float
}