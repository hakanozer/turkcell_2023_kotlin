package soru6

class Memur : Personel(), MaasHesapla {
    override var maas = 1000
    override var ekCarpan = 0.3f

    override fun maasHesapla(ekSaatUcreti: Int):Float{
        var toplamMaas = ekCarpan * ekSaatUcreti + maas
        return toplamMaas
    }
}