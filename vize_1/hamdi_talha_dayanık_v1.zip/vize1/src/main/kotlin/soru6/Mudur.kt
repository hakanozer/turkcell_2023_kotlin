package soru6

class Mudur : Personel(), MaasHesapla {
    override var maas = 3000
    override var ekCarpan = 0.6f

    override fun maasHesapla(ekSaatUcreti: Int):Float{
        var toplamMaas = ekCarpan * ekSaatUcreti + maas
        return toplamMaas
    }
}