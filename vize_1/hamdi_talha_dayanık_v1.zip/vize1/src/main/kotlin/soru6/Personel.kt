package soru6

abstract class Personel {
    open var maas = 0
    open var ekCarpan = 0f
}