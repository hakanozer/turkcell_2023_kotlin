package soru7

class soru7 {
    /*

    Class'lar gerekli nesneleri oluşturmak için kullanılacak templatelerdir.

    Object'ler sınıflardan oluşturulmuş nesnelerdir.

    Abstract anahtar kelimesi ile oluşturulan sınıflar soyut sınıflardır, kendilerinden obje
    oluşturulamaz. Bu sınıftan miras alacak sınıflar için template oluşturmak amaçlı kullanılır.

    Interface sınıf metodları tutan bir yapıdır. Sınıfların ortak metodları varsa bir interface'de
    tanımlanıp(declaration), ilgili sınıflara implementasyonu yapılabilir.

     */
}