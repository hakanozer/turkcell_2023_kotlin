package soru8

class soru8 {

    /*

    Erişim belirteçleri tanımladığımız metodlar ya da değişkenlerin nerelerden erişilebileceğini
    kontrol eder.

    private - Yapının sadece bulunduğu sınıf içerisinde erişilmesini sağlar.
    protected - Yapının bulunduğu sınıf ve altsınıfları içerisinde erişilmesini sağlar.
    internal - Sadece bulunduğu modül içerisinde erişilmesini sağlar.
    public - Görülebildiği her yerden erişilebilmesini sağlar.

    Kotlin'de dış sınıflar iç sınıfların private yapılarını göremezler.
     */
}