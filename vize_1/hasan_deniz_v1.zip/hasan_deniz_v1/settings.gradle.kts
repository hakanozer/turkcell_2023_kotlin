
rootProject.name = "hasan_deniz_v1"

