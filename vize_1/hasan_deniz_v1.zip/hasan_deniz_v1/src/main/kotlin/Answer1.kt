class Answer1 {
    fun sumOfDigits(num: Int): Int {
        var sum = 0
        var n = num

        while (n > 0) {
            sum += n % 10
            n /= 10
        }
        return sum
    }

}