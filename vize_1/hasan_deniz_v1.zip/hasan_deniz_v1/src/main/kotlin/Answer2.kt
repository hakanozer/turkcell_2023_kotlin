class Answer2 {
    fun reverseDigits(num: Int): Int {
        val numString = num.toString()
        val reversedString = numString.reversed()
        return reversedString.toInt()
    }
}