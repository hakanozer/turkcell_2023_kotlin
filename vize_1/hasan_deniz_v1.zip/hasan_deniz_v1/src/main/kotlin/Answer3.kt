class Answer3 {
    fun seriesSum(n: Int): Double {
        var sum = 0.0
        for (i in 1..n) {
            val partialSum = i.toDouble() / factorial(i)
            sum += partialSum
        }
        return sum + 1
    }

    private fun factorial(n: Int): Int {
        if (n == 0) {
            return 1
        } else {
            return n * factorial(n - 1)
        }
    }
}