class Answer4 {
    fun getSumOfAllPrimes(n: Int): Int {
        var sum = 0
        for (i in 2..n) {
            if (isPrime(i)) {
                sum += i
            }
        }
        return sum
    }

    private fun isPrime(n: Int): Boolean {
        if (n <= 1) {
            return false
        }

        for (i in 2..n / 2) {
            if (n % i == 0) {
                return false
            }
        }
        return true
    }
}