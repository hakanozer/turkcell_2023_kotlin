class Answer7 {
    /*Class
    Sınıfları bir nesnenin özelliklerini ve davranışlarını tanımlayabilmek için kullanırız.
    Bu sınıflara çeşitli fonksiyonlar da ekleyerek bu nesnenin bazı yetenekler kazanmasını sağlayabiliriz.*/

    /*Object
    Object, bir nesnenin singleton olduğunu belirtmek için kullanılır.*/

    /*Abstract
    Abstract anahtar kelimesi, soyut sınıflar veya soyut metodlar oluşturmak istediğimizde kullanılır.
    Bu sınıflar ve metodlar diğer sınflar tarafından miras alınabilir. Ancak abstract sınıf ve metodların doğrudan nesnesi oluşturulamaz. */

    /*Interface
    Interface, sınıfların birbiriyle iletişim kurmasını sağlayan bir şey olarak düşünülebilir. Herhangi bir sınıf bir interfaceyi miras aldığında,
    o interfacedeki metodları kendi içerisinde override ederek kullanabilir.*/


}