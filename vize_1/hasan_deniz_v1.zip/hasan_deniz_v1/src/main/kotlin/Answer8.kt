class Answer8 {
    /*Erişim belirteçleri, sınıf üyelerinin erişim düzeyini belirlemek için kullandığımız anahtar kelimelerdir.
    bunlar şöyledir:

    Public: Başında public kullanılarak oluşturulan üyeler, kodun herhangi bir noktasından erişilebilir.

    Private: Başında private kullanılarak oluşturulan üyeler, yalnızca oluşturulan sınıf içerisinde kullanılabilir.

    Protected: Başında protected kullanılarak oluşturulan üyeler, oluşturulan sınıfta ve bu sınıfın alt sınıflarından erişilebilir. Farklı paketlerden erişilemez

    Inline: Başında inline kullanılarak oluşturulan üyeler, yalnızca aynı paket içerisinde erişilebilir.*/
}