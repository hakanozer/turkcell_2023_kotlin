import answer6.Clerk
import answer6.GeneralManager
import answer6.Manager

fun main(args: Array<String>) {

    val answer1 = Answer1()
    println(answer1.sumOfDigits(123))

    val answer2 = Answer2()
    println(answer2.reverseDigits(123))

    val answer3 = Answer3()
    println(answer3.seriesSum(3))

    val answer4 = Answer4()
    println(answer4.getSumOfAllPrimes(5))

    val answer5 = Answer5()
    println(answer5.isPrime(5))

    val clerkExtraHours = 10
    val clerk = Clerk("Hasan", "Deniz")
    println("Total Salary of ${clerk.firstName} ${clerk.lastName} is ${clerk.calculateSalary(clerkExtraHours)}, which worked extra $clerkExtraHours hours.")

    val managerExtraHours = 10
    val manager = Manager("Hasan", "Deniz")
    println("Total Salary of ${manager.firstName} ${manager.lastName} is ${manager.calculateSalary(managerExtraHours)}, which worked extra $managerExtraHours hours.")

    val generalManagerExtraHours = 10
    val generalManager = GeneralManager("Hasan", "Deniz")
    println("Total Salary of ${generalManager.firstName} ${generalManager.lastName} is ${generalManager.calculateSalary(generalManagerExtraHours)}, which worked extra $generalManagerExtraHours hours.")

}