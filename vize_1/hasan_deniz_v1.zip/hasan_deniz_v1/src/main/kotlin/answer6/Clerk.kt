package answer6

class Clerk(firstName: String, lastName: String) : Employee(firstName, lastName) {
    override fun calculateSalary(extraHours: Int) = 1000.0 + (extraHours * 0.3)
}