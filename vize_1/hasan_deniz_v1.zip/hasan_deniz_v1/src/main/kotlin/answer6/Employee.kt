package answer6

open class Employee(val firstName: String, val lastName: String) : IPayable {
    override fun calculateSalary(extraHours: Int) = 0.0
}