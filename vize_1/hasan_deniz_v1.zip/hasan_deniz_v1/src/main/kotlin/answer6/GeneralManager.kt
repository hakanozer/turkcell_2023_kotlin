package answer6

class GeneralManager(firstName: String, lastName: String) : Employee(firstName, lastName) {
    override fun calculateSalary(extraHours: Int) = 5000.0 + (extraHours * 0.8)
}