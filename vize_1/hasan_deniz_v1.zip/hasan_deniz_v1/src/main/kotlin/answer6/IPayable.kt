package answer6

interface IPayable {
    fun calculateSalary(extraHours: Int): Double
}