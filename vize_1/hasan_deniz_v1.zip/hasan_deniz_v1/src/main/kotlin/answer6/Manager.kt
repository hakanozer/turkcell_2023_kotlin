package answer6

class Manager(firstName: String, lastName: String) : Employee(firstName, lastName) {
    override fun calculateSalary(extraHours: Int) = 3000.0 + (extraHours * 0.6)
}