import soru1.TakeANumber
import soru2.ReverseNums
import soru3.SeriHesapla
import soru4.CalcutalePrimeNums
import soru5.isPrime
import soru6.GenelMudur
import soru6.Memur
import soru6.Mudur

fun main() {

    // Soru 1
    val num = TakeANumber(245)
    num.calculateNum()


    /*---------------------------------------------*/


    // Soru 2
    val reverseNum = ReverseNums(123)
    println(reverseNum.reverseNum())

    /*---------------------------------------------*/

    // Soru 3
    val seriHesapla = SeriHesapla()
    println(seriHesapla.calculate(5))

    /*---------------------------------------------*/


    // Soru 4
    val calcutalePrimeNums = CalcutalePrimeNums()
    println(calcutalePrimeNums.getSumOfAllPrimes(10))

    /*---------------------------------------------*/

    // Soru 5
    println(isPrime(13))

    /*---------------------------------------------*/
    // Soru 6
    val genelMudur = GenelMudur(5000, 10)
    println("Genel Mudur Mesai Dahil Maas ${genelMudur.maasHesapla()}")

    val mudur = Mudur(3000, 10)
    println("Mudur Mesai Dahil Maas ${mudur.maasHesapla()}")

    val memur = Memur(1000, 10)
    println("Memur Mesai Dahil Maas ${memur.maasHesapla()}")

    /*---------------------------------------------*/

    // 7. ve 8. sorular  soru7 ve soru8 packageleri altindadir.

}