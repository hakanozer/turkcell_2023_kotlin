package soru1

class TakeANumber(private var num: Int) {

    fun calculateNum() {
        var toplam = 0
        while (num > 0) {
            toplam += num % 10
            num /= 10
        }
        return println(toplam)
    }
}