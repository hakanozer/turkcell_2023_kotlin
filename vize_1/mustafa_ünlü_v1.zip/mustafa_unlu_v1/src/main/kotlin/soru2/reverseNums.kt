package soru2

class ReverseNums(private val num: Int) {
    fun reverseNum(): Int {
        return this.num.toString().reversed().toInt()
    }

}