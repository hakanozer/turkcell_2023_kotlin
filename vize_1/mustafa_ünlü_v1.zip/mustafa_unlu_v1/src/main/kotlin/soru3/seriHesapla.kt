package soru3

class SeriHesapla {
    fun calculate(n: Int): Double {
        var sum = 0.0
        var factoriyel = 1

        for (number in 1..n) {
            factoriyel *= number
            sum += number.toDouble() / factoriyel
        }
       return sum
    }
}