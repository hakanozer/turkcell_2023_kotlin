package soru4

class CalcutalePrimeNums {
    fun getSumOfAllPrimes(n: Int): Int {
        var sum = 0
        for (i in 2..n) {
            if (isPrime(i)) {
                sum += i
            }
        }
        return sum
    }

    private fun isPrime(number: Int): Boolean {
        if (number <= 1) {
            return false
        }
        for (i in 2 ..  number-1) {
            if (number % i == 0) {
                return false
            }
        }
        return true
    }
}
