package soru5

fun isPrime(number: Int): Boolean {
    if (number <= 1) {
        return false
    }
    for (i in 2 ..  number-1) {
        if (number % i == 0) {
            return false
        }
    }
    return true
}
