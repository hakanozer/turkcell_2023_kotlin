package soru6

class GenelMudur(private val genelMudurMaas: Int, private val mesai: Int) : Personel() {

    override fun maasHesapla(): Double {
        return genelMudurMaas + mesai * 0.8
    }
}