package soru6

class Memur(private val memurMaas: Int, private val mesai: Int) : Personel() {


    override fun maasHesapla(): Double {
        return memurMaas + mesai * 0.3
    }
}
