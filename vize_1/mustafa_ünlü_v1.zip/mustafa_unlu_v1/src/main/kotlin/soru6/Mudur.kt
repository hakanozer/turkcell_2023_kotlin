package soru6

class Mudur(private val mudurMaas: Int, private val mesai: Int) : Personel() {

    override fun maasHesapla(): Double {
        return mudurMaas + mesai * 0.6
    }
}