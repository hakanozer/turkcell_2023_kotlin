package soru6

abstract class Personel {
    abstract fun maasHesapla() : Double
}