package soru7

/**
 *                              Class Tanimi
 *  Classlar object oriented programlamanin temel yapilarindan biridir.
 *  Gercek hayatimizdan herhangi bir nesneyi classlar araciligi ile programlarimiza aktarabiliriz.
 *  Classlar bir nesnenin ozelliklerini ve davranislarini tanimladigimiz yapilardir.
 *  Class icinde nesnenin ozelliklerini property olarak, davranislarini ise method olarak tanimlariz.
 *  Her class bir nesneyi temsil eder. Nesnenin turu sahip oldugu classdir.
 *  Mesela bir A class'i varsa bu class'dan olusturulan her nesne A class'i tipindedir.
 *  Bu yuzden classlari programlarimizda siklikla kullaniriz. Kullanmaliyizda.
 *  Classlar interface'lerden, open classlardan ve abstract classlardan inherit edilebilir.
 */

/**
 *                             Object Tanimi
 * Objectler classlardan olusturulan nesnelerdir.
 * Objectler classlarin instance'laridir, classlarin ozelliklerini ve davranislarini icerir.
 * Mesela bir A class' i varsa bu class'dan val a = A() seklinde bir nesne olusturabiliriz.
 * Buradaki nesne a objectidir. a objecti A class'indan olusturulmustur.
 * Programlarimizda objectler araciligi ile classlarin ozelliklerini ve davranislarini kullanabiliriz.
 * A class'i icinde bir method varsa bu methodu objectler araciligi ile cagirabiliriz.
 * Veya bir public bir property varsa bu propertye objectler araciligi ile erisebiliriz.
 * Kisaca objectler classlarin tipindeki nesnelerdir.
 */

/**                          Abstract Class Tanimi
 * Child classlarda yapilmasini zorunlu olarak koydugumuz yapilari barindirir..
 * Bu sayede child classlarda fazla kod yazmaktan bizi kurtarir.
 * Abstract classlarin icinde; abstract functionlar(body si olmaz) yazilabilir.
 * Abstract class inherit alabilen classdir. Child classlar abstract classlari inherit edebilir.
 * abstract olarak yazilmis class a yeni eklenen tum abstract yapilar child classlarda override edilmek zorundadir.,
 * Abstract classlarin objectleri olusturulamaz.
 * Base classlar bu yuzden abstract yapilir ki instance olusturulamasin. Projenin herhangi bir yerinde anlami degistirilmesin diye.
 * Abstract classlarda yazilan abstract fonksiyonlar, implemente eden classta override ederken, fonksiyonlarin imzalari birebir ayni olmak zorundadir.
 * Abstract classlari programlarimizda kullanmamizin sebebi ; kod tekrarini engellemek, kodun okunabilirligini artirmak ve
 polimorfizmi saglamaktir.
 * Abstract classlar ozunde class olduklari icin class davranislarina sahiptirler.
 */

/**                          Interface Tanimi
 * Interfaceler classlardan olusturulamazlar. Interfaceler classlardan inherit edilemezler.
 * Classlar interfaceleri implement ederler.
 * Classlarin kullanacagi template yapi sunarlar.
 * Interfacelerde tanimladigimiz fonksiyonlari implemente eden classlar override etmek zorundadir.
 * Interfacelerin objectleri olusturulamaz.
 * Interfaceler classlarimiza yetenek kazandirir.
 * Ornek olarak OnclickListener interface'i implement ettigimiz classimiza click etme yetenegi kazandirir.
 * Interfaceleri programlarimizda siklikla kullaniriz.
 *
 */
