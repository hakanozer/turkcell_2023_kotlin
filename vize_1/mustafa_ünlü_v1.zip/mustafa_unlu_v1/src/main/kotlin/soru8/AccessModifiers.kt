package soru8

/**     Access Modifiers Tanimlari
 * Kotlinde access modifierlar ; protected private public internal 4 farkli cesit vardir;
 * private; kendi class i veya yazildigi kt dosyasi disindan erisime izin vermez.
 * public; heryerden erisilir
 * protected; kendi classinda ve  miras alan classlar kullanabilir. Haricinde kullanilamaz.
 * internal; sadece kendi package/module icinde erisilir.
 *
 * Ayrica access modifierlarin kullanim amaci encapsulation saglamaktir.
 * Encapsulation ile classimiza disardan erisimi kisitlariz ve access modifierlar araciligi ile bunu yapariz.
 * Classlarimiza veya diger yapilarimiza erisimi access modifierlar ile belirleriz.
 *
 */