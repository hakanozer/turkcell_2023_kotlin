package com.orhanucar.orhan_ucar_v1.IkıncıSoru

interface Reverseable {
    fun reverse(): String
}