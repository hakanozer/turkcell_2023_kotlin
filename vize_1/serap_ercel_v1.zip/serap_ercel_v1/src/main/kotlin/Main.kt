import soru1.Soru1
import soru2.Soru2
import soru3.Soru3
import soru4.Soru4
import soru5.Soru5
import soru6.GenelMudur
import soru6.Memur
import soru6.Mudur

fun main(args: Array<String>) {

    println("--- SORU 1 ---")
    val soru1 : Soru1 = Soru1()
    soru1.basamakToplamiBul(123)

    println("--- SORU 2 ---")
    val soru2 : Soru2 = Soru2()
    soru2.terstenYazdir(123)

    println("--- SORU 3 ---")
    val soru3 :Soru3 = Soru3()
    soru3.seriToplamiBul(3)

    println("--- SORU 4 ---")
    val soru4 : Soru4 = Soru4()
    soru4.getSumOfAllPrimes(5)

    println("--- SORU 5 ---")
    val soru5 : Soru5 = Soru5()
    println("Asal mı? ${soru5.isPrime(5)}")

    println("--- SORU 6 ---")
    val memur: Memur = Memur()
    val memurMaas = memur.maasHesapla(20)
    println("Memur maas: $memurMaas")

    val mudur: Mudur = Mudur()
    val mudurMaas = mudur.maasHesapla(3)
    println("Müdür maas: $mudurMaas")

    val genelMudur: GenelMudur = GenelMudur()
    val genelMudurMaas = genelMudur.maasHesapla(3)
    println("Genel Müdür maas: $genelMudurMaas")




}