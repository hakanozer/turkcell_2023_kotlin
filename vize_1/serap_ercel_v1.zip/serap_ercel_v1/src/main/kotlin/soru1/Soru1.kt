package soru1

/*
1. Kullanıcıdan 3 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Basamaklarının Toplamını
Yazdırıyorsunuz
Örnek :
Sayı Girin : 245
2 + 4 + 5 = 11
 */

class Soru1 {
    fun basamakToplamiBul(sayi: Int){

        if (sayi in 100..999) {
            val birler = sayi % 10
            val onlar = (sayi / 10) % 10
            val yuzler = sayi / 100

            val toplam = birler + onlar + yuzler

            println("Basamakların toplamı: $toplam")

        } else {
            println("Sayı üç haneli değil!")
        }
    }
}