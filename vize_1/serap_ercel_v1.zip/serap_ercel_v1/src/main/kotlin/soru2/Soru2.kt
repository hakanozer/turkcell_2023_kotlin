package soru2

/*
2. Kullanıcıdan 3 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Rakamlarını Tersten Yazdırıyorsunuz
Örnek :
Sayı Girin : 743
347
 */

class Soru2 {
    fun terstenYazdir(sayi: Int){
        val birler = sayi % 10
        val onlar= (sayi / 10) % 10
        val yuzler = sayi / 100

        println("Sayının tersten yazılmış hali: $birler$onlar$yuzler")
    }
}