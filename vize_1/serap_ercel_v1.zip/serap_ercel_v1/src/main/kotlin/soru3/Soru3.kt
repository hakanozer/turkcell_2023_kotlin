package soru3

/*
3. Seri Toplami Kullanıcıdan Bir N Sayısı Alıyorsunuz. 1'den N'e Kadar Aşağıdaki Seriyi
Hesaplayan Bir Uygulama Yapın
1 + 1/1! + 2/2! + 3/3! + 4/4! + .... + n/n!
 */

class Soru3 {

    fun seriToplamiBul(n: Int) {
        var toplam = 0.0
        var faktoriyel = 1.0
        for (i in 1..n) {
            faktoriyel *= i
            toplam = i + i / faktoriyel
        }
        println("Girdiğiniz sayıya göre seri toplamı: $toplam")
    }
}