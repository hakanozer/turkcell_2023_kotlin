package soru4

/*
4. getSumOfAllPrimes adında bir method olusturun bu methodunuza parametre olarak bir n
sayısı gönderin method, 1'den n'e kadar (n dahil) sayılar arasından, asal sayilari bulup
bunların toplamını döndürecek asal sayi bulmak için staFc boolean isPrime(int number)
şeklinde ayri bir method oluşturup, getSumOfAllPrimes methodunun içinde uygun şekilde
kullanın.
 */

class Soru4 {

    fun getSumOfAllPrimes(n: Int){
        var toplam = 0
        for (i in 1.. n){
            if (isPrime(i)){
                toplam += i
            }
        }
        println("$n sayısına kadar olan asal sayıların toplamı: $toplam")
    }

    private fun isPrime(number: Int) : Boolean{
        if (number < 2) {
            return false
        }
        for (i in 2 until number) {
            if (number % i == 0) {
                return false
            }
        }
        return true
    }
}