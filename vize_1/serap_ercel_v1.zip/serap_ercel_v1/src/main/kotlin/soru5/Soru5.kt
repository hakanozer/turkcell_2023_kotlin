package soru5

/*
5. Parametre olarak aldığı sayıyı asal mı diye kontrol edip, sayı asal ise true, değilse false
döndüren isPrime methodunu yazın.
 */

class Soru5 {

    fun isPrime(number: Int) : Boolean{
        if (number < 2) {
            return false
        }
        for (i in 2 until number) {
            if (number % i == 0) {
                return false
            }
        }
        return true
    }
}