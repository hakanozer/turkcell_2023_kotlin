package soru6

class GenelMudur : Personel {
    var maas = 5000

    override fun maasHesapla(ekSaat: Int): Double {
        return maas + ekSaatUcretiHesapla(ekSaat)
    }

    private fun ekSaatUcretiHesapla(ekSaat: Int): Double {
        return ekSaat * 0.8
    }
}