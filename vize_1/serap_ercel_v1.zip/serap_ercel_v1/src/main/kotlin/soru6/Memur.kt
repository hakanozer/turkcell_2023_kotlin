package soru6

class Memur : Personel {
    var maas = 1000

    override fun maasHesapla(ekSaat: Int): Double {
        return maas + ekSaatUcretiHesapla(ekSaat)
    }

    private fun ekSaatUcretiHesapla(ekSaat: Int): Double {
        return ekSaat * 0.3
    }
}