package soru6

class Mudur : Personel {
    var maas = 3000

    override fun maasHesapla(ekSaat: Int): Double {
        return maas + ekSaatUcretiHesapla(ekSaat)
    }

    private fun ekSaatUcretiHesapla(ekSaat: Int): Double {
        return ekSaat * 0.6
    }
}