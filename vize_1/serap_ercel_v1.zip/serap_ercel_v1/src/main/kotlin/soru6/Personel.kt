package soru6

interface Personel {

    fun maasHesapla(ekSaat: Int): Double

}