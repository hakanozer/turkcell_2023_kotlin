package soru7

/*
7. Class, Object , Abstract, Interface nedir açıklayınız.
 */

class Soru7 {

    /*

    Class (Sınıf): Nesne yönelimli programlamada, nesne oluşturmak için,
    özelliklere ve metotlara sahip olan bir nevi şablonlardır.
    Bir sınıftan birden fazla nesne başka bir deyişle örnek oluşturabiliriz.

    Object (Nesne): Nesne yönelimli programlamada, bir sınıfın özellikleri ve
    metotlarını taşıyan veri yapısıdır.

    Abstract (Soyut): Nesne yönelimli programlamada, somut örnek oluşturmak için
    bir şablon niteliği taşır. Soyut sınıflar veya metodlar olabilir. Bu soyut
    yapılardan doğrudan nesne oluşturulamaz. Bir sınıf Abstract olarak belirlenmişse
    soyut metotlara ve gövdeli somut metodlara sahip olabilir.
    Miras alma yoluyla soyut metodlarını override ederek somutlaştırabiliriz. Bu sayede
    somut nesneler oluşturabiliriz.

    Interface (Arayüz): Nesne yönelimli programlamada, tamamen soyut metotlar içeren bir
    şablonu oluşturmak için kullanılır. Sınıfın yapısını belirlemek için hazırlanır.
    Birden fazla sınıf implemente edebilir ancak bütün soyut metotları override etmelidir.

     */
}