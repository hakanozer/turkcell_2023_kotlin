package soru8

/*
8. Erişim belirteçleri (Access Modifiers) ne iş yapar açıklayınız.
 */

class Soru8 {

    /*
    Public: Bir metot veya özelliğin her yerden erişilebilir olmasını ifade eder.

    Private: Bir metot veya özelliğin yalnızca aynı sınıf içinden erişilebilmesini ifade eder.

    Protected: Bir metot veya özelliğin kendi sınıfı veya alt sınıflarından erişilebilmesini ifade eder.

    Internal: Bir metot veya özelliğin sadece kendi modülü içindeki sınıflardan erişilebilmesini ifade eder.

     */
}