
rootProject.name = "yakup_yigit_yesilada_v1"

