class Answer1 (var num : Int){

    fun sumOfDigits( ) : Int{
        var total: Int = 0
        while (num > 0) {
            total += num % 10
            num /= 10
        }
        return total
    }
}