class Answer2(var num : Int) {


    fun reverseNumberDigits() : Int{
        var reversedNum : Int = 0
        while(num != 0)
        {
            reversedNum *= 10;
            reversedNum += num % 10;
            num /= 10;
        }

        return reversedNum
    }
}