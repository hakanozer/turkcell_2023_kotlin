class Answer3 (var num : Int){

    fun calculateSerie(){
        var sum = 1.0
        for(i in 1..num){
            var fact = 1
            for(a in 1..i){
                fact *= a
            }

            sum += i.toDouble() / fact.toDouble()
        }

        println("Sonuç: $sum")
    }

}