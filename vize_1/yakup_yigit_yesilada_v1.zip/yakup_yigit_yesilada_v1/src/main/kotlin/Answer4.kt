open class Answer4() {

    fun getSumOfAllPrimes(num : Int) : Int{

        var total : Int = 0

        for(i in 2..num){
            if(isPrime(i)){
                total += i
            }
        }

        return total
    }

    open fun isPrime(num : Int) : Boolean{
        var isPrime : Boolean = true
        for(i in 2..(num/2)){
            if(num % i == 0){
                isPrime = false
                break
            }
        }
        return isPrime
    }
}