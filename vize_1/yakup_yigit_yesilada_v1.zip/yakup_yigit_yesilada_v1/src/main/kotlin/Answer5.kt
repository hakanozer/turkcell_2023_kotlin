 class Answer5( ) : Answer4() {

}