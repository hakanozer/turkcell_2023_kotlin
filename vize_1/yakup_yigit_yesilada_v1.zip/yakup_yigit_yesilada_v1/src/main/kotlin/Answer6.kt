class Answer6 {


}