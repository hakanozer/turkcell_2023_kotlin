class Answer7 {

    /*
    A - Class Nedir?

    1. Class, nesne yönelimli programlamada programları parçalara bölmeye yarayan ve karmaşıklığın azalmasını sağlayan
       bir yapı taşıdır.

    2. Bir sınıfta hem metodlar hem de veriler aynı anda birbiriyle ilişki içerisinde bulunabilir.

    3. Sınıflar, kendisi üzerinden oluşturulacak nesneler için bazı üyeler içermelidir. Bu üyeler; field'lar,
       metodlar, constructor'lar, property'ler, event'ler, delegate'ler vb.. dir.

    4. Sınıflar, nesneler için bir şablon görevi görmektedirler. Yani nesnelerin durumlarıyla ilgili işlem ve özellikleri
       tanımlarlar.

    5. Bir sınıf üzerinden nesne üretildiğinde ilk önce varsa değişkenler için bellekte yer tutulur. Daha sonra
       init bloğu çalışır ve sonrasında constructor çalışır.



    Bir sınıf oluşturma örneği:

    class ExampleClass (var x : Int) --> Primary Constructor{

        init{}

        //secondary constructor
        constructor(){

        }
        var property : Int = 0

        fun method(){}

    }

    Not: Primary ve Secondary Constructor örnekte tek seferde gösterilebilmesi için aynı class içerisinde yazılmıştır.


    B - Object Nedir?

    Object (nesne) bir sınıfa ait, o sınıfı temsil eden yapıdır.

    Örneğin yukarıda verdiğimiz class örneğini baz alarak örnek verecek olursak şu şekilde bir nesne oluşturabiliriz:

    var obj = ExampleClass (55)

    Oluşturduğumuz bu nesne, class içerisinde public olan ögelere ulaşmamızı ve bu ögelerle işlemler yapmamızı sağlar.

    C - Interface Nedir?

    1. Interface'ler bir sınıf niteliği taşımazlar, bir sınıfın yeteneklerini tutan bir sözleşme olarak düşünülebilirler.

    2. Sınıfların ortak işlemleri olduğunda bunlar interface'ler ile tutulur ve ilgili sınıflar tarafından impelement edilir.

    3. Interface'ler gövdesiz metodlardan oluşan sınıflardır.

    4. Interface'ler constructor ve init bloklarını içermez veya değer tutmazlar

    5. Bir interface'i implement eden sınıf onun tüm metodlarını override etmek zorundadır

    6. Interface'lerin instance'ları yaratılamaz

    Bir interface örneği inceleyelim:

    interface IUser {
        fun userName() : String
    }

    class User : User{
        override fun userName(){}
    }

    D - Abstract Nedir?

    1. Abstract sınıflar, interface'lerin yapabildiği her şeyi yapmakla beraber ek olarak gövdeli metodlar da içerebilirler

    2. Bir sınıf sadece bir extend işlemi yapabilir ve bu yüzden interface'lere nazaran daha geniş çaplı işlemleri
       yapmak için kullanılırlar.

    3. Abstract sınıflar init bloğu ve constructor yapılarına sahiptirler

    4. Abstract sınıfların instance'ları yaratılamaz

    5. Abstract sınıf içerisindeki "abstract" anahtar kelimesiyle tanımlanmış her ögenin kendisini extend eden sınıf
       tarafından override edilmesi gerekir.

     Bir abstract sınıf örneği yapacak olursak:

     abstract class ExampleClass {
        abstract fun printName()
        open fun printName2(){}

     }

     class MainClass : ExampleClass(){
        override fun printName() {
         print("override etme işlemi zorunlu")
        }
     }

     * Yukarıda 93. satırda bulunan printName2 metodu open anahtar kelimesi içerdiği için override edilmek zorunda
       değildir, isteğe bağlı olarak edilebilir ancak printName fonksiyonu override edilmek zorundadır.

     */


}