class Answer8 {

    private var num : Int = 19

    /*
     Erişim belirteçleri (Access Modifiers) Ne iş yapar?

     1. Erişim belirteçleri sınıflara, nesnelere, constructor'lara, fonksiyonlara ve değişkenlere erişilmesi konusunda
        kısıt belirlemek için kullanılırlar.

     2. Bir sınıfın,fonksiyonun veya değişkenin başında herhangi bir erişim belirleyici tanımlanmazsa default olarak
        public atanır yani her yerden erişilebilir.

      1. Public -> Her yerden erişilebilir
      2. Private -> Sadece tanımlandığı sınıftan erişilebilir
      3. Protected -> Tanımlandığı sınıftan ve o sınıftan miras alan diğer sınıflar tarafından erişilebilir
      4. internal -> Yalnızca aynı modül içerisinden erişilebilir
     */
}

