import answer6.Employee
import answer6.GeneralManager
import answer6.Manager
import answer6.Officer

fun main(args: Array<String>) {

    //Answer1
    var answer1 = Answer1(245)
    println(answer1.sumOfDigits())

    println("**********************")

    //Answer2
    var answer2 = Answer2(1234)
    println(answer2.reverseNumberDigits())

    println("**********************")

    //Answer3
    var answer3 = Answer3(5)
    answer3.calculateSerie()

    println("**********************")

    //Answer4
    var answer4 = Answer4()
    println("Toplam: ${answer4.getSumOfAllPrimes(20)}")

    println("**********************")

    //Answer5
    var answer5 = Answer5()
    if(answer5.isPrime(49)){
        println("Sayı Asaldır")
    }else{
        println("Sayı Asal Değildir")
    }

    println("**********************")

    //Answer6
    var officer : Employee = Officer(1000.0)
    println("Memur için sonuç: ${officer.calculateTotalSalary(5)}")

    var manager : Employee = Manager(3000.0)
    println("Müdür için sonuç: ${manager.calculateTotalSalary(16)}")

    var generalManager : Employee = GeneralManager(5000.0)
    println("Genel Müdür için sonuç: ${generalManager.calculateTotalSalary(47)}")

    //7. ve 8. Soruların yanıtları kendilerine ait dosyalarda mevcuttur.



}