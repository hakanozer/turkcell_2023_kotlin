package answer6

open class Employee(var salary : Double) : IEmployee{
    override fun calculateTotalSalary(additionalHour: Int) : Double {
        return salary
    }
}
