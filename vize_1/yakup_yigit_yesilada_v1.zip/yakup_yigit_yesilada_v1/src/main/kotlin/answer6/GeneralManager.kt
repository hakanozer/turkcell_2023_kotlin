package answer6

class GeneralManager(salary : Double) : Employee(salary) {
    override fun calculateTotalSalary(additionalHour: Int): Double {
        return salary + (additionalHour * 0.8)
    }
}
