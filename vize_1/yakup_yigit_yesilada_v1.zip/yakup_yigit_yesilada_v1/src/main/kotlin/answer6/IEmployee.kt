package answer6

interface IEmployee {

    fun calculateTotalSalary(additionalHour : Int) : Double
}