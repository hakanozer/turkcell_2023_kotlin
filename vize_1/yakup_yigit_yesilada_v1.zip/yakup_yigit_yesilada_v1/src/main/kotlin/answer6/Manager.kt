package answer6

class Manager(salary : Double) : Employee(salary) {
    override fun calculateTotalSalary(additionalHour: Int): Double {
        return salary + (additionalHour * 0.6)
    }
}
