package com.example.vize2

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface DummyService {
    @GET("api/products")
    fun getProducts(): Call<List<Product>>

    @GET("api/product/{id}")
    fun getProductDetails(@Path("id") productId: Int): Call<Product>
}


