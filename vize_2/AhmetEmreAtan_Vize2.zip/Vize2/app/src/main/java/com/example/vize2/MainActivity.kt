package com.example.vize2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Adapter
import android.widget.ListAdapter
import android.widget.ListView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listView)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://dummyjson.com/products/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val productService = retrofit.create(DummyService::class.java)

        productService.getProducts().enqueue(object : Callback<List<Product>> {
            override fun onResponse(call: Call<List<Product>>, response: Response<List<Product>>) {
                if (response.isSuccessful) {
                    val products = response.body()
                    if (!products.isNullOrEmpty()) {
                        adapter = ProductAdapter(this@MainActivity, products)
                        listView.adapter = adapter
                    }
                }
            }

            override fun onFailure(call: Call<List<Product>>, t: Throwable) {
                Log.e("MainActivity", "API request failed", t)
            }
        })

        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedProduct = adapter.getItem(position)
            selectedProduct?.let {
                getProductDetails(it.id)
            }
        }
    }

    private fun getProductDetails(productId: Int) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://dummyjson.com/products/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val productService = retrofit.create(DummyService::class.java)

        productService.getProductDetails(productId).enqueue(object : Callback<Product> {
            override fun onResponse(call: Call<Product>, response: Response<Product>) {
                if (response.isSuccessful) {
                    val product = response.body()
                    product?.let {
                        showProductDetails(product)
                    }
                }
            }

            override fun onFailure(call: Call<Product>, t: Throwable) {
                Log.e("MainActivity", "API request failed", t)
            }
        })
    }

    private fun showProductDetails(product: Product) {
    }
}
