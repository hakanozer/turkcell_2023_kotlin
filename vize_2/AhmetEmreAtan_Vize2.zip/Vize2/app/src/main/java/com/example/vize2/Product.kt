package com.example.vize2

data class Product(val id: Int, val name: String, val imageUrl: String, val price: Double)
