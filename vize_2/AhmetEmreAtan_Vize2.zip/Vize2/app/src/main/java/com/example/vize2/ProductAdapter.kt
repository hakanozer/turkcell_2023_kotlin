package com.example.vize2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class ProductAdapter(
    private val context: Context,
    private val products: List<Product>
) : ArrayAdapter<Product>(context, 0, products) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var itemView = convertView
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.list_item_product, parent, false)
        }

        val product = products[position]

        val imageView = itemView!!.findViewById<ImageView>(R.id.imageView)
        val nameTextView = itemView.findViewById<TextView>(R.id.nameTextView)
        val priceTextView = itemView.findViewById<TextView>(R.id.priceTextView)

        Glide.with(context)
            .load(product.imageUrl)
            .into(imageView)

        nameTextView.text = product.name
        priceTextView.text = "${product.price} $"

        return itemView
    }
}
