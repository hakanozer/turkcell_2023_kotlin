package com.works.visa_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import com.works.visa_2.configs.ApiClient
import com.works.visa_2.models.CartRequest
import com.works.visa_2.services.DummyService
import retrofit2.Call
import retrofit2.Response
import javax.security.auth.callback.Callback

class OrderListActivity : AppCompatActivity() {
    lateinit var orderList : ListView
    lateinit var dummyService3 : DummyService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_list)

        orderList = findViewById(R.id.orderList)

        dummyService3 = ApiClient.getClient().create(DummyService::class.java)

        dummyService3.getAllCarts(1).enqueue(object : retrofit2.Callback<CartRequest>{
            override fun onResponse(call: Call<CartRequest>, response: Response<CartRequest>) {
                val datas = response.body()
                Log.d("datas",datas!!.products.toString())
            }

            override fun onFailure(call: Call<CartRequest>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })

    }
}