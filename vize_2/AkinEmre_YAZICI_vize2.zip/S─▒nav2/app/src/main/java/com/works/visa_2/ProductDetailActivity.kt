package com.works.visa_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.works.visa_2.configs.ApiClient
import com.works.visa_2.models.CartRequest
import com.works.visa_2.models.Product
import com.works.visa_2.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductDetailActivity : AppCompatActivity() {


    lateinit var txtTitleDetailProduct: TextView
    lateinit var txtDescDetailProduct: TextView
    lateinit var txtPriceProductDetail: TextView
    lateinit var txtDiscPDetailProduct: TextView
    lateinit var txtRatingDetailProduct: TextView
    lateinit var txtStockDetailProduct: TextView
    lateinit var txtBrandDetailProduct: TextView
    lateinit var txtCategoryDetailProduct: TextView
    lateinit var ImgDetailProduct: ImageView
    lateinit var btnOrder: Button

    lateinit var dummyService2: DummyService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        dummyService2 = ApiClient.getClient().create(DummyService::class.java)

        txtTitleDetailProduct = findViewById(R.id.txtTitleDetailProduct)
        txtDescDetailProduct = findViewById(R.id.txtDescDetailProduct)
        txtPriceProductDetail = findViewById(R.id.txtPriceProductDetail)
        txtDiscPDetailProduct = findViewById(R.id.txtDiscPDetailProduct)
        txtRatingDetailProduct = findViewById(R.id.txtRatingDetailProduct)
        txtStockDetailProduct = findViewById(R.id.txtStockDetailProduct)
        txtBrandDetailProduct = findViewById(R.id.txtBrandDetailProduct)
        txtCategoryDetailProduct = findViewById(R.id.txtCategoryDetailProduct)
        ImgDetailProduct = findViewById(R.id.ImgDetailProduct)
        btnOrder = findViewById(R.id.btnOrder)

        txtTitleDetailProduct.text = ProductsListActivity.selectedProduct?.title
        txtDescDetailProduct.text = ProductsListActivity.selectedProduct?.description
        txtPriceProductDetail.text = "Price: ${ProductsListActivity.selectedProduct?.price}"
        txtDiscPDetailProduct.text = "Discount: %${ProductsListActivity.selectedProduct?.discountPercentage}"
        txtRatingDetailProduct.text = "Rating: 5/${ProductsListActivity.selectedProduct?.rating}"
        txtStockDetailProduct.text = "Stock: ${ProductsListActivity.selectedProduct?.stock}"
        txtBrandDetailProduct.text = "Brand: ${ProductsListActivity.selectedProduct?.brand}"
        txtCategoryDetailProduct.text = "Category: ${ProductsListActivity.selectedProduct?.category}"
        Glide.with(this).load(ProductsListActivity.selectedProduct?.images?.get(0)).into(ImgDetailProduct)

        btnOrder.setOnClickListener {
            val list = mutableListOf<Product>()
            val product = Product(1,1)

            list.add(product)
            val cartRequest = CartRequest(1, list)
            dummyService2.addCart(cartRequest).enqueue(object : Callback<Product> {


                override fun onResponse(call: Call<Product>, response: Response<Product>) {
                    val datas = response.body()
                    Log.d("status",datas.toString())
                }

                override fun onFailure(call: Call<Product>, t: Throwable) {
                    Log.e("error",t.toString())
                }

            })
        }
    }
}
