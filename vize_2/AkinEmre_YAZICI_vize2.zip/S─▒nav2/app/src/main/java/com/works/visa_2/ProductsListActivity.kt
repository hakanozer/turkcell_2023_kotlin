package com.works.visa_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import com.works.visa_2.adapter.CustomProductsListAdapter
import com.works.visa_2.configs.ApiClient
import com.works.visa_2.models.CartRequest
import com.works.visa_2.models.DummyProducts
import com.works.visa_2.models.singleProduct
import com.works.visa_2.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductsListActivity : AppCompatActivity() {

    lateinit var dummyService1: DummyService
    lateinit var productsListView: ListView
    lateinit var btnShowOrder: Button

    companion object Product {
        var selectedProduct: com.works.visa_2.models.singleProduct? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products_list)

        productsListView = findViewById(R.id.productsListView)
        btnShowOrder = findViewById(R.id.btnShowOrder)

        dummyService1 = ApiClient.getClient().create(DummyService::class.java)
        dummyService1.Products().enqueue(object : Callback<DummyProducts> {
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val datas = response.body()
                val adapter = CustomProductsListAdapter(this@ProductsListActivity, datas!!.products)
                productsListView.adapter = adapter
            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                Log.e("dummyService", t.toString())
            }

        })

        productsListView.setOnItemClickListener { adapterView, view, i, l ->
            val selectedItem = productsListView.getItemAtPosition(i) as singleProduct
            selectedProduct = selectedItem
            val intent = Intent(this, ProductDetailActivity::class.java)
            startActivity(intent)
        }

        btnShowOrder.setOnClickListener {

            val intent = Intent(this@ProductsListActivity, OrderListActivity::class.java)
            startActivity(intent)


        }

    }


}


