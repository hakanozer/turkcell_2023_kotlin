package com.works.visa_2.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.works.visa_2.R
import com.works.visa_2.models.singleProduct

class CustomProductsListAdapter(private val context : Activity, private val list : List<singleProduct>)
    : ArrayAdapter<singleProduct>(context,R.layout.products_list, list)
{
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.products_list,null,true)

        val r_Title = rootView.findViewById<TextView>(R.id.r_Title)
        val r_Price = rootView.findViewById<TextView>(R.id.r_Price)
        val r_Rating = rootView.findViewById<TextView>(R.id.r_Rating)

        val r_Image = rootView.findViewById<ImageView>(R.id.r_Img)

        val products = list.get(position)
        r_Title.text = products.title
        r_Price.text = "Price : " + products.price.toString()
        val text  = "Rating : 5/" + products.rating.toString()
        r_Rating.text = text

        Glide.with(context).load(products.thumbnail).into(r_Image)

        return rootView
    }
}