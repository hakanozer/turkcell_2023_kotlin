package com.works.visa_2.models

data class CartRequest(
    val userId:Int = 1,
    val products: List<Product>
)

data class Product (
    val id: Int ,
    val quantity: Int =1
)

