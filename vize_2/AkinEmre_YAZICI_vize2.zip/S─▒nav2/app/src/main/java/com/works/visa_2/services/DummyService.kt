package com.works.visa_2.services

import com.works.visa_2.models.*
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface DummyService
{
    @GET("products")
    fun Products(): Call<DummyProducts>

    @GET("products/{id}")
    fun getProduct(@Path("id") id : Int): Call<singleProduct>

    @POST("carts/add")
    fun addCart(@Body request: CartRequest): Call<Product>

    @GET("carts/{id}")
    fun getAllCarts(@Path("id") id : Int): Call<CartRequest>


}