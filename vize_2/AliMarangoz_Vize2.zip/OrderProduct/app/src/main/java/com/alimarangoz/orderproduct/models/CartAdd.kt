package com.alimarangoz.orderproduct.models

data class CartAdd (val userId : Int,val products : ArrayList<ProductCartAdd>)