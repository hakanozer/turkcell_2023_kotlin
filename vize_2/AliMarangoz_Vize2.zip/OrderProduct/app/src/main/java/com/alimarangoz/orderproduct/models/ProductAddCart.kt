package com.alimarangoz.orderproduct.models

data class ProductCartAdd(val id: Long, val quantity : Int)