package com.alimarangoz.orderproduct.models

data class ProductList(

    val products: List<Product>
)
