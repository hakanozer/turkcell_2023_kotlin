package com.alierdemalkoc.orderapp.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.alierdemalkoc.orderapp.R
import com.alierdemalkoc.orderapp.model.Carts
import com.alierdemalkoc.orderapp.model.Products
import com.bumptech.glide.Glide

class OrdersCustomAdapter (private val context: Activity, private val list: List<Carts>) : ArrayAdapter<Carts>(context, R.layout.custom_list_item1, list)
{
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item1, null, true)

        val r_cartID = rootView.findViewById<TextView>(R.id.r_cartID)
        val r_productId = rootView.findViewById<TextView>(R.id.r_productId)

        val cart = list.get(position)

        r_cartID.text = cart.id.toString()
        r_productId.text = "${cart.products.get(0).id}"

        return rootView
    }
}