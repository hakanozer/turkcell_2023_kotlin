package com.alierdemalkoc.orderapp.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.alierdemalkoc.orderapp.R
import com.alierdemalkoc.orderapp.model.Products
import com.bumptech.glide.Glide

class ProductsCustomAdapter(private val context: Activity, private val list: List<Products>) : ArrayAdapter<Products>(context, R.layout.custom_list_item, list)
{
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)

        val r_title = rootView.findViewById<TextView>(R.id.r_title)
        val r_price = rootView.findViewById<TextView>(R.id.r_price)
        val r_rating = rootView.findViewById<TextView>(R.id.r_rating)
        val r_image = rootView.findViewById<ImageView>(R.id.r_image)

        val product = list.get(position)

        r_title.text = product.title
        r_price.text = "${product.price}"
        r_rating.text = "${product.rating}"
        Glide.with(rootView)
            .load(product.thumbnail)
            .centerCrop()
            .into(r_image)

        return rootView
    }
}