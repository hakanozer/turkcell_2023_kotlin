package com.alierdemalkoc.orderapp.model

data class Carts (
    val id: Long,
    val products: List<Products>,
    val total: Long,
    val discountedTotal: Long,
    val userId: Long,
    val totalProducts: Long,
    val totalQuantity: Long,
)

