package com.alierdemalkoc.orderapp.model

data class Order(
    val userId: Int = 1,
    val quantity: Int = 1,
    val products: List<Products>
)
