package com.alierdemalkoc.orderapp.model

data class Products(
    val id: Long,
    val title: String,
    val description: String,
    val price: Long,
    val discountPercentage: Double,
    val rating: Double,
    val stock: Long,
    val brand: String,
    val category: String,
    val thumbnail: String,
    val images: List<String>
    )

data class DummyProducts (
    val products: List<Products>,
    val total: Long,
    val skip: Long,
    val limit: Long
)
