package com.alierdemalkoc.orderapp.service

import com.alierdemalkoc.orderapp.model.Carts
import com.alierdemalkoc.orderapp.model.DummyProducts
import com.alierdemalkoc.orderapp.model.Order
import com.alierdemalkoc.orderapp.model.Products
import retrofit2.Call
import retrofit2.http.*

interface DummyService{

    @GET("carts/{id}")
    fun singleCart(@Path("id") id: Long) : Call<Carts>

    @GET("products")
    fun getProducts(): Call<DummyProducts>

    @POST("carts/add")
    fun addCart(@Body order: Order): Call<Carts>

    @GET("products/{id}")
    fun singleProduct( @Path("id") id: Long) : Call<Products>
}