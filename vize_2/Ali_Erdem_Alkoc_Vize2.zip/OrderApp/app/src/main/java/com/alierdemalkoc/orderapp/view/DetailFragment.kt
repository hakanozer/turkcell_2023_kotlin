package com.alierdemalkoc.orderapp.view

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import com.alierdemalkoc.orderapp.R
import com.alierdemalkoc.orderapp.config.ApiClient
import com.alierdemalkoc.orderapp.databinding.FragmentDetailBinding
import com.alierdemalkoc.orderapp.model.Carts
import com.alierdemalkoc.orderapp.model.Order
import com.alierdemalkoc.orderapp.model.Products
import com.alierdemalkoc.orderapp.service.DummyService
import com.bumptech.glide.Glide
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailFragment : Fragment() {
    private var _binding : FragmentDetailBinding? = null
    private val binding get() = _binding!!

    lateinit var productTitle: TextView
    lateinit var productDetail: TextView
    lateinit var productPrice: TextView
    lateinit var productImage: ImageView
    lateinit var productRating: TextView
    lateinit var dummyService: DummyService
    var orderProducts = mutableListOf<Products>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        productDetail = binding.productDetail
        productPrice = binding.productPrice
        productRating = binding.productRating
        productTitle = binding.productTitle
        productImage = binding.productImage
        dummyService = ApiClient.getClient().create(DummyService::class.java)
        val id = arguments?.getLong("id")
        dummyService.singleProduct(id!!).enqueue(object: Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                val product = response.body()
                orderProducts.add(product!!)
                if (product != null) {
                    productTitle.text = product.title
                    productDetail.text = product.description
                    productPrice.text = product.price.toString()
                    productRating.text = product.rating.toString()
                    Glide.with(requireActivity())
                        .load(product.thumbnail)
                        .centerCrop()
                        .into(productImage)
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.d("Detail Error", t.toString())
            }

        })

        binding.orderButton.setOnClickListener {
            orderProducts.get(0)
            val order = Order(1,1, orderProducts)
            dummyService.addCart(order).enqueue(object: Callback<Carts>{
                override fun onResponse(call: Call<Carts>, response: Response<Carts>) {
                    if (response.isSuccessful){
                        val carts = response.body()
                        Log.d("cart", carts!!.id.toString())
                        findNavController().navigate(R.id.detailToProducts)
                    } else{
                        Log.d("response error", "response is not succesfull")
                    }

                }

                override fun onFailure(call: Call<Carts>, t: Throwable) {
                    Log.d("error", t.toString())
                }

            })
        }

    }
}