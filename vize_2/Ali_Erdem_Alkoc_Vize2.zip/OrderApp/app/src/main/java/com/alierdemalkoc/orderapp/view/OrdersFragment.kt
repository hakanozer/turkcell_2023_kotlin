package com.alierdemalkoc.orderapp.view

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import com.alierdemalkoc.orderapp.R
import com.alierdemalkoc.orderapp.adapter.OrdersCustomAdapter
import com.alierdemalkoc.orderapp.config.ApiClient
import com.alierdemalkoc.orderapp.databinding.FragmentOrdersBinding
import com.alierdemalkoc.orderapp.databinding.FragmentProductsBinding
import com.alierdemalkoc.orderapp.model.Carts
import com.alierdemalkoc.orderapp.model.Products
import com.alierdemalkoc.orderapp.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class OrdersFragment : Fragment() {
    private var _binding : FragmentOrdersBinding? = null
    private val binding get() = _binding!!

    lateinit var listView: ListView
    lateinit var dummyService: DummyService
    var cartList = mutableListOf<Carts>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentOrdersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listView = binding.ordersListView
        dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.singleCart(1).enqueue(object: Callback<Carts>{
            override fun onResponse(call: Call<Carts>, response: Response<Carts>) {
                if (response.isSuccessful){
                    val cart = response.body()
                    cartList.add(cart!!)
                    val customAdapter = OrdersCustomAdapter(requireActivity(), cartList)
                    listView.adapter = customAdapter
                } else{
                    Log.d("response error", "response error")
                }

            }

            override fun onFailure(call: Call<Carts>, t: Throwable) {
                Log.d("error", t.toString())
            }

        })
    }
}