package com.emirk.emirkarabeyvize2.model

data class JWTUser(
    val username: String,
    val password: String
)