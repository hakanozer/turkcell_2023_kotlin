package com.emirk.emirkarabeyvize2.model

data class ProductRequest(
    val id: Int,
    val quantity: Int
)