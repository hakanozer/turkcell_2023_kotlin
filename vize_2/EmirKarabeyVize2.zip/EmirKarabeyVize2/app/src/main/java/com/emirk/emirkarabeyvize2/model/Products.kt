package com.emirk.emirkarabeyvize2.model

data class Products(
    val products: List<Product>
)