package com.nsicyber.dummybuyapp

import com.nsicyber.dummyapp.models.ProductModel
import kotlin.properties.Delegates

object GeneralData {
   var cartItems: ArrayList<ProductModel> = arrayListOf()


    fun getCart(): ArrayList<ProductModel> {
      val uniqueProducts = ArrayList<ProductModel>()
      val seenIds = HashSet<Int>()

      for (product in cartItems) {
         if (product.id != null && !seenIds.contains(product.id)) {
            uniqueProducts.add(product)
            seenIds.add(product.id)
         } else if (product.id != null) {
            for (existingProduct in uniqueProducts) {
               if (existingProduct.id == product.id) {
                  existingProduct.quantity++
                  break
               }
            }
         }
      }

      return uniqueProducts
   }

   private fun onCartItemsChanged() {
      // Eğer cartItems değeri değiştiğinde yapılması gereken işlemleri burada gerçekleştir
   }
}
