package com.nsicyber.dummybuyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.nsicyber.dummybuyapp.databinding.ActivityMainBinding
import com.nsicyber.dummybuyapp.ui.CartFragment
import com.nsicyber.dummybuyapp.ui.OrdersFragment
import com.nsicyber.dummybuyapp.ui.ProductListFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val adapter = MyPagerAdapter(this)
        binding.viewPager.adapter = adapter

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = "Ürünler"
                1 -> tab.text = "Sepet"
                1 -> tab.text = "Siparişler"
            }
        }.attach()
    }




}

class MyPagerAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int = 3

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> MainFragment()
            1 -> CartFragment()
            2 -> OrdersFragment()
            else -> throw IndexOutOfBoundsException()
        }
    }
}