package com.nsicyber.dummybuyapp.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.nsicyber.dummybuyapp.R


class GalleryAdapter(private val myList: List<String>, private val context: Context) : BaseAdapter() {

    override fun getCount(): Int {
        return myList.size
    }

    override fun getItem(position: Int): Any {
        return myList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = LayoutInflater.from(context)
        val view = convertView ?: inflater.inflate(R.layout.gallery_item, parent, false)

        val currentItem = myList[position]
        val image = view.findViewById<ImageView>(R.id.imageView)
        Glide.with(context)
            .load(currentItem)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .into(image)

        return view
    }
}
