package com.nsicyber.dummybuyapp.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.nsicyber.deezerpractice.utils.Parser
import com.nsicyber.deezerpractice.utils.handleClick
import com.nsicyber.dummyapp.models.ProductModel
import com.nsicyber.dummybuyapp.R

class ProductListAdapter(private val dataList: ArrayList<ProductModel>, private val context: Context, var fragment: Fragment) : BaseAdapter() {
    override fun getCount(): Int {
        return dataList.size
    }
    fun clear() {
        dataList.clear()
        notifyDataSetChanged()
    }
    override fun getItem(position: Int): Any {
        return dataList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        val holder: ProductViewHolder

        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.product_item, parent, false)
            holder = ProductViewHolder(view, context,fragment)
            view.tag = holder
        } else {
            holder = view.tag as ProductViewHolder
        }

        holder.bind(dataList[position])

        return view!!
    }
}

class ProductViewHolder(var itemView: View, private val context: Context, var fragment: Fragment) {
    private val imageView: ImageView = itemView.findViewById(R.id.imageView)
    private val titleText: TextView = itemView.findViewById(R.id.titleText)
    private val priceText: TextView = itemView.findViewById(R.id.priceText)

    fun bind(product: ProductModel) {
        itemView.setOnClickListener {
            handleClick(fragment, R.id.productDetailFragment, Parser.parse(product)!!)
        }

        Glide.with(context).load(product.thumbnail).into(imageView)
        titleText.text = product.title
        priceText.text = product.price.toString()
    }
}
