package com.nsicyber.dummybuyapp.bottomDialogs

import android.app.Activity
import android.content.Context
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.nsicyber.dummybuyapp.R
import com.nsicyber.dummybuyapp.adapters.CartAdapter
import com.nsicyber.dummybuyapp.models.CartResponse

fun openCartDialog(
    context: Context,
    activity: Activity,
    data: CartResponse
) {

    val dialog = BottomSheetDialog(context, R.style.BottomSheetDialog)

    val view = activity.layoutInflater.inflate(R.layout.bottom_cart_response, null)


    val listView = view.findViewById<ListView>(R.id.listView)

    val totalPrice = view.findViewById<TextView>(R.id.totalPrice)
    val adapter = CartAdapter(context, data.products)
    listView.adapter = adapter
    totalPrice.text = data.total.toString()

    dialog.setCancelable(true)

    dialog.setContentView(view)

    dialog.show()

}