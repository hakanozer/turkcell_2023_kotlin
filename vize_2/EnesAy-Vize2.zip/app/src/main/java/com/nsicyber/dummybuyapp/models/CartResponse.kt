package com.nsicyber.dummybuyapp.models

import com.google.gson.annotations.SerializedName

data class CartResponse (

    @SerializedName("id"              ) var id              : Int?                = null,
    @SerializedName("products"        ) var products        : ArrayList<CartProducts> = arrayListOf(),
    @SerializedName("total"           ) var total           : Int?                = null,
    @SerializedName("discountedTotal" ) var discountedTotal : Int?                = null,
    @SerializedName("userId"          ) var userId          : Int?                = null,
    @SerializedName("totalProducts"   ) var totalProducts   : Int?                = null,
    @SerializedName("totalQuantity"   ) var totalQuantity   : Int?                = null

)
data class CartProducts (

    @SerializedName("id"                 ) var id                 : Int?    = null,
    @SerializedName("title"              ) var title              : String? = null,
    @SerializedName("price"              ) var price              : Int?    = null,
    @SerializedName("quantity"           ) var quantity           : Int?    = null,
    @SerializedName("total"              ) var total              : Int?    = null,
    @SerializedName("discountPercentage" ) var discountPercentage : Double? = null,
    @SerializedName("discountedPrice"    ) var discountedPrice    : Int?    = null

)