package com.nsicyber.dummybuyapp.models

import com.google.gson.annotations.SerializedName
import com.nsicyber.dummyapp.models.ProductModel
import java.io.Serializable

class UserAddCartModel : Serializable {

    @SerializedName("userId")
    val userId: Int? = 1

    @SerializedName("products")
    var products: List<ProductModel>? = listOf()

}