package com.nsicyber.dummyapp.network

import com.nsicyber.dummyapp.models.ProductResponse
import com.nsicyber.dummybuyapp.models.CartResponse
import com.nsicyber.dummybuyapp.models.UserAddCartModel
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface RetrofitInterface {




    @GET("/products")
    fun getProductsWithLimit(
        @Query("limit") limit: Int?
    ): Call<ProductResponse>


    @GET("/products/search")
    fun searchProducts(
        @Query("q") searchKey: String?
    ): Call<ProductResponse>



    @GET("/products/{productId}")
    fun getProduct(
        @Path(value = "productId") productId: Int?
    ): Call<ProductResponse>

    @GET("/carts/1")
    fun getCartList(
    ): Call<CartResponse>


    @POST("/carts/add")
    @Headers(
        "Accept: application/json",
        "Content-Type: application/json"
    )
    fun confirmBasket(@Body basketBody: UserAddCartModel): Call<CartResponse>





}
