package com.nsicyber.dummybuyapp.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.nsicyber.dummyapp.network.RetrofitCallback
import com.nsicyber.dummyapp.network.RetrofitClient
import com.nsicyber.dummybuyapp.GeneralData
import com.nsicyber.dummybuyapp.R
import com.nsicyber.dummybuyapp.adapters.ProductListAdapter
import com.nsicyber.dummybuyapp.bottomDialogs.openCartDialog
import com.nsicyber.dummybuyapp.models.CartResponse
import com.nsicyber.dummybuyapp.models.UserAddCartModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [CartFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CartFragment : Fragment() {
    lateinit var listView: ListView
    lateinit var confirm: Button
    lateinit var remove: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cart, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        listView=view.findViewById(R.id.listView)
        confirm=view.findViewById(R.id.confirmCart)
        remove=view.findViewById(R.id.removeCart)

        configureProducts()


    }

    fun configureProducts() {

        val adapter = ProductListAdapter(GeneralData.cartItems, requireContext(),this)
        listView.adapter = adapter
        adapter.notifyDataSetChanged()



        confirm.setOnClickListener {
            getData()
            adapter.clear()
            GeneralData.cartItems= arrayListOf()
        }


remove.setOnClickListener {
    GeneralData.cartItems= arrayListOf()
    adapter.clear()
    adapter.notifyDataSetChanged()
}

    }



    fun getData(){

        val call = RetrofitClient.retrofitInterface(context).confirmBasket(UserAddCartModel().apply { products=GeneralData.getCart() })
        call.enqueue(RetrofitCallback(requireContext(), object : Callback<CartResponse> {
            override fun onResponse(
                call: Call<CartResponse>, response: Response<CartResponse>
            ) {
                if (response.isSuccessful) {

                    response.body()?.let { openCartDialog(requireContext(),requireActivity(), it) }
                }
            }

            override fun onFailure(call: Call<CartResponse>, t: Throwable) {


            }
        }))
    }

    override fun onResume() {
        super.onResume()

        configureProducts()
    }

}