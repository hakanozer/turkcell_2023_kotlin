package com.nsicyber.dummybuyapp.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import com.nsicyber.dummyapp.models.ProductModel
import com.nsicyber.dummyapp.models.ProductResponse
import com.nsicyber.dummyapp.network.RetrofitCallback
import com.nsicyber.dummyapp.network.RetrofitClient
import com.nsicyber.dummybuyapp.R
import com.nsicyber.dummybuyapp.adapters.CartAdapter
import com.nsicyber.dummybuyapp.adapters.ProductListAdapter
import com.nsicyber.dummybuyapp.models.CartProducts
import com.nsicyber.dummybuyapp.models.CartResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [OrdersFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class OrdersFragment : Fragment() {
    // TODO: Rename and change types of parameters

    var products: ArrayList<CartProducts>? = arrayListOf()
    lateinit var listView: ListView
    lateinit var searchText: EditText
    lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_orders, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listView=view.findViewById(R.id.listView)
        getData()





    }


    fun configureProducts() {

        val adapter = CartAdapter(requireContext(),products as List<CartProducts>)
        listView.adapter = adapter
        adapter.notifyDataSetChanged()


    }


    fun getData() {
        val call = RetrofitClient.retrofitInterface(requireContext()).getCartList()
        call.enqueue(RetrofitCallback(requireContext(), object : Callback<CartResponse?> {

            override fun onResponse(
                call: Call<CartResponse?>,
                response: Response<CartResponse?>
            ) {
                if (response.code() == 200) {

                    products = response.body()?.products as ArrayList<CartProducts>
                    configureProducts()
                }
            }

            override fun onFailure(call: Call<CartResponse?>, t: Throwable) {
                Toast.makeText(requireContext(), t.message, Toast.LENGTH_SHORT).show()
            }

        }))
    }

    override fun onResume() {
        super.onResume()
        getData()
    }



}