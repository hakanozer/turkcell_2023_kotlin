package com.nsicyber.dummybuyapp.ui

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.nsicyber.deezerpractice.utils.Parser
import com.nsicyber.dummyapp.models.ProductModel
import com.nsicyber.dummybuyapp.GeneralData
import com.nsicyber.dummybuyapp.R
import com.nsicyber.dummybuyapp.adapters.GalleryAdapter

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [ProductDetailFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ProductDetailFragment : Fragment() {
    var model: ProductModel? = ProductModel()
    private lateinit var titleText: TextView
    private lateinit var priceText: TextView
    private lateinit var stockText: TextView
    private lateinit var ratingText: TextView
    private lateinit var thumbnail: ImageView
    private lateinit var description: TextView
    private lateinit var listView: ListView
    private lateinit var addCart: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        arguments?.let {
            model = Parser.parse(it.getSerializable("data"))
        }
        return inflater.inflate(R.layout.fragment_product_detail, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity()
            .onBackPressedDispatcher
            .addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    findNavController().popBackStack()
                }
            }
            )
        titleText = view.findViewById(R.id.titleText)
        priceText = view.findViewById(R.id.priceText)
        stockText = view.findViewById(R.id.stockText)
        ratingText = view.findViewById(R.id.ratingText)
        thumbnail = view.findViewById(R.id.thumbnail)
        description = view.findViewById(R.id.description)
        listView = view.findViewById(R.id.listView)
        addCart = view.findViewById(R.id.addCart)


       titleText.text= model?.title ?:""
        priceText.text ="₺ "+ model?.price.toString()
        stockText.text="Stock: "+ model?.stock.toString()
        ratingText.text="Rating: "+ model?.rating.toString()
        Glide.with(this).load(model?.thumbnail).into(thumbnail)
        description.text= model?.description ?:""
        addCart.setOnClickListener {
            GeneralData.cartItems.add(model!!)
            Toast.makeText(requireContext(),"Ürün Sepete Eklendi",Toast.LENGTH_SHORT).show()
        }

      listView.adapter  = GalleryAdapter(model?.images!!,requireContext())





    }
}



