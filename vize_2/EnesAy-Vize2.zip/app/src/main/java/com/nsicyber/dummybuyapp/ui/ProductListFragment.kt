package com.nsicyber.dummybuyapp.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.nsicyber.deezerpractice.utils.Parser
import com.nsicyber.deezerpractice.utils.handleClick
import com.nsicyber.dummyapp.models.ProductModel
import com.nsicyber.dummyapp.models.ProductResponse
import com.nsicyber.dummyapp.network.RetrofitCallback
import com.nsicyber.dummyapp.network.RetrofitClient
import com.nsicyber.dummybuyapp.R
import com.nsicyber.dummybuyapp.adapters.ProductListAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [ProductListFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ProductListFragment : Fragment() {


    var products: ArrayList<ProductModel>? = arrayListOf()
lateinit var listView: ListView
lateinit var searchText: EditText
lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_product_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listView=view.findViewById(R.id.listView)
        searchText=view.findViewById(R.id.searchText)
        button=view.findViewById(R.id.button)
        getData()





    }


    fun configureProducts() {

        val adapter = ProductListAdapter(products!!, requireContext(),this)
        listView.adapter = adapter
        adapter.notifyDataSetChanged()

        button.setOnClickListener {
            if(searchText.text.toString()=="")
            {
                adapter.clear()
                getData()
            }
            else{
                adapter.clear()
                searchData(searchText.text.toString())

            }
        }
    }


    fun getData() {
        val call = RetrofitClient.retrofitInterface(requireContext()).getProductsWithLimit(10)
        call.enqueue(RetrofitCallback(requireContext(), object : Callback<ProductResponse?> {

            override fun onResponse(
                call: Call<ProductResponse?>,
                response: Response<ProductResponse?>
            ) {
                if (response.code() == 200) {

                    products = response.body()?.products as ArrayList<ProductModel>
                    configureProducts()
                }
            }

            override fun onFailure(call: Call<ProductResponse?>, t: Throwable) {
                Toast.makeText(requireContext(), t.message, Toast.LENGTH_SHORT).show()
            }

        }))
    }

    fun searchData(key:String) {
        val call = RetrofitClient.retrofitInterface(requireContext()).searchProducts(key)
        call.enqueue(RetrofitCallback(requireContext(), object : Callback<ProductResponse?> {

            override fun onResponse(
                call: Call<ProductResponse?>,
                response: Response<ProductResponse?>
            ) {
                if (response.code() == 200) {

                    products = response.body()?.products as ArrayList<ProductModel>
                    configureProducts()
                }
            }

            override fun onFailure(call: Call<ProductResponse?>, t: Throwable) {
                Toast.makeText(requireContext(), t.message, Toast.LENGTH_SHORT).show()
            }

        }))
    }


}

