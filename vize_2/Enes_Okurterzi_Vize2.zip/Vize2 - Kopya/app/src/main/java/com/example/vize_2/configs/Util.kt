package com.example.vize_2.configs

import com.example.vize_2.models.Product

class Util {
    companion object {
        var choosen: Product? = null
    }
}
