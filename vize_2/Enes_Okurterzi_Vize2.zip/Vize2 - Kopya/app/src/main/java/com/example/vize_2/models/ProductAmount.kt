package com.example.vize_2.models

data class SendCartData(
    val itemId: Int,
    val quantity: Int
)
