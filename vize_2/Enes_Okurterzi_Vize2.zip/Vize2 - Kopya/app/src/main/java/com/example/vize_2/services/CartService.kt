package com.example.vize_2.services

import com.example.vize_2.models.Cart
import com.example.vize_2.models.SendCartData
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface CartService {

    @GET("/carts/1")
    fun singleCart (): Call<Cart>

    @POST("/carts/add")
    fun addToCart (@Body cartData: SendCartData): Call<ResponseBody>

}