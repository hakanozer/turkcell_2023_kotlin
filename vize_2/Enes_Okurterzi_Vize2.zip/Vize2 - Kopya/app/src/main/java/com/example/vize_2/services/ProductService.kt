package com.example.vize_2.services

import com.example.vize_2.models.Product
import com.example.vize_2.models.Products
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ProductService {

    @GET("/products")
    fun products(): Call<Products>

    @GET("/products")
    fun firstTenProduct( @Query("limit") limit: Int): Call<Products>

    @GET("/products/{id}")
    fun singleProduct( @Path("id") id: Int) : Call<Product>

}