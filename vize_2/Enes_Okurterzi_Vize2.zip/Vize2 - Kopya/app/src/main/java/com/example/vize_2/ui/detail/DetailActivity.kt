package com.example.vize_2.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.vize_2.R
import com.example.vize_2.configs.ApiClient
import com.example.vize_2.configs.Util
import com.example.vize_2.models.SendCartData
import com.example.vize_2.services.CartService
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {

    lateinit var imgDetail: ImageView
    lateinit var txtDetailTitle: TextView
    lateinit var txtDetailDescription: TextView
    lateinit var txtDetailPrice: TextView
    lateinit var txtDetailRating: TextView
    lateinit var cartService: CartService
    val product = Util.choosen!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        initView()
        setView()
    }

    private fun initView() {
        imgDetail = findViewById(R.id.imgDetail)
        txtDetailTitle = findViewById(R.id.txtDetailTitle)
        txtDetailDescription = findViewById(R.id.txtDetailDescription)
        txtDetailPrice = findViewById(R.id.txtDetailPrice)
        txtDetailRating = findViewById(R.id.txtDetailRating)
        cartService = ApiClient.getClient().create(CartService::class.java)
    }

    private fun setView() {
        Glide.with(this).load(product.thumbnail).into(imgDetail)
        txtDetailTitle.text = product.title
        txtDetailDescription.text = product.description
        txtDetailPrice.text = product.price.toString()
        txtDetailRating.text = product.rating.toString()
    }

    fun btnAddToCart(view: View) {
        val cartData = SendCartData(product.id.toInt(),1)
        cartService.addToCart(cartData).enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                val response = response.body()
                if (response != null) {
                    Toast.makeText(this@DetailActivity,"Saccesfully Added", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Log.e("addToCart", t.toString())
            }

        })

    }


}