package com.example.vize_2.ui.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ListView
import com.example.vize_2.R
import com.example.vize_2.configs.ApiClient
import com.example.vize_2.configs.Util
import com.example.vize_2.models.Product
import com.example.vize_2.models.Products
import retrofit2.Callback
import com.example.vize_2.services.ProductService
import com.example.vize_2.ui.detail.DetailActivity
import com.example.vize_2.ui.oldorder.OldOrderActivity
import retrofit2.Call
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    lateinit var productListView: ListView
    lateinit var productService: ProductService
    lateinit var adapter: MainAdapter
    var productList: MutableList<Product> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initView()
        adapterSet()
        getAllProducts()

        productListView.setOnItemClickListener { adapterView, view, i, l ->
            Util.choosen = productList[i]
            val intent = Intent(this@MainActivity, DetailActivity::class.java)
            startActivity(intent)
        }


    }

    private fun initView() {
        productListView = findViewById(R.id.productListView)
        productService = ApiClient.getClient().create(ProductService::class.java)
    }

    private fun adapterSet() {
        adapter = MainAdapter(this@MainActivity, productList)
        productListView.adapter = adapter
    }

    private fun getAllProducts() {

        productService.products().enqueue(object: Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                productList = response.body()?.products as MutableList<Product>
                adapterSet() // notify dataSet Changed çalışmıyor.
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.e("getAllProducts function", t.toString())
            }
        })

    }

    fun btnOldOrders(view: View) {
        val intent = Intent(this@MainActivity, OldOrderActivity::class.java)
        startActivity(intent)
    }

}