package com.example.vize_2.ui.main

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.vize_2.R
import com.example.vize_2.models.Product

class MainAdapter(private val context: Activity, private val list: List<Product>) :
    ArrayAdapter<Product>(context, R.layout.product_list_item, list)   {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.product_list_item, null, true)

        val imgListItem = rootView.findViewById<ImageView>(R.id.imgListItem)
        val txtListItemTitle = rootView.findViewById<TextView>(R.id.txtOldOrderTitle)
        val txtListItemPrice = rootView.findViewById<TextView>(R.id.txtOldOrderPrice)

        val product = list[position]

        txtListItemTitle.text = product.title
        txtListItemPrice.text = product.price.toString()

        val imageUrl = product.thumbnail

        Glide.with(rootView).load(imageUrl).into(imgListItem)


        return rootView
    }

}