package com.example.vize_2.ui.oldorder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ListView
import com.example.vize_2.R
import com.example.vize_2.configs.ApiClient
import com.example.vize_2.models.Cart
import com.example.vize_2.models.CartProduct
import com.example.vize_2.services.CartService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class OldOrderActivity : AppCompatActivity() {

    lateinit var oldOrderListView: ListView
    lateinit var cartService: CartService
    lateinit var adapter: OldOrderAdapter
    var cartProductList: MutableList<CartProduct> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_old_order)
        initView()
        adapterSet()
        getCart()
    }

    private fun initView() {
        oldOrderListView = findViewById(R.id.oldOrderListView)
        cartService = ApiClient.getClient().create(CartService::class.java)
    }

    private fun adapterSet() {
        adapter = OldOrderAdapter(this@OldOrderActivity, cartProductList)
        oldOrderListView.adapter = adapter
    }

    private fun getCart() {

        cartService.singleCart().enqueue(object : Callback<Cart> {
            override fun onResponse(call: Call<Cart>, response: Response<Cart>) {
                cartProductList = response.body()?.products as MutableList<CartProduct>
                adapterSet()

            }

            override fun onFailure(call: Call<Cart>, t: Throwable) {
                Log.e("getCart function", t.toString())
            }

        })

    }

}