package com.example.vize_2.ui.oldorder

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.vize_2.R
import com.example.vize_2.models.CartProduct

class OldOrderAdapter(private val context: Activity, private val list: List<CartProduct>) :
    ArrayAdapter<CartProduct>(context, R.layout.old_order_list_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.old_order_list_item, null, true)

        val txtOldOrderTitle = rootView.findViewById<TextView>(R.id.txtOldOrderTitle)
        val txtOldOrderPrice = rootView.findViewById<TextView>(R.id.txtOldOrderPrice)
        val txtOldOrderQuantity = rootView.findViewById<TextView>(R.id.txtOldOrderQuantity)

        val cartProduct = list[position]

        txtOldOrderTitle.text = cartProduct.title
        txtOldOrderPrice.text = cartProduct.price.toString()
        txtOldOrderQuantity.text = cartProduct.quantity.toString()

        return rootView
    }

}