package com.example.turkcellmidterm2.models

data class ProductRequest(
    var id: Long, var quantity: Int
)
