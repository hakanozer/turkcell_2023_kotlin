package com.gultendogan.gulten_dogan_vize2.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.gultendogan.gulten_dogan_vize2.R
import com.gultendogan.gulten_dogan_vize2.model.Product
import com.gultendogan.gulten_dogan_vize2.util.OnProductItemClickListener

class ProductAdapter(
    private val context: Context,
    private val productList: List<Product>,
    private val itemClickListener: OnProductItemClickListener
) : BaseAdapter() {

    override fun getCount(): Int {
        return productList.size
    }

    override fun getItem(position: Int): Any {
        return productList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(context).inflate(R.layout.row_layout, parent, false)

        val product = productList[position]

        val imageView = view.findViewById<ImageView>(R.id.productImage)
        val productNameTextView = view.findViewById<TextView>(R.id.productNameText)
        val productPriceTextView = view.findViewById<TextView>(R.id.productPriceText)
        val productRatingTextView = view.findViewById<TextView>(R.id.productRatingText)


        productNameTextView.text = product.title
        productPriceTextView.text = "Price: ${product.price}$"
        productRatingTextView.text = "Rating: ${product.rating}"


        Glide.with(context)
            .load(product.images[0])
            .into(imageView)


        view.setOnClickListener {
            val product = productList[position]
            itemClickListener.onItemClick(product)
        }

        return view
    }
}
