package com.gultendogan.gulten_dogan_vize2.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.gultendogan.gulten_dogan_vize2.R
import com.gultendogan.gulten_dogan_vize2.model.Product

class ProductListAdapter(context: Context, private val products: List<Product>) :
    ArrayAdapter<Product>(context, R.layout.list_item_product, products) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var itemView = convertView
        if (itemView == null) {
            val inflater = LayoutInflater.from(context)
            itemView = inflater.inflate(R.layout.list_item_product, parent, false)
        }

        val product = products[position]

        val titleTextView = itemView?.findViewById<TextView>(R.id.titleTextView)
        val priceTextView = itemView?.findViewById<TextView>(R.id.priceTextView)
        val ratingTextView = itemView?.findViewById<TextView>(R.id.ratingTextView)

        titleTextView?.text = product.title
        priceTextView?.text =  "Price: ${product.price}$"
        ratingTextView?.text = "Rating: ${product.rating}"

        return itemView!!
    }
}