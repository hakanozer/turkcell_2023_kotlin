package com.gultendogan.gulten_dogan_vize2.model

data class CartDetail(
    val id: Int,
    val products: List<Product>,
    val total: Int,
    val discountedTotal: Int,
    val userId: Int,
    val totalProducts: Int,
    val totalQuantity: Int,
    val isDeleted: Boolean,
    val deletedOn: String
)