package com.gultendogan.gulten_dogan_vize2.model

import com.google.gson.annotations.SerializedName

data class CartProduct(
    @SerializedName("id") val id: Int,
    @SerializedName("quantity") val quantity: Int
)