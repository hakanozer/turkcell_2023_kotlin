package com.gultendogan.gulten_dogan_vize2.model

import com.google.gson.annotations.SerializedName

data class CartRequest(
    @SerializedName("userId") val userId: Int,
    @SerializedName("products") val products: List<CartProduct>
)