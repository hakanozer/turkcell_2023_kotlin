package com.gultendogan.gulten_dogan_vize2.service

import com.gultendogan.gulten_dogan_vize2.model.*
import retrofit2.Call
import retrofit2.http.*

interface Service {

    @GET("products")
    fun getProducts(@Query("limit") limit: Int): Call<ApiResponse>

    @GET("products/{productId}")
    fun getProductDetails(@Path("productId") productId: Int): Call<ApiResponse>

    @GET("carts")
    fun getCarts(): Call<ApiResponse>

    @GET("carts/{cartId}")
    fun getCartDetails(@Path("cartId") cartId: Int): Call<CartDetail>

    @POST("carts/add")
    @Headers("Content-Type: application/json")
    fun addCart(@Body cartRequest: CartRequest): Call<ApiResponse>

}
