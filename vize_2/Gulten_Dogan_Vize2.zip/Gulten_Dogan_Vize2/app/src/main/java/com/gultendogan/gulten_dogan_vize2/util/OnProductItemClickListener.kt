package com.gultendogan.gulten_dogan_vize2.util

import com.gultendogan.gulten_dogan_vize2.model.Product

interface OnProductItemClickListener {
    fun onItemClick(product: Product)
}