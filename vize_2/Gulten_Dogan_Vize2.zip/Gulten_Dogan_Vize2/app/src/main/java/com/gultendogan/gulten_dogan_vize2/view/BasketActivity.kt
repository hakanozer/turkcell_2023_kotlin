package com.gultendogan.gulten_dogan_vize2.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.gultendogan.gulten_dogan_vize2.R
import com.gultendogan.gulten_dogan_vize2.adapter.ProductListAdapter
import com.gultendogan.gulten_dogan_vize2.client.RetrofitClient
import com.gultendogan.gulten_dogan_vize2.model.CartDetail
import com.gultendogan.gulten_dogan_vize2.model.Product
import com.gultendogan.gulten_dogan_vize2.service.Service
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BasketActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var service: Service

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_basket)

        listView = findViewById(R.id.addListView)

        service = RetrofitClient.create()

        fetchCartDetails()
    }

    private fun fetchCartDetails() {
        service.getCartDetails(1).enqueue(object : Callback<CartDetail> {
            override fun onResponse(call: Call<CartDetail>, response: Response<CartDetail>) {
                if (response.isSuccessful) {
                    val cart = response.body()
                    if (cart != null) {
                        showCartList(cart.products)
                    } else {
                    }
                } else {
                }
            }

            override fun onFailure(call: Call<CartDetail>, t: Throwable) {

            }
        })
    }

    private fun showCartList(products: List<Product>) {
        val adapter = ProductListAdapter(this@BasketActivity, products)
        listView.adapter = adapter
    }
}