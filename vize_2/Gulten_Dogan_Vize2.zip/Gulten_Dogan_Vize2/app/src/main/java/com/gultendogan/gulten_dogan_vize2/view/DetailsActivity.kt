package com.gultendogan.gulten_dogan_vize2.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bumptech.glide.Glide
import com.gultendogan.gulten_dogan_vize2.R
import com.gultendogan.gulten_dogan_vize2.client.RetrofitClient
import com.gultendogan.gulten_dogan_vize2.model.ApiResponse
import com.gultendogan.gulten_dogan_vize2.model.CartProduct
import com.gultendogan.gulten_dogan_vize2.model.CartRequest
import com.gultendogan.gulten_dogan_vize2.service.Service
import kotlinx.android.synthetic.main.activity_details.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailsActivity : AppCompatActivity() {

    private val service: Service

    init {

        service = RetrofitClient.create()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        Glide.with(this)
            .load((intent.getSerializableExtra("productImages")).toString())
            .into(detailView)

        titleTextDetail.text = "Title: " + (intent.getSerializableExtra("productTitle")).toString()
        descriptionText.text = "Description: " + (intent.getSerializableExtra("productDescription")).toString()
        ratingText.text = "Rating: " + (intent.getSerializableExtra("productRating")).toString()
        priceText.text = "Price: " + (intent.getSerializableExtra("productPrice")).toString()

        val productId = intent.getSerializableExtra("productId")


        addButton.setOnClickListener {
            val cartRequest = CartRequest(
                userId = 1,
                products = listOf(
                    CartProduct(id = 1, quantity = 1),
                    CartProduct(id = 50, quantity = 2)
                )
            )

            service.addCart(cartRequest).enqueue(object : Callback<ApiResponse> {
                override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                    if (response.isSuccessful) {
                        val apiResponse = response.body()
                        if (apiResponse != null) {
                            Toast.makeText(this@DetailsActivity, "Sipariş başarıyla oluşturuldu", Toast.LENGTH_SHORT).show()
                        } else {
                        }
                    } else {
                    }
                }

                override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                }
            })
        }

    }

}