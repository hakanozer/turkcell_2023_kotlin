package com.gultendogan.gulten_dogan_vize2.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ListView
import com.gultendogan.gulten_dogan_vize2.R
import com.gultendogan.gulten_dogan_vize2.adapter.ProductAdapter
import com.gultendogan.gulten_dogan_vize2.client.RetrofitClient
import com.gultendogan.gulten_dogan_vize2.model.ApiResponse
import com.gultendogan.gulten_dogan_vize2.model.Product
import com.gultendogan.gulten_dogan_vize2.util.OnProductItemClickListener
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity(), OnProductItemClickListener {
    private lateinit var listView: ListView
    private lateinit var productAdapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listView)
        productAdapter = ProductAdapter(this, emptyList(), this)

        listView.adapter = productAdapter


        val service = RetrofitClient.create()
        val call = service.getProducts(10)

        call.enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful) {
                    val apiResponse = response.body()
                    val productList = apiResponse?.products

                    if (productList != null) {
                        productAdapter = ProductAdapter(this@MainActivity, productList, this@MainActivity)
                        listView.adapter = productAdapter
                    }
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                // Handle failure
            }
        })
    }

    override fun onItemClick(product: Product) {
        val intent = Intent(this, DetailsActivity::class.java)
        intent.putExtra("productId", product.id)
        intent.putExtra("productTitle", product.title)
        intent.putExtra("productDescription", product.description)
        intent.putExtra("productRating", product.rating)
        intent.putExtra("productPrice", product.price)
        intent.putExtra("productImages", product.images[0])
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val menuInflater = menuInflater
        menuInflater.inflate(R.menu.menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.go_to_basket){
            val intent = Intent(this,BasketActivity::class.java)
            startActivity(intent)
        }
        return super.onOptionsItemSelected(item)
    }

}