package com.kursatmemis.vize_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.kursatmemis.vize_2.models.ProductCart

class CartActivity : AppCompatActivity() {

    private lateinit var cartListView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        cartListView = findViewById(R.id.cartListView)

        val cart = MainActivity.cart
        val products: MutableList<ProductCart> = cart?.products as MutableList<ProductCart>

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, products)
        cartListView.adapter = adapter
    }
}