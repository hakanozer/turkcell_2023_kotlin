package com.kursatmemis.vize_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import com.kursatmemis.vize_2.adapters.ProductAdapter
import com.kursatmemis.vize_2.configs.ApiClient
import com.kursatmemis.vize_2.models.Cart
import com.kursatmemis.vize_2.models.ProductMainActivity
import com.kursatmemis.vize_2.models.ProductResponse
import com.kursatmemis.vize_2.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var productsListView: ListView
    private var productsDataSource = mutableListOf<ProductMainActivity>()
    private lateinit var showCartButton: Button

    companion object {
        var cart: Cart? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showCartButton = findViewById(R.id.showCartButton)
        productsListView = findViewById(R.id.productsLitView)
        val adapter = ProductAdapter(this, productsDataSource)
        productsListView.adapter = adapter

        productsListView.setOnItemClickListener { adapterView, view, i, l ->
            val intent = Intent(this@MainActivity, ProductDetailActivity::class.java)
            intent.putExtra("id", productsDataSource[i].id)
            startActivity(intent)
        }

        val dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.getProducts().enqueue(object : Callback<ProductResponse> {
            override fun onResponse(
                call: Call<ProductResponse>,
                response: Response<ProductResponse>
            ) {
                val products = response.body()?.products
                if (products != null) {
                    for (product in products) {
                        Log.d("response-getProducts", "id: ${product.id} titke: ${product.title}")
                        productsDataSource.add(product)
                    }
                    adapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(call: Call<ProductResponse>, t: Throwable) {
                Log.d("onFailure-getProducts", t.toString())
            }

        })

        showCartButton.setOnClickListener {
            dummyService.getCarts().enqueue(object : Callback<Cart>{
                override fun onResponse(call: Call<Cart>, response: Response<Cart>) {
                    cart = response.body()
                    val intent = Intent(this@MainActivity, CartActivity::class.java)
                    startActivity(intent)
                }

                override fun onFailure(call: Call<Cart>, t: Throwable) {
                    TODO("Not yet implemented")
                }

            })
        }

    }
}