package com.kursatmemis.vize_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.kursatmemis.vize_2.configs.ApiClient
import com.kursatmemis.vize_2.models.*
import com.kursatmemis.vize_2.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var productDetailImageImageView: ImageView
    private lateinit var productDetailTitleTextView: TextView
    private lateinit var productDetailDetailTextView: TextView
    private lateinit var productDetailPriceTextView: TextView
    private lateinit var productDetailPointTextView: TextView
    private lateinit var orderButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        setViews()

        val productId = intent.getLongExtra("id", -1)
        if (productId == (-1).toLong()) {
            Toast.makeText(
                this,
                "Selected Product Not Found!",
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }

        val dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.getDetailProduct(productId).enqueue(object : Callback<ProductMainActivity> {
            override fun onResponse(
                call: Call<ProductMainActivity>,
                response: Response<ProductMainActivity>
            ) {
                val product = response.body()
                if (product != null) {
                    Glide.with(this@ProductDetailActivity).load(product.images[0])
                        .into(productDetailImageImageView)
                    productDetailTitleTextView.text = product.title
                    productDetailDetailTextView.text =
                        "${getString(R.string.detail)} ${product.description}"
                    productDetailPriceTextView.text =
                        "${getString(R.string.price)} ${product.price}"
                    productDetailPointTextView.text =
                        "${getString(R.string.point)} ${product.rating}"

                }
            }

            override fun onFailure(call: Call<ProductMainActivity>, t: Throwable) {
                Log.d("onFailure-getDetailProduct", t.toString())
            }

        })

        orderButton.setOnClickListener {
            val list: List<Product> = emptyList()
            val order = Order(1, list)
            dummyService.order(order).enqueue(object : Callback<OrderResponse>{
                override fun onResponse(
                    call: Call<OrderResponse>,
                    response: Response<OrderResponse>
                ) {
                    Log.d("order-response-code", response.code().toString())
                    Log.d("response-body", response.body().toString())
                }

                override fun onFailure(call: Call<OrderResponse>, t: Throwable) {
                    Log.d("onFailure-order", t.toString())
                }

            })

        }

    }

    private fun setViews() {
        productDetailImageImageView = findViewById(R.id.productDetailImageImageView)
        productDetailTitleTextView = findViewById(R.id.productDetailTitleTextView)
        productDetailDetailTextView = findViewById(R.id.productDetailDetailTextView)
        productDetailPriceTextView = findViewById(R.id.productDetailPriceTextView)
        productDetailPointTextView = findViewById(R.id.productDetailPointTextView)
        orderButton = findViewById(R.id.orderButton)
    }
}