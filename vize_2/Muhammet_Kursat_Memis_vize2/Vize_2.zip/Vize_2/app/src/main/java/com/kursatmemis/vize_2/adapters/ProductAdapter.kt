package com.kursatmemis.vize_2.adapters

import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.kursatmemis.vize_2.R
import com.kursatmemis.vize_2.models.ProductMainActivity

class ProductAdapter(val context: AppCompatActivity, val products: MutableList<ProductMainActivity>) :
    ArrayAdapter<ProductMainActivity>(context, R.layout.custom_product_view, products) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val custom_product_view = inflater.inflate(R.layout.custom_product_view, null)
        val productImage = custom_product_view.findViewById<ImageView>(R.id.productImageImageView)
        val productTitle = custom_product_view.findViewById<TextView>(R.id.productTitleTextView)
        val productPrice = custom_product_view.findViewById<TextView>(R.id.productPriceTextView)

        val product = products[position]

        Glide.with(context).load(product.images[0]).into(productImage)
        productTitle.text = "${context.getString(R.string.product_name)} ${product.title}"
        productPrice.text = "${context.getString(R.string.product_price)} ${product.price}$"
        return custom_product_view
    }
}