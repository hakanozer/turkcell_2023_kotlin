package com.kursatmemis.vize_2.models

data class Cart (
    val id: Long,
    val products: List<ProductCart>,
    val total: Long,
    val discountedTotal: Long,
    val userID: Long,
    val totalProducts: Long,
    val totalQuantity: Long
)

data class ProductCart (
    val id: Long,
    val title: String,
    val price: Long,
    val quantity: Long,
    val total: Long,
    val discountPercentage: Double,
    val discountedPrice: Long
) {
    override fun toString(): String {
        return "Title: $title Price: $price"
    }
}
