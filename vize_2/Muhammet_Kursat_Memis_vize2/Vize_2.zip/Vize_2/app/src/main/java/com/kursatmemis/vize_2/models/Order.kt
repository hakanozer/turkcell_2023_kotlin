package com.kursatmemis.vize_2.models

data class Order (
    val userID: Long,
    val products: List<Product>
)

data class Product (
    val id: Long,
    val quantity: Long
)