package com.kursatmemis.vize_2.models

data class OrderResponse (
    val id: Long,
    val products: List<ProductOrderResponse>,
    val total: Long,
    val discountedTotal: Long,
    val userID: Long,
    val totalProducts: Long,
    val totalQuantity: Long
)

data class ProductOrderResponse (
    val id: Long,
    val title: String,
    val price: Long,
    val quantity: Long,
    val total: Long,
    val discountPercentage: Double,
    val discountedPrice: Long
)