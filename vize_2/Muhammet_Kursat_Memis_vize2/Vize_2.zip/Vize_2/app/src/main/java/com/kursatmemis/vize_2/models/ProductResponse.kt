package com.kursatmemis.vize_2.models

data class ProductResponse (
    val products: List<ProductMainActivity>,
    val total: Long,
    val skip: Long,
    val limit: Long
)

data class ProductMainActivity (
    val id: Long,
    val title: String,
    val description: String,
    val price: Long,
    val discountPercentage: Double,
    val rating: Double,
    val stock: Long,
    val brand: String,
    val category: String,
    val thumbnail: String,
    val images: List<String>
)
