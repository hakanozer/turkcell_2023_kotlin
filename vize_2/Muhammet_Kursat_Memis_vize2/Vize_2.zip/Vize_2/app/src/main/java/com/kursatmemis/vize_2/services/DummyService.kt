package com.kursatmemis.vize_2.services

import com.kursatmemis.vize_2.models.*
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface DummyService {

    @GET("products")
    fun getProducts(): Call<ProductResponse>

    @GET("products/{endpoint}")
    fun getDetailProduct(@Path("endpoint") productId: Long): Call<ProductMainActivity>

    @GET("carts/1")
    fun getCarts(): Call<Cart>

    @POST("carts/add")
    fun order(@Body order: Order) : Call<OrderResponse>
}