package com.serapercel.urunsiparisuygulamasi.models

data class RequestProduct(
    val id: Int,
    val quantity: Int
)