package com.example.snav_2_furkan_urhan






import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.snav_2_furkan_urhan.data.Product


class DetailActivity: AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val product: Product? = intent.getParcelableExtra("product")
        val productTitleTextView: TextView = findViewById(R.id.Title)
        val productDescription: TextView = findViewById(R.id.Description)
        val productImageView: ImageView = findViewById(R.id.Image)

        if (product != null) {
            productTitleTextView.text = product.title
            productDescription.text = product.description


            Glide.with(this)
                .load(product.thumbnail)
                .override(1000, 900)
                .into(productImageView)
        }
    }
}