package com.example.snav_2_furkan_urhan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import android.widget.ListView
import com.example.snav_2_furkan_urhan.adapter.Adapter

import com.example.snav_2_furkan_urhan.configs.ApiClient
import com.example.snav_2_furkan_urhan.data.Product
import com.example.snav_2_furkan_urhan.data.ProductData
import com.example.snav_2_furkan_urhan.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var searchEditText: EditText
    private lateinit var productListView: ListView
    private lateinit var dummyService: DummyService
    private lateinit var productAdapter: Adapter
    private var productList = mutableListOf<Product>()
    private var filteredProductList = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchEditText = findViewById(R.id.search)
        productListView = findViewById(R.id.productListView)

        dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.getProductdata().enqueue(object : Callback<ProductData> {
            override fun onResponse(call: Call<ProductData>, response: Response<ProductData>) {
                Log.d("products", response.body().toString())

                for (product in response.body()!!.products) {
                    productList.add(product)
                }

                filteredProductList = productList.toMutableList()
                updateListView(filteredProductList)
            }

            override fun onFailure(call: Call<ProductData>, t: Throwable) {
                Log.e("eroor", "server error")
            }
        })

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
                val searchText = s.toString().trim().toLowerCase(Locale.getDefault())

                filteredProductList = if (searchText.isEmpty()) {
                    productList.toMutableList()
                } else {
                    productList.filter { product ->
                        product.title.toLowerCase(Locale.getDefault()).contains(searchText)
                    }.toMutableList()
                }

                updateListView(filteredProductList)
            }
        })
    }

    private fun updateListView(newProductList: List<Product>) {
        productAdapter = Adapter(this, newProductList)
        productListView.adapter = productAdapter
    }
}
