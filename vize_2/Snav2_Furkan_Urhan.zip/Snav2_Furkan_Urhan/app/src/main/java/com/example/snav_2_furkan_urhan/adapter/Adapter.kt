package com.example.snav_2_furkan_urhan.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.content.Context
import android.content.Intent
import android.widget.BaseAdapter
import android.widget.ListAdapter
import com.bumptech.glide.Glide
import com.example.snav_2_furkan_urhan.DetailActivity
import com.example.snav_2_furkan_urhan.R
import com.example.snav_2_furkan_urhan.data.Product



class Adapter(
    private val context: Context,
    private val productList: List<Product>
) : BaseAdapter() {

    override fun getCount(): Int {
        return productList.size
    }

    override fun getItem(position: Int): Any {
        return productList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        val holder: ProductViewHolder

        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item, parent, false)
            holder = ProductViewHolder(view)
            view.tag = holder
        } else {
            holder = view.tag as ProductViewHolder
        }

        val product = productList[position]

        holder.productName.text = product.title

        Glide.with(context)
            .load(product.thumbnail)
            .override(200, 100)
            .centerCrop()
            .into(holder.productImage)

        view?.setOnClickListener {
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("product", product)
            context.startActivity(intent)
        }

        return view!!
    }

    private class ProductViewHolder(itemView: View) {
        val productName: TextView = itemView.findViewById(R.id.TextView)
        val productImage: ImageView = itemView.findViewById(R.id.imageview)
    }
}

