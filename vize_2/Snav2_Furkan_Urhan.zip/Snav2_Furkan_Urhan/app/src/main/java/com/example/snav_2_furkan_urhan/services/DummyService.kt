package com.example.snav_2_furkan_urhan.services



import com.example.snav_2_furkan_urhan.data.ProductData
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface DummyService {

    @GET("products?limit=50")
    fun getProductdata():Call<ProductData>

    @GET("products/search")
    fun searchProducts(@Query("q") query: String):Call<ProductData>

}