package com.sumeyra.midtermtwo.common.util


import com.sumeyra.midtermtwo.common.util.Constants.BASE_URL
import com.sumeyra.midtermtwo.retrofit.ProductService
import com.sumeyra.midtermtwo.retrofit.RetrofitClient

object ApiUtils {

    fun getProductsDAOInterface(): ProductService =
        RetrofitClient.getClient(BASE_URL).create(ProductService::class.java)
}