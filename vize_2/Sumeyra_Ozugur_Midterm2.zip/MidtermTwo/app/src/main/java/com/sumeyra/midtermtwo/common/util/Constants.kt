package com.sumeyra.midtermtwo.common.util

object Constants {

    const val BASE_URL = "https://dummyjson.com/"
}