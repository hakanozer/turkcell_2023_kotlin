package com.sumeyra.midtermtwo.model

data class AddBasketModel(
    val userId:Int = 1,
    val products: List<AddBasketProduct>
)

data class AddBasketProduct(
    val id:Int ,
    val quantity:Int =1
)

