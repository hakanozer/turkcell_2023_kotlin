package com.sumeyra.midtermtwo.retrofit


import com.sumeyra.midtermtwo.model.*
import retrofit2.Call
import retrofit2.http.*


interface ProductService {

    @GET("products")
    fun allProducts(): Call<ProductModel>

    @GET("products/{id}")
    fun getProductDetail(@Path("id") id: Int): Call<Product>

    @GET("carts/1")
    fun getAllBasket(): Call<BasketModel>

    @POST("carts/add")
    fun setProduct(@Body addBasketModel: AddBasketModel):Call<BasketModel>

}