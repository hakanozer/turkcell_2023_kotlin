package com.sumeyra.midtermtwo.ui.basket

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.sumeyra.midtermtwo.common.util.ApiUtils
import com.sumeyra.midtermtwo.databinding.ActivityBasketBinding
import com.sumeyra.midtermtwo.model.BasketModel
import com.sumeyra.midtermtwo.retrofit.ProductService
import com.sumeyra.midtermtwo.ui.main.MainAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BasketActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBasketBinding
    private val adapter by lazy { BasketAdapter() }

    private val characterService: ProductService = ApiUtils.getProductsDAOInterface()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBasketBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.recyclerView.adapter = adapter
        getProductsBasket()
    }

    fun getProductsBasket() {
        val call = characterService.getAllBasket()

        call.enqueue(object : Callback<BasketModel> {
            override fun onResponse(call: Call<BasketModel>, response: Response<BasketModel>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        adapter.updateList(it.products)
                    }


                } else {
                    Log.e(
                        "Error",
                        "Failed to retrieve products: ${response.code()} ${response.message()}"
                    )
                }
            }

            override fun onFailure(call: Call<BasketModel>, t: Throwable) {
                Log.e("Error", "Failed to retrieve products", t)
            }
        })
    }

}