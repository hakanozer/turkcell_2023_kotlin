package com.sumeyra.midtermtwo.ui.basket

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.midtermtwo.common.extension.loadImage
import com.sumeyra.midtermtwo.databinding.ItemBasketBinding

import com.sumeyra.midtermtwo.model.ProductX

class BasketAdapter() :
    RecyclerView.Adapter<BasketAdapter.ViewHolder>() {
    private var basketList = listOf<ProductX>()

    inner class ViewHolder(val binding: ItemBasketBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(product: ProductX) = with(binding) {
            //  tvTitle.text = characterModel.name
            tvTitle.text = product.title
            tvPrice.text = "${product.price} TL"

        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBasketBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(basketList[position])
    }

    override fun getItemCount() = basketList.size

    fun updateList(updatedList: List<ProductX>) {
        this.basketList = updatedList
        notifyDataSetChanged()
    }
}