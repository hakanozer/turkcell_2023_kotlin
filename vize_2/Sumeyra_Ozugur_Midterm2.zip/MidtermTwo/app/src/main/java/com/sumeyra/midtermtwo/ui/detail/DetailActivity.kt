package com.sumeyra.midtermtwo.ui.detail

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.sumeyra.midtermtwo.common.extension.loadImage
import com.sumeyra.midtermtwo.common.util.ApiUtils
import com.sumeyra.midtermtwo.databinding.ActivityDetailBinding
import com.sumeyra.midtermtwo.model.*
import com.sumeyra.midtermtwo.retrofit.ProductService
import com.sumeyra.midtermtwo.ui.basket.BasketActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private val productService: ProductService = ApiUtils.getProductsDAOInterface()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val productId = intent.getIntExtra("id", 0)
        getProductsDetail(productId)

        binding.button.setOnClickListener {
            addBasket(productId)
        }

        binding.button2.setOnClickListener {
            val intent = Intent(this@DetailActivity, BasketActivity::class.java)
            startActivity(intent)
        }

    }

    fun getProductsDetail(productId: Int) {
        val call = productService.getProductDetail(productId)

        call.enqueue(object : Callback<Product> {
            override fun onResponse(call: Call<Product>, response: Response<Product>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        showProduct(it)
                    }


                } else {
                    Log.e(
                        "Error",
                        "Failed to retrieve products: ${response.code()} ${response.message()}"
                    )
                }
            }

            override fun onFailure(call: Call<Product>, t: Throwable) {
                Log.e("Error", "Failed to retrieve products", t)
            }
        })
    }

    fun addBasket(productId: Int) {
        val model = AddBasketModel(products = listOf(AddBasketProduct(productId)))

        val call = productService.setProduct(model)

        call.enqueue(object : Callback<BasketModel> {
            override fun onResponse(call: Call<BasketModel>, response: Response<BasketModel>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        Log.v("deneme",it.toString())
                    }


                } else {
                    Log.e(
                        "Error",
                        "Failed to retrieve product: ${response.code()} ${response.message()}"
                    )
                }
            }

            override fun onFailure(call: Call<BasketModel>, t: Throwable) {
                Log.e("Error", "Failed to retrieve products", t)
            }
        })
    }

    fun showProduct(characterResponse: Product) {
        binding.tvTitle.text = characterResponse.title
        binding.tvDescription.text = characterResponse.description
        binding.tvPrice.text = "${characterResponse.price} TL"
        binding.ivDetail.loadImage(characterResponse.images[0])

    }
}