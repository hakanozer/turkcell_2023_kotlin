package com.sumeyra.midtermtwo.ui.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.sumeyra.midtermtwo.common.util.ApiUtils
import com.sumeyra.midtermtwo.databinding.ActivityMainBinding
import com.sumeyra.midtermtwo.model.ProductModel
import com.sumeyra.midtermtwo.retrofit.ProductService
import com.sumeyra.midtermtwo.ui.detail.DetailActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val adapter by lazy { MainAdapter(onClickProduct = ::onClickProduct) }


    private val characterService: ProductService = ApiUtils.getProductsDAOInterface()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.recyclerView.adapter = adapter
        getProducts()

// Toast.makeText(this@HomeActivity, "Internet or Server Fail", Toast.LENGTH_LONG).show()
    }

    fun getProducts() {
        val call = characterService.allProducts()

        call.enqueue(object : Callback<ProductModel> {
            override fun onResponse(call: Call<ProductModel>, response: Response<ProductModel>) {
                if (response.isSuccessful) {
                    val characterResponse = response.body()
                    characterResponse?.products?.let {
                        adapter.updateList(it)

                    }
                } else {
                    Log.e(
                        "Error",
                        "Failed to retrieve products: ${response.code()} ${response.message()}"
                    )
                }
            }

            override fun onFailure(call: Call<ProductModel>, t: Throwable) {
                Log.e("Error", "Failed to retrieve products", t)
            }
        })
    }

    private fun onClickProduct(id: Int) {
        val intent = Intent(this@MainActivity, DetailActivity::class.java)
        intent.putExtra("id", id)
        startActivity(intent)

    }

}