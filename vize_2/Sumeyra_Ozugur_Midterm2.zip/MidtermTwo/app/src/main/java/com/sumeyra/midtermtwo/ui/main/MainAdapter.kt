package com.sumeyra.midtermtwo.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.midtermtwo.common.extension.loadImage
import com.sumeyra.midtermtwo.databinding.ItemMainBinding
import com.sumeyra.midtermtwo.model.Product


class MainAdapter(val onClickProduct: (Int) -> Unit) :
    RecyclerView.Adapter<MainAdapter.ViewHolder>() {
    private var productList = listOf<Product>()

    inner class ViewHolder(val binding: ItemMainBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(product: Product) = with(binding) {
            //  tvTitle.text = characterModel.name
            tvTitle.text = product.title
            tvPrice.text = "${product.price} TL"
            ivProduct.loadImage(product.images[0])

            binding.root.setOnClickListener {
                onClickProduct(product.id)
            }

        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMainBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(productList[position])
    }

    override fun getItemCount() = productList.size

    fun updateList(updatedList: List<Product>) {
        this.productList = updatedList
        notifyDataSetChanged()
    }
}