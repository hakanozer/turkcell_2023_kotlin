package com.vize_2.model

data class Cart(
    val userId:Int,
    val quantity: Int
)
data class Quantity(
    val productId:Long,
    val quantity:Int
)
