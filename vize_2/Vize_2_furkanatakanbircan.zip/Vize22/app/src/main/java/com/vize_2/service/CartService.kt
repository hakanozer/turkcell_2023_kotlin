package com.vize_2.service

import android.telecom.Call
import com.vize_2.model.Cart
import com.vize_2.model.Product
import com.vize_2.model.Quantity
import retrofit2.http.Body
import retrofit2.http.POST

interface CartService {
    @POST("/carts/add")
    fun addCart(@Body quantity: Quantity):retrofit2.Call<Cart>
}