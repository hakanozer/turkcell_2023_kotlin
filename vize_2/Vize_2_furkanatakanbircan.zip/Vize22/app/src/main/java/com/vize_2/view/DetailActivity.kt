package com.vize_2.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.vize_2.config.ApiClient
import com.vize_2.databinding.ActivityDetailBinding
import com.vize_2.model.Cart
import com.vize_2.model.Product
import com.vize_2.service.CartService
import com.vize_2.service.ProductService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    lateinit var binding: ActivityDetailBinding
    lateinit var productService:ProductService
    lateinit var cartService:CartService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intent.getStringExtra("data")?.let {
            var id = it

            cartService = ApiClient.getClient().create(CartService::class.java)
            val product = productService.singleProduct(id).enqueue(object : Callback<Product>{
                override fun onResponse(call: Call<Product>, response: Response<Product>) {
                    val count = response.body()
                    count?.let {
                        binding.txtDetailPageTitle.text= count.title
                        binding.txtDetailPageDescription.text=count.description
                        binding.txtDetailPageRating.text=count.description
                        binding.txtDetailPagePrice.text=count.price.toString()

                        Glide.with(this@DetailActivity).load(count.images[1])
                            .into(binding.imgDetail)
                        binding.btnSepeteEkle.setOnClickListener {
                            productService = ApiClient.getClient().create(ProductService::class.java)
                            val cart = Cart(1,1)
                        }
                    }
                }

                override fun onFailure(call: Call<Product>, t: Throwable) {
                    t.printStackTrace()
                }

            })

        }

    }
}