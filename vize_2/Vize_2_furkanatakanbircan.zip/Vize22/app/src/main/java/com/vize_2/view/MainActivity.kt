package com.vize_2.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListAdapter
import com.vize_2.R
import com.vize_2.adapter.MyAdapter
import com.vize_2.config.ApiClient
import com.vize_2.databinding.ActivityMainBinding
import com.vize_2.model.DummyProducts
import com.vize_2.model.Product
import com.vize_2.service.ProductService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var productService:ProductService
    lateinit var list:List<Product>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        productService = ApiClient.getClient().create(ProductService::class.java)
        productService.getProducts("100").enqueue(object :Callback<DummyProducts>{
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val datas = response.body()?.products
                list= datas!!
                datas?.let {
                    val myAdapter = MyAdapter(this@MainActivity, itemList =datas)
                    myAdapter.notifyDataSetChanged()
                    binding.listViewProducts.adapter=myAdapter
                    binding.listViewProducts.setOnItemClickListener { adapterView, view, i, l ->

                        var intent = Intent(this@MainActivity,DetailActivity::class.java)
                        intent.putExtra("data",datas.get(i).id.toString())
                        startActivity(intent)

                        true
                    }
                }
            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                t.printStackTrace()
            }

        }

        )
    }
}