package com.cankarademir.vize2_deneme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
    }
}