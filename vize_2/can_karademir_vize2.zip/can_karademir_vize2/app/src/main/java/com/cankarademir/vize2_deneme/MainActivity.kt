package com.cankarademir.vize2_deneme


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.cankarademir.vize2_deneme.adapter.ProductListViewAdapter
import com.cankarademir.vize2_deneme.configs.ApiClient
import com.cankarademir.vize2_deneme.configs.Util
import com.cankarademir.vize2_deneme.models.AllProducts
import com.cankarademir.vize2_deneme.models.Product
import com.cankarademir.vize2_deneme.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var dummyService: DummyService
    lateinit var productListView: ListView
    lateinit var cartBtn: Button

    var productList: MutableList<Product> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        productListView = findViewById(R.id.productListView)
        cartBtn= findViewById(R.id.btnMyCart)

        dummyService = ApiClient.getClient().create(DummyService::class.java)
        dummyService.getProducts(25).enqueue(
            object : Callback<AllProducts> {
                override fun onResponse(
                    call: Call<AllProducts>,
                    response: Response<AllProducts>
                ) {
                    val products = response.body()
                    if (products != null) {
                        for (product in products!!.products) {
                            productList.add(product)
                        }
                        val adapter: ProductListViewAdapter =
                            ProductListViewAdapter(this@MainActivity, productList)
                        productListView.adapter = adapter
                    }
                }

                override fun onFailure(call: Call<AllProducts>, t: Throwable) {
                    t.printStackTrace()
                    Toast.makeText(this@MainActivity, "Service Failure", Toast.LENGTH_LONG)
                        .show()
                }
            }
        )

        productListView.setOnItemClickListener { adapterView, view, i, l ->
            Util.choosen = productList[i]
            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }

        cartBtn.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }
    }
}
