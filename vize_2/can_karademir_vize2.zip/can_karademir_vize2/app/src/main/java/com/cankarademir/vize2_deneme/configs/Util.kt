package com.cankarademir.vize2_deneme.configs

import com.cankarademir.vize2_deneme.models.CartProducts
import com.cankarademir.vize2_deneme.models.Product


class Util {

    companion object {
        var listOfProduct: MutableList<CartProducts> = mutableListOf<CartProducts>()
        var choosen: Product? = null
    }
}