package com.cankarademir.vize2_deneme.models


data class CartProducts(

    var id: Int? = null,
    var title: String? = null,
    var price: Int? = null,
    var quantity: Int? = null,
    var total: Int? = null,
    var discountPercentage: Double? = null,
    var discountedPrice: Int? = null

)
