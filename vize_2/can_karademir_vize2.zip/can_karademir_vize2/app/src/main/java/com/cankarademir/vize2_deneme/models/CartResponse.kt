package com.cankarademir.vize2_deneme.models

data class CartResponse(

    var carts: ArrayList<Carts> = arrayListOf(),
    var total: Int? = null,
    var skip: Int? = null,
    var limit: Int? = null

)
