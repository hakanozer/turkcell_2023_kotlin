package com.cankarademir.vize2_deneme.models

data class Carts (
    val userID: Long,
    val products: List<CartProduct>
    )

    data class CartProduct (
        val id: Long,
        val quantity: Long
    )
