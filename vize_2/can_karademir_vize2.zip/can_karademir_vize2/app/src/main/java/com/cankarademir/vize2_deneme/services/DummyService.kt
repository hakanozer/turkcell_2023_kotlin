package com.cankarademir.vize2_deneme.services

import com.cankarademir.vize2_deneme.models.AllProducts
import com.cankarademir.vize2_deneme.models.CartProduct
import com.cankarademir.vize2_deneme.models.Carts
import retrofit2.Call
import retrofit2.http.*

interface DummyService {

    @POST("/carts/add")
    fun addCarts(@Body cart: CartProduct): Call<Carts>

    @GET("/products")
    fun getProducts(@Query("limit") limit: Int): Call<AllProducts>

}