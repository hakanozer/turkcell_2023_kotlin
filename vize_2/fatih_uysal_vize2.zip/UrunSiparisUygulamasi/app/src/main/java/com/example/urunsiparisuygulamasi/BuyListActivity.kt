package com.example.urunsiparisuygulamasi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BuyListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buy_list)
    }
}