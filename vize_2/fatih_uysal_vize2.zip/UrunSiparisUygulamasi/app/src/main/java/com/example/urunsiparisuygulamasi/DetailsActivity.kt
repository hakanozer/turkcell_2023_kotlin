package com.example.urunsiparisuygulamasi

import android.app.ProgressDialog.show
import android.graphics.Paint
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.urunsiparisuygulamasi.config.ApiClient

import com.example.urunsiparisuygulamasi.model.Product
import com.example.urunsiparisuygulamasi.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class DetailsActivity : AppCompatActivity() {

    lateinit var textViewPriceNotDisc: TextView
    lateinit var textViewPrice: TextView
    lateinit var textViewRate: TextView
    lateinit var textViewTitle: TextView
    lateinit var textViewDesc: TextView
    lateinit var imageView: ImageView
    lateinit var btn: Button
    lateinit var dummyService :DummyService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        dummyService = ApiClient.getClient().create(DummyService::class.java)
        textViewTitle = findViewById(R.id.textViewDetailsActivityTitle)
        textViewDesc = findViewById(R.id.textViewDetailsActivityDesc)
        textViewPrice = findViewById(R.id.textViewDetailsActivityPrice)
        textViewPriceNotDisc = findViewById(R.id.textViewDetailsActivityNotDiscountedPrice)
        textViewRate = findViewById(R.id.textViewDetailsActivityRate)
        imageView = findViewById(R.id.imageViewDetailsActivity)
        btn = findViewById(R.id.buttonDetailsActivityAdd)

        val itemid = intent.getLongExtra("id", 1)
        val toast = Toast.makeText(this, "Ürün sepetinize eklenmiştir.", Toast.LENGTH_SHORT)


        dummyService.singleproducts(itemid ).enqueue(object : Callback<Product> {
            override fun onResponse(call: Call<Product>, response: Response<Product>) {
                val body = response.body()
                val priceNotDisc = ((body!!.price /( 100 - body.discountPercentage)) * 100).toInt()
                textViewTitle.setText(body.title)
                textViewDesc.setText(body.description)
                textViewPrice.setText(body.price.toString())
                textViewPriceNotDisc.setText(priceNotDisc.toString())
                textViewRate.setText("(${body.rating})")
            }

            override fun onFailure(call: Call<Product>, t: Throwable) {
                TODO("Not yet implemented")
            }



        })

        btn.setOnClickListener {
toast.show()
        }
        Glide.with(this).load(intent.getStringExtra("image")).into(imageView)










    }
}