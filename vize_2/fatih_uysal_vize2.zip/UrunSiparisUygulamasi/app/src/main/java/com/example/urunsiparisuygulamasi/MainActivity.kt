package com.example.urunsiparisuygulamasi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import com.example.urunsiparisuygulamasi.adapter.customProductsListAdapter
import com.example.urunsiparisuygulamasi.config.ApiClient
import com.example.urunsiparisuygulamasi.model.DummyProducts
import com.example.urunsiparisuygulamasi.model.Product
import com.example.urunsiparisuygulamasi.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var dummyService: DummyService
    lateinit var listViewMainActivity: ListView
    lateinit var btn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listViewMainActivity = findViewById(R.id.ListViewMainActivity)
        btn = findViewById(R.id.btnBasket)
        dummyService = ApiClient.getClient().create(DummyService::class.java)

        dummyService.products().enqueue(object : Callback<DummyProducts>{
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val datas = response.body()
                val adapter = customProductsListAdapter(this@MainActivity, datas!!.products)
                listViewMainActivity.adapter = adapter
            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })

        listViewMainActivity.setOnItemClickListener { parent, view, position, id ->
            dummyService.singleproducts((position + 1 ).toLong()).enqueue(object :  Callback<Product>{
                override fun onResponse(call: Call<Product>, response: Response<Product>) {
                    val datas =  response.body()
                    val intent = Intent(this@MainActivity, DetailsActivity::class.java)


                    intent.putExtra("id" , datas!!.id)
                    intent.putExtra("image" , datas!!.thumbnail)

                    startActivity(intent)
                }

                override fun onFailure(call: Call<Product>, t: Throwable) {
                    TODO("Not yet implemented")
                }

            })
        }

        btn.setOnClickListener {
            val intent = Intent(this@MainActivity, BuyScreenActivity::class.java)
            startActivity(intent)
        }
    }
}