package com.example.urunsiparisuygulamasi.adapter

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.urunsiparisuygulamasi.R
import com.example.urunsiparisuygulamasi.model.Product


class customProductsListAdapter(
    private val context: Activity,
    private val list: List<Product>
) : ArrayAdapter<Product>(context, R.layout.custom_list_item, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_list_item, null, true)

        val r_Image = rootView.findViewById<ImageView>(R.id.imageViewCustomListItem)
        val r_Title = rootView.findViewById<TextView>(R.id.textViewCustomListItemTitle)
        val r_Price = rootView.findViewById<TextView>(R.id.textViewCustomListItemDesc)

        val products = list.get(position)
        r_Title.setText("${products.title}")
        r_Price.setText("${products.price}$")

        Glide.with(context).load(products.thumbnail).into(r_Image)
        return rootView


    }
}