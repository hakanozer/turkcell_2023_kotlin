package com.example.urunsiparisuygulamasi.model

data class BuyItem (
    val userID: Long,
    val products: List<ProductBuyChart>
)

data class ProductBuyChart (
    val id: Long,
    val quantity: Long
)
