package com.example.urunsiparisuygulamasi.service


import com.example.urunsiparisuygulamasi.model.DummyProducts
import com.example.urunsiparisuygulamasi.model.Product
import retrofit2.Call
import retrofit2.http.GET

import retrofit2.http.Path
import retrofit2.http.Query

interface DummyService {

    @GET("products")
    fun getProducts(@Query("limit") limit: Int): Call<DummyProducts>

    @GET("products")
    fun products() : Call<DummyProducts>

    @GET("products/{id}")
    fun singleproducts( @Path("id") id : Long) : Call<Product>



}