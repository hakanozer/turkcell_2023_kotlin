package com.example.vize2.models

data class CartItem(
    var id : Int,
    var quantity : String = "1"
)
