package com.mustafaunlu.shoopapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ShoopApplication : Application()
