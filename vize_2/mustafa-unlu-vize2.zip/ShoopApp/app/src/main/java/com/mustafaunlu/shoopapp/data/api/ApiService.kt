package com.mustafaunlu.shoopapp.data.api

import com.mustafaunlu.shoopapp.data.model.CartRequest
import com.mustafaunlu.shoopapp.data.model.CartResponse
import com.mustafaunlu.shoopapp.data.model.Product
import com.mustafaunlu.shoopapp.data.model.Products
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @GET("products")
    suspend fun getProducts(): Products

    @GET("products/{id}")
    suspend fun getProductsById(@Path("id") productId: Int): Product

    @POST("carts/add")
    suspend fun addToCart(@Body request: CartRequest): CartResponse

    @GET("carts/1")
    suspend fun getCart(): CartResponse
}
