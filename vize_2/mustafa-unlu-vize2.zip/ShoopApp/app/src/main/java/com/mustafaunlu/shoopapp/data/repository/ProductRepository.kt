package com.mustafaunlu.shoopapp.data.repository

import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.data.model.CartRequest
import com.mustafaunlu.shoopapp.data.model.CartResponse
import com.mustafaunlu.shoopapp.data.model.Product
import com.mustafaunlu.shoopapp.data.model.Products
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun getAllProducts(): Flow<NetworkResponseState<Products>>

    fun getProductById(productId: Int): Flow<NetworkResponseState<Product>>

    fun addToCart(cartRequest: CartRequest): Flow<NetworkResponseState<CartResponse>>

    fun getCart(): Flow<NetworkResponseState<CartResponse>>
}
