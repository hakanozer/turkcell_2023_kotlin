package com.mustafaunlu.shoopapp.data.repository

import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.data.model.CartRequest
import com.mustafaunlu.shoopapp.data.model.CartResponse
import com.mustafaunlu.shoopapp.data.model.Product
import com.mustafaunlu.shoopapp.data.model.Products
import com.mustafaunlu.shoopapp.data.source.RemoteDataSource
import com.mustafaunlu.shoopapp.di.IoDispatcher
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class ProductRepositoryImpl @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : ProductRepository {
    override fun getAllProducts(): Flow<NetworkResponseState<Products>> {
        return flow {
            emit(NetworkResponseState.Loading)
            when (val response = remoteDataSource.getAllProducts()) {
                is NetworkResponseState.Success -> emit(NetworkResponseState.Success(response.result))
                is NetworkResponseState.Error -> emit(NetworkResponseState.Error(response.exception))
                NetworkResponseState.Loading -> emit(NetworkResponseState.Loading)
            }
        }.flowOn(ioDispatcher)
    }

    override fun getProductById(productId: Int): Flow<NetworkResponseState<Product>> {
        return flow {
            emit(NetworkResponseState.Loading)
            when (val response = remoteDataSource.getProductById(productId)) {
                is NetworkResponseState.Success -> emit(NetworkResponseState.Success(response.result))
                is NetworkResponseState.Error -> emit(NetworkResponseState.Error(response.exception))
                NetworkResponseState.Loading -> emit(NetworkResponseState.Loading)
            }
        }.flowOn(ioDispatcher)
    }

    override fun addToCart(cartRequest: CartRequest): Flow<NetworkResponseState<CartResponse>> {
        return flow {
            emit(NetworkResponseState.Loading)
            when (val response = remoteDataSource.addToCart(cartRequest)) {
                is NetworkResponseState.Success -> emit(NetworkResponseState.Success(response.result))
                is NetworkResponseState.Error -> emit(NetworkResponseState.Error(response.exception))
                NetworkResponseState.Loading -> emit(NetworkResponseState.Loading)
            }
        }.flowOn(ioDispatcher)
    }

    override fun getCart(): Flow<NetworkResponseState<CartResponse>> {
        return flow {
            emit(NetworkResponseState.Loading)
            when (val response = remoteDataSource.getCart()) {
                is NetworkResponseState.Success -> emit(NetworkResponseState.Success(response.result))
                is NetworkResponseState.Error -> emit(NetworkResponseState.Error(response.exception))
                NetworkResponseState.Loading -> emit(NetworkResponseState.Loading)
            }
        }.flowOn(ioDispatcher)
    }
}
