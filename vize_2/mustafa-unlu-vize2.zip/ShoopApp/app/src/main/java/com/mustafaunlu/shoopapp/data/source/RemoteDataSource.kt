package com.mustafaunlu.shoopapp.data.source

import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.data.model.CartRequest
import com.mustafaunlu.shoopapp.data.model.CartResponse
import com.mustafaunlu.shoopapp.data.model.Product
import com.mustafaunlu.shoopapp.data.model.Products

interface RemoteDataSource {
    suspend fun getAllProducts(): NetworkResponseState<Products>

    suspend fun getProductById(productId: Int): NetworkResponseState<Product>

    suspend fun addToCart(cartRequest: CartRequest): NetworkResponseState<CartResponse>

    suspend fun getCart(): NetworkResponseState<CartResponse>
}
