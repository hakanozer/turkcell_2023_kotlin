package com.mustafaunlu.shoopapp.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.data.model.CartRequest
import com.mustafaunlu.shoopapp.data.model.Product
import com.mustafaunlu.shoopapp.data.repository.ProductRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val productRepository: ProductRepository,
) : ViewModel() {
    private val _product = MutableLiveData<NetworkResponseState<Product>>()
    val product: LiveData<NetworkResponseState<Product>> get() = _product

    fun getProduct(id: Int) {
        viewModelScope.launch {
            productRepository.getProductById(id).collect {
                when (it) {
                    is NetworkResponseState.Error -> _product.postValue(NetworkResponseState.Error(it.exception))
                    is NetworkResponseState.Loading -> _product.postValue(NetworkResponseState.Loading)
                    is NetworkResponseState.Success -> _product.postValue(NetworkResponseState.Success(it.result))
                }
            }
        }
    }

    fun addToCart(cartRequest: CartRequest) {
        viewModelScope.launch {
            productRepository.addToCart(cartRequest)
        }
    }
}
