package com.mustafaunlu.shoopapp.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.data.model.Products
import com.mustafaunlu.shoopapp.data.repository.ProductRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val productRepository: ProductRepository) :
    ViewModel() {
    private val _products = MutableLiveData<NetworkResponseState<Products>>()
    val products: LiveData<NetworkResponseState<Products>> get() = _products

    init {
        getAllProducts()
    }
    private fun getAllProducts() {
        viewModelScope.launch {
            productRepository.getAllProducts().collect {
                when(it) {
                    is NetworkResponseState.Error -> _products.postValue(NetworkResponseState.Error(it.exception))
                    is NetworkResponseState.Loading -> _products.postValue(NetworkResponseState.Loading)
                    is NetworkResponseState.Success -> _products.postValue(NetworkResponseState.Success(it.result))
                }
            }
        }
    }
}
