package com.mustafaunlu.shoopapp.ui.shoppingList

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.mustafaunlu.shoopapp.R
import com.mustafaunlu.shoopapp.data.model.CartResponseProduct

class ShoppingListAdapter(
    context: Context,
    resource: Int,
    objects: List<CartResponseProduct>,
) : ArrayAdapter<CartResponseProduct>(context, resource, objects) {

    @SuppressLint("SetTextI18n")
    override fun getView(
        position: Int,
        convertView: View?,
        parent: ViewGroup,
    ): View {
        var view = convertView
        if (view == null) {
            val inflater = LayoutInflater.from(context)
            view = inflater.inflate(R.layout.shopping_list_item, parent, false)
        }

        val cartProduct = getItem(position)
        val productNameTextView = view!!.findViewById<TextView>(R.id.itemNameTextView)
        val productPriceTextView = view!!.findViewById<TextView>(R.id.itemPriceTextView)
        val productId = view!!.findViewById<TextView>(R.id.itemId)
        val productQuantity = view!!.findViewById<TextView>(R.id.itemQuantity)

        productNameTextView.text = cartProduct?.title
        productPriceTextView.text = "${ cartProduct?.price } TL"
        productId.text = "Product Id: ${cartProduct?.id}"
        productQuantity.text = "Quantity: ${cartProduct?.quantity}"

        return view
    }
}
