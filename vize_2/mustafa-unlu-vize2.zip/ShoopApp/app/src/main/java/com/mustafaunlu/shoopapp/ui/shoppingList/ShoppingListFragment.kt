package com.mustafaunlu.shoopapp.ui.shoppingList

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.mustafaunlu.shoopapp.R
import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.databinding.FragmentShoppingListBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ShoppingListFragment : Fragment() {

    private lateinit var binding: FragmentShoppingListBinding
    private val viewModel: ShoppingListViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentShoppingListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.addToCartState.observe(viewLifecycleOwner) {
            when (it) {
                is NetworkResponseState.Error -> {
                }
                is NetworkResponseState.Loading -> {
                }
                is NetworkResponseState.Success -> {
                    binding.cartListview.adapter = ShoppingListAdapter(
                        requireContext(),
                        R.layout.shopping_list_item,
                        it.result.products,
                    )
                }
            }
        }
    }
}
