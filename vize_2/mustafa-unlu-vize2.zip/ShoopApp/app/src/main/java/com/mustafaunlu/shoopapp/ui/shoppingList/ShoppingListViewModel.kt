package com.mustafaunlu.shoopapp.ui.shoppingList

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.shoopapp.common.NetworkResponseState
import com.mustafaunlu.shoopapp.data.model.CartResponse
import com.mustafaunlu.shoopapp.data.repository.ProductRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShoppingListViewModel @Inject constructor(
    private val repository: ProductRepository,
) : ViewModel() {
    private val _addToCartState = MutableLiveData<NetworkResponseState<CartResponse>>()
    val addToCartState: LiveData<NetworkResponseState<CartResponse>> get() = _addToCartState

    init {
        getCart()
    }

    private fun getCart() {
        viewModelScope.launch {
            repository.getCart().collect {
                when (it) {
                    is NetworkResponseState.Error -> _addToCartState.postValue(NetworkResponseState.Error(it.exception))
                    is NetworkResponseState.Loading -> _addToCartState.postValue(NetworkResponseState.Loading)
                    is NetworkResponseState.Success -> _addToCartState.postValue(NetworkResponseState.Success(it.result))
                }
            }
        }
    }
}
