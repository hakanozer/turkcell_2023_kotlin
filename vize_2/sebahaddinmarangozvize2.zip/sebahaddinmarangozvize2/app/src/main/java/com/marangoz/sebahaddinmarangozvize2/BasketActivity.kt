package com.marangoz.sebahaddinmarangozvize2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.marangoz.sebahaddinmarangozvize2.model.BasketOutPut
import com.marangoz.sendnotification.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BasketActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private var customAdapter : BasketAdapter? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_basket)

        listView = findViewById(R.id.listView1)

        ApiClient.getDummyService().basketsProducts().enqueue(object : Callback<BasketOutPut> {
            override fun onResponse(call: Call<BasketOutPut>, response: Response<BasketOutPut>) {
                val dummyProducts = response.body()
                customAdapter = BasketAdapter(this@BasketActivity, dummyProducts!!.products)
                listView.adapter = customAdapter



            }

            override fun onFailure(call: Call<BasketOutPut>, t: Throwable) {
            }


        })



    }
}