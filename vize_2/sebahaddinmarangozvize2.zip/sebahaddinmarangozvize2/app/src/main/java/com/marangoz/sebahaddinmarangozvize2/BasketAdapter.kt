package com.marangoz.sebahaddinmarangozvize2

import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.marangoz.sebahaddinmarangozvize2.model.ProductCart

class BasketAdapter(private val context: Activity, var list: Array<ProductCart>): BaseAdapter() {


        override fun getCount(): Int {
            return list.size
        }

        override fun getItem(p0: Int): Any? {
            return null
        }

        override fun getItemId(p0: Int): Long {
            return 0
        }


        @SuppressLint("ViewHolder", "MissingInflatedId")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val rootView = context.layoutInflater.inflate(R.layout.basket_item, null, true)

            val titleText = rootView.findViewById<TextView>(R.id.titleBText)
            val brandText = rootView.findViewById<TextView>(R.id.priceBText)




            val product = list[position]

            titleText.text = product.title
            brandText.text = product.price.toString()



            return rootView
        }

    }
