package com.marangoz.sebahaddinmarangozvize2

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.bumptech.glide.Glide
import com.marangoz.uruntanitimsebahaddinmarangoz.Product

class CustomAdapter (private val context: Activity, var list: List<Product>): BaseAdapter() {


    override fun getCount(): Int {
        return list.size
    }

    override fun getItem(p0: Int): Any? {
       return null
    }

    override fun getItemId(p0: Int): Long {
       return 0
    }


    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rootView = context.layoutInflater.inflate(R.layout.custom_listview, null, true)

        val titleText = rootView.findViewById<TextView>(R.id.titleText)
        val image = rootView.findViewById<ImageView>(R.id.imageView)
        val brandText = rootView.findViewById<TextView>(R.id.brandText)
        val priceText = rootView.findViewById<TextView>(R.id.priceText)
        val card = rootView.findViewById<CardView>(R.id.cardView)



        val product = list[position]

        titleText.text = product.title
        Glide.with(rootView).load(product.images[0]).into(image)
        brandText.text = product.brand
        priceText.text = product.price.toString()


        card.setOnClickListener(){
            val intent = Intent(context,DetailActivity::class.java)

            intent.putExtra("id",product.id)

            context.startActivity(intent)


        }



        return rootView
    }

}