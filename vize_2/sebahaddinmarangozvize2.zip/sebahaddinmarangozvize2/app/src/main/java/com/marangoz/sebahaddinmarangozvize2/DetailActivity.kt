package com.marangoz.sebahaddinmarangozvize2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import com.bumptech.glide.Glide
import com.marangoz.sebahaddinmarangozvize2.model.BasketOutPut
import com.marangoz.sebahaddinmarangozvize2.model.CartAdd
import com.marangoz.sebahaddinmarangozvize2.model.ProductCart
import com.marangoz.sebahaddinmarangozvize2.model.ProductCartAdd
import com.marangoz.sendnotification.ApiClient
import com.marangoz.uruntanitimsebahaddinmarangoz.Product
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class DetailActivity : AppCompatActivity() {
    private lateinit var brandText : TextView
    private lateinit var desText : TextView
    private lateinit var priceText : TextView
    private lateinit var titleText : TextView
    private lateinit var image : ImageView
    private lateinit var image1 : ImageView
    private lateinit var image2 : ImageView
    private lateinit var sepet : CardView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        brandText = findViewById(R.id.brandText)
        desText = findViewById(R.id.desText)
        priceText = findViewById(R.id.textView8)
        titleText = findViewById(R.id.titleText)
        image = findViewById(R.id.imageView2)
        image1 = findViewById(R.id.imageView3)
        image2 = findViewById(R.id.imageView4)
        sepet = findViewById(R.id.siparisButton)


        ApiClient.getDummyService().singleProducts(intent.getLongExtra("id",0)).enqueue(object : Callback<Product> {
            override fun onResponse(call: Call<Product>, response: Response<Product>) {
                val products = response.body()


                brandText.text = products?.brand
                desText.text = products?.description
                priceText.text = products?.price.toString() + " TL"
                titleText.text = products?.title

                Glide.with(this@DetailActivity).load(products?.images?.get(0)).into(image)
                Glide.with(this@DetailActivity).load(products?.images?.get(1)).into(image1)
                Glide.with(this@DetailActivity).load(products?.images?.get(2)).into(image2)


            }

            override fun onFailure(call: Call<Product>, t: Throwable) {
            }


        })

        sepet.setOnClickListener(){
            val productCartAdd = ProductCartAdd(intent.getLongExtra("id",0),1)
            val arraylist= ArrayList<ProductCartAdd>()
            arraylist.add(productCartAdd)
            val cartAdd = CartAdd(1,arraylist)


            ApiClient.getDummyService().addCart(cartAdd).enqueue(object : Callback<BasketOutPut>{
                override fun onResponse(
                    call: Call<BasketOutPut>,
                    response: Response<BasketOutPut>
                ) {
                    val products = response.body()
                    if (products?.products != null){
                        Toast.makeText(this@DetailActivity,"Ürün Başarıyla Eklendi",Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<BasketOutPut>, t: Throwable) {


                }

            })


        }



    }
}