package com.marangoz.sebahaddinmarangozvize2

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import androidx.cardview.widget.CardView
import com.marangoz.sendnotification.ApiClient
import com.marangoz.uruntanitimsebahaddinmarangoz.DummyProducts
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    private lateinit var listView : ListView
    private lateinit var siparisCard : CardView
    private  var customAdapter : CustomAdapter? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.listView1)
        siparisCard = findViewById(R.id.siparisButton)
        results()


        siparisCard.setOnClickListener(){
            startActivity(Intent(this,BasketActivity::class.java))
        }


    }
    fun results(){
        ApiClient.getDummyService().products().enqueue(object : Callback<DummyProducts> {
            override fun onResponse(call: Call<DummyProducts>, response: Response<DummyProducts>) {
                val dummyProducts = response.body()
                customAdapter = CustomAdapter(this@MainActivity, dummyProducts!!.products)
                listView.adapter = customAdapter



            }

            override fun onFailure(call: Call<DummyProducts>, t: Throwable) {
            }


        })
    }
}