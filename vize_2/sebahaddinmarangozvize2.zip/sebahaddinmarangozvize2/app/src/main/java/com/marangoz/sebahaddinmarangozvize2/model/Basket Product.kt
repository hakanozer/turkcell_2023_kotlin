package com.marangoz.sebahaddinmarangozvize2.model

import com.marangoz.uruntanitimsebahaddinmarangoz.Product


data class BasketOutPut (
    var id: Long = 0,
    var products: Array<ProductCart>,
    var total: Long = 0,
    var discountedTotal: Long = 0,
    var userID: Long = 0,
    var totalProducts: Long = 0,
    var totalQuantity: Long = 0
)



data class ProductCart(
    var id: Long = 0,
    var title: String? = null,
    var price: Long = 0,
    var quantity: Long = 0,
    var total: Long = 0,
    var discountPercentage: Double = 0.0,
    var discountedPrice: Long = 0
)
