package com.marangoz.sebahaddinmarangozvize2.model

data class CartAdd (val userId : Int,val products : ArrayList<ProductCartAdd>)