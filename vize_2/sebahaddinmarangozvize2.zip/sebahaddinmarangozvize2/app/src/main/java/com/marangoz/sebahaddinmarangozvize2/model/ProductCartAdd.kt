package com.marangoz.sebahaddinmarangozvize2.model

data class ProductCartAdd(val id: Long, val quantity : Int)