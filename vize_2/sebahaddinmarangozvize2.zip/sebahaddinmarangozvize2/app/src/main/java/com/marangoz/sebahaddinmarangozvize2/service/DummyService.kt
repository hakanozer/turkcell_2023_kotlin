package com.marangoz.sebahaddinmarangozvize2.service

import com.marangoz.sebahaddinmarangozvize2.model.BasketOutPut
import com.marangoz.sebahaddinmarangozvize2.model.CartAdd
import com.marangoz.uruntanitimsebahaddinmarangoz.DummyProducts
import com.marangoz.uruntanitimsebahaddinmarangoz.Product
import retrofit2.Call
import retrofit2.http.*

interface DummyService {



    @GET("/products")
    fun products( ) : Call<DummyProducts>

    @GET("carts/1")
    fun basketsProducts( ) : Call<BasketOutPut>


    @GET("products/{pronumber}")
    fun singleProducts(
        @Path("pronumber") number:Long
    ) : Call<Product>



    @POST("carts/add")
    fun addCart(
        @Body() cartData: CartAdd
    ) : Call<BasketOutPut>

}