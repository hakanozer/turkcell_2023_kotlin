package com.example.vize2.screens

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.example.vize2.R
import com.example.vize2.config.ApiClient
import com.example.vize2.databinding.FragmentHomeBinding
import com.example.vize2.databinding.FragmentProductDetailBinding
import com.example.vize2.models.CartPostProduct
import com.example.vize2.models.Product
import com.example.vize2.services.ICartService
import com.example.vize2.services.IProductService
import com.example.vize2.utils.Util.showToast
import com.example.vize2.viewModels.HomeViewModel
import com.example.vize2.viewModels.ProductDetailViewModel

class ProductDetailFragment : Fragment() {

    private  var _binding: FragmentProductDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var navController: NavController
    private lateinit var productDetailViewModel: ProductDetailViewModel
    private var productId : Int? = null
    private var product : Product? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let { bundle ->
            productId = bundle.getInt("productId")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProductDetailBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init(view)
        registerEvents()
        listenEvents()
    }

    private fun init(view : View){
        navController = Navigation.findNavController(view)
        productDetailViewModel = ViewModelProvider(this)[ProductDetailViewModel::class.java]
        productDetailViewModel.productService = ApiClient.getClient().create(IProductService::class.java)
        productDetailViewModel.cartService = ApiClient.getClient().create(ICartService::class.java)
        if(productId != null){
            productDetailViewModel.getProduct(productId!!)
        }
    }

    private fun registerEvents(){
        binding.btnOrder.setOnClickListener {
            product?.let {
                var cartPostProductList = mutableListOf<CartPostProduct>()
                val cartPostProduct = CartPostProduct(it.id,1)
                cartPostProductList.add(cartPostProduct)
                productDetailViewModel.addToCart(cartPostProductList)
                navController.navigate(R.id.action_productDetailFragment2_to_cartFragment)
            }
        }
    }

    private fun setProductFields(){
        product?.let { currentProduct->
            Glide.with(this).load(currentProduct.images[0]).into(binding.imgProductImage)
            binding.txtTitle.text = currentProduct.title
            binding.txtDescription.text = currentProduct.description
            binding.txtPrice.text = "Price: " + currentProduct.price.toString() + " $"
            binding.txtRate.text = currentProduct.rating.toString()
            binding.txtBrand.text = currentProduct.brand
            binding.txtStock.text = "Stock: " + currentProduct.stock
        }
    }


    private fun listenEvents(){
        productDetailViewModel.product.observe(viewLifecycleOwner){result->
            result?.let {currentProduct->
                product = currentProduct
                setProductFields()
            }
        }

        productDetailViewModel.isAddFailed.observe(viewLifecycleOwner){result ->
            result?.let {
                if(it){
                    showToast("Order Success")
                }else{
                    showToast("Order Failed")
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}