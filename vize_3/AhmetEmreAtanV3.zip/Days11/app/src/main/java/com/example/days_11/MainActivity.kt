package com.example.days_11

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.days_11.adapter.MusicAdapter
import com.example.days_11.configs.Api
import com.example.days_11.models.Music
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var toggle : ActionBarDrawerToggle

    private lateinit var musicRecyclerView: RecyclerView
    private lateinit var musicAdapter: MusicAdapter
    private var musicList: List<Music> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val drawerLayout : DrawerLayout = findViewById(R.id.drawerLayout)
        val navView : NavigationView = findViewById(R.id.nav_view)

        toggle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        navView.setNavigationItemSelectedListener {

            when (it.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_login -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_settings -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_share -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_rateus -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }

        musicRecyclerView = findViewById(R.id.musicRecyclerView)
        musicRecyclerView.layoutManager = LinearLayoutManager(this)

        Api.getMusicData { fetchedMusicList, error ->
            if (error != null) {
                error.printStackTrace()
            } else {
                fetchedMusicList?.let { musicList ->
                    this.musicList = musicList
                    musicAdapter = MusicAdapter(this.musicList)
                    musicRecyclerView.adapter = musicAdapter
                }
            }
        }

        musicList = listOf(
            Music(1, "Experience", "Ludovico Einaudi", 6.22),
            Music(2, "Valse", "Evgeny Grinko", 3.37),
            Music(3, "Remembrance", "Balmorhea", 5.50),
            Music(4, "Stay", "Hans Zimmer", 5.14),
            Music(5, "Joruney", "Mark Eliyahu", 4.29),
            Music(6, "Faulkner's Sleep", "Evgeny Grinko", 5.33)
        )
        musicAdapter = MusicAdapter(musicList)
        musicRecyclerView.adapter = musicAdapter
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (toggle.onOptionsItemSelected(item)){
            return true
        }

        return super.onOptionsItemSelected(item)
    }
}