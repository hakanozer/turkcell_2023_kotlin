package com.example.days_11

import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MusicDetail : AppCompatActivity() {

    var mediaPlayer : MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_detail)

        val button:Button = findViewById(R.id.button)


        button.setOnClickListener ( object : View.OnClickListener{
            override fun onClick(v: View?) {


                mediaPlayer = MediaPlayer.create(this@MusicDetail, Uri.parse("https://www.youtube.com/watch?v=RgKKgzVhMgY"))
                mediaPlayer?.start()
            }
        } )

    }
}