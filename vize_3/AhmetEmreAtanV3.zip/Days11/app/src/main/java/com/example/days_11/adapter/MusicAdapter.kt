package com.example.days_11.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.days_11.MusicDetail
import com.example.days_11.R
import com.example.days_11.models.Music

class MusicAdapter(private val musicList: List<Music>) : RecyclerView.Adapter<MusicAdapter.MusicViewHolder>() {

    class MusicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        val artistTextView: TextView = itemView.findViewById(R.id.artistTextView)
        val durationTextView: TextView = itemView.findViewById(R.id.durationTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.card_item, parent, false)
        return MusicViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MusicViewHolder, position: Int) {
        val music = musicList[position]
        holder.titleTextView.text = music.title
        holder.artistTextView.text = music.artist.toString()
        holder.durationTextView.text = "${music.duration} seconds"

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, MusicDetail::class.java)
            intent.putExtra("musicId", music.id)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return musicList.size
    }
}
