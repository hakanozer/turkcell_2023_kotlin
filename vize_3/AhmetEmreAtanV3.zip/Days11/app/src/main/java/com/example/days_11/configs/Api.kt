package com.example.days_11.configs

import com.example.days_11.models.Music
import com.example.days_11.models.MusicResponse
import com.example.days_11.service.DummyMusicService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object Api {
    private val apiService: DummyMusicService

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://mocki.io/v1/f27fbefc-d775-4aee-8d65-30f76f1f7109/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(DummyMusicService::class.java)
    }

    fun getMusicData(callback: (List<Music>?, Throwable?) -> Unit) {
        val call = apiService.getMusicData()
        call.enqueue(object : Callback<MusicResponse> {
            override fun onResponse(call: Call<MusicResponse>, response: Response<MusicResponse>) {
                println("Response: $response")
                if (response.isSuccessful) {
                    val musicResponse = response.body()
                    val musicList = musicResponse?.musicList
                    callback(musicList, null)
                } else {
                    val error = Throwable("API request failed: ${response.code() ?: "Unknown error"}")
                    callback(null, error)
                }
            }

            override fun onFailure(call: Call<MusicResponse>, t: Throwable) {
                t.printStackTrace()
                callback(null, t)
            }
        })
    }
}

fun main() {
    Api.getMusicData { musicList, error ->
        if (error != null) {
            error.printStackTrace()
        } else {
            musicList?.let { musicList ->
                for (music in musicList) {
                    println("Title: ${music.title}, Artist: ${music.artist}, Duration: ${music.duration} seconds")
                }
            }
        }
    }
}
