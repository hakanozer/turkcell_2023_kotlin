package com.example.days_11.models

data class Music(val id: Int, val title: String, val artist: String, val duration: Double)
