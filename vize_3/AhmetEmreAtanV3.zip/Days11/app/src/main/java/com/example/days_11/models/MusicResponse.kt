package com.example.days_11.models

data class MusicResponse(val musicList: List<Music>)
