package com.example.days_11.service

import com.example.days_11.models.MusicResponse
import retrofit2.Call
import retrofit2.http.GET

interface DummyMusicService {

    @GET("https://mocki.io/v1/f27fbefc-d775-4aee-8d65-30f76f1f7109/")
    fun getMusicData(): Call<MusicResponse>

}