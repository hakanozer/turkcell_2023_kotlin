package com.works.vize3.common

object GlideImage {

    val musicImage = "https://cdn.icon-icons.com/icons2/1185/PNG/512/1490134636-synthesizer_82238.png"
    val volumeBar = "https://cdn-icons-png.flaticon.com/512/727/727269.png"
    val playButton = "https://cdn-icons-png.flaticon.com/256/8037/8037724.png"
    val pauseButton = "https://cdn.iconscout.com/icon/free/png-256/free-pause-1779830-1513994.png"
    val star = "https://cdn-icons-png.flaticon.com/512/7966/7966745.png"
}