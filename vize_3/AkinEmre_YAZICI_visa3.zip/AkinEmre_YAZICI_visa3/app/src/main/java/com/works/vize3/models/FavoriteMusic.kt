package com.works.vize3.models

data class FavoriteMusic(
    var ID : String = "",
    val title : String = "",
    val url : String = ""
)
