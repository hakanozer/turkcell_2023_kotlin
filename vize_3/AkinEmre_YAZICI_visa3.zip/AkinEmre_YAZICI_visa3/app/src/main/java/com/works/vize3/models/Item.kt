package com.works.vize3.models

data class Item (
    var ID : String = "",
    val baseCat: Long = 0,
    val title: String = "",
    val url: String = ""
)