package com.works.vize3.models

data class MusicList(
    val musicCategories: List<MusicCategory> = listOf()
)
