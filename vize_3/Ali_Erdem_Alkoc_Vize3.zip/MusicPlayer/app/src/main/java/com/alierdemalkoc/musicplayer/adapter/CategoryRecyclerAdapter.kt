package com.alierdemalkoc.musicplayer.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.alierdemalkoc.musicplayer.R
import com.alierdemalkoc.musicplayer.databinding.CategoryListItemBinding
import com.alierdemalkoc.musicplayer.models.MusicCategory

class CategoryRecyclerAdapter (private val categories: List<MusicCategory>) :
    RecyclerView.Adapter<CategoryRecyclerAdapter.CollectionsViewHolder>() {

    lateinit var context: Context

    class CollectionsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val binding = CategoryListItemBinding.bind(itemView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CollectionsViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.category_list_item, parent, false)
        context = parent.context
        return CollectionsViewHolder(view)
    }

    override fun onBindViewHolder(holder: CollectionsViewHolder, position: Int) {
        holder.binding.apply {
            val category = categories[position]
            tvParentTitle.text = category.baseTitle
            val musicsAdapter = MusicRecyclerAdapter(category.items)
            rvMusic.adapter = musicsAdapter
            rvMusic.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

            tvParentTitle.setOnClickListener {
                rvMusic.visibility = if (rvMusic.isShown) View.GONE else View.VISIBLE
            }
        }
    }

    override fun getItemCount() = categories.size
}