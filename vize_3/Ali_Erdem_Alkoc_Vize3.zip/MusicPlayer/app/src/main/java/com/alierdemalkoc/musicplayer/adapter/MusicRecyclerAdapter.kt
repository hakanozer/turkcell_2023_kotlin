package com.alierdemalkoc.musicplayer.adapter

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.alierdemalkoc.musicplayer.R
import com.alierdemalkoc.musicplayer.databinding.MusicListItemBinding
import com.alierdemalkoc.musicplayer.models.Item

class MusicRecyclerAdapter (private val itemModel: List<Item>) :
    RecyclerView.Adapter<MusicRecyclerAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val binding = MusicListItemBinding.bind(itemView)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.music_list_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            tvMusicTitle.text = itemModel[position].title
        }
        holder.binding.imgShare.setOnClickListener {
           val navController = Navigation.findNavController(holder.itemView)
            val bundle = Bundle()
            bundle.putString("title", holder.binding.tvMusicTitle.text.toString())
            bundle.putString("url", itemModel[position].url)
            navController.navigate(R.id.viewPagerToDetail, bundle)
        }
    }

    override fun getItemCount() = itemModel.size
}