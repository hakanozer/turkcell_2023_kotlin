package com.alierdemalkoc.musicplayer.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MusicApplication: Application() {
}