package com.alierdemalkoc.musicplayer.models

data class Music(
    val musicCategories: List<MusicCategory> = listOf(),
)

data class MusicCategory(
    val baseTitle: String = "",
    val items: List<Item> = listOf(),
)

data class Item(
    val baseCat: Long = 0,
    val title: String = "",
    val url: String = "",
    val isFav: Boolean = false
)

