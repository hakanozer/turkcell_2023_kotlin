package com.alierdemalkoc.musicplayer.repo

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.alierdemalkoc.musicplayer.models.Music
import com.alierdemalkoc.musicplayer.models.MusicCategory
import com.alierdemalkoc.musicplayer.service.MusicService
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

class MusicRepository @Inject constructor(
private val musicService: MusicService,
private val firebaseDatabase: FirebaseDatabase
) {
    val reference = firebaseDatabase.reference
    val musicCategoryList: MutableLiveData<List<MusicCategory>> = MutableLiveData()

    fun getMusics() : MutableLiveData<List<MusicCategory>> {
        musicService.getMusics().enqueue(object: Callback<Music>{
            override fun onResponse(call: Call<Music>, response: Response<Music>) {
                if (response.isSuccessful){
                        reference.child("Musics").setValue(response.body())
                    Log.d("msc1", musicCategoryList.toString())
                }
            }

            override fun onFailure(call: Call<Music>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
        return musicCategoryList
    }

    fun getMusicsFromDb(){
        reference.orderByChild("musicCategories").addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()){
                    snapshot.children.forEach {
                        Log.d("it", it.toString())
                        val music = it.getValue(Music::class.java)
                        musicCategoryList.postValue(music!!.musicCategories)
                        Log.d("msc2", musicCategoryList.toString())
                        Log.d("msc", music.toString())
                    }
                } else{
                    Log.d("null", "null")
                    getMusics()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("err", error.toString())
            }

        })
    }

    fun updateFav(){

    }


}