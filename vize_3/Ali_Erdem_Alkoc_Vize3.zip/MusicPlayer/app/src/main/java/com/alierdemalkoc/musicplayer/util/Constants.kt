package com.alierdemalkoc.musicplayer.util

class Constants {
    companion object {
        const val BASE_URL = "https://mocki.io/v1/"
    }
}