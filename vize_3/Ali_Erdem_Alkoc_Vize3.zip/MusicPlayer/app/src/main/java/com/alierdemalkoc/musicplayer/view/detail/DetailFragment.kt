package com.alierdemalkoc.musicplayer.view.detail

import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.alierdemalkoc.musicplayer.R
import com.alierdemalkoc.musicplayer.databinding.FragmentDetailBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DetailFragment : Fragment() {
    private val viewModel: DetailViewModel by viewModels()
    lateinit var sharedPreferences: SharedPreferences
    lateinit var sharedPreferencesFav: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    lateinit var editorFav: SharedPreferences.Editor
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!
    lateinit var mediaPlayer: MediaPlayer
    lateinit var volSeekBar: SeekBar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.titleText.text = arguments?.getString("title")
        binding.playbutton.setOnClickListener {
            mediaPlayer = MediaPlayer.create(requireContext(), Uri.parse(arguments?.getString("url")))
            mediaPlayer.start()
        }
        sharedPreferencesFav = requireContext().getSharedPreferences("fav", MODE_PRIVATE)
        binding.isFav.setOnClickListener {
            editorFav = sharedPreferencesFav.edit()
            editorFav.putString("fav", arguments?.getString("url"))
            editorFav.commit()
            if (sharedPreferencesFav.getString("fav","").equals(arguments?.getString("url"))){
                binding.isFav.setImageResource(R.drawable.fav)
            }
        }
        if (sharedPreferencesFav.getString("fav","").equals(arguments?.getString("url"))){
            binding.isFav.setImageResource(R.drawable.fav)
        }
        sharedPreferences = requireContext().getSharedPreferences("volume", MODE_PRIVATE)
        editor = sharedPreferences.edit()
        val volume = sharedPreferences.getFloat("volume",0.5f)
        volSeekBar = binding.seekBar
        mediaPlayer.setVolume(volume, volume)
        volSeekBar.progress = (volume*100).toInt()
        volSeekBar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                Log.d("Int", p1.toString())
                Log.d("Boolean", p2.toString())

                val f1 = p1.toFloat() / 100
                editor.putFloat("volume", f1)
                editor.commit()
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
            }

        })
    }
}