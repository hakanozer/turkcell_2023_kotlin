package com.alierdemalkoc.musicplayer.view.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alierdemalkoc.musicplayer.models.MusicCategory
import com.alierdemalkoc.musicplayer.repo.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val musicRepository: MusicRepository
) : ViewModel() {
    var categoryList: LiveData<List<MusicCategory>> = musicRepository.musicCategoryList

    fun getMusicFromList(){

    }
}