package com.alierdemalkoc.musicplayer.view.favs

import androidx.lifecycle.ViewModel

class FavsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}