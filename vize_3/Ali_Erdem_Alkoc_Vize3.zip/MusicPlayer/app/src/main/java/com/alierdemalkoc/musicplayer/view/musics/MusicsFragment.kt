package com.alierdemalkoc.musicplayer.view.musics

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.alierdemalkoc.musicplayer.R
import com.alierdemalkoc.musicplayer.adapter.CategoryRecyclerAdapter
import com.alierdemalkoc.musicplayer.databinding.FragmentMusicsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MusicsFragment : Fragment() {
    private val viewModel: MusicsViewModel by viewModels()
    private var _binding: FragmentMusicsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMusicsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getMusicsFromDb()
        viewModel.categoryList.observe(viewLifecycleOwner){
            Log.d("observe", it.toString())
            binding.rvParent.adapter = CategoryRecyclerAdapter(it)
        }


    }

}