package com.alierdemalkoc.musicplayer.view.musics

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alierdemalkoc.musicplayer.models.MusicCategory
import com.alierdemalkoc.musicplayer.repo.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MusicsViewModel @Inject constructor(
private val musicRepository: MusicRepository
) : ViewModel() {
    var categoryList: LiveData<List<MusicCategory>> = musicRepository.musicCategoryList

    fun getMusicsFromDb(){
        viewModelScope.launch {
            musicRepository.getMusicsFromDb()
        }
    }
}