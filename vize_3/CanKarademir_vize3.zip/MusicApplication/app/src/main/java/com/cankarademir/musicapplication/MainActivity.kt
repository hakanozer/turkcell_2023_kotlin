package com.cankarademir.musicapplication

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.cankarademir.musicapplication.configs.ApiClient
import com.cankarademir.musicapplication.data.Item
import com.cankarademir.musicapplication.data.Music
import com.cankarademir.musicapplication.data.MusicCategory
import com.cankarademir.musicapplication.databinding.ActivityMainBinding
import com.cankarademir.musicapplication.services.ApiServices
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    lateinit var apiServices: ApiServices
    private lateinit var binding: ActivityMainBinding
    val db = Firebase.firestore
    private val PREFS_NAME = "MyPrefs"
    private val KEY_FIRST_RUN = "firstRun"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val firstRun = sharedPreferences.getBoolean(KEY_FIRST_RUN, true)

        if (firstRun) {
            apiServices = ApiClient().getClients().create(ApiServices::class.java)
            apiServices.musicCategories().enqueue(object : Callback<Music> {
                override fun onResponse(call: Call<Music>, response: Response<Music>) {
                    if (response.isSuccessful) {
                        val music = response.body()
                        for (musics in music!!.musicCategories) {
                            val itemList = mutableListOf<Item>()
                            for (item in musics.items) {
                                itemList.add(item)
                            }
                            val musicCategory = MusicCategory(
                                baseTitle = "${musics.baseTitle}",
                                items = itemList
                            )
                            db.collection("musicCategories")
                                .add(musicCategory).addOnSuccessListener {
                                    Log.d("MainActivity", "Alınan veriler: $musicCategory")
                                }
                        }
                        val editor = sharedPreferences.edit()
                        editor.putBoolean(KEY_FIRST_RUN, false)
                        editor.apply()
                    }
                }

                override fun onFailure(call: Call<Music>, t: Throwable) {
                    Log.e("MainActivity", "Veri alınamadı: ${t.message}")
                }
            })
        }

        val navView: BottomNavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home, R.id.navigation_notifications
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
    }
}