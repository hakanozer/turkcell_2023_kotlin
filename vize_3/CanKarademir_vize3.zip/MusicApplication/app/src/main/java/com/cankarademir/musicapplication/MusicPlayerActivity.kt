package com.cankarademir.musicapplication

import android.content.Context
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.cankarademir.musicapplication.data.Favori
import com.cankarademir.musicapplication.data.MusicCategory
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MusicPlayerActivity : AppCompatActivity() {

    var mediaPlayer: MediaPlayer? = null
    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)

        val baseTitleData = intent.getStringExtra("baseTitle")
        val titleData = intent.getStringExtra("title")
        val urlData = intent.getStringExtra("url").toString()
        val baseCatData = intent.getStringExtra("baseCat")

        val imageButton = findViewById<ImageButton>(R.id.favoriteButton)
        val play = findViewById<ImageButton>(R.id.playButton)
        val pause = findViewById<ImageButton>(R.id.pauseButton)
        val volSeekBar = findViewById<SeekBar>(R.id.seekBar)


        val sharedPreferences = getSharedPreferences("MyPreferences", Context.MODE_PRIVATE)
        val lastProgress = sharedPreferences.getInt("lastProgress", 50)

        mediaPlayer?.setVolume(0.5f, 0.5f)
        volSeekBar.progress = lastProgress
        volSeekBar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                Log.d("Int", p1.toString())
                Log.d("Boolean", p2.toString())

                sharedPreferences.edit().putInt("lastProgress", p1).apply()

                val volume = p1 / 100f
                mediaPlayer?.setVolume(volume, volume)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
            }
        })

        playAudio(urlData)
        play.setOnClickListener {
            playAudio(urlData)
        }
        pause.setOnClickListener {
            pauseAudio()
        }

        val musicFavori = Favori(
            baseTitle = "${baseTitleData}",
            baseCat = "${baseCatData}",
            title = "$titleData",
            url = "$urlData"
        )

        val docRef = db.collection("musicFavorite")
            .whereEqualTo("baseTitle", baseTitleData)
            .whereEqualTo("baseCat", baseCatData)
            .whereEqualTo("title", titleData)
            .whereEqualTo("url", urlData)

        var isFavorite = false
        docRef.get().addOnSuccessListener { querySnapshot ->
            isFavorite = !querySnapshot.isEmpty
            if (isFavorite) {
                isFavorite = true
                imageButton.setImageResource(R.drawable.star)
            } else {
                // Veri veritabanında bulunmadığında yapılacak işlemler
            }
        }.addOnFailureListener { exception ->
            Log.e("MusicPlayerActivity", "Data query failed: $exception")
        }

        imageButton.setOnClickListener {
            isFavorite = !isFavorite
            if (isFavorite) {
                db.collection("musicFavorite")
                    .add(musicFavori).addOnSuccessListener {
                        Log.d("MusicPlayerActivity", "Alınan veriler: $musicFavori")
                    }
                imageButton.setImageResource(R.drawable.star)

            } else {
                db.collection("musicFavorite")
                    .whereEqualTo("baseTitle", baseTitleData)
                    .whereEqualTo("baseCat", baseCatData)
                    .whereEqualTo("title", titleData)
                    .whereEqualTo("url", urlData)
                    .get()
                    .addOnSuccessListener { querySnapshot ->
                        for (documentSnapshot in querySnapshot.documents) {
                            documentSnapshot.reference.delete()
                                .addOnSuccessListener {
                                    Log.d("MusicPlayerActivity", "Veri başarıyla silindi")
                                }
                                .addOnFailureListener { exception ->
                                    Log.e(
                                        "MusicPlayerActivity",
                                        "Silme işlemi başarısız oldu: $exception"
                                    )
                                }
                        }
                    }
                imageButton.setImageResource(R.drawable.star_border)
            }
        }
        if (baseTitleData != null && titleData != null) {
            val baseTitleTxt = findViewById<TextView>(R.id.baseTitleTxt)
            val titleTxt = findViewById<TextView>(R.id.titleTxt)
            baseTitleTxt.text = baseTitleData
            titleTxt.text = titleData
        }
    }

    private fun playAudio(url: String) {
        mediaPlayer = MediaPlayer().apply {
            setDataSource(url)
            setOnPreparedListener {
                start()
            }
            prepareAsync()
        }
    }

    private fun pauseAudio() {
        if (mediaPlayer!!.isPlaying) {

            mediaPlayer!!.stop()
            mediaPlayer!!.reset()
            mediaPlayer!!.release()
        } else {
            Toast.makeText(this, "Audio Has Not Played ", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pauseAudio()
    }
}