package com.cankarademir.musicapplication.adapters

import android.content.Context
import android.widget.SimpleExpandableListAdapter

class ExpandableListViewAdapter(
    private val context: Context,
    private val expandableTitle: List<String>,
    private val expandableDetail: Map<String, List<String>>
) : SimpleExpandableListAdapter(
    context, expandableTitle.map { title -> hashMapOf("Title" to title) },
    android.R.layout.simple_expandable_list_item_1,
    arrayOf("Title"),
    intArrayOf(android.R.id.text1),
    expandableDetail.map { entry -> entry.value.map { title -> hashMapOf("Item" to title) } },
    android.R.layout.simple_expandable_list_item_2,
    arrayOf("Item"),
    intArrayOf(android.R.id.text1)
)
