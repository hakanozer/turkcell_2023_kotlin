package com.cankarademir.musicapplication.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cankarademir.musicapplication.R
import com.cankarademir.musicapplication.data.Favori

class RecyclerViewAdapter( var itemList: List<Favori>)  : RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>() {

    class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val baseTitle = view.findViewById<TextView>(R.id.txtBaseTitle)
        val title = view.findViewById<TextView>(R.id.txtTitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.favorite_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentitem = itemList[position]
        holder.baseTitle.text = currentitem.baseTitle
        holder.title.text = currentitem.title
    }

    override fun getItemCount(): Int {
        return itemList.size
    }
}