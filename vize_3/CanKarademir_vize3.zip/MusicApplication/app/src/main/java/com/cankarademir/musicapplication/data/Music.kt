package com.cankarademir.musicapplication.data

data class Music(
    val musicCategories: List<MusicCategory>
)

data class MusicCategory (
    val baseTitle: String,
    val items: List<Item>
)

data class Item (
    val baseCat: Long,
    val title: String,
    val url: String
)
data class Favori(
    val baseTitle: String,
    val baseCat: String,
    val title: String,
    val url: String
)