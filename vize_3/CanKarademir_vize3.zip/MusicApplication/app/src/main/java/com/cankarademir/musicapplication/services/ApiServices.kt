package com.cankarademir.musicapplication.services

import com.cankarademir.musicapplication.data.Music
import retrofit2.Call
import retrofit2.http.GET

interface ApiServices {

        @GET("f27fbefc-d775-4aee-8d65-30f76f1f7109")
        fun musicCategories(): Call<Music>

}