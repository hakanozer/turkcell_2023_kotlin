package com.cankarademir.musicapplication.ui.favorite

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.cankarademir.musicapplication.adapters.RecyclerViewAdapter
import com.cankarademir.musicapplication.data.Favori
import com.cankarademir.musicapplication.databinding.FragmentFavoriteBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class FavoriteFragment : Fragment() {

    private var _binding: FragmentFavoriteBinding? = null
    val db = Firebase.firestore
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val itemList = mutableListOf<Favori>()
        db.collection("musicFavorite").get().addOnSuccessListener { querySnapshot ->
            for (documentSnapshot in querySnapshot) {
                val baseTitle = documentSnapshot.getString("baseTitle") ?: ""
                val baseCat = documentSnapshot.getString("baseCat") ?: ""
                val title = documentSnapshot.getString("title") ?: ""
                val url = documentSnapshot.getString("url") ?: ""

                val item = Favori(baseTitle, baseCat, title, url)
                itemList.add(item)
            }

            val adapter = RecyclerViewAdapter(itemList)
            val recyclerView = binding.favori
            recyclerView.layoutManager = LinearLayoutManager(context)
            recyclerView.adapter = adapter
        }.addOnFailureListener { exception ->
            // Hata durumunda yapılacak işlemler
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}