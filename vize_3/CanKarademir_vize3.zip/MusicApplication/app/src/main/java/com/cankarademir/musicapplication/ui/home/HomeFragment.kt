package com.cankarademir.musicapplication.ui.home

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.cankarademir.musicapplication.MusicPlayerActivity
import com.cankarademir.musicapplication.adapters.ExpandableListViewAdapter
import com.cankarademir.musicapplication.data.Item
import com.cankarademir.musicapplication.data.MusicCategory
import com.cankarademir.musicapplication.databinding.FragmentHomeBinding
import com.google.firebase.firestore.FirebaseFirestore

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    val db = FirebaseFirestore.getInstance()
    val musicCategories: MutableList<MusicCategory> = mutableListOf()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
//        val homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val musicCollection = db.collection("musicCategories")
        musicCollection.get().addOnSuccessListener { result ->
            for (document in result) {
                val baseTitle = document.getString("baseTitle") ?: ""
                val itemsList = document.get("items") as ArrayList<HashMap<String, Any>>
                val items: MutableList<Item> = mutableListOf()
                for (itemMap in itemsList) {
                    val baseCat = itemMap["baseCat"] as Long
                    val title = itemMap["title"] as String
                    val url = itemMap["url"] as String
                    val item = Item(baseCat, title, url)
                    items.add(item)
                }
                val musicCategory = MusicCategory(baseTitle, items)
                musicCategories.add(musicCategory)
            }
            ExpandableListView(musicCategories)
        }
            .addOnFailureListener { exception ->
                Log.d(TAG, "Error getting documents: ", exception)
            }


        return root
    }


    private fun ExpandableListView(catagories: List<MusicCategory>) {
        val expandableListTitle = mutableListOf<String>()
        val expandableListDetails = mutableMapOf<String, List<String>>()

        catagories.forEach { catagory ->
            expandableListTitle.add(catagory.baseTitle)
            val itemTitles = catagory.items.map { it.title }
            expandableListDetails[catagory.baseTitle] = itemTitles
        }
        val expandableListAdapter = ExpandableListViewAdapter(
            requireContext(), expandableListTitle, expandableListDetails
        )
        binding.expandableListView.setAdapter(expandableListAdapter)

        binding.expandableListView.setOnChildClickListener { parent, v, groupPosition, childPosition, id ->
            val clickedItemTitle =
                expandableListDetails[expandableListTitle[groupPosition]]?.get(childPosition)
            val clickedGroup= catagories[groupPosition]
            val clickedItem = clickedGroup.items[childPosition]

            val baseTitle = clickedGroup.baseTitle
            val title = clickedItem.title
            val baseCat = clickedItem.baseCat
            val url = clickedItem.url

            val intent = Intent(requireContext(), MusicPlayerActivity::class.java)
            intent.putExtra("baseTitle", "$baseTitle")
            intent.putExtra("title", "$title")
            intent.putExtra("url", "$url")
            intent.putExtra("", "$baseCat")
            startActivity(intent)

            true
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}