package com.emirk.turkcellandroidmusicplayer.domain.ui_model

data class Music (
    val baseCat: Int,
    val title: String,
    val url: String
)