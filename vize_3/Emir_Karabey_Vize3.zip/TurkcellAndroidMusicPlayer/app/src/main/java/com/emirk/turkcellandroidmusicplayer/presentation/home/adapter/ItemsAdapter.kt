package com.emirk.turkcellandroidmusicplayer.presentation.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.emirk.turkcellandroidmusicplayer.data.remote.dto.MusicDto
import com.emirk.turkcellandroidmusicplayer.databinding.ItemItemsBinding

class ItemsAdapter (
    private val itemsItemClickListener: ItemsItemClickListener
) : ListAdapter<MusicDto, ItemsViewHolder>(diffUtil) {

    companion object {
        private val diffUtil = object : DiffUtil.ItemCallback<MusicDto>() {
            override fun areItemsTheSame(
                oldItem: MusicDto,
                newItem: MusicDto
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: MusicDto,
                newItem: MusicDto
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemsViewHolder {
        val binding = ItemItemsBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ItemsViewHolder(binding,itemsItemClickListener)
    }

    override fun onBindViewHolder(holder: ItemsViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }
}