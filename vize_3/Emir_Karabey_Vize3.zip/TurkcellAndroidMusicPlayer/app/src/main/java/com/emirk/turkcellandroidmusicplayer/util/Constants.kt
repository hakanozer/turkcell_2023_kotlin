package com.emirk.turkcellandroidmusicplayer.util

object Constants {

    const val MUSIC_BASE_URL = "https://mocki.io/v1/"
    const val CATEGORY_END_POINT = "f27fbefc-d775-4aee-8d65-30f76f1f7109"
}