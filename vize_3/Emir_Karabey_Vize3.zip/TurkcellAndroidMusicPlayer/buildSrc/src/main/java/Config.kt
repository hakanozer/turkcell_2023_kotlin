object Config {
    const val compileSdk = 33
    const val minSdk = 23
    const val targetSdk = 33
    const val versionCode = 1
    const val versionName = "1.0"
    const val applicationId = "com.emirk.turkcellandroidmusicplayer"
}