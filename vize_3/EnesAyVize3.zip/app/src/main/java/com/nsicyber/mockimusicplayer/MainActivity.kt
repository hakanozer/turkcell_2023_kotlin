package com.nsicyber.mockimusicplayer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.nsicyber.mockimusicplayer.databinding.ActivityMainBinding
import com.nsicyber.mockimusicplayer.databinding.ActivitySplashBinding
import com.nsicyber.mockimusicplayer.ui.LikedMusicsFragment
import com.nsicyber.mockimusicplayer.ui.MusicListFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val adapter = ViewPagerAdapter(this)
        binding.viewPager.adapter = adapter

        // İlgili sayfa değiştikçe sekme başlığını güncelleyen TabLayoutMediator'ü ayarlayın
        TabLayoutMediator( binding.tabLayout,  binding.viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = "Şarkılar"
                1 -> tab.text = "Favoriler"
            }
        }.attach()

    }
}



class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {
    override fun getItemCount(): Int {
        return 2  // İki sekme olduğunu belirtin
    }

    override fun createFragment(position: Int): Fragment {
        // Her bir sekme için ilgili Fragment'ı döndürün
        return when (position) {
            0 -> MusicListFragment()
            1 -> LikedMusicsFragment()
            else -> throw IllegalArgumentException("Geçersiz sekme numarası: $position")
        }
    }
}