package com.nsicyber.mockimusicplayer


interface MediaPlayerInterface {
    interface OnProgressListener {
        fun onProgressUpdate(progress: Int, total: Int)
    }

    // Diğer fonksiyonlar...

    fun setOnProgressListener(listener: OnProgressListener)
    fun play()

    fun stop()

    fun pause()

    fun dispose()

    fun resume()

    fun onInfo()

    fun setUrl(uri : String?)

    fun setVolume(cur:Float)


}