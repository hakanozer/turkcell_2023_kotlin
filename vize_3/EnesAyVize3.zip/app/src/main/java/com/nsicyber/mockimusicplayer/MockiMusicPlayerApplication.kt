package com.nsicyber.mockimusicplayer



import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MockiMusicPlayerApplication :Application(){
    override fun onCreate() {
        super.onCreate()
    }
}