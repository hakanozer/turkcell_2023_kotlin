package com.nsicyber.mockimusicplayer.activities

import android.content.Context
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.AttributeSet
import android.view.View
import android.widget.SeekBar
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.nsicyber.mockimusicplayer.R
import com.nsicyber.mockimusicplayer.databinding.ActivityMainBinding
import com.nsicyber.mockimusicplayer.databinding.ActivityMusicPlayerBinding
import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import com.nsicyber.mockimusicplayer.remote.models.MusicCategory
import com.nsicyber.mockimusicplayer.repositories.FirebaseRepository
import com.nsicyber.mockimusicplayer.repositories.MusicPlayerRepository
import com.nsicyber.mockimusicplayer.utils.PreferencesHelper
import com.nsicyber.mockimusicplayer.utils.fromJson
import com.nsicyber.mockimusicplayer.viewmodels.MusicListViewModel
import com.nsicyber.mockimusicplayer.viewmodels.MusicListViewModelFactory
import com.nsicyber.mockimusicplayer.viewmodels.MusicPlayerViewModel
import com.nsicyber.mockimusicplayer.viewmodels.MusicPlayerViewModelFactory

class MusicPlayerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMusicPlayerBinding
    private lateinit var currTimeObserver: Observer<Int>
    private var isSeekBarTracking = false
    private lateinit var viewModel: MusicPlayerViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMusicPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(
            this,
            MusicPlayerViewModelFactory(MusicPlayerRepository())
        )[MusicPlayerViewModel::class.java]

        val musicList: MusicCategory? =
            intent.getStringExtra("model")?.fromJson(MusicCategory::class.java)
        val index = intent.getIntExtra("index", 0)
        var preferencesHelper = PreferencesHelper(this)
        viewModel.setVolumeLevel(preferencesHelper.volume)

        viewModel.setMusicList(musicList)
        viewModel.setCurrIndex(index)
        setupSeekBar()
        setupVolumeControl()
        configureViews()
        configureClicks()

    }

    fun configureClicks() {
        binding.nextButton.setOnClickListener {
            nextSong()
        }
        binding.prevButton.setOnClickListener {
            prevSong()
        }
        binding.playButton.setOnClickListener {
            if (viewModel.isPlaying.value == true)
                stopSong()
            else
                playSong()
        }
    }

    fun configureViews() {
        viewModel.musicList.observe(this) { musicCategory ->
            binding.songTitle.text =
                musicCategory?.items?.get(viewModel.currIndex.value ?: 0)?.title
            binding.songCategory.text = musicCategory?.baseTitle
        }
        viewModel.currentDuration.observe(this) { duration ->
            binding.currTime.text = duration.toString()
        }
        viewModel.currentDuration.observe(this) { duration ->
            binding.totalDuration.text = duration.toString()
        }

        currTimeObserver = Observer { currentTime ->
            if (!isSeekBarTracking) {
                binding.timeSlider.progress = currentTime
            }
            binding.currTime.text = currentTime.toString()
        }


        viewModel.currentDuration.observe(this, currTimeObserver)

    }

    fun stopSong() {

        viewModel.pauseSong()
    }

    fun playSong() {
        viewModel.setCurrentDuration(0)
        viewModel.currentDuration.observe(this) { duration ->
            viewModel.isPlaying.observe(this) {
                if (it == false) {
                    if (duration > 0)
                        viewModel.resumeSong()
                    else
                        viewModel.playSong()
                }

            }
        }


    }


    fun nextSong() {
        viewModel.nextSong()
        configureViews()
        playSong()

    }

    fun prevSong() {
        viewModel.prevSong()
        configureViews()
        playSong()

    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.currentDuration.removeObserver(currTimeObserver)
    }

    private fun setupVolumeControl() {
        binding.volumeSlider.addOnChangeListener { slider, value, fromUser ->
            if (fromUser) {
                val volume = value / slider.valueTo
                viewModel.setVolumeLevel(volume.toInt())
            }
        }
    }


    private fun setupSeekBar() {
        binding.timeSlider.max = viewModel.totalDuration.value ?: 0
        binding.timeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    binding.currTime.text = progress.toString()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isSeekBarTracking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isSeekBarTracking = false
                val progress = seekBar?.progress ?: 0
                viewModel.setCurrentDuration(progress)
            }
        })
    }


}