package com.nsicyber.mockimusicplayer.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.nsicyber.mockimusicplayer.MainActivity
import com.nsicyber.mockimusicplayer.R
import com.nsicyber.mockimusicplayer.databinding.ActivitySplashBinding
import com.nsicyber.mockimusicplayer.di.AppModule
import com.nsicyber.mockimusicplayer.remote.retrofit.RetrofitInterface
import com.nsicyber.mockimusicplayer.repositories.ApiRepository
import com.nsicyber.mockimusicplayer.repositories.FirebaseRepository
import com.nsicyber.mockimusicplayer.viewmodels.MusicPlayerViewModel
import com.nsicyber.mockimusicplayer.viewmodels.MusicPlayerViewModelFactory
import com.nsicyber.mockimusicplayer.viewmodels.SplashViewModel
import com.nsicyber.mockimusicplayer.viewmodels.SplashViewModelFactory
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding
    private lateinit var viewModel: SplashViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = ViewModelProvider(
            this,
            SplashViewModelFactory(ApiRepository(AppModule.provideApi()), FirebaseRepository())
        )[SplashViewModel::class.java]
        CoroutineScope(Dispatchers.Main).launch {
            viewModel.apiToDatabase()
            startActivity(Intent(this@SplashActivity,MainActivity::class.java))
        }


    }


}