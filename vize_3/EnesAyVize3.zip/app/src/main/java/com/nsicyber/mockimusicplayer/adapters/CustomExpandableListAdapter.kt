package com.nsicyber.mockimusicplayer.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseExpandableListAdapter
import android.widget.TextView
import com.nsicyber.mockimusicplayer.R
import com.nsicyber.mockimusicplayer.remote.models.Item
import com.nsicyber.mockimusicplayer.remote.models.MusicCategory

class CustomExpandableListAdapter(private val context: Context) : BaseExpandableListAdapter() {
    private var dataList: List<MusicCategory> = emptyList()
    private var onChildClickListener: ((groupPosition: Int, childPosition: Int) -> Unit)? = null

    fun setData(data: List<MusicCategory>?) {
        data?.let {
            dataList = it
            notifyDataSetChanged()
        }

    }

    override fun getGroupCount(): Int {
        return dataList.size
    }

    override fun getChildrenCount(groupPosition: Int): Int {
        return dataList[groupPosition].items?.size?:0
    }

    override fun getGroup(groupPosition: Int): MusicCategory {
        return dataList[groupPosition]
    }

    override fun getChild(groupPosition: Int, childPosition: Int): Item? {
        return dataList[groupPosition].items?.get(childPosition)
    }

    override fun getGroupId(groupPosition: Int): Long {
        return groupPosition.toLong()
    }

    override fun getChildId(groupPosition: Int, childPosition: Int): Long {
        return childPosition.toLong()
    }

    override fun hasStableIds(): Boolean {
        return true
    }

    override fun getGroupView(
        groupPosition: Int,
        isExpanded: Boolean,
        convertView: View?,
        parent: ViewGroup?
    ): View {
        val view: View
        val holder: GroupViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.group_layout, parent, false)
            holder = GroupViewHolder(view)
            view.tag = holder
        } else {
            view = convertView
            holder = convertView.tag as GroupViewHolder
        }

        val obj = getGroup(groupPosition)
        holder.titleTextView.text = obj.baseTitle

        return view
    }

    override fun getChildView(
        groupPosition: Int,
        childPosition: Int,
        isLastChild: Boolean,
        convertView: View?,
        parent: ViewGroup?
    ): View {
        val view: View
        val holder: ChildViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.child_layout, parent, false)
            holder = ChildViewHolder(view)
            view.tag = holder
        } else {
            view = convertView
            holder = convertView.tag as ChildViewHolder
        }

        val child = getChild(groupPosition, childPosition)
        holder.childTextView.text = child?.title

        view.setOnClickListener {
            onClick(groupPosition, childPosition)
        }

        return view
    }


    override fun isChildSelectable(groupPosition: Int, childPosition: Int): Boolean {
        return true
    }

    private class GroupViewHolder(view: View) {
        val titleTextView: TextView = view.findViewById(R.id.group_title)
    }

    private class ChildViewHolder(view: View) {
        val childTextView: TextView = view.findViewById(R.id.child_title)
    }

    fun setOnChildClickListener(listener: (groupPosition: Int, childPosition: Int) -> Unit) {
        onChildClickListener = listener
    }

    private fun onClick(groupPosition: Int, childPosition: Int) {
        onChildClickListener?.invoke(groupPosition, childPosition)
    }
}
