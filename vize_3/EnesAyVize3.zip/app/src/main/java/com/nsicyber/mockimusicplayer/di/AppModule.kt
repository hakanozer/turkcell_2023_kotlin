package com.nsicyber.mockimusicplayer.di


import com.nsicyber.mockimusicplayer.repositories.ApiRepository
import com.nsicyber.mockimusicplayer.utils.Constants.BASE_URL
import com.nsicyber.mockimusicplayer.remote.retrofit.RetrofitInterface
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton
    @Provides
    fun provideApiRepository(api: RetrofitInterface) = ApiRepository(api)

    @Singleton
    @Provides
    fun provideApi(): RetrofitInterface {
        return Retrofit.Builder().addConverterFactory((GsonConverterFactory.create()))
            .baseUrl(BASE_URL).build().create(RetrofitInterface::class.java)
    }

}