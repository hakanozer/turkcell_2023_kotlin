package com.nsicyber.mockimusicplayer.remote.models

data class Item(
    val baseCat: Int?=null,
    val title: String?=null,
    val url: String?=null
)