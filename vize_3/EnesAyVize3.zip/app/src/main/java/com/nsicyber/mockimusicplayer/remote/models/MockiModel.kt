package com.nsicyber.mockimusicplayer.remote.models

data class MockiModel(
    val musicCategories: List<MusicCategory>?= listOf<MusicCategory>()
)
