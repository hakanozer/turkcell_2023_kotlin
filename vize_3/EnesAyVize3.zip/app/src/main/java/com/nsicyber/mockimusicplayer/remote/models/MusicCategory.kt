package com.nsicyber.mockimusicplayer.remote.models

data class MusicCategory(
    val baseTitle: String?=null,
    val items: List<Item>?= listOf<Item>()
)