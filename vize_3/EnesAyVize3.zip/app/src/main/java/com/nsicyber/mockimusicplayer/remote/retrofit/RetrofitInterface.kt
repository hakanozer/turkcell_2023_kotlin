package com.nsicyber.mockimusicplayer.remote.retrofit


import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import retrofit2.http.GET

interface RetrofitInterface {

    @GET("v1/f27fbefc-d775-4aee-8d65-30f76f1f7109 ")
    suspend fun getList(): MockiModel

}