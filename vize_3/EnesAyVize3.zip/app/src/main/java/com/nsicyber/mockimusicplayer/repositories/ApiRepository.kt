package com.nsicyber.mockimusicplayer.repositories


import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import com.nsicyber.mockimusicplayer.utils.Resource
import com.nsicyber.mockimusicplayer.remote.retrofit.RetrofitInterface
import dagger.hilt.android.scopes.ActivityScoped
import java.lang.Exception
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ApiRepository @Inject constructor(
    private val api: RetrofitInterface
) {

    suspend fun getMockiList(): Resource<MockiModel> {
        val response = try {
            api.getList()
        }
        catch (e:Exception){
            return Resource.Error("error")
        }
        return Resource.Success(response)
    }




}