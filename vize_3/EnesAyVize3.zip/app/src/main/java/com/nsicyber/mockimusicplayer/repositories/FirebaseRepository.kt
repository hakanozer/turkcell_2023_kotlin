package com.nsicyber.mockimusicplayer.repositories

import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase
import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseRepository @Inject constructor() {

    val database: DatabaseReference = FirebaseDatabase.getInstance().reference


    fun fetchData(callback: (MockiModel?) -> Unit) {
        val dataRef = database.child("data")
        dataRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val mockiModel = dataSnapshot.getValue(MockiModel::class.java)
                callback(mockiModel)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Veri çekme işlemi iptal edildiğinde yapılacak işlemler
            }
        })
    }

    fun saveData(mockiModel: MockiModel) {
        val dataRef = database.child("data")
        dataRef.setValue(mockiModel)
            .addOnSuccessListener {
                // Kaydetme başarılı olduğunda yapılacak işlemler
                // Örneğin, bir Toast mesajı gösterilebilir
            }
            .addOnFailureListener {
                // Kaydetme başarısız olduğunda yapılacak işlemler
            }
    }

}
