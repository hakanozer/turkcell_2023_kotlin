package com.nsicyber.mockimusicplayer.repositories

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.nsicyber.mockimusicplayer.remote.models.MockiModel

import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.util.Log
import com.nsicyber.mockimusicplayer.MediaPlayerInterface
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class MusicPlayerRepository @Inject constructor() : MediaPlayerInterface {
    private var progressListener: MediaPlayerInterface.OnProgressListener? = null
    override fun setOnProgressListener(listener: MediaPlayerInterface.OnProgressListener) {
        progressListener = listener
    }
    var mediaPlayer = MediaPlayer()

    private var isBuffering = false


    override fun play() {
        onInfo()
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC)
        mediaPlayer.prepare()
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        mediaPlayer.start()
    }

    override fun resume(){
        mediaPlayer.start()
    }

    override fun onInfo(){
        mediaPlayer.setOnBufferingUpdateListener{ mediaPlayer,state ->
            Log.v("MEDIASTATE",state.toString())
            when (state) {
                MediaPlayer.MEDIA_INFO_BUFFERING_START -> isBuffering = true
                MediaPlayer.MEDIA_INFO_BUFFERING_END -> isBuffering = false
            }
        }
    }

    override fun stop() {
        mediaPlayer.reset()
        mediaPlayer.stop()
    }

    override fun pause() {
        mediaPlayer.pause()
    }

    override fun dispose() {
        mediaPlayer.reset()
        mediaPlayer.release()
        mediaPlayer = MediaPlayer()
    }

    override fun setUrl(uri: String?) {
        if(uri == null) return;
        mediaPlayer.setDataSource(uri);
    }


    override fun setVolume(volume: Float) {
        mediaPlayer.setVolume(volume, volume)
    }


}