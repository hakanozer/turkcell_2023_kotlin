package com.nsicyber.mockimusicplayer.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.nsicyber.mockimusicplayer.R
import com.nsicyber.mockimusicplayer.databinding.FragmentLikedMusicsBinding
import com.nsicyber.mockimusicplayer.databinding.FragmentMusicListBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [LikedMusicsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class LikedMusicsFragment : Fragment(R.layout.fragment_liked_musics) {
    private var fragmentBinding: FragmentLikedMusicsBinding? = null

    override fun onViewCreated(
        view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val binding= FragmentLikedMusicsBinding.bind(view)
        fragmentBinding=binding

       // binding.textView1.text="Hello World"

    }

    override fun onDestroyView() {
        super.onDestroyView()
        fragmentBinding = null
    }

}