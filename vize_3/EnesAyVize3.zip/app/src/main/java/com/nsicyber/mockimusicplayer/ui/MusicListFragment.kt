package com.nsicyber.mockimusicplayer.ui

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.nsicyber.mockimusicplayer.R
import com.nsicyber.mockimusicplayer.activities.MusicPlayerActivity
import com.nsicyber.mockimusicplayer.adapters.CustomExpandableListAdapter
import com.nsicyber.mockimusicplayer.databinding.FragmentMusicListBinding
import com.nsicyber.mockimusicplayer.remote.models.Item
import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import com.nsicyber.mockimusicplayer.remote.models.MusicCategory
import com.nsicyber.mockimusicplayer.repositories.FirebaseRepository
import com.nsicyber.mockimusicplayer.utils.toJson
import com.nsicyber.mockimusicplayer.viewmodels.MusicListViewModel
import com.nsicyber.mockimusicplayer.viewmodels.MusicListViewModelFactory

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


/**
 * A simple [Fragment] subclass.
 * Use the [MusicListFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class MusicListFragment : Fragment(R.layout.fragment_music_list) {

    private var fragmentBinding: FragmentMusicListBinding? = null
    private lateinit var viewModel: MusicListViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(
            this,
            MusicListViewModelFactory(FirebaseRepository())
        )[MusicListViewModel::class.java]
        viewModel.getMusicList()
    }

    override fun onViewCreated(
        view: View, savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        val binding = FragmentMusicListBinding.bind(view)
        fragmentBinding = binding

        viewModel.musicList.observe(viewLifecycleOwner) {
            fragmentBinding!!.progressBar.visibility = View.GONE
            setItemsToView(it)
        }


    }

    fun setItemsToView(mockiModel: MockiModel) {
        val adapter = CustomExpandableListAdapter(requireContext())
        adapter.setData(mockiModel.musicCategories)
        adapter.setOnChildClickListener { groupPosition, childPosition ->
            // Tıklanan child'a göre yapılacak işlemleri burada gerçekleştirin.
            openMusicDetail(mockiModel.musicCategories?.get(groupPosition), childPosition)
        }
        fragmentBinding!!.listView.setAdapter(adapter)

    }


    fun openMusicDetail(model: MusicCategory?, index: Int) {
        var intent= Intent(requireContext(),MusicPlayerActivity::class.java)
        intent.putExtra("index",index)
        intent.putExtra("model",model.toJson())
        startActivity(intent)
    }


    override fun onDestroyView() {
        super.onDestroyView()
        fragmentBinding = null
    }

}

