package com.nsicyber.mockimusicplayer.utils

object Constants {
    const val BASE_URL = "https://mocki.io/"
}