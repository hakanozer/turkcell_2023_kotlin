package com.nsicyber.mockimusicplayer.utils

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager

class PreferencesHelper constructor(context: Context) {
    private val mPreferences: SharedPreferences
    private val mEditor: SharedPreferences.Editor


    var isConfigured: Boolean
        get() = mPreferences.getBoolean(   IS_CONFIGURED, false)
        set(isConfigured) {
            mEditor.putBoolean("IS_CONFIGURED", isConfigured)
            mEditor.commit()
        }


    var volume: Int
        get() = mPreferences.getInt(VOLUME, 50)
        set(volume) {
            mEditor.putInt(VOLUME, volume)
            mEditor.commit()
        }


    fun clear() {
        mEditor.clear().commit()
    }

    companion object {
        private var instance: PreferencesHelper? = null
        private const val VOLUME = "volume"
        private const val IS_CONFIGURED = "is_configured"


    }

    init {
        mPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        mEditor = mPreferences.edit()
    }
}