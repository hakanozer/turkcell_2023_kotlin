package com.nsicyber.mockimusicplayer.utils

import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException

fun <T> String.fromJson(type: Class<T>): T? {
    try {
        return Gson().fromJson(this, type);
    } catch (e: Exception) {
        print(e)
    }
    return null;
}
fun <T> T.toJson(): String? {
    return Gson().toJson(this)
}