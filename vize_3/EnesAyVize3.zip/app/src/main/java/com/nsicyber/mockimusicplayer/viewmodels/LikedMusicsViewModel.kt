package com.nsicyber.mockimusicplayer.viewmodels

class LikedMusicsViewModel {
}