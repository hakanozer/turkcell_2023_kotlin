package com.nsicyber.mockimusicplayer.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.google.firebase.ktx.Firebase
import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import com.nsicyber.mockimusicplayer.repositories.FirebaseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject


@HiltViewModel
class MusicListViewModel @Inject constructor(private var firebaseRepository: FirebaseRepository) :
    ViewModel() {

    val musicList = MutableLiveData<MockiModel>()

    fun getMusicList() {
        CoroutineScope(Dispatchers.IO).launch {
            withContext(Dispatchers.Main) {
                firebaseRepository.fetchData {
                    musicList.postValue(it)
                }
            }
        }
    }


}

class MusicListViewModelFactory(private val firebaseRepository: FirebaseRepository) :
    ViewModelProvider.Factory {
     override fun <T : ViewModel> create(modelClass: Class<T>): T {
         return MusicListViewModel(firebaseRepository) as T

     }

}