package com.nsicyber.mockimusicplayer.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.nsicyber.mockimusicplayer.MediaPlayerInterface
import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import com.nsicyber.mockimusicplayer.remote.models.MusicCategory
import com.nsicyber.mockimusicplayer.repositories.FirebaseRepository
import com.nsicyber.mockimusicplayer.repositories.MusicPlayerRepository
import com.nsicyber.mockimusicplayer.utils.PreferencesHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject


@HiltViewModel
class MusicPlayerViewModel @Inject constructor(private var musicPlayerRepository: MusicPlayerRepository) :
    ViewModel() {

    val totalDuration = MutableLiveData<Int>()
    val currentDuration = MutableLiveData<Int>(0)
    val isPlaying = MutableLiveData<Boolean>(false)
    val volumeLevel = MutableLiveData<Int>(50)

    val musicList = MutableLiveData<MusicCategory>()
    val currIndex = MutableLiveData<Int>()

    fun setMusicList(musicCategory: MusicCategory?) {
        musicCategory?.let {
            musicList.postValue(it)
            musicList.observeForever { value ->
                println(value)
            }
        }

    }

    fun setCurrentDuration(duration: Int) {
        val totalDuration = totalDuration.value ?: 0
        if (duration >= 0 && duration <= totalDuration) {
            currentDuration.postValue(duration)
            musicPlayerRepository.mediaPlayer.seekTo(duration)
        }
    }

    fun setCurrIndex(index: Int) {
        currIndex.postValue(index)
    }

    fun playSong() {
        musicPlayerRepository.setUrl(musicList.value?.items?.get(currIndex.value!!)?.url)

        musicPlayerRepository.play()
        musicPlayerRepository.setOnProgressListener(object :
            MediaPlayerInterface.OnProgressListener {
            override fun onProgressUpdate(progress: Int, total: Int) {
                currentDuration.postValue(progress)
                totalDuration.postValue(total)
            }
        })
        isPlaying.value = true

    }

    fun nextSong() {
        if (musicList.value?.items?.size!! < currIndex.value!! + 1) {
            currIndex.postValue(currIndex.value!! + 1)
            currentDuration.value = 0
            musicPlayerRepository.setUrl(musicList.value!!.items?.get(currIndex.value!!)?.url)
            stopSong()
            playSong()
        }


    }

    fun resumeSong() {
        musicPlayerRepository.resume()
        isPlaying.value = true

    }

    fun pauseSong() {
        musicPlayerRepository.pause()
        isPlaying.value = false
    }

    fun disposeSong() {
        musicPlayerRepository.dispose()
    }

    fun stopSong() {
        musicPlayerRepository.stop()
    }

    fun setVolumeLevel(volume: Int) {
        volumeLevel.postValue(volume)

        musicPlayerRepository.setVolume(volume / 100f)
    }

    fun prevSong() {
        if (0 <= currIndex.value!! - 1) {
            currIndex.postValue(currIndex.value!! - 1)
            currentDuration.value = 0
            musicPlayerRepository.setUrl(musicList.value!!.items?.get(currIndex.value!!)?.url)
            stopSong()
            playSong()
        }

    }

}

class MusicPlayerViewModelFactory(private val musicPlayerRepository: MusicPlayerRepository) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MusicPlayerViewModel(musicPlayerRepository) as T
    }
}