package com.nsicyber.mockimusicplayer.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.nsicyber.mockimusicplayer.remote.models.MockiModel
import com.nsicyber.mockimusicplayer.repositories.ApiRepository
import com.nsicyber.mockimusicplayer.repositories.FirebaseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject




@HiltViewModel
class SplashViewModel @Inject constructor(private var apiRepository: ApiRepository,private var firebaseRepository: FirebaseRepository) :
    ViewModel() {

        suspend fun apiToDatabase(){

            apiRepository.getMockiList().data?.let { firebaseRepository.saveData(it) }

        }

}

class SplashViewModelFactory(private var apiRepository: ApiRepository,private val firebaseRepository: FirebaseRepository) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SplashViewModel(apiRepository,firebaseRepository) as T
    }
}