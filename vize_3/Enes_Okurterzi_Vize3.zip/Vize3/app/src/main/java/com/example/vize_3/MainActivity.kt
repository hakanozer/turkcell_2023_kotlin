package com.example.vize_3

import android.content.ContentValues
import android.content.ContentValues.TAG
import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.Navigation
import com.example.vize_3.configs.MockiClient
import com.example.vize_3.databinding.ActivityMainBinding
import com.example.vize_3.models.Category
import com.example.vize_3.models.Item
import com.example.vize_3.models.Music
import com.example.vize_3.models.MusicCategories
import com.example.vize_3.services.MockiService
import com.example.vize_3.ui.HomeFragment
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.BuildConfig
import com.google.firebase.ktx.Firebase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        supportActionBar!!.setBackgroundDrawable(ColorDrawable(getColor(R.color.background)))

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.action_bar_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.favouriteMenuItem -> {
                Navigation.findNavController(this, R.id.fragmentContainerView).navigate(R.id.favouriteFragment)
            }
        }
        return super.onOptionsItemSelected(item)
    }


}