package com.example.vize_3

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.vize_3.configs.MockiClient
import com.example.vize_3.databinding.ActivitySplashBinding
import com.example.vize_3.models.Category
import com.example.vize_3.models.Item
import com.example.vize_3.models.Music
import com.example.vize_3.models.MusicCategories
import com.example.vize_3.services.MockiService
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.BuildConfig
import com.google.firebase.ktx.Firebase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SplashActivity : AppCompatActivity() {

    val sharedPrefs by lazy {
        getSharedPreferences(
            "${BuildConfig.VERSION_NAME}_sharedPreferences",
            Context.MODE_PRIVATE)
    }

    lateinit var mockiService: MockiService
    lateinit var db: FirebaseFirestore
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        supportActionBar!!.setBackgroundDrawable(ColorDrawable(getColor(R.color.background)))
        db = Firebase.firestore

        val firstTime = sharedPrefs.getBoolean("first_time", true)

        if (firstTime) {
            view.postDelayed({
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            },15000)
        } else {
            view.postDelayed({
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            },5000)

        }

        db.collection("musics")
            .get()
            .addOnSuccessListener {
                if (it.isEmpty) {
                    getDataFromMocki()
                }
            }


    }


    private fun getDataFromMocki() {
        mockiService = MockiClient.getClient().create(MockiService::class.java)
        mockiService.musicCategories().enqueue(object: Callback<MusicCategories> {
            override fun onResponse(
                call: Call<MusicCategories>,
                response: Response<MusicCategories>
            ) {
                setFirebase(response.body())
            }

            override fun onFailure(call: Call<MusicCategories>, t: Throwable) {
                Log.e("musicCategories", t.toString())
            }

        })
    }

    private fun setFirebase(body: MusicCategories?) {
        if (body != null) {
            for (musicCategory in body.musicCategories) {

                setCategoriesFirebase(musicCategory.baseTitle)
                setMusicsFirebase(musicCategory.items, musicCategory.baseTitle)

            }
        }
        sharedPrefs.edit().putBoolean("first_time",false).apply()
    }

    private fun setMusicsFirebase(items: List<Item>, baseTitle: String) {
        for (item in items) {

            val music = Music(baseTitle,
                item.baseCat,
                item.title,
                item.url,
                false)

            db.collection("musics")
                .add(music)
                .addOnSuccessListener { documentReference ->
                    Log.d(ContentValues.TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                }
                .addOnFailureListener { e ->
                    Log.w(ContentValues.TAG, "Error adding document", e)
                }
        }
    }

    private fun setCategoriesFirebase(baseTitle: String) {
        val category = Category(baseTitle)

        db.collection("categories")
            .add(category)
            .addOnSuccessListener { documentReference ->
                Log.d(ContentValues.TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error adding document", e)
            }
    }


}