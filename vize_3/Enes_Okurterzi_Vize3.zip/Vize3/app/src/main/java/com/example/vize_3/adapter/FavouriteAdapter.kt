package com.example.vize_3.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Recycler
import com.example.vize_3.R
import com.example.vize_3.configs.Util
import com.google.firebase.firestore.QueryDocumentSnapshot

class FavouriteAdapter(val list: List<QueryDocumentSnapshot>) : RecyclerView.Adapter<FavouriteAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouriteAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.favourite_adapter_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavouriteAdapter.ViewHolder, position: Int) {
        holder.favouriteItemTitle.text = list[position].data.get("title").toString()

        holder.itemView.setOnClickListener {
            Util.chosen = list[position]
            Navigation.findNavController(it).navigate(R.id.action_favouriteFragment_to_detailFragment)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        var favouriteItemTitle: TextView = itemView.findViewById(R.id.favouriteItemTitle)
    }
}
