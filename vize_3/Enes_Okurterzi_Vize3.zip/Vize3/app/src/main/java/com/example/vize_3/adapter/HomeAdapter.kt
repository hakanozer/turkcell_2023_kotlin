package com.example.vize_3.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseExpandableListAdapter
import android.widget.LinearLayout
import android.widget.TextView
import androidx.navigation.Navigation
import com.example.vize_3.R
import com.example.vize_3.configs.Util
import com.google.firebase.firestore.QueryDocumentSnapshot

class HomeAdapter internal constructor(private val context: Context,
                                       private val groupList: List<String>,
                                       private val childList: HashMap<String, List<QueryDocumentSnapshot>>
)
    :BaseExpandableListAdapter() {

    override fun getGroupCount(): Int {
        return groupList.size
    }

    override fun getChildrenCount(p0: Int): Int {
        return this.childList[this.groupList[p0]]?.size ?: 0
    }

    override fun getGroup(p0: Int): Any {
        return groupList[p0]
    }

    override fun getChild(p0: Int, p1: Int): Any {
        return this.childList[this.groupList[p0]]!![p1]
    }

    override fun getGroupId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getChildId(p0: Int, p1: Int): Long {
        return p1.toLong()
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun getGroupView(p0: Int, p1: Boolean, p2: View?, p3: ViewGroup?): View {
        var convertView = p2
        val title = getGroup(p0) as String

        if (convertView == null) {
            val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.group_item, null)
        }

        val categoryTitle = convertView!!.findViewById<TextView>(R.id.categoryTitle)
        categoryTitle.text = title

        return convertView

    }

    override fun getChildView(p0: Int, p1: Int, p2: Boolean, p3: View?, p4: ViewGroup?): View {
        var convertView = p3
        val childDocument = getChild(p0, p1) as QueryDocumentSnapshot
        val title = childDocument.data["title"].toString()

        if (convertView == null) {
            val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.child_item, null)
        }

        val childItem = convertView!!.findViewById<LinearLayout>(R.id.childItem)
        val childTitle = convertView!!.findViewById<TextView>(R.id.childTitle)
        childTitle.text = title

        childItem.setOnClickListener {
            Util.chosen = childDocument
            Navigation.findNavController(it).navigate(R.id.action_homeFragment_to_detailFragment)
        }



        return convertView
    }

    override fun isChildSelectable(p0: Int, p1: Int): Boolean {
        return true
    }
}