package com.example.vize_3.configs

import com.example.vize_3.models.Music
import com.google.firebase.firestore.QueryDocumentSnapshot

class Util {
    companion object {
        var chosen: QueryDocumentSnapshot? = null
        var chosenMusic: Music? = null
    }
}