package com.example.vize_3.models

data class Category(
    val categoryTitle: String,
)
