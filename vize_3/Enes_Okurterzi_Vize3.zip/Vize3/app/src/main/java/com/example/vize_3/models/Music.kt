package com.example.vize_3.models

data class Music(
    var baseTitle: String,
    var baseCat: Long,
    var title: String,
    var url: String,
    var favourite: Boolean
)
