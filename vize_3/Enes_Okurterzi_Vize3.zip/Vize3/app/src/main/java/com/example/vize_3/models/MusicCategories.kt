package com.example.vize_3.models

data class MusicCategories(
    val musicCategories: List<MusicCategory>
)

data class MusicCategory (
    val baseTitle: String,
    val items: List<Item>
)

data class Item (
    val baseCat: Long,
    val title: String,
    val url: String
)
