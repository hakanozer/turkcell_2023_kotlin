package com.example.vize_3.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import com.example.vize_3.R
import com.example.vize_3.configs.Util
import com.example.vize_3.databinding.FragmentDetailBinding
import com.example.vize_3.models.Music
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.BuildConfig
import com.google.firebase.ktx.Firebase

class DetailFragment : Fragment() {

    val sharedPrefs by lazy {
        requireActivity().getSharedPreferences(
            "${BuildConfig.VERSION_NAME}_sharedPreferences",
            Context.MODE_PRIVATE)
    }

    lateinit var db: FirebaseFirestore
    lateinit var mediaPlayer: MediaPlayer
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(inflater,container,false)
        dataSet()
        viewSet()
        db = Firebase.firestore

        binding.favouriteBtn.setOnClickListener {
            val documentReference = db.collection("musics").document(Util.chosen!!.id)
            if (!Util.chosenMusic!!.favourite){

                Util.chosenMusic!!.favourite = true
                documentReference.set(Util.chosenMusic!!)
            } else {

                Util.chosenMusic!!.favourite = false
                documentReference.set(Util.chosenMusic!!)
            }
            buttonSet()

        }

        binding.playBtn.setOnClickListener {
            mediaPlayer.start()
        }

        binding.pauseBtn.setOnClickListener {
            mediaPlayer.pause()
        }

        binding.volumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                val f1 = p1.toFloat() / 100
                mediaPlayer.setVolume(f1,f1)
                sharedPrefs.edit().putFloat("volume",f1).apply()
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })

        return binding.root
    }

    private fun initializeMediaPlayer() {
        val url = Util.chosen!!.data.get("url").toString()
        mediaPlayer = MediaPlayer()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mediaPlayer.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setLegacyStreamType(AudioManager.STREAM_MUSIC)
                    .build()
            )
        } else {
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC)
        }
        try {
            mediaPlayer.setOnPreparedListener { mp -> mp.start() }
            mediaPlayer.setDataSource(url)
            mediaPlayer.prepareAsync()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStop() {
        this@DetailFragment.requireView().postDelayed({
            mediaPlayer.stop()
        }, 500)

        super.onStop()
    }


    private fun viewSet() {
        buttonSet()

        val volume = sharedPrefs.getFloat("volume", 0.5f)

        initializeMediaPlayer()
        binding.detailTitleTxt.text = Util.chosen?.data?.get("title").toString()
        binding.volumeSeekBar.progress = (volume * 100).toInt()
        mediaPlayer.setVolume(volume,volume)
    }

    private fun dataSet() {
        val data = Util.chosen!!.data

        val music = Music(
            data["baseTitle"].toString(),
            data["baseCat"].toString().toLong(),
            data["title"].toString(),
            data["url"].toString(),
            data["favourite"].toString().toBoolean(),
        )
        Util.chosenMusic = music
    }

    private fun buttonSet() {
        if (!Util.chosenMusic!!.favourite) {
            binding.favouriteBtn.setImageResource(R.drawable.baseline_star_border_24)
        } else {
            binding.favouriteBtn.setImageResource(R.drawable.baseline_star_24)
        }
    }

}