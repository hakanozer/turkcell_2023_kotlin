package com.example.vize_3.ui

import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.vize_3.R
import com.example.vize_3.adapter.FavouriteAdapter
import com.example.vize_3.databinding.FragmentFavouriteBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QueryDocumentSnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class FavouriteFragment : Fragment() {

    private var _binding: FragmentFavouriteBinding? = null
    private val binding get() = _binding!!
    private lateinit var favouriteAdapter: FavouriteAdapter
    lateinit var db: FirebaseFirestore
    private var dataList: MutableList<QueryDocumentSnapshot> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavouriteBinding.inflate(inflater, container, false)

        db = Firebase.firestore

        getList()

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        favouriteAdapter = FavouriteAdapter(dataList)
        binding.recyclerView.adapter = favouriteAdapter

        return binding.root
    }

    private fun getList() {
        dataList = mutableListOf()

        db.collection("musics")
            .whereEqualTo("favourite", true)
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    dataList.add(document)
                    favouriteAdapter.notifyDataSetChanged()
                }
            }
            .addOnFailureListener { exception ->
                Log.w(ContentValues.TAG, "Error getting documents: ", exception)
            }


    }

}