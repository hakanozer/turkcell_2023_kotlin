package com.example.vize_3.ui

import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import com.example.vize_3.R
import com.example.vize_3.adapter.HomeAdapter
import com.example.vize_3.databinding.FragmentHomeBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QueryDocumentSnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.Timer
import java.util.TimerTask
import kotlin.concurrent.timerTask

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    lateinit var db: FirebaseFirestore
    private lateinit var listViewAdapter: HomeAdapter
    private var groupList: List<String> = mutableListOf()
    private var childList: HashMap<String, List<QueryDocumentSnapshot>> = HashMap()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        db = Firebase.firestore

        showList()

        listViewAdapter = HomeAdapter(this.requireContext(),groupList, childList)
        binding.eListView.setAdapter(listViewAdapter)


        return binding.root
    }


    fun showList() {
        groupList = ArrayList()
        childList = HashMap()

        db.collection("categories")
                .orderBy("categoryTitle")
                .get()
                .addOnSuccessListener { result ->
                    for (document in result) {
                        (groupList as ArrayList<String>).add(document.data["categoryTitle"].toString())
                        listViewAdapter.notifyDataSetChanged()
                    }
                    setChild()
                }
                .addOnFailureListener { exception ->
                    Log.w(ContentValues.TAG, "Error getting documents: ", exception)
        }

        listViewAdapter = HomeAdapter(this.requireContext(),groupList, childList)
        binding.eListView.setAdapter(listViewAdapter)


    }

    private fun setChild() {

            for (it in groupList) {
                val childDocument: MutableList<QueryDocumentSnapshot> = ArrayList()
                db.collection("musics")
                    .whereEqualTo("baseTitle", it)
                    .get()
                    .addOnSuccessListener { result ->
                        for (document in result) {
                            childDocument.add(document)
                        }
                        childList[it] = childDocument
                        listViewAdapter.notifyDataSetChanged()
                    }
                    .addOnFailureListener { exception ->
                        Log.w(ContentValues.TAG, "Error getting documents: ", exception)
                    }
            }

    }


}