package com.plcoding.spotifycloneyt.data.model

data class MusicCategory(
    val baseTitle: String,
    val items: List<MusicItem>
)