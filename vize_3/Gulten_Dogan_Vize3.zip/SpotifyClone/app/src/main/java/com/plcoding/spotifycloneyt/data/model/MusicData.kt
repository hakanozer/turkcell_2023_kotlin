package com.plcoding.spotifycloneyt.data.model

data class MusicData(
    val musicCategories: List<MusicCategory>
)