package com.plcoding.spotifycloneyt.data.model

data class MusicItem(
    val baseCat: Int,
    val title: String,
    val url: String
)