package com.plcoding.spotifycloneyt.service

import com.plcoding.spotifycloneyt.data.model.MusicData
import com.plcoding.spotifycloneyt.data.model.MusicItem
import retrofit2.Call
import retrofit2.http.GET

//https://mocki.io/v1/f27fbefc-d775-4aee-8d65-30f76f1f7109

interface Service {

    @GET("/v1/f27fbefc-d775-4aee-8d65-30f76f1f7109")
    fun getCategory(): Call<MusicData>


    @GET("/v1/f27fbefc-d775-4aee-8d65-30f76f1f7109")
    fun getItem(): Call<MusicItem>


}