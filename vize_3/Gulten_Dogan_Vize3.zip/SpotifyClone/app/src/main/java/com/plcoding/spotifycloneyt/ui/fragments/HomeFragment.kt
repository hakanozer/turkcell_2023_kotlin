package com.plcoding.spotifycloneyt.ui.fragments

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.RequestManager
import com.plcoding.spotifycloneyt.R
import com.plcoding.spotifycloneyt.adapters.SongAdapter
import com.plcoding.spotifycloneyt.data.entities.Song
import com.plcoding.spotifycloneyt.data.model.MusicData
import com.plcoding.spotifycloneyt.other.Resource
import com.plcoding.spotifycloneyt.other.Status
import com.plcoding.spotifycloneyt.service.Service
import com.plcoding.spotifycloneyt.ui.viewmodels.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.fragment_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class HomeFragment : Fragment(R.layout.fragment_home) {

    lateinit var mainViewModel: MainViewModel
    private val baseUrl = "https://mocki.io"

    @Inject
    lateinit var songAdapter: SongAdapter

    @Inject
    lateinit var glide: RequestManager

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mainViewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)
        setupRecyclerView()
        subscribeToObservers()
        fetchMusicItems()
    }

    private fun setupRecyclerView() = rvAllSongs.apply {
        adapter = songAdapter
        layoutManager = LinearLayoutManager(requireContext())
    }

    private fun subscribeToObservers() {
        mainViewModel.mediaItems.observe(viewLifecycleOwner) { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    allSongsProgressBar.isVisible = false
                    result.data?.let { songs ->
                        songAdapter.songs = songs
                        songAdapter.notifyDataSetChanged()
                    }
                }
                Status.ERROR -> Unit
                Status.LOADING -> allSongsProgressBar.isVisible = true
            }
        }

        songAdapter.setItemClickListener { song ->
            mainViewModel.playOrToggleSong(song)
        }
    }

    private fun fetchMusicItems() {
        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(Service::class.java)
        val call = service.getCategory()

        call.enqueue(object : Callback<MusicData> {
            override fun onResponse(call: Call<MusicData>, response: Response<MusicData>) {
                if (response.isSuccessful) {
                    val musicData = response.body()
                    val songs = mutableListOf<Song>()

                    musicData?.musicCategories?.forEach { category ->
                        category.items.forEach { musicItem ->
                            val song = Song(
                                mediaId = UUID.randomUUID().toString(),
                                title = musicItem.title,
                                subtitle = category.baseTitle,
                                songUrl = musicItem.url,
                                imageUrl = "" // Placeholder for image URL
                            )
                            songs.add(song)
                        }
                    }
                    mainViewModel.updateMediaItems(songs)
                } else {
                    println("Request failed: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<MusicData>, t: Throwable) {
                println("Request failed: ${t.message}")
            }
        })
    }
}