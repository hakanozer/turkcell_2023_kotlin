package com.example.android_music_player.configs

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.android_music_player.dao.FavoriteMusicDao
import com.example.android_music_player.models.FavoriteMusic
import com.example.android_music_player.models.Item

@Database(entities = [FavoriteMusic::class], version = 1)
abstract class AppDataBase : RoomDatabase() {

    abstract fun studentDao(): FavoriteMusicDao

}