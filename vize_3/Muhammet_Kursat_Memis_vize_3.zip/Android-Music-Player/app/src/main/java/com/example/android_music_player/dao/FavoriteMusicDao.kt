package com.example.android_music_player.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.android_music_player.models.FavoriteMusic
import com.example.android_music_player.models.Item
import com.example.android_music_player.models.MusicCategory

@Dao
interface FavoriteMusicDao {

    @Insert
    fun insert(favoriteMusic: FavoriteMusic)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_music WHERE url = :url LIMIT 1)")
    fun existsByUrl(url: String): Boolean

    @Query("DELETE FROM favorite_music WHERE url = :url")
    fun deleteByURL(url: String)

    @Query("Delete From favorite_music")
    fun deleteAll()

    @Query("Select * from favorite_music")
    fun getAll(): List<FavoriteMusic>
}