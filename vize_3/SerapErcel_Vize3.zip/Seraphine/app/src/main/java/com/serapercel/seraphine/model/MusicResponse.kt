package com.serapercel.seraphine.model

data class MusicResponse (
    val musicCategories: List<MusicCategory>? = null
)
