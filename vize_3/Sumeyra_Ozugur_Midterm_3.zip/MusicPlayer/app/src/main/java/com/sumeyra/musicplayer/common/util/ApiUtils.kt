package com.sumeyra.musicplayer.common.util

import com.sumeyra.musicplayer.common.util.Constants.BASE_URL
import com.sumeyra.musicplayer.retrofit.MusicService
import com.sumeyra.musicplayer.retrofit.RetrofitClient

object ApiUtils {
    fun getMusicsDAOInterface(): MusicService =
        RetrofitClient.getClient(BASE_URL).create(MusicService::class.java)
}