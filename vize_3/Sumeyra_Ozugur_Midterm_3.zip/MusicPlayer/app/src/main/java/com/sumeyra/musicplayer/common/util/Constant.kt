package com.sumeyra.musicplayer.common.util

object Constants {

    const val BASE_URL = "https://mocki.io/v1/"

}