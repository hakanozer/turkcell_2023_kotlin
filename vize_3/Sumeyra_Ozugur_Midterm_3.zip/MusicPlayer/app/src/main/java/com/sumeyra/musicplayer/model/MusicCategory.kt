package com.sumeyra.musicplayer.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MusicCategory(
    val baseTitle: String,
    val items: List<MusicItem>
):Parcelable{
        constructor() : this("", listOf())
}