package com.sumeyra.musicplayer.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import kotlinx.parcelize.Parcelize


@Parcelize
@Entity(tableName = "fav_table",  primaryKeys = ["fav_id", "fav_url"])
data class MusicItem(
    @ColumnInfo(name = "fav_id")
    val baseCat: Int = -1,
    @ColumnInfo(name = "fav_title")
    val title: String = "",
    @ColumnInfo(name = "fav_url")
    val url: String = "",
    var isFav: Boolean = false
):Parcelable