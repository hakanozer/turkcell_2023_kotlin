package com.sumeyra.musicplayer.model

data class MusicResponse(
    val musicCategories: List<MusicCategory>
){
   constructor(): this(listOf<MusicCategory>())
}
