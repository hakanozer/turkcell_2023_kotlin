package com.sumeyra.musicplayer.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.google.firebase.firestore.FirebaseFirestore
import com.sumeyra.musicplayer.common.resource.NetworkResource
import com.sumeyra.musicplayer.common.util.ApiUtils
import com.sumeyra.musicplayer.model.MusicCategory
import com.sumeyra.musicplayer.model.MusicItem
import com.sumeyra.musicplayer.model.MusicResponse
import com.sumeyra.musicplayer.retrofit.MusicService
import com.sumeyra.musicplayer.room.FavMusicDatabase
import kotlinx.coroutines.tasks.await

class MusicRepository(application: Application) {
    private val musicService: MusicService = ApiUtils.getMusicsDAOInterface()
    private val fireStore: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val favDao = FavMusicDatabase.getDatabase(application).favDao()
    var favList: LiveData<List<MusicItem>> = favDao.getAllFav()

    private suspend fun getAllMusicFromApi(): NetworkResource<MusicResponse> {
        NetworkResource.Loading
        val musicResponse = musicService.getMusicData()
        return if (musicResponse.isSuccessful) {
            val musicResponseBody = musicResponse.body()
            if (musicResponseBody == null) {
                NetworkResource.Error("Something went wrong")
            } else {
                NetworkResource.Success(data = musicResponseBody)
            }
        } else {
            NetworkResource.Error("Failed to retrieve musics: ${musicResponse.code()} ${musicResponse.message()}")
        }
    }
    private suspend fun addMusicToFirebase(musicCategories: List<MusicCategory>) {
        val map = hashMapOf(
            "musicCategories" to musicCategories
        )
        fireStore.collection("musics").document("categories").set(map).await()
    }

    suspend fun getAllMusics(): NetworkResource<MusicResponse?>? {
        NetworkResource.Loading
        val result = fireStore.collection("musics").document("categories").get().await()
        return if (result.data?.isNotEmpty() == true) {
            NetworkResource.Success(result.toObject(MusicResponse::class.java))
        } else {
            val musicResult = getAllMusicFromApi()
            if (musicResult is NetworkResource.Success) {
                addMusicToFirebase(musicResult.data.musicCategories)
                musicResult
            } else {
                null
            }
        }
    }

    suspend fun addToFav(fav: MusicItem) = favDao.addToFav(fav)
    suspend fun updateTodo(fav: MusicItem) = favDao.updateMusic(fav)
    suspend fun deleteFromFav(fav: MusicItem) = favDao.deleteFromFav(fav)
}