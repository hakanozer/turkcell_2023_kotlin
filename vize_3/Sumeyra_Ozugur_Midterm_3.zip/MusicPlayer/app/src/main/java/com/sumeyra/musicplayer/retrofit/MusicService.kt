package com.sumeyra.musicplayer.retrofit

import com.sumeyra.musicplayer.model.MusicResponse
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET

interface MusicService {

    @GET("f27fbefc-d775-4aee-8d65-30f76f1f7109")
    suspend fun getMusicData(): Response<MusicResponse>

}