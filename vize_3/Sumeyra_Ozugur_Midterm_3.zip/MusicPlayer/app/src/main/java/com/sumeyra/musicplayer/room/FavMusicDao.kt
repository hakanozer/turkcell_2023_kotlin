package com.sumeyra.musicplayer.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sumeyra.musicplayer.model.MusicItem

@Dao
interface FavMusicDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToFav(fav: MusicItem)

    @Query("SELECT * FROM fav_table ORDER BY fav_id ASC")
    fun getAllFav(): LiveData<List<MusicItem>>

    @Update
    suspend fun updateMusic(fav: MusicItem)

    @Delete
    suspend fun deleteFromFav(fav: MusicItem)
}