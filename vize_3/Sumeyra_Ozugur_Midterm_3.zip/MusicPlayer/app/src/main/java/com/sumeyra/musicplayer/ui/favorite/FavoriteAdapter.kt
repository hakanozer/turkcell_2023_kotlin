package com.sumeyra.musicplayer.ui.favorite

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.musicplayer.databinding.MusicFavItemBinding
import com.sumeyra.musicplayer.model.MusicItem


class FavoriteAdapter(
    private val onClick: (MusicItem ) -> Unit = {},
) : ListAdapter<MusicItem, FavoriteAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            MusicFavItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
    }

    inner class ViewHolder(private val binding: MusicFavItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(fav: MusicItem) = with(binding) {
            title.text = fav.title

            root.setOnClickListener {
                onClick(fav)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<MusicItem>() {
        override fun areItemsTheSame(oldItem:MusicItem, newItem: MusicItem) =
            oldItem.url == newItem.url

        override fun areContentsTheSame(oldItem:MusicItem, newItem: MusicItem) =
            oldItem == newItem
    }
}