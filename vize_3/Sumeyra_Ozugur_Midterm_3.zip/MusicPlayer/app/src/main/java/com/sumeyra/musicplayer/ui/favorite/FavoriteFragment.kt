package com.sumeyra.musicplayer.ui.favorite


import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.sumeyra.musicplayer.R
import com.sumeyra.musicplayer.databinding.FragmentFavoriteBinding
import com.sumeyra.musicplayer.delegete.viewBinding
import com.sumeyra.musicplayer.model.MusicItem


class FavoriteFragment : Fragment(R.layout.fragment_favorite) {
    private val binding by viewBinding(FragmentFavoriteBinding::bind)
    private val viewModel: FavoriteViewModel by viewModels()
    private val adapter by lazy { FavoriteAdapter( onClick = ::onClick) }

    private fun onClick(musicItem: MusicItem) {
        val action =
            FavoriteFragmentDirections.actionFavoriteFragmentToMusicFragment(musicItem)
        findNavController().navigate(action)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding){
            binding.recyclerView.adapter = adapter
        }
        initializeObserver()

    }



    private fun initializeObserver() {
        viewModel.favAllList.observe(viewLifecycleOwner){ favList ->
          if(favList.isEmpty()) {
              binding.tvEmpty.visibility =View.VISIBLE
              adapter.submitList(favList)
          }
          else
          {
              binding.tvEmpty.visibility =View.GONE
              adapter.submitList(favList)
          }
        }
    }
}