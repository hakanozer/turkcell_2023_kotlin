package com.sumeyra.musicplayer.ui.favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.sumeyra.musicplayer.model.MusicItem
import com.sumeyra.musicplayer.repository.MusicRepository

class FavoriteViewModel (application: Application) : AndroidViewModel(application) {
    private val musicRepository = MusicRepository(application)
    val favAllList: LiveData<List<MusicItem>> = musicRepository.favList


}