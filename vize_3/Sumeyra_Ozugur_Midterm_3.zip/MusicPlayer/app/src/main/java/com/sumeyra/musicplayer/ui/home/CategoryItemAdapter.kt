package com.sumeyra.musicplayer.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.musicplayer.databinding.MusicCategoryRowItemBinding
import com.sumeyra.musicplayer.model.MusicItem

class CategoryItemAdapter(  private val onItemClick: (item: MusicItem) -> Unit)
    : ListAdapter<MusicItem, CategoryItemAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            MusicCategoryRowItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
    }

    inner class ViewHolder(private val binding: MusicCategoryRowItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: MusicItem) = with(binding) {
            title.text = item.title
            binding.title.setOnClickListener { onItemClick(item) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback< MusicItem>() {
        override fun areItemsTheSame(oldItem:  MusicItem, newItem:  MusicItem) =
            oldItem.baseCat == newItem.baseCat

        override fun areContentsTheSame(oldItem:  MusicItem, newItem: MusicItem) =
            oldItem == newItem
    }
}