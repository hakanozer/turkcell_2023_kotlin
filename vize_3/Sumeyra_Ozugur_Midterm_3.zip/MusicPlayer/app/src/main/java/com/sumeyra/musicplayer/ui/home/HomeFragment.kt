package com.sumeyra.musicplayer.ui.home

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.sumeyra.musicplayer.R
import com.sumeyra.musicplayer.common.extension.showErrorSnackBar
import com.sumeyra.musicplayer.common.resource.NetworkResource
import com.sumeyra.musicplayer.databinding.FragmentHomeBinding
import com.sumeyra.musicplayer.delegete.viewBinding


class HomeFragment : Fragment(R.layout.fragment_home) {
    private val binding by viewBinding(FragmentHomeBinding::bind)
    private val viewModel: HomeViewModel by viewModels()
    private val adapter by lazy { MusicAdapter() }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recyclerView.adapter = adapter
        initializeObserver()
    }

    private fun initializeObserver() {
        viewModel.musicList.observe(viewLifecycleOwner) {
            when (it) {
                is NetworkResource.Success -> {
                    adapter.submitList(it.data?.musicCategories)
                    binding.progressBar.visibility = View.GONE

                }
                is NetworkResource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
                else -> requireView().showErrorSnackBar("Fail", true)
            }

        }
    }
}