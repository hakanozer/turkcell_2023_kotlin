package com.sumeyra.musicplayer.ui.home


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.sumeyra.musicplayer.common.resource.NetworkResource
import com.sumeyra.musicplayer.model.MusicResponse
import com.sumeyra.musicplayer.repository.MusicRepository
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val musicRepository = MusicRepository(application)
    private val _musicList = MutableLiveData<NetworkResource<MusicResponse?>?>()
    val musicList: LiveData<NetworkResource<MusicResponse?>?> get() = _musicList

    init {
        getAllMusic()
    }


    private fun getAllMusic() {
        viewModelScope.launch {
            _musicList.value = NetworkResource.Loading
            _musicList.value = musicRepository.getAllMusics()
        }
    }
}
