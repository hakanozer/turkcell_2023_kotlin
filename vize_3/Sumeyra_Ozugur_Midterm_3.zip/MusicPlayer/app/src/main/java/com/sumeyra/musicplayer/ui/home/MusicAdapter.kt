package com.sumeyra.musicplayer.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sumeyra.musicplayer.databinding.MusicRowItemBinding
import com.sumeyra.musicplayer.model.MusicCategory

class MusicAdapter : ListAdapter<MusicCategory, MusicAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            MusicRowItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
    }

    inner class ViewHolder(private val binding: MusicRowItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(musicCategory: MusicCategory) = with(binding) {
            musicBaseTitle.text = musicCategory.baseTitle


            val itemAdapter = CategoryItemAdapter { musicItem ->
                val action = HomeFragmentDirections.actionHomeFragmentToMusicFragment(musicItem)
                binding.root.findNavController().navigate(action)
            }

            itemAdapter.submitList(musicCategory.items)

            categoryItemRecyclerview.adapter = itemAdapter

        }
    }

    class DiffCallback : DiffUtil.ItemCallback<MusicCategory>() {
        override fun areItemsTheSame(oldItem: MusicCategory, newItem: MusicCategory) =
            oldItem.baseTitle == newItem.baseTitle

        override fun areContentsTheSame(oldItem: MusicCategory, newItem: MusicCategory) =
            oldItem == newItem
    }
}