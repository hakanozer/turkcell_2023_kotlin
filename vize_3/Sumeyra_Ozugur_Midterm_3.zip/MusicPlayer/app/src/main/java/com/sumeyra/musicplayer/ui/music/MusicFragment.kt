package com.sumeyra.musicplayer.ui.music


import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import androidx.core.content.edit
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.sumeyra.musicplayer.R
import com.sumeyra.musicplayer.databinding.FragmentMusicBinding
import com.sumeyra.musicplayer.delegete.viewBinding
import com.sumeyra.musicplayer.model.MusicItem


class MusicFragment : Fragment(R.layout.fragment_music) {
    private val binding by viewBinding(FragmentMusicBinding::bind)
    private val viewModel: MusicViewModel by viewModels()
    private val args: MusicFragmentArgs by navArgs()
    private lateinit var exoPlayer: ExoPlayer

    private val volumeSharedPref by lazy {
        requireActivity().getSharedPreferences("VolumePref", Context.MODE_PRIVATE)
    }
    private val audioManager: AudioManager by lazy {
        requireContext().getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    private var savedVolume: Float = 0.5f // Varsayılan ses seviyesi 0.5

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val musicType = args.itemMusic




        with(binding){
            titleItem.text = musicType.title
            setupExoPlayer(musicType.url)
            setupVolumeSeekBar()



            btnAddFav.setOnClickListener {

                if(musicType.isFav){
                    musicType.isFav =false
                    val updateMusic = MusicItem(musicType.baseCat,musicType.title,musicType.url,musicType.isFav)
                    viewModel.deleteFromFav(updateMusic)
                    btnAddFav.setBackgroundResource(R.drawable.ic_favorite)
                    viewModel.updateFav(updateMusic)
                }else{
                    musicType.isFav = true
                    val updateMusic = MusicItem(musicType.baseCat,musicType.title,musicType.url,musicType.isFav)
                    viewModel.addToFav(updateMusic)
                    btnAddFav.setBackgroundResource(R.drawable.ic_full_fav)
                    viewModel.updateFav(updateMusic)
                }
            }

            if(musicType.isFav) binding.btnAddFav.setBackgroundResource(R.drawable.ic_full_fav)
            else binding.btnAddFav.setBackgroundResource(R.drawable.ic_favorite)
        }
    }

    private fun setupExoPlayer(mp3Url: String) {
        val mediaItem = MediaItem.fromUri(Uri.parse(mp3Url))

        exoPlayer = context?.let { ExoPlayer.Builder(it).build() }!!
        binding.playerView.player = exoPlayer
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()

    }

    private fun updateSystemVolume(volume: Float) {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val targetVolume = (volume * maxVolume).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, 0)
    }

    private fun setupVolumeSeekBar() {
        savedVolume = volumeSharedPref.getFloat("volume", savedVolume)

        //shared da ki değeri progrese ve textviewa setledik.
        val progress = (savedVolume * 100).toInt()
        binding.seekVolume.progress = progress
        binding.tvSeekProgress.text = progress.toString()


        //seekbarı her elimizle değiştirdiğimizde exoPlayerın ses seviyesi ve textviewları güncelleyip ardından sharade saveliyoruz.
        binding.seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvSeekProgress.text = progress.toString()

                if (fromUser) {
                    val volume = progress / 100f
                    exoPlayer.volume = volume
                    savedVolume = volume

                    // Sistem ses seviyesini güncelliyor
                    updateSystemVolume(volume)

                    //progresin değerini sharede saveledik.
                    volumeSharedPref.edit {
                        putFloat("volume", volume)
                        apply()
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                binding.tvSeekProgress.text = seekBar?.progress.toString()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                binding.tvSeekProgress.text = seekBar?.progress.toString()
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayer.stop()
        exoPlayer.release()

    }
}