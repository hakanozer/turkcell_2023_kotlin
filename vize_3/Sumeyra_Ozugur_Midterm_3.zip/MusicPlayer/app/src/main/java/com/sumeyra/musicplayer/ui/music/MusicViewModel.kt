package com.sumeyra.musicplayer.ui.music

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sumeyra.musicplayer.model.MusicItem
import com.sumeyra.musicplayer.repository.MusicRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val musicRepository = MusicRepository(application)


    fun addToFav(fav: MusicItem) {
        viewModelScope.launch(Dispatchers.IO) {
            musicRepository.addToFav(fav)
        }
    }

    fun deleteFromFav(fav: MusicItem) {
        viewModelScope.launch(Dispatchers.IO) {
            musicRepository.deleteFromFav(fav)
        }
    }

    fun updateFav(fav:MusicItem){
        viewModelScope.launch(Dispatchers.IO) {
            musicRepository.updateTodo(fav)

        }
    }
}