package com.example.musicplayerapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.musicplayerapp.adapters.ExpandableListViewAdapter
import com.example.musicplayerapp.databinding.ActivityMainBinding
import com.example.musicplayerapp.models.Music
import com.example.musicplayerapp.models.MusicCategories
import com.example.musicplayerapp.models.MusicCategory
import com.example.musicplayerapp.services.Service
import com.example.musicplayerapp.utils.ApiClient
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    lateinit var service: Service
    lateinit var groupList: MutableList<MusicCategory>
    lateinit var childList: HashMap<MusicCategory, List<Music>>
    lateinit var mCategories: MusicCategories
    lateinit var expListAdapter: ExpandableListViewAdapter

    lateinit var db: DatabaseReference

    var firstTime: Boolean = true

    companion object{
        lateinit var currentUserId: String
        lateinit var selectedCategory: MusicCategory
        lateinit var selectedMusic: Music
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val sharedPref = getSharedPreferences("userId", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()

        //İlk giriş olup olmadığını kontrol etme mantığı
        if(!sharedPref.contains("userId")){
            val id = UUID.randomUUID().toString()
            editor.putString("userId", id).commit()
            currentUserId = id
        }else{
            var id = sharedPref.getString("userId", "")
            if (id.toString().isEmpty()){
                id = UUID.randomUUID().toString()
                sharedPref.edit().putString(id, "userId").commit()
                currentUserId = id
            }else{
                firstTime = false
                currentUserId = id!!
            }
        }

        db = FirebaseDatabase.getInstance("https://music-player-app-3a98a-default-rtdb.europe-west1.firebasedatabase.app").getReference("Users")
        mCategories = MusicCategories(listOf<MusicCategory>())
        service = ApiClient.getClient().create(Service::class.java)
        groupList = mutableListOf()
        childList = HashMap()

        if (firstTime){
            GlobalScope.launch {
                fetchDataFromService()
                firstTime = false
            }
        }else{
            fetchDataFromDatabase()
        }

        binding.catList.setOnChildClickListener { parent, v, groupPosition, childPosition, id ->
            selectedCategory = groupList[groupPosition]
            selectedMusic = childList[groupList[groupPosition]]!![childPosition]
            val i = Intent(this@MainActivity, PlayerActivity::class.java)
            startActivity(i)
            binding.catList.collapseGroup(groupPosition)
            false
        }
    }

    override fun onResume() {
        super.onResume()
        groupList.clear()
        childList.clear()
        fetchDataFromDatabase()
    }

    fun createCollections(mCategories: MusicCategories){
        for(cat in mCategories.musicCategories){
            groupList.add(cat)
            val musics: MutableList<Music> = ArrayList()
            for (music in cat.items){
                musics.add(music)
            }
            childList[groupList[groupList.lastIndex]] = musics
        }
    }

    fun writeToDatabase(mCategories: MusicCategories){
        for (cat in mCategories.musicCategories){
            for (music in cat.items){
                music.favourite = "false"
                music.title?.let {
                    db.child(currentUserId).child(cat.baseTitle.replace(".", "")).child(
                        it.replace(".", "")).setValue(music)
                }
            }
        }
    }

    suspend fun fetchDataFromService(){
        withContext(Dispatchers.IO){
            service.getCategories().enqueue(object : Callback<MusicCategories>{
                override fun onResponse(
                    call: Call<MusicCategories>,
                    response: Response<MusicCategories>
                ) {
                    if(response.body() != null){
                        mCategories.musicCategories = response.body()!!.musicCategories
                        writeToDatabase(mCategories)
                        createCollections(mCategories)
                        expListAdapter = ExpandableListViewAdapter(applicationContext, groupList, childList)
                        binding.catList.setAdapter(expListAdapter)
                    }
                }

                override fun onFailure(call: Call<MusicCategories>, t: Throwable) {
                    TODO("Not yet implemented")
                }
            })
        }
    }

    fun fetchDataFromDatabase(){
        db.child(currentUserId).addListenerForSingleValueEvent(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val mcList = mutableListOf<MusicCategory>()
                val favmList = mutableListOf<Music>()
                snapshot.children.forEach {
                    val mList = mutableListOf<Music>()
                    for (i in it.children){
                        val m: Music = Music(
                            i.child("baseCat").getValue(Int::class.java), i.child("title").getValue(String::class.java),
                            i.child("url").getValue(String::class.java), i.child("favourite").getValue(String::class.java))
                        if (m.favourite == "true"){
                            val favm = Music(m.baseCat, it.key!!.toString()+ "|" + m.title, m.url, m.favourite)
                            favmList.add(favm)
                        }
                        mList.add(m)
                    }
                    val mc: MusicCategory = MusicCategory(it.key!!, mList)
                    mcList.add(mc)
                }
                groupList.add(MusicCategory("Favourites", listOf()))
                childList[groupList[groupList.lastIndex]] = favmList
                for (mc in mcList){
                    if(mc.baseTitle != null){
                        groupList.add(mc)
                        val musics: MutableList<Music> = ArrayList()
                        for (music in mc.items){
                            musics.add(music)
                        }
                        childList[groupList[groupList.lastIndex]] = musics
                    }
                }
                expListAdapter = ExpandableListViewAdapter(applicationContext, groupList, childList)
                binding.catList.setAdapter(expListAdapter)
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }
}