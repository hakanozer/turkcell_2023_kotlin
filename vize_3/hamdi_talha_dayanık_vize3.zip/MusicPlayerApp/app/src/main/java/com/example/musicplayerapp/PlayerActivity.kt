package com.example.musicplayerapp

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.appcompat.app.AppCompatActivity
import com.example.musicplayerapp.databinding.ActivityPlayerBinding
import com.example.musicplayerapp.models.Music
import com.example.musicplayerapp.models.MusicCategory
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    lateinit var mediaPlayer: MediaPlayer
    var isPlaying: Boolean = true
    var selectedMusic: Music = MainActivity.selectedMusic
    var selectedCategory: MusicCategory = MainActivity.selectedCategory
    var volume = 50f

    lateinit var db: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.volumeBar.setProgress(volume.toInt())

        val sharedPref = getSharedPreferences("vol", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()

        if(!sharedPref.contains("vol")){
            editor.putString("vol", volume.toString()).commit()
        }else{
            volume = sharedPref.getString("vol", "")!!.toFloat()
            binding.volumeBar.setProgress(volume.toInt())
        }

        db = FirebaseDatabase.getInstance("https://music-player-app-3a98a-default-rtdb.europe-west1.firebasedatabase.app").getReference("Users")

        mediaPlayer = MediaPlayer.create(this, Uri.parse(selectedMusic.url!!.replace("http", "https")))
        mediaPlayer.setVolume((volume/100).toFloat(), (volume/100).toFloat())
        mediaPlayer.start()

        binding.categoryTitle.text = selectedCategory.baseTitle
        binding.musicTitle.text = selectedMusic.title

        if(selectedMusic.favourite == "true"){
            binding.favButton.setImageResource(R.drawable.baseline_favorite_50)
        }else{
            binding.favButton.setImageResource(R.drawable.baseline_favorite_border_50)
        }

        binding.volumeBar.setOnSeekBarChangeListener(object: OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                volume = progress.toFloat()
                mediaPlayer.setVolume(volume/100, volume/100)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                editor.putString("vol", volume.toString()).commit()
            }

        })

        binding.playButton.setOnClickListener {
            if (isPlaying){
                binding.playButton.setImageResource(R.drawable.baseline_play_arrow_50)
                mediaPlayer.pause()
                isPlaying = false
            }else{
                binding.playButton.setImageResource(R.drawable.baseline_pause_50)
                mediaPlayer.start()
                isPlaying = true
            }
        }

        binding.favButton.setOnClickListener {
            if (selectedCategory.baseTitle == "Favourites"){
                if (selectedMusic.favourite == "false"){
                    db.child(MainActivity.currentUserId).child(selectedMusic.title!!.replace(".", "").substringBefore("|"))
                        .child(selectedMusic.title!!.replace(".","").substringAfter("|")).child("favourite").setValue("true")
                    binding.favButton.setImageResource(R.drawable.baseline_favorite_50)
                    selectedMusic.favourite = "true"
                }else{
                    db.child(MainActivity.currentUserId).child(selectedMusic.title!!.replace(".", "").substringBefore("|"))
                        .child(selectedMusic.title!!.replace(".","").substringAfter("|")).child("favourite").setValue("false")
                    binding.favButton.setImageResource(R.drawable.baseline_favorite_border_50)
                    selectedMusic.favourite = "false"
                }
            }else{
                if (selectedMusic.favourite == "false"){
                    db.child(MainActivity.currentUserId).child(selectedCategory.baseTitle.replace(".", ""))
                        .child(selectedMusic.title!!.replace(".","")).child("favourite").setValue("true")
                    binding.favButton.setImageResource(R.drawable.baseline_favorite_50)
                    selectedMusic.favourite = "true"
                }else{
                    db.child(MainActivity.currentUserId).child(selectedCategory.baseTitle.replace(".", ""))
                        .child(selectedMusic.title!!.replace(".","")).child("favourite").setValue("false")
                    binding.favButton.setImageResource(R.drawable.baseline_favorite_border_50)
                    selectedMusic.favourite = "false"
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        mediaPlayer.release()
    }

}