package com.example.musicplayerapp.models

data class Music(
    val baseCat: Int?,
    val title: String?,
    val url: String?,
    var favourite: String? = "false"
)
