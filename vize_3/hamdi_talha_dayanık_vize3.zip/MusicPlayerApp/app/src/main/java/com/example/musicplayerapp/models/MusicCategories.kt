package com.example.musicplayerapp.models

data class MusicCategories(
    var musicCategories: List<MusicCategory>
)
