package com.example.musicplayerapp.models

data class MusicCategory(
    var baseTitle: String,
    var items: List<Music>
)
