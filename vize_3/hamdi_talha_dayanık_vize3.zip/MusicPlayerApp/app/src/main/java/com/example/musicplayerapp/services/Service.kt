package com.example.musicplayerapp.services

import com.example.musicplayerapp.models.MusicCategories
import com.example.musicplayerapp.models.MusicCategory
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET

interface Service {

    @GET("v1/f27fbefc-d775-4aee-8d65-30f76f1f7109")
    fun getCategories() : Call<MusicCategories>
}