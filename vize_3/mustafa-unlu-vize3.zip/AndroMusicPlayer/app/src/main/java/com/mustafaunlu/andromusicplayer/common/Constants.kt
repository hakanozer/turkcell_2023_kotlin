package com.mustafaunlu.andromusicplayer.common

object Constants {
    const val SHARED_PREF_FILE_NAME = "userData"
    const val SHARED_PREF_FAV_FILE_NAME = "FavoriteData"
    const val SHARED_PREF_IS_FIRST_KEY = "isFirstLogin"
    const val PARENT = 0
    const val CHILD = 1
}