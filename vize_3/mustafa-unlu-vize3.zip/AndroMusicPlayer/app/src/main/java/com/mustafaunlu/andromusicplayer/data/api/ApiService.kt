package com.mustafaunlu.andromusicplayer.data.api

import com.mustafaunlu.andromusicplayer.data.dto.Response
import retrofit2.http.GET

interface ApiService {
    @GET("v1/f27fbefc-d775-4aee-8d65-30f76f1f7109")
    suspend fun getMusicCategoriesFromApi(): Response
}
