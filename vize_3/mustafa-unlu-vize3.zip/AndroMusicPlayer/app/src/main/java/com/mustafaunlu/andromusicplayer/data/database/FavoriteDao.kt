package com.mustafaunlu.andromusicplayer.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic

@Dao
interface FavoriteDao {
    @Insert
    fun insertFavorite(music: FavoriteMusic)

    @Delete
    fun deleteFavorite(music: FavoriteMusic)

    @Query("SELECT * FROM favorite_music")
    fun getAllFavoriteMusic(): List<FavoriteMusic>
}
