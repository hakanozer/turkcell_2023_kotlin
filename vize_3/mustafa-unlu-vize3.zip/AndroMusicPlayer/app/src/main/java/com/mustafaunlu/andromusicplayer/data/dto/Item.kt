package com.mustafaunlu.andromusicplayer.data.dto


import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Item(
    @Json(name = "baseCat")
    val baseCat: Int = 0,
    @Json(name = "title")
    val title: String = "",
    @Json(name = "url")
    val url: String = "",
)