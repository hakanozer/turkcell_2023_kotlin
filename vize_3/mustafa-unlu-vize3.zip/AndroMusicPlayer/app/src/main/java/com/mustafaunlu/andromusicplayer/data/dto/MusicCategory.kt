package com.mustafaunlu.andromusicplayer.data.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MusicCategory(
    @Json(name = "baseTitle")
    val baseTitle: String = "",
    @Json(name = "items")
    val items: List<Item> = emptyList(),
)
