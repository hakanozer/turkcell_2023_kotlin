package com.mustafaunlu.andromusicplayer.data.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Response(
    @Json(name = "musicCategories")
    var musicCategories: List<MusicCategory> = emptyList(),
)
