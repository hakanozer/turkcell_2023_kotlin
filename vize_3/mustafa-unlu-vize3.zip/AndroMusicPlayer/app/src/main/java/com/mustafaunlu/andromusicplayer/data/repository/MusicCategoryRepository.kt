package com.mustafaunlu.andromusicplayer.data.repository

import com.mustafaunlu.andromusicplayer.common.NetworkResponse
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic
import com.mustafaunlu.andromusicplayer.data.dto.Item
import com.mustafaunlu.andromusicplayer.data.dto.MusicCategory
import com.mustafaunlu.andromusicplayer.data.dto.Response
import kotlinx.coroutines.flow.Flow

interface MusicCategoryRepository {
    fun getMusicCategoriesFromApi(): Flow<NetworkResponse<Response>>

    fun addMusicCategory(
        baseTitle: String,
        items: List<Item>,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    )

    fun getMusicCategoriesRealtime(
        onSuccess: (List<MusicCategory>) -> Unit,
        onFailure: (String) -> Unit,
    )

    suspend fun getAllFavoriteMusic(): List<FavoriteMusic>

    suspend fun addFavoriteMusic(favoriteMusic: FavoriteMusic)

    suspend fun deleteFavoriteMusic(favoriteMusic: FavoriteMusic)
}
