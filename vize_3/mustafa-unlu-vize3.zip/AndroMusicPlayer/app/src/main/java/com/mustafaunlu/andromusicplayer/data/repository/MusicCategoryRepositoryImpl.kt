package com.mustafaunlu.andromusicplayer.data.repository

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.mustafaunlu.andromusicplayer.common.NetworkResponse
import com.mustafaunlu.andromusicplayer.data.database.FavoriteDao
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic
import com.mustafaunlu.andromusicplayer.data.dto.Item
import com.mustafaunlu.andromusicplayer.data.dto.MusicCategory
import com.mustafaunlu.andromusicplayer.data.dto.Response
import com.mustafaunlu.andromusicplayer.data.source.RemoteDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class MusicCategoryRepositoryImpl @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    private val firestore: FirebaseFirestore,
    private val dao: FavoriteDao,

) : MusicCategoryRepository {
    private val collection = firestore.collection("music_categories")
    override fun getMusicCategoriesFromApi(): Flow<NetworkResponse<Response>> {
        return remoteDataSource.getMusicCategoriesFromApi().flowOn(Dispatchers.IO)
    }

    override fun addMusicCategory(
        baseTitle: String,
        items: List<Item>,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit,
    ) {
        val musicCategory = hashMapOf(
            "baseTitle" to baseTitle,
            "items" to items,
        )

        collection
            .add(musicCategory)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener {
                onFailure(it.localizedMessage ?: "Bir hata oluştu")
            }
    }

    override fun getMusicCategoriesRealtime(
        onSuccess: (List<MusicCategory>) -> Unit,
        onFailure: (String) -> Unit,
    ) {
        collection.addSnapshotListener { snapshot, error ->
            snapshotToList(snapshot) { onSuccess(it) }
            error?.let { onFailure(it.message.orEmpty()) }
        }
    }

    override suspend fun getAllFavoriteMusic(): List<FavoriteMusic> {
        return try {
            dao.getAllFavoriteMusic()
        } catch (e: Exception) {
            throw e
        }
    }

    override suspend fun addFavoriteMusic(favoriteMusic: FavoriteMusic) {
        dao.insertFavorite(favoriteMusic)
    }

    override suspend fun deleteFavoriteMusic(favoriteMusic: FavoriteMusic) {
        dao.deleteFavorite(favoriteMusic)
    }

    private fun snapshotToList(
        querySnapshot: QuerySnapshot?,
        list: (List<MusicCategory>) -> Unit,
    ) {
        val tempList = arrayListOf<MusicCategory>()

        querySnapshot?.let { snapshot ->
            for (document in snapshot.documents) {
                Log.d("TAG", "snapshotToList: ${document.data}")
                val baseTitle = document.getString("baseTitle") ?: ""
                val items = document.get("items") as? List<HashMap<String, Any>> ?: emptyList()
                val itemList = items.map { item ->
                    Item(
                        baseCat = item["baseCat"] as? Int ?: 0,
                        title = item["title"] as? String ?: "",
                        url = item["url"] as? String ?: "",
                    )
                }
                tempList.add(
                    MusicCategory(
                        baseTitle = baseTitle,
                        items = itemList,
                    ),
                )
            }

            list(tempList)
        }
    }
}
