package com.mustafaunlu.andromusicplayer.data.source

import com.mustafaunlu.andromusicplayer.common.NetworkResponse
import com.mustafaunlu.andromusicplayer.data.dto.Response
import kotlinx.coroutines.flow.Flow

interface RemoteDataSource {
    fun getMusicCategoriesFromApi(): Flow<NetworkResponse<Response>>
}