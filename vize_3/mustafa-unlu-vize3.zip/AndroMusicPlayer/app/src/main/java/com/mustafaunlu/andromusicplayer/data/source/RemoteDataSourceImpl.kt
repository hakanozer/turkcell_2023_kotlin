package com.mustafaunlu.andromusicplayer.data.source

import com.mustafaunlu.andromusicplayer.common.NetworkResponse
import com.mustafaunlu.andromusicplayer.data.api.ApiService
import com.mustafaunlu.andromusicplayer.data.dto.Response
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class RemoteDataSourceImpl @Inject constructor(private val apiService: ApiService) : RemoteDataSource {
    override fun getMusicCategoriesFromApi(): Flow<NetworkResponse<Response>> {
        return flow {
            emit(NetworkResponse.Loading)
            try {
                val response = apiService.getMusicCategoriesFromApi()
                emit(NetworkResponse.Success(response))
            } catch (e: Exception) {
                emit(NetworkResponse.Error(e))
            }
        }
    }
}
