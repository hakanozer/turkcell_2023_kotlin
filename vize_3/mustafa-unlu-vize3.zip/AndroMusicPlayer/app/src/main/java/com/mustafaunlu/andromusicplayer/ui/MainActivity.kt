package com.mustafaunlu.andromusicplayer.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import com.mustafaunlu.andromusicplayer.R
import com.mustafaunlu.andromusicplayer.ui.favorite.FavoriteFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.favorite, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.fragment_favorite -> {
                supportFragmentManager.commit {
                    replace(R.id.nav_host_fragment, FavoriteFragment())
                    addToBackStack("favorite")
                }
                true
            }

            else -> {
                super.onOptionsItemSelected(item)}
        }
    }
}
