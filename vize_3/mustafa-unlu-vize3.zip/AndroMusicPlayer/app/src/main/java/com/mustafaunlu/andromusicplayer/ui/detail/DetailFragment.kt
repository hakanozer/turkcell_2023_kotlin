package com.mustafaunlu.andromusicplayer.ui.detail

import android.content.SharedPreferences
import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.mustafaunlu.andromusicplayer.R
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic
import com.mustafaunlu.andromusicplayer.databinding.FragmentDetailBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class DetailFragment : Fragment() {
    private lateinit var binding: FragmentDetailBinding
    private val args by navArgs<DetailFragmentArgs>()
    private lateinit var mediaPlayer: MediaPlayer
    private val viewModel: DetailViewModel by viewModels()

    @Inject
    lateinit var sharedPref: SharedPreferences
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentDetailBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        playAudio(args.itemUrl)
        binding.apply {
            musicTitle.text = args.itemTitle
            playButton.setOnClickListener {
                playAudio(args.itemUrl)
            }

            pauseButton.setOnClickListener {
                pauseAudio()
            }

            setupSeekBar()

            favoriteButtonLogic()
        }
        val isFavorite = sharedPref.getBoolean(args.itemUrl, false)
        updateFavoriteButton(isFavorite)
    }

    private fun favoriteButtonLogic() {
        binding.addFavorite.setOnClickListener {
            val isFavorite = sharedPref.getBoolean(args.itemUrl, false)
            val editor = sharedPref.edit()
            editor.putBoolean(args.itemUrl, !isFavorite)
            editor.apply()

            updateFavoriteButton(!isFavorite)
        }
    }

    private fun updateFavoriteButton(isFavorite: Boolean) {
        if (isFavorite) {
            binding.addFavorite.setImageResource(R.drawable.ic_favorite_selected)
            viewModel.addFavoriteMusic(FavoriteMusic(title = args.itemTitle, url = args.itemUrl))
        } else {
            binding.addFavorite.setImageResource(R.drawable.ic_favorite)
            viewModel.deleteFavoriteMusic(FavoriteMusic(title = args.itemTitle, url = args.itemUrl))
        }
    }

    private fun setupSeekBar() {
        binding.apply {
            seekBar.max = 100
            seekBar.progress = 50
            seekBar.setOnSeekBarChangeListener(object :
                SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar,
                    progress: Int,
                    fromUser: Boolean,
                ) {
                    if (fromUser) {
                        val volumeNum = progress / 100.0f
                        mediaPlayer.setVolume(volumeNum, volumeNum)
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar) {}
                override fun onStopTrackingTouch(seekBar: SeekBar) {}
            })
        }
    }

    private fun pauseAudio() {
        if (this::mediaPlayer.isInitialized && mediaPlayer.isPlaying) {
            mediaPlayer.pause()
        }
    }

    private fun playAudio(audioUrl: String) {
        mediaPlayer = MediaPlayer()
        mediaPlayer.setDataSource(audioUrl)
        mediaPlayer.prepare()
        mediaPlayer.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (this::mediaPlayer.isInitialized) {
            mediaPlayer.stop()
            mediaPlayer.release()
        }
    }
}
