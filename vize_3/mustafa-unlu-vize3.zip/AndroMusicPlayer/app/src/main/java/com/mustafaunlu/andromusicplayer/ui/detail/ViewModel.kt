package com.mustafaunlu.andromusicplayer.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic
import com.mustafaunlu.andromusicplayer.data.repository.MusicCategoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: MusicCategoryRepository,
) : ViewModel() {
    private val _favMusic = MutableLiveData<List<FavoriteMusic>>()
    val favMusic: LiveData<List<FavoriteMusic>> = _favMusic

    fun getFavoriteMusic() {
        viewModelScope.launch(Dispatchers.IO) {
            val response = repository.getAllFavoriteMusic()
            _favMusic.postValue(response)
        }
    }

    fun addFavoriteMusic(music: FavoriteMusic) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addFavoriteMusic(music)
        }
    }

    fun deleteFavoriteMusic(music: FavoriteMusic) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFavoriteMusic(music)
        }
    }
}
