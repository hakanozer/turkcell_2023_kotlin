package com.mustafaunlu.andromusicplayer.ui.favorite

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic
import com.mustafaunlu.andromusicplayer.databinding.FavoriteItemBinding

class FavoriteAdapter(private val itemList: List<FavoriteMusic>, private val onItemClicked: (FavoriteMusic) -> Unit) : RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val binding = FavoriteItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoriteViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        holder.bind(itemList[position])
    }

    inner class FavoriteViewHolder(private val binding: FavoriteItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(favoriteMusic: FavoriteMusic) {
            binding.apply {
                favTv.text = favoriteMusic.title
                root.setOnClickListener {
                    onItemClicked(favoriteMusic)
                }
            }
        }
    }
}
