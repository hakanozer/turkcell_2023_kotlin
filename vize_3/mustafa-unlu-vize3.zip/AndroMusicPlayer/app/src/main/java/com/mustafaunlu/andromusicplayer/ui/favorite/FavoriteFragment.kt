package com.mustafaunlu.andromusicplayer.ui.favorite

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.mustafaunlu.andromusicplayer.data.dto.FavoriteMusic
import com.mustafaunlu.andromusicplayer.databinding.FragmentFavoriteBinding
import com.mustafaunlu.andromusicplayer.ui.detail.DetailViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FavoriteFragment : Fragment() {

    private lateinit var binding: FragmentFavoriteBinding
    private lateinit var adapter: FavoriteAdapter
    private val viewModel: DetailViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentFavoriteBinding.inflate(layoutInflater, container, false)
        viewModel.getFavoriteMusic()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.favMusic.observe(viewLifecycleOwner) { response ->
            binding.apply {
                adapter = FavoriteAdapter(response, ::onItemClicked)
                rvFavorite.adapter = adapter
            }
        }
    }

    private fun onItemClicked(favoriteMusic: FavoriteMusic) {
        // tiklayinca detaile gidilecek unutma yaz
    }
}
