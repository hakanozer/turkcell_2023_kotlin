package com.mustafaunlu.andromusicplayer.ui.home

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.mustafaunlu.andromusicplayer.common.Constants.SHARED_PREF_IS_FIRST_KEY
import com.mustafaunlu.andromusicplayer.common.NetworkResponse
import com.mustafaunlu.andromusicplayer.databinding.FragmentHomeBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding

    @Inject
    lateinit var sharedPref: SharedPreferences

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var adapter: ExpandableRecyclerViewAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentHomeBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val isFirstLogin = checkFirstLogin()

        if (isFirstLogin) {
            viewModel.getMusicCategoriesFromApiAndUploadToFirebase()
        } else {
            viewModel.getMusicCategoriesFromFirebase()
        }

        setObserver()
    }

    private fun setObserver() {
        viewModel.musicCategories.observe(viewLifecycleOwner) { response ->
            when (response) {
                is NetworkResponse.Success -> {
                    val musicCategories = response.result
                    val parentList = mutableListOf<ParentData>()
                    musicCategories.forEach { musicCategory ->
                        val parentData = ParentData()
                        parentData.parentTitle = musicCategory.baseTitle
                        parentData.subList = musicCategory.items.map { subCategory ->
                            ChildData(subCategory.title, subCategory.url)
                        }.toMutableList()
                        parentList.add(parentData)
                    }
                    adapter = ExpandableRecyclerViewAdapter(parentList, ::onClickedChildItem)
                    binding.rvHome.adapter = adapter
                }

                is NetworkResponse.Loading -> {
                    // Yükleme durumunda yapılacak işlemler
                }

                is NetworkResponse.Error -> {
                    // Hata durumunda yapılacak işlemle
                }
            }
        }
    }

    private fun onClickedChildItem(childData: ChildData) {
        val action = HomeFragmentDirections.actionHomeFragmentToDetailFragment(
            childData.childTitle,
            childData.url,
        )
        findNavController().navigate(action)
    }

    private fun checkFirstLogin(): Boolean {
        return sharedPref.getBoolean(SHARED_PREF_IS_FIRST_KEY, true)
    }
}
