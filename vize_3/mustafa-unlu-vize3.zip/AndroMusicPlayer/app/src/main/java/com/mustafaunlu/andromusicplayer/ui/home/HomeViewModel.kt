package com.mustafaunlu.andromusicplayer.ui.home

import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.material.snackbar.Snackbar
import com.mustafaunlu.andromusicplayer.common.Constants.SHARED_PREF_IS_FIRST_KEY
import com.mustafaunlu.andromusicplayer.common.NetworkResponse
import com.mustafaunlu.andromusicplayer.data.dto.MusicCategory
import com.mustafaunlu.andromusicplayer.data.repository.MusicCategoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: MusicCategoryRepository,
    private val sharedPreferences: SharedPreferences,
) : ViewModel() {

    private val _musicCategories = MutableLiveData<NetworkResponse<List<MusicCategory>>>()
    val musicCategories: LiveData<NetworkResponse<List<MusicCategory>>> = _musicCategories

    fun getMusicCategoriesFromApiAndUploadToFirebase() {
        viewModelScope.launch {
            repository.getMusicCategoriesFromApi().collectLatest { response ->
                when (response) {
                    is NetworkResponse.Success -> {
                        response.result.musicCategories.forEach {
                            repository.addMusicCategory(
                                it.baseTitle,
                                it.items,
                                {
                                },
                                {
                                },
                            )
                        }

                        sharedPreferences.edit().putBoolean(SHARED_PREF_IS_FIRST_KEY, false)
                            .apply()
                        getMusicCategoriesFromFirebase()
                    }

                    is NetworkResponse.Loading -> {
                        // Yükleme durumunda yapılacak işlemler
                    }

                    is NetworkResponse.Error -> {
                        // Hata durumunda yapılacak işlemler
                    }
                }
            }
        }
    }

    fun getMusicCategoriesFromFirebase() {
        viewModelScope.launch {
            repository.getMusicCategoriesRealtime(
                onSuccess = { musicCategories ->
                    _musicCategories.value = NetworkResponse.Success(musicCategories)
                },
                onFailure = { errorMessage ->

                },
            )
        }
    }
}
