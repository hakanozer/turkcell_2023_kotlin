package com.musicsapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.musicsapp.adapter.ContentAdapter
import com.musicsapp.databinding.FragmentFeedBinding
import com.musicsapp.model.MusicCategory
import com.musicsapp.viewmodel.FeedViewModel




class FeedFragment : Fragment() {
    private lateinit var binding: FragmentFeedBinding

    private lateinit var viewModel: FeedViewModel
    private val contentAdapter = ContentAdapter(arrayListOf())    //arraylistof boş öylesine verdim dolcak
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        binding = FragmentFeedBinding.inflate(inflater,container,false)

        val root: View = binding.root
        return root

    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {



        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this).get(FeedViewModel::class.java)
        viewModel.refreshData()

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = contentAdapter

        observeLiveData(contentAdapter)



    /* super.onViewCreated(view, savedInstanceState)



        viewModel = ViewModelProvider(this).get(FeedViewModel::class.java)
        viewModel.refreshData()

        binding.recyclerView.layoutManager= LinearLayoutManager(context)



        observeLiveData()
*/


    }


    private fun observeLiveData(contentAdapter: ContentAdapter){
        /*viewModel.categories.observe(viewLifecycleOwner, Observer {category ->
            category?.let {
                binding.recyclerView.visibility = View.VISIBLE
                contentAdapter.updateContentList(category)
                binding.recyclerView.adapter=ContentAdapter(it)
            }
        })

         */

        viewModel.categories.observe(viewLifecycleOwner, Observer { category ->
            category?.let {
                binding.recyclerView.visibility = View.VISIBLE
                contentAdapter.updateContentList(it.musicCategories)
                //binding.recyclerView.adapter = contentAdapter
            }
        })

    }


}