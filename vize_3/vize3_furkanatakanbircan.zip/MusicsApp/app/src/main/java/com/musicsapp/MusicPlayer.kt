package com.musicsapp

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaParser.SeekMap
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import java.net.URI
import java.net.URISyntaxException

class MusicPlayer : Fragment() {
    var secondUrl: String? = null
    var mediaPlayer: MediaPlayer? = null
    lateinit var volSeekBar :SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            secondUrl = MusicPlayerArgs.fromBundle(it).url
            Log.d("url", secondUrl!!)

            val uri = Uri.parse(secondUrl)
            mediaPlayer = MediaPlayer.create(activity, uri)
            mediaPlayer?.start()



            view?.let {
                volSeekBar = it.findViewById(R.id.valSeekBar)
                mediaPlayer!!.setVolume(0.5f,0.5f)
                volSeekBar.progress = 50
                volSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {

                        val f1 =p1.toFloat()/100
                        mediaPlayer!!.setVolume(f1,f1)

                    }

                    override fun onStartTrackingTouch(p0: SeekBar?) {

                    }

                    override fun onStopTrackingTouch(p0: SeekBar?) {

                    }

                })


            }

        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment


        return inflater.inflate(R.layout.fragment_music_player, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)




        }








    }




