package com.musicsapp.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.musicsapp.R
import com.musicsapp.databinding.ItemTitleRowBinding
import com.musicsapp.model.MusicCategory


class ContentAdapter(var categoryList : ArrayList<MusicCategory>): RecyclerView.Adapter<ContentAdapter.ContentViewHolder>() {
    lateinit var context: Context
    class ContentViewHolder(var view :View) :RecyclerView.ViewHolder(view){
        val binding = ItemTitleRowBinding.bind(itemView)
        val txtCategory :TextView = view.findViewById(R.id.txtCategory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContentViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_title_row,parent,false)
        context= parent.context
        return ContentViewHolder(view)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: ContentViewHolder, position: Int) {
        holder.txtCategory.text = categoryList[position].baseTitle
        val subItemAdapter = SubItemAdapter(categoryList[position].items)
        holder.binding.rvSubItem.adapter = subItemAdapter
        holder.binding.rvSubItem.layoutManager = LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false)
        holder.txtCategory.setOnClickListener {     //ana kategorideki item a tıklayınca ne olacağını buraya yazdık

            holder.binding.rvSubItem.visibility = if (holder.binding.rvSubItem.isShown) View.GONE  else View.VISIBLE
            if (holder.binding.rvSubItem.isShown) holder.txtCategory.setTextColor(ContextCompat.getColor(context, R.color.select_color))
            else holder.txtCategory.setTextColor(Color.BLACK)
        }


    }

    fun updateContentList(newCategoryList: List<MusicCategory>){
        categoryList.clear()
        categoryList.addAll(newCategoryList)
        notifyDataSetChanged()
    }


}