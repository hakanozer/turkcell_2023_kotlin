package com.musicsapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.musicsapp.FeedFragment
import com.musicsapp.FeedFragmentDirections
import com.musicsapp.R
import com.musicsapp.databinding.SubListItemBinding
import com.musicsapp.model.Item

class SubItemAdapter(private val subItemModel: List<Item>) :
    RecyclerView.Adapter<SubItemAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val binding = SubListItemBinding.bind(itemView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.sub_list_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            txtSubItemTitle.text= subItemModel[position].title
        }
        holder.binding.txtSubItemTitle.setOnClickListener {
            val action = FeedFragmentDirections.actionFeedFragmentToMusicPlayer(subItemModel[position].url)
            Navigation.findNavController(it).navigate(action)

        }
    }

    override fun getItemCount() = subItemModel.size
}