package com.musicsapp.model

data class Contents (
    val musicCategories: List<MusicCategory>
)

data class MusicCategory (
    val baseTitle: String,
    val items: List<Item>
)

data class Item (
    val baseCat: Long,
    val title: String,
    val url: String
)


