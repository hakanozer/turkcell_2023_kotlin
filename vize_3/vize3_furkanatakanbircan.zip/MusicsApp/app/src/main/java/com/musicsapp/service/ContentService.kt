package com.musicsapp.service

import com.musicsapp.model.Contents
import io.reactivex.Single
import retrofit2.http.GET

interface ContentService {
    @GET("f27fbefc-d775-4aee-8d65-30f76f1f7109")
    fun getContent(): Single<Contents>  //single bir defa alıyor observable süreklilik veriyordu firebase kaydetcez ve ordan alcaz sonrasında
}