package com.musicsapp.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.musicsapp.model.Contents
import com.musicsapp.model.Item
import com.musicsapp.model.MusicCategory
import com.musicsapp.service.ContentService
import com.musicsapp.util.ApiClient
import com.musicsapp.util.CustomSharedPreferences
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.launch
import java.util.*

class FeedViewModel(application: Application): BaseViewModel(application) {

    lateinit var shared:SharedPreferences
    lateinit var contentService: ContentService
    private val disposable=CompositeDisposable()
    private var customSharedPreferences = CustomSharedPreferences(getApplication())

    val categories = MutableLiveData<Contents>()  
    val database = FirebaseDatabase.getInstance("https://trkcllvize3-default-rtdb.europe-west1.firebasedatabase.app")

    fun refreshData(){

            getDataFromAPI()



    }

    private fun getDataFromAPI(){
        contentService= ApiClient.getClient().create(ContentService::class.java)


        disposable.add(
            contentService.getContent()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object : DisposableSingleObserver<Contents>(){
                    override fun onSuccess(t: Contents) {
                        categories.value=t

                        storeInFirebase(t)
                    }

                    override fun onError(e: Throwable) {
                        e.printStackTrace()
                    }


                })
        )


    }

    fun getDataFromFirebaseDatabase(){
        //val musicCategory = MusicCategory()
            launch {
                var getData = object : ValueEventListener {

                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        val baseTitle = dataSnapshot.child("baseTitle").value as String
                        val itemsList = mutableListOf<Item>()

                        for (snapshot in dataSnapshot.child("items").children) {
                            val basecat = snapshot.child("basecat").value as Long
                            val title = snapshot.child("title").value as String
                            val url = snapshot.child("url").value as String

                            val musicItem = Item(basecat, title, url)
                            itemsList.add(musicItem)
                        }

                        val musicCategory = MusicCategory(baseTitle, itemsList)
                       // val contents = Contents(MusicCategory)
                        with(categories){

                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        TODO("Not yet implemented")
                    }


                }

            }


    }
    private fun showContents(contents: Contents){
        categories.value=contents
    }

    private fun storeInFirebase(contents: Contents){
        launch {
            for (iterator in contents.musicCategories) {
                val categoryId = UUID.randomUUID().toString()
                val rootNode = database.reference.child("musicCategories").child(categoryId)
                rootNode.child("baseTitle").setValue(iterator.baseTitle)
                val itemNode =rootNode.child("items")
                //firebaseRef.setValue(item)

                for (i in iterator.items) {
                    val itemId = UUID.randomUUID().toString()
                    val itemChildNode = itemNode.child(itemId)
                    itemChildNode.child("basecat").setValue(i.baseCat)
                    itemChildNode.child("title").setValue(i.title)
                    itemChildNode.child("url").setValue(i.url)

                }//shared prefernces burda true ya döndürcem

            }
        }

    }


}
